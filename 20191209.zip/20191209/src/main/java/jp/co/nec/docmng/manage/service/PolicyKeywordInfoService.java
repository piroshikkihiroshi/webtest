package jp.co.nec.docmng.manage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.manage.entity.PolicyKeywordInfo;
import jp.co.nec.docmng.manage.util.map.PolicyKeywordInfoMapManage;

@Service
public class PolicyKeywordInfoService {

    @Autowired
    private PolicyKeywordInfoMapManage policyKeywordMapper;

    @Transactional
    public List<PolicyKeywordInfo> findAll(){
        List<PolicyKeywordInfo> entityList = policyKeywordMapper.findAll();
        return entityList;
    }

    public void deleteKeyWord(Integer policyId) {
        policyKeywordMapper.deleteKeyWord(policyId);
    }

}
