package jp.co.nec.docmng.blackPaint.entity;

import java.util.Date;

public class PolicyKeywordInfoBlackPaint {


    public Integer getPolicyId() {
		return policy_id;
	}
	public void setPolicyId(Integer policy_id) {
		this.policy_id = policy_id;
	}
	public String getPolicyKeyword() {
		return policy_keyword;
	}
	public void setPolicyKeyword(String policy_keyword) {
		this.policy_keyword = policy_keyword;
	}
	public Date getCreateTime() {
		return create_time;
	}
	public void setCreateTime(Date create_time) {
		this.create_time = create_time;
	}
	public Date getUpdateTime() {
		return update_time;
	}
	public void setUpdateTime(Date update_time) {
		this.update_time = update_time;
	}
	private Integer policy_id;
    private String policy_keyword;
    private Date create_time;
    private Date update_time;


}