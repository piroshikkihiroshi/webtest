package jp.co.nec.docmng.blackPaint.entity;

public class CategoryEntPaint {

	public int getCategory_id() {
		return categoryId;
	}
	public void setCategory_id(int category_id) {
		this.categoryId = category_id;
	}
	public String getCategory_name() {
		return categoryName;
	}
	public void setCategory_name(String category_name) {
		this.categoryName = category_name;
	}
	public String getCategory_author() {
		return categoryAuthor;
	}
	public void setCategory_author(String category_author) {
		this.categoryAuthor = category_author;
	}
	private int categoryId;
	private String categoryName;
	private String categoryAuthor;

}
