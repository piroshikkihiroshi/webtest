// To use this code, add the following Maven dependency to your project:
//
//     com.fasterxml.jackson.core : jackson-databind : 2.9.0
//
// Import this package:
//
//     import jp.co.nec.docmng.blackPaint.entity.procenter.PrcenterConvert;
//
// Then you can deserialize a JSON string with
//
//     ProcenterEnt data = PrcenterConvert.fromJsonString(jsonString);

package jp.co.nec.docmng.blackPaint.entity.procenter;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.databind.ObjectWriter;

public class PrcenterConvert {
    // Serialize/deserialize helpers


    public static ProcenterEnt fromJsonString(String json) throws IOException {
        return getObjectReader().readValue(json);
    }

    public static String toJsonString(ProcenterEnt obj) throws JsonProcessingException {
        return getObjectWriter().writeValueAsString(obj);
    }

    private static ObjectReader reader;
    private static ObjectWriter writer;

    @SuppressWarnings("deprecation")
	private static void instantiateMapper() {
        ObjectMapper mapper = new ObjectMapper();
        reader = mapper.reader(ProcenterEnt.class);
        writer = mapper.writerFor(ProcenterEnt.class);
    }

    private static ObjectReader getObjectReader() {
        if (reader == null) instantiateMapper();
        return reader;
    }

    private static ObjectWriter getObjectWriter() {
        if (writer == null) instantiateMapper();
        return writer;
    }
} //class
