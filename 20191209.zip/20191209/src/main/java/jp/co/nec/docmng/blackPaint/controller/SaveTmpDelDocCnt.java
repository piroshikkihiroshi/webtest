/**
 * 名称：SaveTmpDocCnt.java
 * 機能名：一時保存Control
 * 概要：一時保存機能のControlを行う。
 */

package jp.co.nec.docmng.blackPaint.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.blackPaint.logic.dirFile.DirCnt;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocTmpMarkerService;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocumentService;

/**
 * 一時保存機能のControlを行う。
 */
@RestController
public class SaveTmpDelDocCnt {

	/**
	 * objLog log出力に使用する
	 */
	@Autowired
	ServletContext context;
	@Autowired
	TmpMaskDocumentService tmpMaskDocumentService;
	@Autowired
	TmpMaskDocTmpMarkerService tmpMaskDocTmpMarkerService;

	static Logger objLog = LoggerFactory.getLogger(SaveTmpDelDocCnt.class);

	/**
	 * 一時保存メソッド
	 * 一時保存を押下したときの処理制御をする。
	 * @param strHashJson 以下の値を入れ込んだjsonString
	 * strTmpDir 黒塗り編集画面で処理したHTMLが格納されたTMPディレクトリ名。
	 * strRedHtml 黒塗り編集候補HTMLのouterHTML。
	 * strMaskHtml 黒塗り編集HTMLのouterHTML。
	 * strFileName オリジナルwordファイル名。
	 * documentId ドキュメントID
	 */
	@ResponseBody
	@PostMapping("/blackpaint/SaveTmpDelDocCnt")
	@ResponseStatus(HttpStatus.OK)
	public String SaveTmpDocCntRest(
			@RequestBody String strHashJson,
			@CookieValue(value = "user_id", required = false) String UserId,
			Model model) {

		//メンバ変数初期化
		int intDocumentId = -1; //documentId


		//POSTされたjsonをパースする
		ObjectMapper objMapper = new ObjectMapper();
		List<Map<String, String[]>> objTmpList = null;
		TypeReference<List<Map<String, String[]>>> objType = new TypeReference<List<Map<String, String[]>>>() {
		};
		try {
			objTmpList = objMapper.readValue(strHashJson, objType);
		} catch (JsonParseException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} catch (JsonMappingException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} catch (IOException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} //try

		HashMap<String, String[]> objMap = (HashMap<String, String[]>) objTmpList.get(0);

		for (String strKey : objMap.keySet()) {
			switch (strKey) {
			case "documentId":
				intDocumentId = Integer.parseInt(objMap.get(strKey)[0]);
				break;
			default:
				break;
			}//switch

		} //for

		//DB削除処理
		try {
			//markerTable
			tmpMaskDocTmpMarkerService.deleteTmpMarkerDoc(intDocumentId, UserId);

			//tmp_mask_documentテーブル対象削除
			tmpMaskDocumentService.deleteTmpDoc(intDocumentId, UserId);

		} catch (Exception e) {
			objLog.error("err message", e);
			System.err.println(e);
		} //try

		return "200";
	} //getView1

	/**
	 * エラー画面遷移(黒塗り処理)
	 */
	@ExceptionHandler(Exception.class)
	public String handleException(
			Exception e,
			HttpServletRequest request,
			HttpServletResponse response,
			Model model
			){


		//モデル初期化
		DirCnt objDirCls = new DirCnt();
		Cookie cookie[] = request.getCookies();
		String strTmpDir_i = "";
		if (cookie != null){
			for (int i = 0 ; i < cookie.length ; i++){
				if (cookie[i].getName().equals("strTmpDirName")){
					strTmpDir_i = cookie[i].getValue();
				} //if
			} //for
		} //if

		//作業ディレクトリかたずけ
		if(strTmpDir_i.equals(""))  {
			objLog.info("作業ディレクトリの取得が失敗しました");
		}else {
			try {
				//作業ディレクトリ,ファイルかたづけ
				objDirCls.DelDirctory(context.getRealPath("/") + strTmpDir_i);
				objLog.info("作業ディレクトリ削除完了");
			} catch (Exception e1) {
				objLog.info("作業ディレクトリ削除失敗");
			} //try

		} //if


		response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		objLog.error("Error occurred.", e);
		StringWriter objSw = new StringWriter();
		PrintWriter objPw = new PrintWriter(objSw);
		e.printStackTrace(objPw);
		objPw.flush();
		String strError = objSw.toString();
		model.addAttribute("errorMessage", e.getMessage() + "\r\n" + "StackTrace" + "\r\n" + strError) ;


		return "blackPaint/Fail";
	} //method

} //MaskHtmlCnt
