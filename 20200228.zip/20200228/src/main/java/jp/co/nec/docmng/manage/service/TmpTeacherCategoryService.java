/**
 * 名称：TmpTeacherCategoryService.java
 * 機能名：管理系教師データ(分類)登録画面一時保存情報連携
 * 概要：管理系にて使用する教師データ(分類)登録画面一時保存情報への連携用サービス
 */

package jp.co.nec.docmng.manage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.manage.entity.TmpTeacherCategoryList;
import jp.co.nec.docmng.manage.util.map.TmpTeacherCategoryListMapManage;

/**
 * 管理系教師データ(分類)登録画面一時保存情報連携
 */
@Service
public class TmpTeacherCategoryService {

    @Autowired
    private TmpTeacherCategoryListMapManage tmpTeacherCategoryListMapper;

	/**
	 * 全件取得
	 * @return 検索結果
	 */
    @Transactional
    public List<TmpTeacherCategoryList> findAll(){
        List<TmpTeacherCategoryList> entityList = tmpTeacherCategoryListMapper.findAll();
        return entityList;
    }

	/**
	 * データ取得_カテゴリー指定
	 * @param categoryId カテゴリーID
	 * @return 検索結果
	 */
    @Transactional
    public List<TmpTeacherCategoryList> findCategoryId(Integer categoryId){
        List<TmpTeacherCategoryList> entityList = tmpTeacherCategoryListMapper.findCategoryId(categoryId);
        return entityList;
    }

	/**
	 * データ登録
	 * @param tmpTeacherCategoryList 登録情報
	 */
    @Transactional
    public void updateCategoryId(TmpTeacherCategoryList tmpTeacherCategoryList){
        tmpTeacherCategoryListMapper.updateCategoryId(tmpTeacherCategoryList);
    }

	/**
	 * データ更新_プライマリキー指定
	 * @param tmpTeacherCategoryList 更新情報
	 */
    @Transactional
    public void insert(TmpTeacherCategoryList tmpTeacherCategoryList) {
        tmpTeacherCategoryListMapper.insertReflect(tmpTeacherCategoryList);
    }

    /**
     * 全削除実施
     */
    @Transactional
    public void deleteAll() {
        tmpTeacherCategoryListMapper.deleteAll();
    }

}
