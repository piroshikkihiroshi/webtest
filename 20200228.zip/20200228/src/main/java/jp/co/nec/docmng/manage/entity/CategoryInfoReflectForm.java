/**
 * 名称：CategoryInfoReflectForm.java
 * 機能名：
 * 概要：
 */

package jp.co.nec.docmng.manage.entity;

import java.util.List;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * 
 */
@JsonInclude
public class CategoryInfoReflectForm {
    private List<AddValues> addValues;
    private List<ChangedValues> changedValues;
    private List<Integer> deleteRow;

	/**
	 * addValues getter
	 * @return addValues
	 */
    public List<AddValues> getAddValues() {
        return addValues;
    }

	/**
	 * addValues setter
	 * @param addValues
	 */
    public void setAddValues(List<AddValues> addValues) {
        this.addValues = addValues;
    }

	/**
	 * changedValues getter
	 * @return changedValues
	 */
    public List<ChangedValues> getChangedValues() {
        return changedValues;
    }

	/**
	 * changedValues setter
	 * @param changedValues
	 */
    public void setChangedValues(List<ChangedValues> changedValues) {
        this.changedValues = changedValues;
    }

	/**
	 * deleteRow getter
	 * @return deleteRow
	 */
    public List<Integer> getDeleteRow() {
        return deleteRow;
    }

	/**
	 * deleteRow setter
	 * @param deleteRow
	 */
    public void setDeleteRow(List<Integer> deleteRow) {
        this.deleteRow = deleteRow;
    }

    /**
     * 
     */
    public static class AddValues {
        @NotBlank(message = "必須項目です。")
        private String categoryName;
        @NotBlank(message = "必須項目です。")
        private String categoryAuthor;

        /**
         * categoryName getter
         * @return categoryName
         */
        public String getCategoryName() {
            return categoryName;
        }

        /**
         * categoryName setter
         * @param categoryName
         */
        public void setCategoryName(String categoryName) {
            this.categoryName = categoryName;
        }

        /**
         * categoryAuthor getter
         * @return categoryAuthor
         */
        public String getCategoryAuthor() {
            return categoryAuthor;
        }

        /**
         * categoryAuthor setter
         * @param categoryAuthor
         */
        public void setCategoryAuthor(String categoryAuthor) {
            this.categoryAuthor = categoryAuthor;
        }
    }

    /**
     * 
     */
    public static class ChangedValues {
        @NotBlank(message = "必須項目です。")
        private Integer categoryId;
        @NotBlank(message = "必須項目です。")
        private String categoryName;

        /**
         * categoryId getter
         * @return categoryId
         */
        public Integer getCategoryId() {
            return categoryId;
        }

        /**
         * categoryId setter
         * @param categoryId
         */
        public void setCategoryId(Integer categoryId) {
            this.categoryId = categoryId;
        }

        /**
         * categoryName getter
         * @return categoryName
         */
        public String getCategoryName() {
            return categoryName;
        }

        /**
         * categoryName setter
         * @param categoryName
         */
        public void setCategoryName(String categoryName) {
            this.categoryName = categoryName;
        }


    }

}


