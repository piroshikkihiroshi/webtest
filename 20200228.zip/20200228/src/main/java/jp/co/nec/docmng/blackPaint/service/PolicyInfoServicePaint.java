/**
 * 名称：PolicyInfoServicePaint.java
 * 機能名：黒塗り処理ポリシー情報連携
 * 概要：黒塗り処理にて使用するポリシー情報への連携用サービス
 */

package jp.co.nec.docmng.blackPaint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.blackPaint.entity.PolicyInfoEntBlackPaint;
import jp.co.nec.docmng.blackPaint.repository.PolicyInfoMapPaint;

/**
 * 黒塗り処理ポリシー情報連携
 */
@Service
public class PolicyInfoServicePaint {

	@Autowired
	private  PolicyInfoMapPaint objPolicyInfoMapper;

	/**
	 * 全件取得
	 * @return 検索結果
	 */
	@Transactional
	public List<PolicyInfoEntBlackPaint> findAll() {
		// 全件
		return objPolicyInfoMapper.findAll();
	} //findAll

} //PolicyInfoServiceApi
