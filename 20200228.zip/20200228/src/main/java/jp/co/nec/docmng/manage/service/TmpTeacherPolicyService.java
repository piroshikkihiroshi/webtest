/**
 * 名称：TmpTeacherPolicyService.java
 * 機能名：管理系教師データ(黒塗り箇所摘出)登録画面一時保存情報連携
 * 概要：管理系にて使用する教師データ(黒塗り箇所摘出)登録画面一時保存情報への連携用サービス
 */

package jp.co.nec.docmng.manage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.manage.entity.TmpTeacherPolicyList;
import jp.co.nec.docmng.manage.util.map.TmpTeacherPolicyListMapManage;

/**
 * 管理系教師データ(黒塗り箇所摘出)登録画面一時保存情報連携
 */
@Service
public class TmpTeacherPolicyService {

    @Autowired
    private TmpTeacherPolicyListMapManage tmpTeacherPolicyListMapper;

	/**
	 * 全件取得
	 * @return 検索結果
	 */
    @Transactional
    public List<TmpTeacherPolicyList> findAll(){
        List<TmpTeacherPolicyList> entityList = tmpTeacherPolicyListMapper.findAll();
        return entityList;
    }

    /**
     * 全削除実施
     */
    @Transactional
    public void deleteAll(){
        tmpTeacherPolicyListMapper.deleteAll();
    }

    /**
     * 登録処理
	 * @param tmpTeacherPolicyList 登録情報
     */
    @Transactional
    public void insert(TmpTeacherPolicyList tmpTeacherPolicyList){
        tmpTeacherPolicyListMapper.insertTmpPolicy(tmpTeacherPolicyList);
    }

    /**
     * その他ポリシーで更新する
	 * @param tmpTeacherPolicyList 更新情報
     */
    @Transactional
    public void updateOther(TmpTeacherPolicyList tmpTeacherPolicyList){
        tmpTeacherPolicyListMapper.updateOther(tmpTeacherPolicyList);
    }

    /**
     * ポリシーIDに一致する一覧を返す
	 * @param policyId ポリシーID
     * @return 検索結果
     */
    public List<TmpTeacherPolicyList> findPolicyId(Integer policyId) {
        List<TmpTeacherPolicyList> list = tmpTeacherPolicyListMapper.findPolicyId(policyId);
        return list;
    }

}
