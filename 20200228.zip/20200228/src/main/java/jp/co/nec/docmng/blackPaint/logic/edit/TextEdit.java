/**
 * 名称：TextEdit.java
 * 機能名：Textファイル 黒塗り文書作成画面初期表示メソッド
 * 概要：Textファイルを黒塗り文書作成画面に初期表示する
 */

package jp.co.nec.docmng.blackPaint.logic.edit;

import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletContext;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;

import jp.co.nec.docmng.blackPaint.controller.MaskHtmlCnt;
import jp.co.nec.docmng.blackPaint.entity.DocumentInfoEntPaint;
import jp.co.nec.docmng.blackPaint.logic.Aspose.AsposeWordModel;
import jp.co.nec.docmng.blackPaint.logic.dirFile.DirCnt;
import jp.co.nec.docmng.blackPaint.logic.dirFile.FileCnt;
import jp.co.nec.docmng.blackPaint.logic.maskHtml.AiDataSelect;
import jp.co.nec.docmng.blackPaint.logic.maskHtml.HtmlStructure;
import jp.co.nec.docmng.blackPaint.logic.maskHtml.MaskHtmlModel;
import jp.co.nec.docmng.blackPaint.service.DocInfoServicePaint;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocMarkerServicePaint;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocumentServicePaint;
import jp.co.nec.docmng.library.blackprintextract.entity.BlackPrintPlace;
import jp.co.nec.docmng.library.blackprintextract.service.BlackPrintExtract;

/**
 * Textファイル 黒塗り文書作成画面初期表示メソッド
 */
public class TextEdit {
    static Logger objLog = LoggerFactory.getLogger(MaskHtmlCnt.class);

    @Autowired
    ServletContext context;
    @Autowired DocInfoServicePaint docInfoService;

    @Autowired
    TmpMaskDocMarkerServicePaint tmpMaskDocTmpMarkerService;

    @Autowired
    TmpMaskDocumentServicePaint tmpMaskDocumentService;

    HashMap<String, String> hashMap = new HashMap<String,String>();

    /**
     * 黒塗り文書作成画面初期表示メソッド
     * 画面初期表示の処理をする。
     * @param listDoc 文書情報から取得したデータのリスト
     * @param strTmpDir ファイル作成用フォルダパス
     * @param resourceLoader ResourceLoader
     * @param status 空文字: 初期処理 1: 再開 2: 黒塗りリスト確定
     * @param policySelect 選択黒塗りポリシーID
     * @return 
     */
    public HashMap<String,String> textEditMain(
            List<DocumentInfoEntPaint> listDoc,
            String strTmpDir,
            ResourceLoader resourceLoader,
            String status,//空文字: 初期処理 1: 再開 2: 黒塗りリスト確定
            String policySelect

            ) {

        int documentId = listDoc.get(0).getDocumentId();


        String aiData = ""; //aiが返すデータ

        String strHeight = "785"; //word A4の時 他は未考慮
//        int insPageLen = 1942; //txtのページの長さ(1行54文字、36行想定)-2
		int insPageLen = 1888; //txtのページの長さ(1行54文字、35行想定)-2 //マスク箇所のbadge対応の為marginをいれ1行減らした

        FileCnt objFileCnt = new FileCnt();
        AsposeWordModel objAspCls = new AsposeWordModel();
        MaskHtmlModel  objMaskCls = new MaskHtmlModel();
        DirCnt objDirCls = new DirCnt();



        String strHtmlName = documentId + ".html"; //作成html名
        String strHtmlPath = strTmpDir + documentId + ".html"; //作成htmlパス

        String strStyle = ""; //CSSを作成する
        strStyle+="<style>";
        strStyle+=".tagRed{";
        strStyle+="    color: rgb(233, 84, 84);";
        strStyle+="    display: inline-grid;";
        strStyle+="    overflow: hidden;";
//        strStyle+="    background-color: #ffff7b;";
        strStyle+="}";
        strStyle+=".tagRng{";
        strStyle+="    color: rgb(233, 87, 51);";
        strStyle+="    background-color: rgba(159, 192, 230, 0.884);";
        strStyle+="}";
        strStyle+=".tagMsk{";
        strStyle+="    color: black;";
            strStyle+="    word-break: break-all;";

            strStyle+="    line-height: 1.2;";
            strStyle+="    width: 97%;";
            strStyle+="    text-align: justify;";
            strStyle+="    background-color: black;";
            strStyle+="    display: inline-grid;";
            strStyle+="    overflow: hidden;";

        strStyle+="}";
        strStyle+=".awpage {";
        strStyle+="    position: relative;";
        strStyle+="    border: none;";
        strStyle+="    margin: 0px;";
        strStyle+="}";
        strStyle+=".redimg{";
        strStyle+="    -webkit-filter: sepia(100%)  hue-rotate(300deg); ";
        strStyle+="    -moz-filter: sepia(100%)  hue-rotate(300deg);";
        strStyle+="    -o-filter: sepia(100%)  hue-rotate(300deg);";
        strStyle+="    -ms-filter: sepia(100%)  hue-rotate(300deg);";
        strStyle+="    filter: sepia(100%)  hue-rotate(300deg);";
        strStyle+="}";

        //badge対応
        strStyle+=".redNumber {";
        strStyle+="	   position: absolute;";
        strStyle+="	   z-index: 1000;";
        strStyle+="	   padding: 1px;";
        strStyle+="    font-size: 10.5px;";
        strStyle+="	   background-color: #fff;";
        strStyle+="	   background-clip: padding-box;";
        strStyle+="	   border: 1px solid rgba(0,0,0,.2);";
        strStyle+="	   border-radius: 10rem;";

        strStyle+="    font-family: \"VL Gothic\";";
        strStyle+="    color: black;";
        strStyle+="    font-style: normal;";
        strStyle+="}";
        strStyle+=" .redNumber:hover {";
        strStyle+="    opacity: 0.0;";
        strStyle+="}";
        strStyle+=" .redHidden {";
        strStyle+="  visibility: hidden;";
        strStyle+="}";
        strStyle+=".mskNumber {";
        strStyle+="	    display: none;";
        strStyle+="}";
        strStyle+="</style>";

        FileWriter objFile=null;
        String[] arrMask=null;
        String[] arrRed=null;

        //全文検索モックデータ コロン区切りでペアは+区切り intpos,そこからつづく,intpos,そこからつづく
        String strTestData = aiData;
        String strAllHtml = "";
        String strOrgBody = "";
        String strNotTagBody = "";
        String strRepBody = "";
        String strMaskHtml= "";
        String strRedHtml = "";
        int intPageCnt = 0;
        String strEditMarker = "";


        objLog.info("txt処理開始");
        try {
            //出力フォルダ作成
            objDirCls.makeDirWithCheck(strTmpDir);
            objDirCls.makeDirWithCheck(strTmpDir + documentId);
            //動的templateを作成
            String strOutHtml = "";
            strOutHtml+="<body>";
            strOutHtml+=listDoc.get(0).getDocumentContents();
            strOutHtml+="</body>";

            //全文検索エンジンに渡す用の文字列を取得する
            strNotTagBody=listDoc.get(0).getDocumentContents();

//			※※※※※※※検索エンジンに送付※※※※※※※

            //AIdata
            BlackPrintExtract objAiCls  = new BlackPrintExtract();
            //aiDatalist
//			if (status.equals("")) { //初期処理時のみ
                List<BlackPrintPlace> listAi = null;
                try {
                    listAi = objAiCls.extractBlackPrintPlace(documentId);
                    BlackPrintPlace tmpPrintPlace = null;
                    aiData = "";
                    for (int i = 0; i < listAi.size(); i++) {
                        tmpPrintPlace = listAi.get(i);
                        aiData+=tmpPrintPlace.start + ":" + tmpPrintPlace.end + ":" + tmpPrintPlace.policyID + "+";
                    } //for
                    aiData = aiData.substring(0,aiData.length()-1);
                } catch (Exception e2) {
                    aiData="";
                    objLog.info("AIデータ取得処理でエラーが発生したため、取得したHTMLをそのまま表示");
                    objLog.error( "err message", e2 );
                    e2.printStackTrace();
                } //try
//			} //if


            if(aiData==null) aiData="";

            //debug
//			aiData="43:46:1+48:49:1+51:54:1+346:349:1+359:360:1+432:435:1+437:440:1+443:444:1+498:501:1+503:504:1+630:633:1+750:753:1+854:859:1+861:862:1+864:869:1+882:883:1+886:887:1+895:896:1+905:907:1+929:934:1+994:996:1+1079:1084:1+1166:1170:1+1198:1201:1";
//			aiData="10:11:1+39:48:1+53:66:1+81:85:1+98:102:1+104:109:1+184:187:1+327:328:1";
//			aiData="1:4:1+23:24:1";
//			aiData="1:6:1+12:13:1+37:38:1+65:66:1+68:71:1+73:74:1+80:82:1+107:108:1+145:147:1+178:179:1+181:183:1+234:235:1+252:252:1+259:260:1+279:284:1+286:292:1+297:309:1+319:322:1+324:325:1+343:344:1+359:360:1+380:381:1+395:483:1+484:485:1+487:490:1+504:505:1+545:546:1+591:593:1+603:680:1+684:687:1+690:696:1+698:702:1+710:711:1+721:727:1+746:752:1+754:755:1+774:809:1+813:813:1+838:839:1+847:850:1+855:858:1+861:862:1+886:887:1+889:892:1+894:895:1+898:900:1+902:906:1+922:925:1+980:981:1+990:1087:1+1099:1100:1+1106:1107:1+1109:1112:1+1117:1120:1+1123:1125:1+1160:1163:1+1192:1193:1+1211:1212:1+1227:1230:1+1278:1279:1+1281:1286:1+1291:1294:1+1297:1299:1+1309:1310:1+1343:1344:1+1346:1347:1+1359:1359:1+1371:1372:1+1374:1386:1+1388:1391:1+1393:1393:1+1413:1414:1";
//			aiData="4:6:1+13:15:1+17:20:1+40:43:1+77:78:1+80:82:1+112:118:1+137:138:1+161:162:1+164:166:1+172:173:1+208:208:1+230:233:1+241:245:1+260:283:1+286:287:1+298:314:1+321:325:1+341:347:1+355:359:1+361:362:1+365:367:1+369:375:1+382:383:1+395:399:1+401:402:1+410:410:1+427:427:1+437:439:1+442:442:1+452:452:1+472:474:1+476:482:1+484:487:1+489:490:1+493:504:1+517:517:1+520:528:1+533:536:1+542:542:1+566:568:1+594:596:1+673:675:1+700:700:1+745:745:1+751:755:1+764:767:1+769:769:1+798:798:1+801:806:1+811:813:1+815:816:1+841:854:1+886:887:1+907:909:1+911:912:1+920:926:1+932:933:1+942:945:1+953:958:1+982:983:1+986:986:1+1001:1002:1+1053:1054:1+1058:1060:1+1074:1075:1+1128:1129:1+1159:1161:1+1177:1178:1+1202:1210:1+1213:1214:1+1222:1224:1+1226:1227:1+1245:1246:1+1249:1252:1+1278:1279:1+1283:1285:1+1287:1288:1+1314:1317:1+1319:1321:1+1343:1345:1+1347:1350:1";

        	//20200204 add
            AiDataSelect objAiDataSelect = new AiDataSelect();
            aiData=objAiDataSelect.selectAiData(aiData,policySelect);

            objLog.info("aiData="+aiData);

            if(!aiData.equals("")) {
                //全文検索から戻ってきた値をhashへ成型
                HashMap<Integer, String> hashRepPos = objMaskCls.makePosHash(aiData);
                objMaskCls.makePosHash(aiData);

                //bodyの構造体hashを取得
                HashMap<Integer, HtmlStructure> hashBodyStructure = objMaskCls.getBodyStructure(strOutHtml);
                //全文検索エンジンに返した結果を置換してbodyを入れ替えた文字列を取得(黒塗り)
                arrMask=objMaskCls.bodyReplace(hashRepPos, hashBodyStructure,1);
                strRepBody = arrMask[0];
                strEditMarker = arrMask[1];

                //htmlのbodyの中身を入れ替え、置換HTMLを作成する
                strMaskHtml = objMaskCls.makeBody(strOutHtml,strRepBody);

                //20191212 結果から再度構造体を作成し、ページネーションを作成
                HashMap<Integer, HtmlStructure> hashBodyPageStructure = objMaskCls.getBodyStructure(strMaskHtml);
                String strTmpTxt ="";
                strTmpTxt = objMaskCls.bodyMakePaginate(hashBodyPageStructure,insPageLen);

                //スタイルシートPath埋め込み
                strMaskHtml = objMaskCls.insertStyleTxt(strTmpTxt,strStyle);


                //全文検索エンジンに返した結果を置換してbodyを入れ替えた文字列を取得(赤文字)
                arrRed=objMaskCls.bodyReplace(hashRepPos, hashBodyStructure,2);
                strRepBody=arrRed[0];

                //htmlのbodyの中身を入れ替え、置換HTMLを作成する
                strRedHtml = objMaskCls.makeBody(strOutHtml,strRepBody);

                //20191212 結果から再度構造体を作成し、ページネーションを作成
                hashBodyPageStructure=null;
                hashBodyPageStructure = objMaskCls.getBodyStructure(strRedHtml);
                strTmpTxt ="";
                strTmpTxt = objMaskCls.bodyMakePaginate(hashBodyPageStructure,insPageLen);

                //スタイルシートPath埋め込み
                strRedHtml = objMaskCls.insertStyleTxt(strTmpTxt,strStyle);

            }else { //aidataなし
                objLog.info("aiDataが無いため、サーバでの黒塗り処理は行いません。");
                strMaskHtml = strOutHtml;
                //20191212 結果から再度構造体を作成し、ページネーションを作成
                HashMap<Integer, HtmlStructure> hashBodyPageStructure = objMaskCls.getBodyStructure(strMaskHtml);
                String strTmpTxt ="";
                strTmpTxt = objMaskCls.bodyMakePaginate(hashBodyPageStructure,insPageLen);

                //スタイルシートPath埋め込み
                strMaskHtml = objMaskCls.insertStyleTxt(strTmpTxt,strStyle);

                //赤文字
                strRedHtml = strOutHtml;
                //20191212 結果から再度構造体を作成し、ページネーションを作成
                hashBodyPageStructure=null;
                hashBodyPageStructure = objMaskCls.getBodyStructure(strRedHtml);
                strTmpTxt ="";
                strTmpTxt = objMaskCls.bodyMakePaginate(hashBodyPageStructure,insPageLen);

                //スタイルシートPath埋め込み
                strRedHtml = objMaskCls.insertStyleTxt(strTmpTxt,strStyle);


            } //if
                synchronized (this) {

                    //css,黒塗り画像ファイル配備 ※deploy時にエラーになるためresourceLoaderで取得
                    String strCssPath = "/static/css/blackPaint/mask.css";
                    String strImgPath = "/static/css/images/m";
                    //deploy後に動かないので修正
                    objLog.info("ファイル、イメージ配備開始");
                    Resource resource =null;
                    resource = resourceLoader.getResource("classpath:" + strCssPath);
                    objLog.info(strCssPath +"存在判定："+ resource.exists());
                    InputStream objIs = resource.getInputStream();
                    byte[] arrByte = null;
                    arrByte = IOUtils.toByteArray(objIs);
                    FileOutputStream objOutSr = null;
                    objOutSr=new FileOutputStream(strTmpDir + "/" + documentId+ "/mask.css");
                    objOutSr.write(arrByte);//出力（dataのbyte列をファイルに書き込む）
                    objOutSr.close();//閉じる(fosを使ったファイル操作を終えた時に実行)

                    resource = resourceLoader.getResource("classpath:" + strImgPath);
                    objLog.info(strCssPath +"存在判定："+ resource.exists());
                    objIs = resource.getInputStream();
                    arrByte = IOUtils.toByteArray(objIs);

                    objOutSr=new FileOutputStream(strTmpDir + "/" + documentId+ "/m");

                    objOutSr.write(arrByte);//出力（dataのbyte列をファイルに書き込む）
                    objOutSr.close();//閉じる(fosを使ったファイル操作を終えた時に実行)

                    objLog.info("ファイル、イメージ配備完了");
                } //synchronized

                String strMaskOutPath = strTmpDir + "mask_" + strHtmlName;
                String strRedOutPath = strTmpDir + "red_" + strHtmlName;


                //htmlを出力する(黒塗り)
                if (objFileCnt.writeFile(strMaskOutPath, strMaskHtml)) {
                    objLog.info("maskHTML完了");
                } else {
                    objLog.error("maskHTML生成失敗");
                }
                //htmlを出力する(赤文字)
                if (objFileCnt.writeFile(strRedOutPath, strRedHtml)) {
                    objLog.info("赤文字HTML完了");
                } else {
                    objLog.error("赤文字HTML生成失敗");
                }
                //ページカウント取得
//				intPageCnt = 1; //暫定
                intPageCnt = objAspCls.aspPageGet(strMaskHtml);
//				intPageCnt = objAspCls.aspPageGet(strMaskHtml) - 1;
                hashMap.put("strPageCnt", intPageCnt+"");
                hashMap.put("strEditMarker", strEditMarker);
                hashMap.put("aiData", aiData);
				hashMap.put("strHeight", strHeight);


        } catch (IOException e) {
            objLog.error( "err message", e );
            e.printStackTrace();
        } //try


        return hashMap;





    } //method





} //class
