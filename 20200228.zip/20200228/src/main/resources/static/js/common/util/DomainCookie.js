/* global alert */
/**
 * @fileOverview ドメインCookie処理
 * 				　ドメインCookieに関するsetter、getterを実装する。
 * @desc 機能名　　：ファイル検索機能
 * @desc 画面名　　：ファイル検索画面
 */

var DomainCookie = {};
var DomainInfo;

/** 
 * ドメインCookie初期化処理
 * ドメインCookieを初期作成し、ドメイン情報を取得する。
 * @memberOf  DomainCookie.js
 * @param {String} domainInfo(in)
 */
DomainCookie.initDomainCookie = function(domainInfo){

	// 引数がない場合は処理を終了
	if (domainInfo === null || domainInfo === undefined){
		alert("ドメインCookie初期処理エラー\r\nドメイン情報が不正です。");
		return;
	}
	
	// サーバ情報を設定する
	DomainInfo = domainInfo;
	
	// 初期値設定
	var userInfo = "{\"userId\":\"\", \"userName\":\"\", \"userRole\":\"\"}";
	DomainCookie.setDomainCookie("user_info", userInfo);
};

/** 
 * ドメインCookie設定処理
 * ドメインCookieを設定する。
 * @memberOf  DomainCookie.js
 * @param {String} key(in)
 * @param {String} value(in)
 */
DomainCookie.setDomainCookie = function(key, value){

	// 引数がない場合は処理を終了
	if (key === null || key === undefined){
		alert("ドメインCookie設定処理エラー\r\nキー情報が不正です。");
		return;
	}
	if (value === null || value === undefined){
		alert("ドメインCookie設定処理エラー\r\n値の内容が不正です。");
		return;
	}
	
	if(DomainInfo !== null && DomainInfo !== undefined){
		value += "; domain=" + DomainInfo;
	}
	value += "; path=/;";
	
	// ドメインCookieを設定
	document.cookie = key + "=" + value;
};

/** 
 * ドメインCookie取得処理
 * ドメインCookieを取得する。
 * @memberOf  DomainCookie.js
 * @param {String} key(in)
 * @return {String} value
 */
DomainCookie.getDomainCookie = function(key){

	// 引数がない場合は処理を終了
	if (key === null || key === undefined){
		alert("ドメインクッキ初期処理エラー\r\nキー情報が不正です。");
		return "";
	}
	
	var retValue = null;

	// ドキュメントからクッキーを取得
	var cookieArray = document.cookie.split(";");
	cookieArray.forEach(function(value) {
		var cookieKeyValue = value.split("=");
		var cookieKey = cookieKeyValue[0].trim();
		var cookieValue = cookieKeyValue[1].trim();

		if (cookieKey === key) {
			retValue = cookieValue;
		}
	});

	return retValue;
};

/** 
 * ユーザーID設定処理
 * ドメインCookieのユーザーIDを設定する。
 * @memberOf  DomainCookie.js
 * @param {String} userId(in)
 */
DomainCookie.setUserId = function(userId){
	
	// 引数がない場合は処理を終了
	if (userId === null || userId === undefined){
		alert("ユーザーID設定処理エラー\r\nユーザーIdが不正です。");
		return;
	}
	
	// ユーザーID設定
	var UserInfo = JSON.parse(DomainCookie.getDomainCookie("user_info"));
	UserInfo.userId = userId;
	DomainCookie.setDomainCookie("user_info", JSON.stringify(UserInfo));	
};

/** 
 * ユーザー名設定処理
 * ドメインCookieのユーザー名を設定する。
 * @memberOf  DomainCookie.js
 * @param {String} userName(in)
 */
DomainCookie.setUserName = function(userName){
	
	// 引数がない場合は処理を終了
	if (userName === null || userName === undefined){
		alert("ユーザー名設定処理エラー\r\nユーザー名が不正です。");
		return;
	}
	
	// ユーザーID設定
	var UserInfo = JSON.parse(DomainCookie.getDomainCookie("user_info"));
	UserInfo.userName = userName;
	DomainCookie.setDomainCookie("user_info", JSON.stringify(UserInfo));
};

/** 
 * ユーザー権限設定処理
 * ドメインCookieのユーザー権限を設定する。
 * @memberOf  DomainCookie.js
 * @param {String} userRole(in)
 */
DomainCookie.setUserRole = function(userRole){

	// 引数がない場合は処理を終了
	if (userRole === null || userRole === undefined){
		alert("ユーザー権限設定処理エラー\r\nユーザー権限が不正です。");
		return;
	}
	
	// ユーザーID設定
	var UserInfo = JSON.parse(DomainCookie.getDomainCookie("user_info"));
	UserInfo.userRole = userRole;
	DomainCookie.setDomainCookie("user_info", JSON.stringify(UserInfo));
};

/** 
 * ユーザーID取得処理
 * ドメインCookieのユーザーIDを取得する。
 * @memberOf  DomainCookie.js
 * @returns {String}
 */
DomainCookie.getUserId = function(){
	// ユーザーID設定
	var UserInfo = JSON.parse(DomainCookie.getDomainCookie("user_info"));
	return UserInfo.userId;
};

/** 
 * ユーザー名取得処理
 * ドメインCookieのユーザー名を取得する。
 * @memberOf  DomainCookie.js
 * @returns {String}
 */
DomainCookie.getUserName = function(){
	// ユーザー名設定
	var UserInfo = JSON.parse(DomainCookie.getDomainCookie("user_info"));
	return UserInfo.userName;
};

/** 
 * ユーザー権限取得処理
 * ドメインCookieのユーザー権限を取得する。
 * @memberOf  DomainCookie.js
 * @returns {String}
 */
DomainCookie.getUserRole = function(){
	// ユーザーI名設定
	var UserInfo = JSON.parse(DomainCookie.getDomainCookie("user_info"));
	return UserInfo.userRole;
};