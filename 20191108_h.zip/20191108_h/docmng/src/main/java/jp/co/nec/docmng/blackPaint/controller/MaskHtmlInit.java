package jp.co.nec.docmng.blackPaint.controller;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MaskHtmlInit {



	@GetMapping("blackPaint/MaskHtmlInit")
	public String getblackTextTest(HttpServletResponse response,Model model) {

		//testデータを入れる
		String TGT_FILE_NAME= "\\\\yoks3104\\Project\\NES_文書管理システム\\99_tmp\\上田\\aspTest\\Test.docx";
//		String TGT_FILE_NAME= "C:\\temp\\SpringBoot.docx";
//		String ALL_SEARCH_MOCK_DATA = "2:9+15:5";
		String ALL_SEARCH_MOCK_DATA = "2:9:1+15:5:2";

		String DOCUMENT_ID = "1";

		//ユーザはクッキーで取得予定なので仮で設定
		Cookie cookie = new Cookie("user_id", "testUser");
	    cookie.setMaxAge(60*60);
	    cookie.setPath("/");
		response.addCookie(cookie);

		Cookie cookie2 = new Cookie("user_name", "testName");
	    cookie2.setMaxAge(60*60);
	    cookie2.setPath("/");
		response.addCookie(cookie2);

		model.addAttribute("TGT_FILE_NAME", TGT_FILE_NAME);
		model.addAttribute("ALL_SEARCH_MOCK_DATA", ALL_SEARCH_MOCK_DATA);
		model.addAttribute("DOCUMENT_ID", DOCUMENT_ID);


		return "blackPaint/MaskHtmlInit";
	} //getView1

} //MaskHtmlCnt
