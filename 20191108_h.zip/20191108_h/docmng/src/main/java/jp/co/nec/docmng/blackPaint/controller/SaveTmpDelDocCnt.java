/**
 * 名称：SaveTmpDocCnt.java
 * 機能名：一時保存Control
 * 概要：一時保存機能のControlを行う。
 */

package jp.co.nec.docmng.blackPaint.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.blackPaint.service.TmpMaskDocTmpMarkerService;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocumentService;

/**
 * 一時保存機能のControlを行う。
 */
@RestController
public class SaveTmpDelDocCnt {

	/**
	 * objLog log出力に使用する
	 */
	@Autowired
	TmpMaskDocumentService tmpMaskDocumentService;
	@Autowired
	TmpMaskDocTmpMarkerService tmpMaskDocTmpMarkerService;

	static Logger objLog = LoggerFactory.getLogger(SaveTmpDelDocCnt.class);

	/**
	 * 一時保存メソッド
	 * 一時保存を押下したときの処理制御をする。
	 * @param strHashJson 以下の値を入れ込んだjsonString
	 * documentId ドキュメントID
	 */
	@ResponseBody
	@PostMapping("/blackpaint/SaveTmpDelDocCnt")
	@ResponseStatus(HttpStatus.OK)
	public String SaveTmpDocCntRest(
			@RequestBody String strHashJson,
			@CookieValue(value = "user_id", required = false) String UserId,
			Model model) {

		//メンバ変数初期化
		int intDocumentId = -1; //documentId


		//POSTされたjsonをパースする
		ObjectMapper objMapper = new ObjectMapper();
		List<Map<String, String[]>> objTmpList = null;
		TypeReference<List<Map<String, String[]>>> objType = new TypeReference<List<Map<String, String[]>>>() {
		};
		try {
			objTmpList = objMapper.readValue(strHashJson, objType);
		} catch (JsonParseException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} catch (JsonMappingException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} catch (IOException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} //try

		HashMap<String, String[]> objMap = (HashMap<String, String[]>) objTmpList.get(0);

		for (String strKey : objMap.keySet()) {
			switch (strKey) {
			case "documentId":
				intDocumentId = Integer.parseInt(objMap.get(strKey)[0]);
				break;
			default:
				break;
			}//switch

		} //for

		//DB削除処理
		try {
			//tmp_mask_documentテーブル対象削除
			tmpMaskDocumentService.deleteTmpDoc(intDocumentId, UserId);
			//markerTable
			tmpMaskDocTmpMarkerService.deleteTmpMarkerDoc(intDocumentId, UserId);

		} catch (Exception e) {
			objLog.error("err message", e);
			System.err.println(e);
		} //try

		return "200";
	} //getView1

} //MaskHtmlCnt
