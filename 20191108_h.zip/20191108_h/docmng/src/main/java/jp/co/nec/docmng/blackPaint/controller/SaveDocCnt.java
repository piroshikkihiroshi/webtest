/**
 * 名称：SaveTmpDocCnt.java
 * 機能名：一時保存Control
 * 概要：一時保存機能のControlを行う。
 */

package jp.co.nec.docmng.blackPaint.controller;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.zeroturnaround.zip.ZipUtil;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.blackPaint.entity.MaskDocMarkerEntBlackPaint;
import jp.co.nec.docmng.blackPaint.entity.MaskDocumentEntBlackPaint;
import jp.co.nec.docmng.blackPaint.entity.PolicyKeywordInfoBlackPaint;
import jp.co.nec.docmng.blackPaint.logic.dirFile.DirCnt;
import jp.co.nec.docmng.blackPaint.logic.dirFile.FileCnt;
import jp.co.nec.docmng.blackPaint.service.MaskDocMarkerService;
import jp.co.nec.docmng.blackPaint.service.MaskDocumentService;
import jp.co.nec.docmng.blackPaint.service.PolicyKeywordInfoServiceBlackPaint;

/**
 * 保存機能のControlを行う。
 */
@Controller
public class SaveDocCnt {

	/**
	 * context サーブレットのRealPathを取得する
	 * objLog log出力に使用する
	 * PAGE_CLASS ページを判定するHTMLClass。ページをSplitするのに使用する
	 * ARR_HEAD ファイル名、フォルダ名を判定するために使用する
	 */
	@Autowired
	ServletContext context;
	@Autowired
	MaskDocumentService maskDocumentService;
	@Autowired
	MaskDocMarkerService maskDocMarkerService;
	@Autowired
	PolicyKeywordInfoServiceBlackPaint policyKeywordInfoServiceBlackPaint;

	static Logger objLog = LoggerFactory.getLogger(SaveDocCnt.class);

	static String PAGE_CLASS = "awdiv awpage"; //splitするページのHTMLClass
	static String[] ARR_HEAD = { "mask_", "red_" }; //ファイル名、フォルダ名のヘッダー配列

	/**
	 * 保存メソッド
	 * 保存を押下したときの処理制御をする。
	 * 対象はPROCENTER/C と　mask_document
	 * @param strHashJson jsonString
	 */
	@PostMapping("/SaveDocCnt")
	public String SaveTmpDocCntRest(
			@RequestParam("strJson") String strJson,
			@CookieValue(value = "user_id", required = false) String UserId,
			Model model) {


		//モデル初期化
		FileCnt objFileCnt = new FileCnt();
		DirCnt objDirCls = new DirCnt();

		//メンバ変数初期化
		String strTmpDir = ""; //黒塗り編集画面で処理したHTMLが格納されたTMPディレクトリ名。
		String strRedHtml = ""; //黒塗り編集候補HTMLのouterHTML。
		String strMaskHtml = ""; //黒塗り編集HTMLのouterHTML。
		String strFileName = ""; //オリジナルwordファイル名。
		int intDocumentId = -1; //documentId
		String strListJson = ""; //黒塗りリストの情報のjson

		String strBasePath = ""; //黒塗り作成時の作業フォルダ
		String strHead = ""; //ファイル名、フォルダ名のヘッダー
		String strFileOutDir = ""; //PDF出力フォルダ
		String strHtmlDir = ""; //黒塗り作成時HTMLに対するimg,css等が入っているフォルダ
		String strRealPath = context.getRealPath("/");
		String strTmpTimeStamp = ""; //tempファイルタイムスタンプ

		String updateTime =""; //更新日時
		String retentionPeriod=""; //保存期間
		String[] arrPrint = null; //印刷範囲のインデックス true：印刷 false 印刷無し
		String[] arrMaskPaths = null; //黒塗りpdfパス
		String[] arrRedPaths = null; //黒塗り候補pdfパス

		//以下黒塗りリスト配列
		String[] keywords=null;
		String[] pages=null;
		String[] policyNames=null;
		String[] Reasons=null;
		String[] Remarks=null;

		//以下黒塗りリスト配列
		String[] glArrBfIds = null;
		String[] glArrAfIds = null;
		String[] glArrPolicys = null;

		byte[] byteZip = null; //zipにした際のbyte配列
		File objZipFile = null;




		strTmpTimeStamp = String.valueOf(System.currentTimeMillis());

		//POSTされたjsonをパースする
		ObjectMapper objMapper = new ObjectMapper();
		List<Map<String, String[]>> objTmpList = null;
		TypeReference<List<Map<String, String[]>>> objType = new TypeReference<List<Map<String, String[]>>>() {
		};
		try {
			objTmpList = objMapper.readValue(strJson, objType);
		} catch (JsonParseException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} catch (JsonMappingException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} catch (IOException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} //try

		HashMap<String, String[]> objMap = (HashMap<String, String[]>) objTmpList.get(0);

		Object objTmp = null;
		for (String strKey : objMap.keySet()) {
			switch (strKey) {
			case "tmpDir":
				strTmpDir = objMap.get(strKey)[0];
				break;
			case "strFileName":
				strFileName = objMap.get(strKey)[0];
				break;
			case "updateTime":
				updateTime = objMap.get(strKey)[0];
				break;
			case "retentionPeriod":
				retentionPeriod = objMap.get(strKey)[0];
				break;
			case "documentId":
				intDocumentId = Integer.parseInt(objMap.get(strKey)[0]);
				break;
			case "arrPrint":
				arrPrint = (String[]) objMap.get(strKey);
				break;
			case "arrMaskPaths":
				arrMaskPaths = (String[]) objMap.get(strKey);
				break;
			case "arrRedPaths":
				arrRedPaths = (String[]) objMap.get(strKey);
				break;
				//*******以下黒塗りリスト用
			case "keywords":
				keywords = (String[]) objMap.get(strKey);
				break;
			case "pages":
				pages = (String[]) objMap.get(strKey);
				break;
			case "policyNames":
				policyNames = (String[]) objMap.get(strKey);
				break;
			case "Reasons":
				Reasons = (String[]) objMap.get(strKey);
				break;
			case "Remarks":
				Remarks = (String[]) objMap.get(strKey);
				break;
			case "glArrBfIds":
				glArrBfIds = (String[]) objMap.get(strKey);
				break;
			case "glArrAfIds":
				glArrAfIds = (String[]) objMap.get(strKey);
				break;
			case "glArrPolicys":
				glArrPolicys = (String[]) objMap.get(strKey);
				break;
			default:
				break;
			}//switch

		} //for

		//拡張子無しファイル名取得
		String strFileWithoutExtension = objFileCnt.getNameWithoutExtension(strFileName);

//		//出力フォルダ(result)作成
		strBasePath = strRealPath + strTmpDir;
		strFileOutDir = strRealPath + "result" + strTmpTimeStamp + "/";
		String strRealPathWithoutSlash = strRealPath.substring(0,strRealPath.length()-1); //末尾必要ないRealPathが必要
		try {
			objDirCls.makeDirWithCheck(strFileOutDir);
			//結合PDFファイル作成
			//結合対象が不定なので一度リストに格納
			List<File> listMaskPdfs = new ArrayList<File>();
			List<File> listRedPdfs = new ArrayList<File>();
			int intFileCnt=0;
			for (int i = 1; i < arrPrint.length; i++) { //ページは1ページ目からなので1からスタート
				String strOutChk = arrPrint[i];
				if (strOutChk.equals("true")) { //trueの場合結合対象
					File objFileMask = new File(strRealPathWithoutSlash+arrMaskPaths[i-1]);
					File objFileRed = new File(strRealPathWithoutSlash+arrMaskPaths[i-1]);
					listMaskPdfs.add(objFileMask);
					listRedPdfs.add(objFileRed);
					intFileCnt++;
				} //if
			} //for
			File[] objMaskPdfs = new File[intFileCnt];
			File[] objRedPdfs = new File[intFileCnt];

			for (int i = 0; i < listMaskPdfs.size(); i++) {
				objMaskPdfs[i] = listMaskPdfs.get(i);
				objRedPdfs[i] = listRedPdfs.get(i);
			} //for

			ByteArrayOutputStream byteMasks = objFileCnt.PDFCombine(objMaskPdfs);
            FileOutputStream fileMaskOut = new FileOutputStream(strFileOutDir+strFileWithoutExtension+"(公開用).pdf");
            byteMasks.writeTo(fileMaskOut);
            fileMaskOut.close();
            byteMasks.close();

			ByteArrayOutputStream byteReds = objFileCnt.PDFCombine(objRedPdfs);
            FileOutputStream fileRedOut = new FileOutputStream(strFileOutDir+strFileWithoutExtension+"(査閲用).pdf");
            byteReds.writeTo(fileRedOut);
            fileRedOut.close();
            byteReds.close();


    		//zipに固める
    		String strZipOut = strRealPath + "zip" + strTmpTimeStamp + "/" + "mask.zip";
    		objDirCls.makeDirWithCheck(strRealPath + "zip" + strTmpTimeStamp + "/");
    		ZipUtil.pack(new File(strFileOutDir), new File(strZipOut));

    		//zipをbyte配列にする
			objZipFile = new File(strZipOut);
			byteZip = Files.readAllBytes(objZipFile.toPath());

		} catch (IOException e1) {
			objLog.error("err message", e1);
			e1.printStackTrace();

		} catch (Exception e1) {
			objLog.error("err message", e1);
			e1.printStackTrace();
		} //tyr

		//DBに格納
		// システム日付を取得する
		Timestamp sysdate = Timestamp.valueOf(LocalDateTime.now());
		//エンティティインスタンス化
		MaskDocumentEntBlackPaint objEnt = new MaskDocumentEntBlackPaint();
		try {
			//tmp_mask_documentテーブル
			objEnt.setDocumentId(intDocumentId);
			objEnt.setUserId(UserId);
			objEnt.setHtmlZipData(byteZip);
			objEnt.setUpdateTime(null);
			objEnt.setCreateTime(sysdate);
			maskDocumentService.insertMaskDocument(objEnt);

			//markerTable
			MaskDocMarkerEntBlackPaint objEnt2 = null;
			for (int i = 0; i < glArrBfIds.length; i++) {
				objEnt2 = new MaskDocMarkerEntBlackPaint();
				objEnt2.setDocumentId(intDocumentId);
				objEnt2.setMarkerStartCd(glArrBfIds[i]);
				objEnt2.setMarkerEndCd(glArrAfIds[i]);
				objEnt2.setMarkerPolicy(Integer.parseInt(glArrPolicys[i]));
				if (Remarks.length == 0) {
					objEnt2.setMarkerRemarks("");
				} else {
					objEnt2.setMarkerRemarks(Remarks[i]);
				} //if insertTmpMaskDocument
				objEnt2.setCreateTime(sysdate);
				maskDocMarkerService.insertMaskDocument(objEnt2);

			} //for

			//policy_keyword_info table
			PolicyKeywordInfoBlackPaint objEnt3 = null;
			for (int i = 0; i < glArrBfIds.length; i++) {
				objEnt3 = new PolicyKeywordInfoBlackPaint();
				objEnt3.setPolicyId(Integer.parseInt(glArrPolicys[i]));
				objEnt3.setPolicyKeyword(keywords[i]);
				objEnt3.setCreateTime(sysdate);
				policyKeywordInfoServiceBlackPaint.insertPolicyKeyword(objEnt3);
			} //for


			//セッションで削除できないためとりあえずそのまま
			//作業ディレクトリ,ファイルかたづけ
//			objDirCls.DelDirctory(strFileOutDir);
//			objZipFile.delete();
//			objDirCls.DelDirctory(strBasePath);

		} catch (Exception e) {
			objLog.error("err message", e);
			System.err.println(e);
		} //try

		//*************PROCENTER/Cの保存処理**********************


		//*************NAS様の検索画面へ遷移する**********************
		return "blackPaint/Success";
	} //getView1

} //MaskHtmlCnt
