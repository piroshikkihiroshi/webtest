/**
 * 名称：TrainingPolicyControllerファイル
 * 機能名：教師データ登録（黒塗り箇所抽出）コントローラー
 * 概要：教師データ登録（黒塗り箇所抽出）の制御を実施する
 */
package jp.co.nec.docmng.manege.controller;

import java.io.File;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.library.train.MakeTrainingData;
import jp.co.nec.docmng.manege.entity.PolicyInfoEntity;
import jp.co.nec.docmng.manege.entity.TmpTeacherPolicyList;
import jp.co.nec.docmng.manege.service.PolicyInfoService;
import jp.co.nec.docmng.manege.service.TmpTeacherPolicyService;

@Controller
@RequestMapping("/manege/training_policy")
public class TrainingPolicyController {

    @Autowired
    PolicyInfoService policyInfoService;
    @Autowired
    TmpTeacherPolicyService tmpTeacherPolicyService;
    /** 正解データコンバート用API */

    MakeTrainingData train = new MakeTrainingData();

    /**
     * <p>教師データ登録（黒塗り箇所抽出）GET処理</p>
     * 処理内容：<br>
     * <ol>
     *   <li>教師データ登録（黒塗り箇所抽出）を表示する</li>
     * </ol>
     * @param model モデル
     * @return 教師データ登録（黒塗り箇所抽出）画面のURL
     */
    @GetMapping
    public String getTrainingPolicy(Model model) {
        System.out.println("教師データ（黒塗り箇所摘出）登録画面表示（GET）");
        // 全件取得
        List<PolicyInfoEntity> policyInfos = policyInfoService.findAll();
        model.addAttribute("policyInfo", policyInfos);

        System.out.println(policyInfos);
//
        List<TmpTeacherPolicyList> teacherPolicyLists = tmpTeacherPolicyService.findAll();
        model.addAttribute("teacherPolicyList", teacherPolicyLists);

        // TODO:ユーザIDからユーザ名を取得
        //       共通処理から取得する？
        model.addAttribute("userName", "user3（管理者）");

        return "manege/training_policy";
    }

    /**
     * <p>設定反映処理メソッド</p>
     * 処理内容：<br>
     * <ol>
     *   <li>画面上で削除した項目と紐づくDBの項目を削除する。</li>
     *   <li>画面上で編集した項目と紐づくDBの項目を更新する。</li>
     *   <li>画面上で追加した項目と紐づくDBの項目を追加する<。/li>
     * </ol>
     * @param editValue 画面上で編集した項目の値
     * @param deleteRows 画面上で削除した列情報
     * @param addValue
     * @return リロード
     * @throws Exception
     */
    @PostMapping(params = "saveValue")
    public String save(
            @RequestParam("saveValue") String saveValue, Model model) throws Exception {
        // 全件取得
        System.out.println("登録ボタン押下");
        System.out.println(saveValue);

        // システム日付を取得する
        Timestamp sysdate = Timestamp.valueOf(LocalDateTime.now());
        ObjectMapper mapper = new ObjectMapper();
        // リクエスト情報をjsonツリー化
        JsonNode addValueList = mapper.readTree(saveValue);
        JsonNode teacherPolicyList = addValueList.get("teacher_policy_list");
        String savePath = addValueList.get("savePath").asText();

        //TODO: 正解データコンバートAPI呼出し
        try {
            correctDataConvert(teacherPolicyList, savePath);
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("error", "エラー");
            return "manege/training_policy";
        }
        // ALL削除
        tmpTeacherPolicyService.deleteAll();

        // ALL登録
        for (int i = 0; i < teacherPolicyList.size(); i++) {
            TmpTeacherPolicyList tmpTeacherPolicyList = new TmpTeacherPolicyList();
            JsonNode tmp = teacherPolicyList.get(i);
            // ユーザID
            String userId = tmp.get("userId").asText();
            // 表示順
            Integer sortId = tmp.get("sortId").asInt();
            // ポリシーID
            Integer policyId = tmp.get("policyId").asInt();
            // 正解データ格納先パス
            String directoryPath = tmp.get("directoryPath").asText();
            // 作成日時
            Timestamp createTime = sysdate;
            // 更新日時
            Timestamp updateTime = sysdate;

            //DB更新用データ登録
            tmpTeacherPolicyList.setUserId(userId);
            tmpTeacherPolicyList.setSortId(sortId);
            tmpTeacherPolicyList.setPolicyId(policyId);
            tmpTeacherPolicyList.setDirectoryPath(directoryPath);
            tmpTeacherPolicyList.setCreateTime(createTime);
            tmpTeacherPolicyList.setUpdateTime(updateTime);

            System.out.printf("userID;%s  sortId:%s  policyId:%s\rdirectoryPath: %s\r\n", userId, sortId, policyId, directoryPath);

            tmpTeacherPolicyService.insert(tmpTeacherPolicyList);
        }

        // 表示データ再取得
        List<PolicyInfoEntity> policyInfos = policyInfoService.findAll();
        model.addAttribute("policyInfo", policyInfos);
        List<TmpTeacherPolicyList> teacherPolicyLists = tmpTeacherPolicyService.findAll();
        model.addAttribute("teacherPolicyList", teacherPolicyLists);
        // TODO:ユーザIDからユーザ名を取得
        //       共通処理から取得する？
        model.addAttribute("userName", "user3（管理者）");

        return "manege/training_policy";
    }


    /**
     * <p>設定反映処理メソッド</p>
     * 処理内容：正解データコンバートAPIの呼び出しと処理
     * @throws Exception
     * @param addValueList
     * @param savePath
     */
    private void correctDataConvert(JsonNode addValueList, String savePath) throws Exception {
        File saveDrectory = new File(savePath);
        if (!saveDrectory.exists()) {
            System.out.printf("保存先のフォルダ[%s]は存在しません。", savePath);
            //TODO:エラー処理　ひとまず例外をスローしておく
            throw new Exception("保存先のフォルダが存在しません");
        }
        //正解データコンバート用APIデータ（フォルダ）
        HashMap<Integer, String> input = new HashMap<Integer, String>();
        for (Integer i = 0; i < addValueList.size(); i++) {
            String directoryPath = addValueList.get(i).get("directoryPath").asText();
            System.out.printf("[%s]  [%s]\r\n",i , directoryPath);
            File directory = new File(directoryPath);
            if (!directory.exists()) {
                System.out.printf("正解データ格納先[%s]は存在しません。", directoryPath);
                //TODO:エラー処理　ひとまず例外をスローしておく
                throw new Exception("正解データ格納先が存在しません。");
            }
            //正解データコンバート用データ保存
            input.put(i+1, directoryPath);
        }
        //
        train.makeBlackPrintTrainData(input, savePath);
    }
}
