package jp.co.nec.docmng.manege.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.manege.entity.TmpTeacherCategoryList;
import jp.co.nec.docmng.manege.util.map.TmpTeacherCategoryListMapManege;

@Service
public class TmpTeacherCategoryService {

    @Autowired
    private TmpTeacherCategoryListMapManege tmpTeacherCategoryListMapper;

    @Transactional
    public List<TmpTeacherCategoryList> findAll(){
        List<TmpTeacherCategoryList> entityList = tmpTeacherCategoryListMapper.findAll();
        return entityList;
    }

}
