package fontCnt;


import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;


public class FontCnt_bk_20190812 {

	public static void main(String[] args) {
		FontCnt_bk_20190812 objMe = new FontCnt_bk_20190812();

		String strTgt = "＊";
//		String strTgt = "ドメイン";
//		String strStyle = "ＭＳ Ｐゴシック";
//		String strStyle = "ＭＳ ゴシック";
		String strStyle = "ＭＳ Ｐ明朝";
//		String strStyle = "メイリオ";
		int intSize = 10;
		int intType = 0;
		double dblRet = objMe.getFontWidth(strTgt,strStyle,intSize,intType );
		System.out.println(dblRet);
	}


	//fontの幅を取得する
	//memo ＊や■は1サイズで1px
	/**
	 * @param strTgt_i テキストの文字
	 * @param strFontStyle_i フォント名 ：ＭＳ Ｐゴシック等
	 * @param intSize_i //フォントサイズ
	 * @param intFontType_i 線の種類 PLAIN:0 BOLD:1 ITALIC:2 3:BOLD + ITALIC
	 * @return
	 */
	public double getFontWidth (String strTgt_i,String strFontStyle_i,int intSize_i,int intFontType_i) {

		double dblTgtWidth;
		try {
			Font objChkFont = new Font(strFontStyle_i, intFontType_i, intSize_i);
			BufferedImage objTmpImg = new BufferedImage(100, 100, BufferedImage.TYPE_3BYTE_BGR);
			Graphics2D objTmpGrapics = objTmpImg.createGraphics();
			Rectangle2D objTmpRectangle = objChkFont.getStringBounds(strTgt_i, objTmpGrapics.getFontRenderContext());
			dblTgtWidth = objTmpRectangle.getWidth(); //横方向のピクセル数



			System.out.println("対象文字： " + strTgt_i + " 対象フォントスタイル： " + strFontStyle_i + " 対象フォントサイズ： " + intSize_i + " 対象ステータス(太字とか)： " + intFontType_i );
		} catch (Exception e) {
			e.printStackTrace();
			dblTgtWidth = -1.0;
		} //try

		return dblTgtWidth;
	} //getFontWidth


	public int getFontType(boolean blBold_i , boolean blItalic_i ) {
		int intFontType = 0;
		if (blBold_i && blItalic_i) {
			intFontType = Font.BOLD + Font.ITALIC;

		}else if (blBold_i) {
			intFontType = Font.BOLD;
		}else if (blItalic_i) {
			intFontType = Font.ITALIC;
		} //if

		return intFontType;
	}

} //FontCnt
