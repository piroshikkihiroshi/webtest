package test;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

public class Test1 {

	public static void main(String[] args) {
		String filename = "";
		filename = "C:/Users/ueda tatsuya/Desktop/poisample-master/blog.goo.ne.jp_evergreen_19_mod.xlsx";
		try {
			Desktop.getDesktop().open(new File(filename));
			System.out.println("test");
		} catch (IOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}

	}

}
