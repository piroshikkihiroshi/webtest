package excel;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFShapeGroup;
import org.apache.poi.hssf.usermodel.HSSFSimpleShape;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFChart;
import org.apache.poi.xssf.usermodel.XSSFDrawing;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFShapeGroup;
import org.apache.poi.xssf.usermodel.XSSFSimpleShape;

public class ExcelTest_bk_20190809_2 {

	static Logger objLog = Logger.getLogger( ExcelTest_bk_20190809_2.class );

	public static void main(String[] args) {
		// 処理前の時刻を取得
		long startTime = System.currentTimeMillis();

		//設定
		String strMaskMsg = "test";

		//		String strFilePath = "C:/Users/ueda tatsuya/Desktop/test/test.xlsx";
		String strFilePath = "C:/Users/ueda tatsuya/Desktop/poisample-master/blog.goo.ne.jp_evergreen_19_mod.xlsx";
		String strCopyPath = strFilePath + "_" + System.currentTimeMillis() + ".xlsx";

		//出力先ファイルをコピーしてから書き換える
		try {
			Files.copy(Paths.get(strFilePath), Paths.get(strCopyPath));
			ExcelTest_bk_20190809_2 objExcelTest = new ExcelTest_bk_20190809_2();
			objExcelTest.getAllStr(strCopyPath,strMaskMsg);
		} catch (IOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}


		// 処理後の時刻を取得
		long endTime = System.currentTimeMillis();

		objLog.info("開始時刻：" + startTime + " ms");
		objLog.info("終了時刻：" + endTime + " ms");
		objLog.info("処理時間：" + (endTime - startTime) + " ms");

	} //main

	public void getAllStr(String strFilePath_i, String strMaskMsg_i) {

		InputStream objIS;
		Workbook objWB = null;
		try {

			objIS = new FileInputStream(strFilePath_i);
			objWB = WorkbookFactory.create(objIS);
			Font objFont = objWB.createFont();
			objFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());

			//シートの値取得
			for (int i = 0; i < objWB.getNumberOfSheets(); i++) {
				Sheet sheet = objWB.getSheetAt(i);

				for (Row objRow : sheet) {
					for (Cell objCell : objRow) {

						cellMusk(objWB,objCell, strMaskMsg_i);


					} //for(objCell)
				} //for(objRow)
				//shapeの処理
				objLog.info("shape:");
				XSSFDrawing drawing = (XSSFDrawing) sheet.createDrawingPatriarch();
				//通常のシェイプ
				for (Object objShape : drawing.getShapes()) {
					handleShape(objWB,objShape);
				} //for

				objLog.info("Graf:");
				//Graf
				if (drawing != null) {
					List<XSSFChart> objCharts = drawing.getCharts();
					if (objCharts != null && objCharts.size() > 0) {
						int j = objCharts.size() ;
						for (j = 0; j < objCharts.size() ; j++) {
							XSSFChart objChart = objCharts.get(j);
							XSSFRichTextString objGrafTitle = objChart.getTitleText();
//							objSb_i.append(objGrafTitle.toString());
						} //for

					} //if
				} //if
			} //for(sheet)


		} catch (Exception e) {
			e.printStackTrace();
		} //try

	} //getAllStr

	//オートシェイプを処理するメソッド
	public void handleShape(Workbook objWB_i,Object d) {
		String s = "";
		//shapeの処理(XLSX形式)
		if (d instanceof XSSFSimpleShape) {
			s = ((XSSFSimpleShape) d).getText();
		}
		//shapeの処理(XLS形式)
		if (d instanceof HSSFSimpleShape) {
			s = ((HSSFSimpleShape) d).getString().getString();
		}
		//グループ化されたshapeの処理(XLSX形式)
		if (d instanceof XSSFShapeGroup) {
			((XSSFShapeGroup) d).forEach(gs -> handleShape(objWB_i,gs));
		}
		//グループ化されたshapeの処理(XLS形式)
		if (d instanceof HSSFShapeGroup) {
			((HSSFShapeGroup) d).forEach(gs -> handleShape(objWB_i,gs));
		}
		//        result.add(func.apply(s));
		//        System.out.println(s);
//		objSb_i.append(s);
		objLog.info(s);
	} //handleShape



	/**
	 * @param objCell_i
	 * @param strMaskMsg
	 * @return
	 */
	public int cellMusk(Workbook objWB_i,Cell objCell_i,String strMaskMsg) {
		int intRet = 0;
		objLog.info("[row" + (objCell_i.getRowIndex() + 1) + ":clm" + (objCell_i.getColumnIndex() + 1) + "]");

		switch (objCell_i.getCellType()) {
		case NUMERIC:
			objLog.info("[NUMRIC ]" + objCell_i.getNumericCellValue());
			break;
		case STRING:
			objLog.info("[STRING ]" + objCell_i.getStringCellValue());
	        //セルのフォントを設定する
			Font objFont = objWB_i.createFont();
	        CellStyle objStyle = objWB_i.createCellStyle();
	        objStyle.setFont(objFont);
	        objCell_i.setCellStyle(objStyle);
			break;
		case FORMULA:
			objLog.info("[FORMULA]" + objCell_i.getCellFormula());
			break;
		case BOOLEAN:
			objLog.info("[BOOLEAN]" + objCell_i.getBooleanCellValue());
			break;
		case ERROR:
			objLog.info("[ERROR  ]" + objCell_i.getErrorCellValue());
			break;
//		case BLANK:
//			continue;
//		default:
//			continue;
		} //switch

		return intRet;
	} //cellMusk


} //ExcelTest
