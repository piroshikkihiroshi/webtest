package excel;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFShapeGroup;
import org.apache.poi.hssf.usermodel.HSSFSimpleShape;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFChart;
import org.apache.poi.xssf.usermodel.XSSFDrawing;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFShapeGroup;
import org.apache.poi.xssf.usermodel.XSSFSimpleShape;

public class ExcelTest_bk_20190809 {

	public static void main(String[] args) {

		// 処理前の時刻を取得
		long startTime = System.currentTimeMillis();

		//		String strFilePath = "C:/Users/ueda tatsuya/Desktop/test/test.xlsx";
		String strFilePath = "C:/Users/ueda tatsuya/Desktop/poisample-master/blog.goo.ne.jp_evergreen_19_mod.xlsx";
		StringBuilder objSb = new StringBuilder();
		ExcelTest_bk_20190809 objExcelTest = new ExcelTest_bk_20190809();

		objExcelTest.getAllStr(strFilePath, objSb);

		// 処理後の時刻を取得
		long endTime = System.currentTimeMillis();

		System.out.println(objSb.toString());

		System.out.println("開始時刻：" + startTime + " ms");
		System.out.println("終了時刻：" + endTime + " ms");
		System.out.println("処理時間：" + (endTime - startTime) + " ms");

	} //main

	public void getAllStr(String strFilePath_i, StringBuilder objSb_i) {

		InputStream objIS;
		Workbook objWB = null;
		try {
			//            // 出力先ファイルをコピーしてから書き換える
			//            Files.copy(Paths.get(filenameSrc), Paths.get(filenameDest), StandardCopyOption.REPLACE_EXISTING);

			objIS = new FileInputStream(strFilePath_i);
			objWB = WorkbookFactory.create(objIS);


			//シートの値取得
			for (int i = 0; i < objWB.getNumberOfSheets(); i++) {
				Sheet sheet = objWB.getSheetAt(i);

				for (Row objRow : sheet) {
					for (Cell objCell : objRow) {

						objSb_i.append("[").append(objCell.getSheet().getSheetName()).append("]");
//						objSb_i.append(objCell.getRowIndex()).append(":").append(objCell.getColumnIndex());
						objSb_i.append("row" + objCell.getRowIndex() + 1).append(":clm").append(objCell.getColumnIndex() + 1);

						switch (objCell.getCellType()) {
						case NUMERIC:
							objSb_i.append("[NUMRIC ]").append(objCell.getNumericCellValue() + "\r\n");
							break;
						case STRING:
							objSb_i.append("[STRING ]").append(objCell.getStringCellValue() + "\r\n");
							break;
						case FORMULA:
							objSb_i.append("[FORMULA]").append(objCell.getCellFormula() + "\r\n");
							break;
						case BOOLEAN:
							objSb_i.append("[BOOLEAN]").append(objCell.getBooleanCellValue() + "\r\n");
							break;
						case ERROR:
							objSb_i.append("[ERROR  ]").append(objCell.getErrorCellValue() + "\r\n");
							break;
						case BLANK:
							continue;
						default:
							continue;
						} //switch

					} //for(objCell)
				} //for(objRow)
				//shapeの処理
				objSb_i.append("shape:" + "\r\n");
				XSSFDrawing drawing = (XSSFDrawing) sheet.createDrawingPatriarch();
				//通常のシェイプ
				for (Object objShape : drawing.getShapes()) {
					handleShape(objShape, objSb_i);
				} //for

				objSb_i.append("Graf:" + "\r\n");
				//Graf
				if (drawing != null) {
					List<XSSFChart> objCharts = drawing.getCharts();
					if (objCharts != null && objCharts.size() > 0) {
						int j = objCharts.size() ;
						for (j = 0; j < objCharts.size() ; j++) {
							XSSFChart objChart = objCharts.get(j);
							XSSFRichTextString objGrafTitle = objChart.getTitleText();
							objSb_i.append(objGrafTitle.toString() + "\r\n");
						} //for

					} //if
				} //if
			} //for(sheet)


		} catch (Exception e) {
			e.printStackTrace();
		} //try

	} //getAllStr

	//オートシェイプを処理するメソッド
	public void handleShape(Object d, StringBuilder objSb_i) {
		String s = "";
		//shapeの処理(XLSX形式)
		if (d instanceof XSSFSimpleShape) {
			s = ((XSSFSimpleShape) d).getText();
		}
		//shapeの処理(XLS形式)
		if (d instanceof HSSFSimpleShape) {
			s = ((HSSFSimpleShape) d).getString().getString();
		}
		//グループ化されたshapeの処理(XLSX形式)
		if (d instanceof XSSFShapeGroup) {
			((XSSFShapeGroup) d).forEach(gs -> handleShape(gs, objSb_i));
		}
		//グループ化されたshapeの処理(XLS形式)
		if (d instanceof HSSFShapeGroup) {
			((HSSFShapeGroup) d).forEach(gs -> handleShape(gs, objSb_i));
		}
		//        result.add(func.apply(s));
		//        System.out.println(s);
		objSb_i.append(s + "\r\n");
	} //handleShape

} //ExcelTest
