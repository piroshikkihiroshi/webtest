package excel;

import java.awt.Color;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFShapeGroup;
import org.apache.poi.hssf.usermodel.HSSFSimpleShape;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFChart;
import org.apache.poi.xssf.usermodel.XSSFDrawing;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFShapeGroup;
import org.apache.poi.xssf.usermodel.XSSFSimpleShape;
import org.apache.poi.xssf.usermodel.XSSFTextParagraph;
import org.apache.poi.xssf.usermodel.XSSFTextRun;

import fontCnt.FontCnt;

public class ExcelTest_20190811_2 {

	static Logger objLog = Logger.getLogger( ExcelTest.class );
	static FontCnt objFontCls = new FontCnt();

	public static void main(String[] args) {
		// 処理前の時刻を取得
		long startTime = System.currentTimeMillis();

		//設定
		String strMaskMsg = "メイ";

		//		String strFilePath = "C:/Users/ueda tatsuya/Desktop/test/test.xlsx";
		String strFilePath = "C:/Users/ueda tatsuya/Desktop/poisample-master/blog.goo.ne.jp_evergreen_19_mod.xlsx";
		String strCopyPath = strFilePath + "_" + System.currentTimeMillis() + ".xlsx";

		try {
			ExcelTest objExcelTest = new ExcelTest();
			objExcelTest.excelSetMask(strFilePath,strCopyPath,strMaskMsg);
		} catch (Exception e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}


		// 処理後の時刻を取得
		long endTime = System.currentTimeMillis();

		objLog.info("開始時刻：" + startTime + " ms");
		objLog.info("終了時刻：" + endTime + " ms");
		objLog.info("処理時間：" + (endTime - startTime) + " ms");

	} //main

	public void getAllStr(String strFilePath_i, String strOutPath_i,String strMaskMsg_i) {

		InputStream objIS;
		Workbook objWB = null;
		try {

			objIS = new FileInputStream(strFilePath_i);
			objWB = WorkbookFactory.create(objIS);
//			Font objFont = objWB.createFont();
//			objFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());

			//シートの値取得
			for (int i = 0; i < objWB.getNumberOfSheets(); i++) {
				Sheet sheet = objWB.getSheetAt(i);

				for (Row objRow : sheet) {
					for (Cell objCell : objRow) {

						cellMusk(objWB,objCell, strMaskMsg_i);


					} //for(objCell)
				} //for(objRow)
				//shapeの処理
				objLog.info("shape:");
				XSSFDrawing drawing = (XSSFDrawing) sheet.createDrawingPatriarch();
				//通常のシェイプ
				for (Object objShape : drawing.getShapes()) {
					handleShape(objWB,objShape);
				} //for

				objLog.info("Graf:");
				//Graf
				if (drawing != null) {
					List<XSSFChart> objCharts = drawing.getCharts();
					if (objCharts != null && objCharts.size() > 0) {
						int j = objCharts.size() ;
						for (j = 0; j < objCharts.size() ; j++) {
							XSSFChart objChart = objCharts.get(j);
							XSSFRichTextString objGrafRichText = objChart.getTitleText();
							Font objFont = objWB.createFont();
							objGrafRichText.applyFont(objFont); //フォント色


							objLog.info(objGrafRichText);
						} //for

					} //if
				} //if
			} //for(sheet)

    	    // 変更するエクセルファイルを指定
			FileOutputStream outFile  = new FileOutputStream(strOutPath_i);
    	    // 書き込み
    	    objWB.write(outFile);
    	    objLog.info(strOutPath_i + "出力完了");


		} catch (Exception e) {
			e.printStackTrace();
		} //try

	} //getAllStr


	// memo
	//図形の塗りつぶし色を設定するには、HSSFSimpleShapeクラスのsetFillColorメソッドを、
	//図形の枠線の色を設定するには、HSSFSimpleShapeクラスのsetLineStyleColorメソッドを、
	//図形の枠線の幅を設定するには、HSSFSimpleShapeクラスのsetLineWidthメソッドを、
	//図形の枠線の種類を設定するには、HSSFSimpleShapeクラスのsetLineStyleメソッドを使用します
	//オートシェイプを処理するメソッド
	public void handleShape(Workbook objWB_i,Object objShape_i) {
		String strTgt = "";

		//shapeの処理(XLSX形式)
		if (objShape_i instanceof XSSFSimpleShape) {
			XSSFSimpleShape objTgtShape = ((XSSFSimpleShape) objShape_i);
			strTgt = ((XSSFSimpleShape) objShape_i).getText();
			for (int i = 0; i < objTgtShape.getTextParagraphs().size(); i++) {
				XSSFTextParagraph objParag = objTgtShape.getTextParagraphs().get(i);
				for (int j = 0; j < objParag.getTextRuns().size(); j++) {
					XSSFTextRun objTextRun = objParag.getTextRuns().get(j);
					objTextRun.setFontColor(Color.BLACK);
					objTextRun.setText("value you want to set");
				} //for j
			} //for i



		}
		//shapeの処理(XLS形式)
		if (objShape_i instanceof HSSFSimpleShape) {
			XSSFSimpleShape objTgtShape = ((XSSFSimpleShape) objShape_i);
			objTgtShape.setLineStyle(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
			strTgt = ((HSSFSimpleShape) objShape_i).getString().getString();

		}
		//グループ化されたshapeの処理(XLSX形式)
		if (objShape_i instanceof XSSFShapeGroup) {
			((XSSFShapeGroup) objShape_i).forEach(gs -> handleShape(objWB_i,gs));
		}
		//グループ化されたshapeの処理(XLS形式)
		if (objShape_i instanceof HSSFShapeGroup) {
			((HSSFShapeGroup) objShape_i).forEach(gs -> handleShape(objWB_i,gs));
		}


		if(!strTgt.contentEquals("")) objLog.info(strTgt);


	} //handleShape



	/**
	 * @param objCell_i
	 * @param strMaskMsg_i
	 * @return
	 */
	public int cellMusk(Workbook objWB_i,Cell objCell_i,String strMaskMsg_i) {
		int intRet = 0;
//		objLog.info("[row" + (objCell_i.getRowIndex() + 1) + ":clm" + (objCell_i.getColumnIndex() + 1) + "]");
        String strTgt = "";

		switch (objCell_i.getCellType()) {
		case NUMERIC:
			objLog.info("[row" + (objCell_i.getRowIndex() + 1) + ":clm" + (objCell_i.getColumnIndex() + 1) + "]" + "[NUMRIC]" + objCell_i.getNumericCellValue());
			strTgt = String.valueOf(objCell_i.getNumericCellValue());
			break;
		case STRING:
			objLog.info("[row" + (objCell_i.getRowIndex() + 1) + ":clm" + (objCell_i.getColumnIndex() + 1) + "]" + "[STRING]" + objCell_i.getStringCellValue());
			strTgt = objCell_i.getStringCellValue();
			break;
		case FORMULA:
			objLog.info("[row" + (objCell_i.getRowIndex() + 1) + ":clm" + (objCell_i.getColumnIndex() + 1) + "]" + "[FORMULA]" + objCell_i.getCellFormula());
			strTgt = objCell_i.getCellFormula();
			break;
		case BOOLEAN:
			objLog.info("[row" + (objCell_i.getRowIndex() + 1) + ":clm" + (objCell_i.getColumnIndex() + 1) + "]" + "[BOOLEAN]" + objCell_i.getBooleanCellValue());
			strTgt = String.valueOf(objCell_i.getBooleanCellValue());
			break;
		case ERROR:
			objLog.info("[row" + (objCell_i.getRowIndex() + 1) + ":clm" + (objCell_i.getColumnIndex() + 1) + "]" + "[ERROR  ]" + objCell_i.getErrorCellValue());
			strTgt = String.valueOf(objCell_i.getErrorCellValue());

			break;
//		case BLANK:
//			continue;
//		default:
//			continue;
		} //switch

		if (strTgt.contains(strMaskMsg_i)) { //マスク対象の場合置換処理

			//置換対象の文字幅を調べる
			double dblOrgWidth = 0.0;

			//セルの書式が全て同じ場合getFontName()はnullが帰ってくるのでTry catchで判断
			String[] arrTmp = strTgt.split("");
			boolean blEqualStyle = false;
			XSSFRichTextString objOrgRichText = (XSSFRichTextString)objCell_i.getRichStringCellValue();
			try {
				XSSFFont objGetFont = objOrgRichText.getFontAtIndex(0);
				String strTmp = arrTmp[0];
		        String strFontStyle = objGetFont.getFontName(); //フォント名 ：ＭＳ Ｐゴシック等
			} catch (Exception e) {
				blEqualStyle = true;
			} //try

			if(blEqualStyle) {
				objLog.info(strTgt + "は書式が統一なのでまとめて文字幅を判定します。");
			}else {
				objLog.info(strTgt + "は書式が異なるのでChar毎に文字幅を判定します。");
			} //if


			//※※※残課題※※※※※※※※※※※
			//置換対象の文字幅を調べる
			if(blEqualStyle) {
		        //取得したセルのフォントの種類
		        XSSFCellStyle objXssFCell = (XSSFCellStyle) objCell_i.getCellStyle();
		        XSSFFont objGetFont = objXssFCell.getFont();
		        String strFontStyle = objGetFont.getFontName(); //フォント名 ：ＭＳ Ｐゴシック等
		        int intSize = objGetFont.getFontHeightInPoints(); //フォントサイズ
		        boolean blBold = objGetFont.getBold(); //太字判定
		        boolean blItalic = objGetFont.getItalic(); //斜体判定
		        int intFontType = 0;
				intFontType = objFontCls.getFontType(blBold, blItalic);
				dblOrgWidth = objFontCls.getFontWidth(strTgt, strFontStyle, intSize, intFontType);
			}else { ////セルの書式が違う場合1文字ずつ調べる
				for (int i = 0; i < objOrgRichText.length(); i++) {
					XSSFFont objGetFont = objOrgRichText.getFontAtIndex(i);
					String strTmp = arrTmp[i];
			        String strFontStyle = objGetFont.getFontName(); //フォント名 ：ＭＳ Ｐゴシック等
			        int intSize = objGetFont.getFontHeightInPoints(); //フォントサイズ
			        boolean blBold = objGetFont.getBold(); //太字判定
			        boolean blItalic = objGetFont.getItalic(); //斜体判定
			        int intFontType = 0;
			        double dblTmpFontWidth = 0.0;
					intFontType = objFontCls.getFontType(blBold, blItalic);
					dblTmpFontWidth = objFontCls.getFontWidth(strTmp, strFontStyle, intSize, intFontType);
					dblOrgWidth += dblTmpFontWidth;
				} //for
			}


			objLog.info("文字列幅"+dblOrgWidth);

//	        objStyle.setFillForegroundColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex()); //塗りつぶし色
//	        objStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND); //塗りつぶし
//	        objCell_i.setCellStyle(objStyle);


			//暫定 リッチテキストの文字列だけ置換



		} //if




		return intRet;
	} //cellMusk






} //ExcelTest
