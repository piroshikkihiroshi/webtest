package excel;

import java.awt.Color;
import java.awt.Desktop;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFShapeGroup;
import org.apache.poi.hssf.usermodel.HSSFSimpleShape;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFChart;
import org.apache.poi.xssf.usermodel.XSSFDrawing;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFShapeGroup;
import org.apache.poi.xssf.usermodel.XSSFSimpleShape;
import org.apache.poi.xssf.usermodel.XSSFTextParagraph;
import org.apache.poi.xssf.usermodel.XSSFTextRun;

import fontCnt.FontCnt;
import structure.RichTextStructure;

public class ExcelTest_20190812_4 {

	static Logger objLog = Logger.getLogger( ExcelTest.class );
	static FontCnt objFontCls = new FontCnt();
	final String MASK_MARK = "■"; //マスクする記号
	final int EXCEL_SPACE = 3; //Excelの文字間隔は3px(仮定)
	final String PROPORTIONAL_STR = "Ｐ"; //プロポーショナルを判定(暫定)
	public static void main(String[] args) {
		// 処理前の時刻を取得
		long startTime = System.currentTimeMillis();

		//設定
		String strMaskMsg = "メイ";

		//		String strFilePath = "C:/Users/ueda tatsuya/Desktop/test/test.xlsx";
		String strFilePath = "C:/Users/ueda tatsuya/Desktop/poisample-master/blog.goo.ne.jp_evergreen_19_mod.xlsx";
		String strCopyPath = strFilePath + "_" + System.currentTimeMillis() + ".xlsx";

		try {
			ExcelTest objExcelTest = new ExcelTest();
			objExcelTest.excelSetMask(strFilePath,strCopyPath,strMaskMsg);
		} catch (Exception e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}



		// 処理後の時刻を取得
		long endTime = System.currentTimeMillis();

		objLog.info("開始時刻：" + startTime + " ms");
		objLog.info("終了時刻：" + endTime + " ms");
		objLog.info("処理時間：" + (endTime - startTime) + " ms");
		File objMakeFile = new File(strCopyPath);
		try {
			Desktop.getDesktop().open(objMakeFile);
		} catch (IOException e) {
			e.printStackTrace();
		} //try

	} //main

	public void getAllStr(String strFilePath_i, String strOutPath_i,String strMaskMsg_i) {

		InputStream objIS;
		Workbook objWB = null;
		try {

			objIS = new FileInputStream(strFilePath_i);
			objWB = WorkbookFactory.create(objIS);
//			Font objFont = objWB.createFont();
//			objFont.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());

			//シートの値取得
			for (int i = 0; i < objWB.getNumberOfSheets(); i++) {
				Sheet sheet = objWB.getSheetAt(i);

				for (Row objRow : sheet) {
					for (Cell objCell : objRow) {

						cellMusk(objWB,objCell, strMaskMsg_i);


					} //for(objCell)
				} //for(objRow)
				//shapeの処理
				objLog.info("shape:");
				XSSFDrawing drawing = (XSSFDrawing) sheet.createDrawingPatriarch();
				//通常のシェイプ
				for (Object objShape : drawing.getShapes()) {
					handleShape(objWB,objShape);
				} //for

				objLog.info("Graf:");
				//Graf
				if (drawing != null) {
					List<XSSFChart> objCharts = drawing.getCharts();
					if (objCharts != null && objCharts.size() > 0) {
						int j = objCharts.size() ;
						for (j = 0; j < objCharts.size() ; j++) {
							XSSFChart objChart = objCharts.get(j);
							XSSFRichTextString objGrafRichText = objChart.getTitleText();
							Font objFont = objWB.createFont();
							objGrafRichText.applyFont(objFont); //フォント色


							objLog.info(objGrafRichText);
						} //for

					} //if
				} //if

			} //for(sheet)

    	    // 変更するエクセルファイルを指定
			FileOutputStream outFile  = new FileOutputStream(strOutPath_i);
    	    // 書き込み
    	    objWB.write(outFile);
    	    objLog.info(strOutPath_i + "出力完了");


		} catch (Exception e) {
			e.printStackTrace();
		} //try

	} //getAllStr


	// memo
	//図形の塗りつぶし色を設定するには、HSSFSimpleShapeクラスのsetFillColorメソッドを、
	//図形の枠線の色を設定するには、HSSFSimpleShapeクラスのsetLineStyleColorメソッドを、
	//図形の枠線の幅を設定するには、HSSFSimpleShapeクラスのsetLineWidthメソッドを、
	//図形の枠線の種類を設定するには、HSSFSimpleShapeクラスのsetLineStyleメソッドを使用します
	//オートシェイプを処理するメソッド
	public void handleShape(Workbook objWB_i,Object objShape_i) {
		String strTgt = "";

		//shapeの処理(XLSX形式)
		if (objShape_i instanceof XSSFSimpleShape) {
			XSSFSimpleShape objTgtShape = ((XSSFSimpleShape) objShape_i);
			strTgt = ((XSSFSimpleShape) objShape_i).getText();
			for (int i = 0; i < objTgtShape.getTextParagraphs().size(); i++) {
				XSSFTextParagraph objParag = objTgtShape.getTextParagraphs().get(i);
				for (int j = 0; j < objParag.getTextRuns().size(); j++) {
					XSSFTextRun objTextRun = objParag.getTextRuns().get(j);
					objTextRun.setFontColor(Color.BLACK);
					objTextRun.setText("value you want to set");
				} //for j
			} //for i



		}
		//shapeの処理(XLS形式)
		if (objShape_i instanceof HSSFSimpleShape) {
			XSSFSimpleShape objTgtShape = ((XSSFSimpleShape) objShape_i);
			objTgtShape.setLineStyle(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
			strTgt = ((HSSFSimpleShape) objShape_i).getString().getString();

		}
		//グループ化されたshapeの処理(XLSX形式)
		if (objShape_i instanceof XSSFShapeGroup) {
			((XSSFShapeGroup) objShape_i).forEach(gs -> handleShape(objWB_i,gs));
		}
		//グループ化されたshapeの処理(XLS形式)
		if (objShape_i instanceof HSSFShapeGroup) {
			((HSSFShapeGroup) objShape_i).forEach(gs -> handleShape(objWB_i,gs));
		}


		if(!strTgt.contentEquals("")) objLog.info(strTgt);


	} //handleShape



	/**
	 * @param objCell_i
	 * @param strMaskMsg_i
	 * @return
	 */
	@SuppressWarnings("deprecation")
	public int cellMusk(Workbook objWB_i,Cell objCell_i,String strMaskMsg_i) {
		int intRet = 0;
        String strTgt = "";

		switch (objCell_i.getCellType()) {
		case NUMERIC:
			objLog.info("[row" + (objCell_i.getRowIndex() + 1) + ":clm" + (objCell_i.getColumnIndex() + 1) + "]" + "[NUMRIC]" + objCell_i.getNumericCellValue());
			strTgt = String.valueOf(objCell_i.getNumericCellValue());
			break;
		case STRING:
			objLog.info("[row" + (objCell_i.getRowIndex() + 1) + ":clm" + (objCell_i.getColumnIndex() + 1) + "]" + "[STRING]" + objCell_i.getStringCellValue());
			strTgt = objCell_i.getStringCellValue();
			break;
		case FORMULA:
			objLog.info("[row" + (objCell_i.getRowIndex() + 1) + ":clm" + (objCell_i.getColumnIndex() + 1) + "]" + "[FORMULA]" + objCell_i.getCellFormula());
			strTgt = objCell_i.getCellFormula();
			break;
		case BOOLEAN:
			objLog.info("[row" + (objCell_i.getRowIndex() + 1) + ":clm" + (objCell_i.getColumnIndex() + 1) + "]" + "[BOOLEAN]" + objCell_i.getBooleanCellValue());
			strTgt = String.valueOf(objCell_i.getBooleanCellValue());
			break;
		case ERROR:
			objLog.info("[row" + (objCell_i.getRowIndex() + 1) + ":clm" + (objCell_i.getColumnIndex() + 1) + "]" + "[ERROR  ]" + objCell_i.getErrorCellValue());
			strTgt = String.valueOf(objCell_i.getErrorCellValue());

			break;
//		case BLANK:
//			continue;
//		default:
//			continue;
		} //switch

		if (strTgt.contains(strMaskMsg_i)) { //マスク対象の場合置換処理

			//置換対象の文字幅を調べる
			double dblOrgWidth = 0.0;
			String strNotGetFont = "<xml-fragment/>"; //cell内のフォントが異なると最初は取得できないので調べる文字列
			XSSFRichTextString objDelRichText = null; //マスク対象文字列を削除したリッチテキスト
			//セルの書式が全て同じ場合getFontName()はnullが帰ってくるのでTry catchで判断
			String[] arrTmp = strTgt.split("");
			boolean blEqualStyle = false;

			List<RichTextStructure> listRichText = new ArrayList<RichTextStructure>(); //リッチテキスト用代替構造体格納用リスト
			List<Integer> listIdx = containStr(strTgt,strMaskMsg_i); //strMaskMsg_iが格納されているIDX格納
//			int intMaskCnt = 1; //strMaskMsg_iのカウント用
//			int intMaskLen = strMaskMsg_i.length(); //


			XSSFRichTextString objOrgRichText = (XSSFRichTextString)objCell_i.getRichStringCellValue();
			try {
				XSSFFont objGetFont = objOrgRichText.getFontAtIndex(0);
				String strTmp = arrTmp[0];
		        String strFontStyle = objGetFont.getFontName(); //フォント名 ：ＭＳ Ｐゴシック等
			} catch (Exception e) {
				blEqualStyle = true;
			} //try

			if(blEqualStyle) {
				objLog.info(strTgt + "は書式が統一なのでまとめて文字幅を判定します。");
			}else {
				objLog.info(strTgt + "は書式が異なるのでChar毎に文字幅を判定します。");
			} //if



			//置換対象の文字幅を調べる
			XSSFCellStyle objXssCellStyle = (XSSFCellStyle) objCell_i.getCellStyle();
	        XSSFFont objOrgGetFont = objXssCellStyle.getFont();
	        String strOrgFontStyle = objOrgGetFont.getFontName(); //フォント名 ：ＭＳ Ｐゴシック等
	        int intOrgSize = objOrgGetFont.getFontHeightInPoints(); //フォントサイズ
	        boolean blOrgBold = objOrgGetFont.getBold(); //太字判定
	        boolean blOrgItalic = objOrgGetFont.getItalic(); //斜体判定
	        int intOrgFontType = 0; //線の種類 PLAIN:0 BOLD:1 ITALIC:2 3:BOLD + ITALIC
			intOrgFontType = objFontCls.getFontType(blOrgBold, blOrgItalic);


			String strTmp ="";
			String strFontStyle ="";
			int intSize =0;
			boolean blBold =false;
			boolean blItalic =false;
			int intFontType =0;
			double dblTmpFontWidth =0.0;
			boolean blTmpPFlag = false;

			if(blEqualStyle) {
				dblOrgWidth = objFontCls.getFontWidth(strTgt, strOrgFontStyle, intOrgSize, intOrgFontType);
			}else { ////セルの書式が違う場合1文字ずつ調べる
				for (int i = 0; i < objOrgRichText.length(); i++) {

					XSSFFont objGetFont = objOrgRichText.getFontAtIndex(i);
					String strGetFontChk = objGetFont.getCTFont().toString();
					if(strGetFontChk.equalsIgnoreCase(strNotGetFont)) { //この条件だと標準フォントが使用されるので1文字だと取得できない
						strTmp = arrTmp[i];
						strFontStyle = strOrgFontStyle;
						intSize= intOrgSize;
				        if(strFontStyle.contains(PROPORTIONAL_STR)) { //プロポーショナル判定
				        	blTmpPFlag = true;
				        }else {
				        	blTmpPFlag = false;
				        } //if

						blBold = blOrgBold;
						blItalic = blOrgItalic;
						intFontType =intOrgFontType;
						dblTmpFontWidth = objFontCls.getFontWidth(strTmp, strFontStyle, intSize, intFontType);
						dblOrgWidth += dblTmpFontWidth;
					}else {
						strTmp = arrTmp[i];
				        strFontStyle = objGetFont.getFontName(); //フォント名 ：ＭＳ Ｐゴシック等
				        intSize = objGetFont.getFontHeightInPoints(); //フォントサイズ
				        if(strFontStyle.contains(PROPORTIONAL_STR)) { //プロポーショナル判定
				        	blTmpPFlag = true;
				        }else {
				        	blTmpPFlag = false;
				        } //if
				        blBold = objGetFont.getBold(); //太字判定
				        blItalic = objGetFont.getItalic(); //斜体判定
				        intFontType = 0;
				        dblTmpFontWidth = 0.0;
						intFontType = objFontCls.getFontType(blBold, blItalic);
						dblTmpFontWidth = objFontCls.getFontWidth(strTmp, strFontStyle, intSize, intFontType);
						dblOrgWidth += dblTmpFontWidth;

					} //if

					//RichTextStructureを作成
					RichTextStructure objTmp = new RichTextStructure();

					objTmp.strTgt = strTmp;
					objTmp.dblStrWidth = dblTmpFontWidth;
					if(listIdx.contains(i +1 )) {objTmp.blMask = true;} //if
					objTmp.strFontStyle = strFontStyle;
					objTmp.intSize = intSize;
					objTmp.intFontType =intFontType;
					objTmp.shColor = objGetFont.getColor();
					objTmp.bteUnderline = objGetFont.getUnderline();
					objTmp.blStrikeout = objGetFont.getStrikeout();
					objTmp.blPFlag = blTmpPFlag;

					System.out.println("aaaaa:" + objTmp.strFontStyle);

					listRichText.add(objTmp);
				} //for
			} //if
			listRichText.get(0).dblStrAllWidth = dblOrgWidth; //listの0に全体の長さを格納
			objLog.info("Cell 文字列幅："+listRichText.get(0).dblStrAllWidth);
//			//文字間調整
//			excelCharSpace(listRichText);
//			objLog.info("Cell 文字列幅調整後："+listRichText.get(0).dblStrAllWidth);

			//置換文字列をマスク文字へ変更
			List<RichTextStructure> listRepRichText = delRichTextStructure(listRichText);

//			ここが問題

			XSSFRichTextString objRepRichText = createRichText(objWB_i,listRepRichText,objXssCellStyle,objCell_i);
//			RichTextString aaa = ;
		  //セルスタイルを作成し、最初のフォントを割り当てます
//		  HSSFCellStyle style = (HSSFCellStyle) objCell_i.getCellStyle();
//		  style.setFont(style.getFont(objWB_i));
//
//		  HSSFCell hssfCell = row.createCell（idx）;
//			HSSFCell hssfCell = (HSSFCell) objCell_i;
//			objCell_i.setBlank(); //これでも壊れる
//			objCell_i.setCellValue(objRepRichText);


			//※これは通る
//			  //セルスタイルを作成し、最初のフォントを割り当てます
//			  CellStyle style = objWB_i.createCellStyle();
//
//			  // 灰色
//			  Font font_gray = objWB_i.createFont( );
//			  font_gray.setColor((short) 10);
//			  String value = "■■■";
//			  XSSFRichTextString rtext = new XSSFRichTextString(value);
//			  // 灰色
//			  rtext.applyFont(0, 1, font_gray);
//			  //スタイルの設定
//			  objCell_i.setCellStyle(style);
//			  objCell_i.setCellValue(rtext);





			  System.out.println();
//			  style.setFont(font1);
//
//
//
//			  HSSFCell hssfCell = row.createCell(idx);
//			  hssfCell.setCellStyle(style);
//
//			  //リッチテキストは、セルスタイルをオーバーライドする1回の実行で構成されます
//			  HSSFRichTextString richString = new HSSFRichTextString( "Hello、World！");
//			  richString.applyFont(6、13、font2);
//			  hssfCell.setCellValue(richString)


			//セルに反映

			objLog.info("Cell 「" + strMaskMsg_i + "」置換完了");


//	        objStyle.setFillForegroundColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex()); //塗りつぶし色
//	        objStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND); //塗りつぶし
//	        objCell_i.setCellStyle(objStyle);


			//暫定 リッチテキストの文字列だけ置換



		} //if

		return intRet;
	} //cellMusk


	//excelの文字間隔を考慮する
	//listRichText_i 参照渡し
//	public void excelCharSpace(List<RichTextStructure> listRichText_i) {
//
//		int intStrCnt = listRichText_i.size();
//		int intExcelSpace = (intStrCnt - 1) * EXCEL_SPACE;
//		double dblSpace = listRichText_i.get(0).dblStrAllWidth - intExcelSpace;
//		listRichText_i.get(0).dblStrAllWidth = dblSpace;
//		if(listRichText_i.get(0).dblStrAllWidth < 0) {listRichText_i.get(0).dblStrAllWidth = 1;}
//
//	} //excelCharSpace


	public XSSFRichTextString createRichText(Workbook objWB_i,List<RichTextStructure> listRichText_i,XSSFCellStyle objXssCellStyle_i,Cell objCell_i) {

		XSSFRichTextString objMakeRichText = null;
		StringBuffer objSB = new StringBuffer();
		String strTgt  = "";
		//まずは文字列を作成
		for (int i = 0; i < listRichText_i.size(); i++) {
			objSB.append(listRichText_i.get(i).strTgt);
		} //for
		strTgt = objSB.toString();
		objMakeRichText = new XSSFRichTextString(strTgt);

		//リッチテキストに//スタイル,フォントを適用させる
		for (int i = 0; i < listRichText_i.size(); i++) {
			Font objFont = objWB_i.createFont();
			objFont.setFontName(listRichText_i.get(i).strFontStyle);
			objFont.setFontHeightInPoints((short)listRichText_i.get(i).intSize);
			objFont.setColor(listRichText_i.get(i).shColor);
			if (listRichText_i.get(i).intFontType == 0) {
				objFont.setBold(false);
				objFont.setItalic(false);
			}else if (listRichText_i.get(i).intFontType == 1) {
				objFont.setBold(true);
				objFont.setItalic(false);
			}else if (listRichText_i.get(i).intFontType == 3) {
				objFont.setBold(true);
				objFont.setItalic(true);
			} //if
			objFont.setUnderline(listRichText_i.get(i).bteUnderline);
			objFont.setStrikeout(listRichText_i.get(i).blStrikeout);

			objMakeRichText.applyFont(i, i + 1, objFont);

//			if (i == 14) {
//				break;
//			}



		} //for

		CellStyle style = objWB_i.createCellStyle();
		//スタイルの設定
		objCell_i.setCellStyle(style);
		objCell_i.setCellValue(objMakeRichText);

		return objMakeRichText;

	} //createRichText

	public List<RichTextStructure> delRichTextStructure(List<RichTextStructure> listRichText_i){
		List<RichTextStructure> listRepRichText = new ArrayList<RichTextStructure>();
		for (int i = 0; i < listRichText_i.size(); i++) {
			if (listRichText_i.get(i).blMask) {
				//マスク文字を足す
//				if(listRichText_i.get(i).dblStrWidth - EXCEL_SPACE > 0) { //文字間隔対応
//				for (int j = 0; j < listRichText_i.get(i).dblStrWidth - EXCEL_SPACE; j++) {
//					listRepRichText.add(getMascStructure());
//				} //for
//				} //if
				double intWidthLen = 0.0; //プロポーショナルの場合と分ける
				if (listRichText_i.get(i).blPFlag) {
					intWidthLen = listRichText_i.get(i).dblStrWidth - EXCEL_SPACE; //プロポーショナルは文字間隔調整できないので調整しようと思ったが断念
				}else {
					intWidthLen = listRichText_i.get(i).dblStrWidth - EXCEL_SPACE;
				} //if
				for (int j = 0; j < intWidthLen; j++) {
					listRepRichText.add(getMascStructure());
				} //for


			}else {
				listRepRichText.add(listRichText_i.get(i));
			} //if
		} //for
		listRepRichText.get(0).dblStrAllWidth = listRichText_i.get(0).dblStrAllWidth;

//		double aaa = 0.0;
		for (int i = 0; i < listRepRichText.size(); i++) {
			System.out.println(listRepRichText.get(i).strFontStyle);;
		}

		return listRepRichText;
	} //delRichTextStructure

	public RichTextStructure getMascStructure() {
		RichTextStructure objRichTextStr = new RichTextStructure();
		objRichTextStr.strTgt =MASK_MARK;
		objRichTextStr.dblStrWidth = 1.0; //strTgtの文字幅
		objRichTextStr.blMask = false; //マスク対象か True;マスク対象
		objRichTextStr.strFontStyle="ＭＳ ゴシック"; //フォント名 ：ＭＳ Ｐゴシック等
		objRichTextStr.intSize=1; //フォントサイズ
		objRichTextStr.intFontType=0; //線の種類 PLAIN:0 BOLD:1 ITALIC:2 3:BOLD + ITALIC
		objRichTextStr.shColor = 0; //フォントの色
		objRichTextStr.bteUnderline = 0; //アンダーライン
		objRichTextStr.blStrikeout = false; //取り消し線
		objRichTextStr.dblStrAllWidth=0.0; //元のリッチテキスト全体の文字幅
		return objRichTextStr;

	} //getMascStructure


	/**
	 * strTgt_iでtrSearch_iが始まるindexをListで返す
	 * @param strTgt_i
	 * @param strSearch_i
	 * @return
	 */
	public List containStr (String strTgt_i,String strSearch_i) {

		List<Integer> listRet = new ArrayList<Integer>();

        int intIndex;
        int intSearchLen = strSearch_i.length();
        int intSerchCnt = 1;

        for (int i = 0; i < strTgt_i.length(); i++) {
            intIndex = strTgt_i.indexOf(strSearch_i, i);
            if (intIndex != -1) {
            	for (int j = intIndex; j < intSearchLen + intIndex; j++) {
                	listRet.add(j + 1); //Stringのlengthは1から始まるので合わせる
				}//for

                i = intIndex;
            } //if
        } //for


		return listRet;

	} //containStr




} //ExcelTest
