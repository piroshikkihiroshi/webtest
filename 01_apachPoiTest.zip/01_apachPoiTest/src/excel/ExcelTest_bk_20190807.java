package excel;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFShapeGroup;
import org.apache.poi.hssf.usermodel.HSSFSimpleShape;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFChart;
import org.apache.poi.xssf.usermodel.XSSFDrawing;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFShapeGroup;
import org.apache.poi.xssf.usermodel.XSSFSimpleShape;

public class ExcelTest_bk_20190807 {

	public static void main(String[] args) {

		// 処理前の時刻を取得
		long startTime = System.currentTimeMillis();

		//		String strFilePath = "C:/Users/ueda tatsuya/Desktop/test/test.xlsx";
		String strFilePath = "C:/Users/ueda tatsuya/Desktop/poisample-master/blog.goo.ne.jp_evergreen_19_mod.xlsx";
		StringBuilder objSb = new StringBuilder();
		ExcelTest_bk_20190807 objExcelTest = new ExcelTest_bk_20190807();

		objExcelTest.getAllStr(strFilePath, objSb);

		// 処理後の時刻を取得
		long endTime = System.currentTimeMillis();

		System.out.println("開始時刻：" + startTime + " ms");
		System.out.println("終了時刻：" + endTime + " ms");
		System.out.println("処理時間：" + (endTime - startTime) + " ms");

	} //main

	public void getAllStr(String strFilePath_i, StringBuilder objSb_i) {

		InputStream objIS;
		Workbook objWB = null;
		//		try {
		//			objIS = new FileInputStream(strFilePath_i);
		//			objWB = WorkbookFactory.create(objIS);
		//
		//			// 全シートを繰り返し処理する場合
		//			Iterator<Sheet> objSheets = objWB.sheetIterator();
		//			while(objSheets.hasNext()) {
		//				Sheet objSheet = objSheets.next();
		//				System.out.println(objSheet.getSheetName());
		//			} //while
		//
		//
		//		} catch (FileNotFoundException e) {
		//			e.printStackTrace();
		//		} catch (IOException e) {
		//			e.printStackTrace();
		//		} catch(Exception e) {
		//			e.printStackTrace();
		//		}
		//
		//		try {
		//			objWB.close();
		//		} catch (IOException e) {
		//			// TODO 自動生成された catch ブロック
		//			e.printStackTrace();
		//		}
		StringBuilder sb = new StringBuilder();
		try {
			//            // 出力先ファイルをコピーしてから書き換える
			//            Files.copy(Paths.get(filenameSrc), Paths.get(filenameDest), StandardCopyOption.REPLACE_EXISTING);

			objIS = new FileInputStream(strFilePath_i);
			objWB = WorkbookFactory.create(objIS);

			for (int i = 0; i < objWB.getNumberOfSheets(); i++) {
				Sheet sheet = objWB.getSheetAt(i);

				for (Row row : sheet) {
					for (Cell cell : row) {

						sb.append("[").append(cell.getSheet().getSheetName()).append("]");
						sb.append(cell.getRowIndex()).append(":").append(cell.getColumnIndex());

						switch (cell.getCellType()) {
						case NUMERIC:
							sb.append("[NUMRIC ]").append(cell.getNumericCellValue());
							break;
						case STRING:
							sb.append("[STRING ]").append(cell.getStringCellValue());
							break;
						case FORMULA:
							sb.append("[FORMULA]").append(cell.getCellFormula());
							break;
						case BOOLEAN:
							sb.append("[BOOLEAN]").append(cell.getBooleanCellValue());
							break;
						case ERROR:
							sb.append("[ERROR  ]").append(cell.getErrorCellValue());
							break;
						case BLANK:
							continue;
						default:
							continue;
						} //switch

						//						System.out.println(sb);
					} //for

					//shapeの処理
					XSSFDrawing drawing = (XSSFDrawing) sheet.createDrawingPatriarch();
					//通常のシェイプ
					for (Object shape : drawing.getShapes()) {
						handleShape(shape, sb);
					} //for

					//Graf
					if (drawing != null) {
						List<XSSFChart> charts = drawing.getCharts();
						if (charts != null && charts.size() > 0) {
							XSSFChart chart = charts.get(0);
							XSSFRichTextString objGrafTitle = chart.getTitleText();
							sb.append(objGrafTitle.toString());
						} //if
					} //if

				} //for
			} //for
		} catch (Exception e) {
			e.printStackTrace();
		} //try

		System.out.println(sb);
	} //getAllStr

	//オートシェイプを処理するメソッド
	public void handleShape(Object d, StringBuilder sb) {
		String s = "";
		//shapeの処理(XLSX形式)
		if (d instanceof XSSFSimpleShape) {
			s = ((XSSFSimpleShape) d).getText();
		}
		//shapeの処理(XLS形式)
		if (d instanceof HSSFSimpleShape) {
			s = ((HSSFSimpleShape) d).getString().getString();
		}
		//グループ化されたshapeの処理(XLSX形式)
		if (d instanceof XSSFShapeGroup) {
			((XSSFShapeGroup) d).forEach(gs -> handleShape(gs, sb));
		}
		//グループ化されたshapeの処理(XLS形式)
		if (d instanceof HSSFShapeGroup) {
			((HSSFShapeGroup) d).forEach(gs -> handleShape(gs, sb));
		}
		//        result.add(func.apply(s));
		//        System.out.println(s);
		sb.append(s);
	} //handleShape

} //ExcelTest
