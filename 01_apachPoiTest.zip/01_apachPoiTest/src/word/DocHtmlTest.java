package word;

import java.awt.Desktop;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.apache.poi.hwpf.HWPFDocumentCore;
import org.apache.poi.hwpf.converter.WordToHtmlConverter;
import org.apache.poi.hwpf.converter.WordToHtmlUtils;

public class DocHtmlTest {
	static Logger objLog = Logger.getLogger(DocHtmlTest.class);

	public static void main(String[] args) {
		// 処理前の時刻を取得
		long startTime = System.currentTimeMillis();

		//設定
		String strMaskMsg = "メイ";

//		String strFilePath = "C:/Users/ueda tatsuya/Desktop/poisample-master/test.docx";
//		String strCopyPath = strFilePath + "_" + System.currentTimeMillis() + ".docx";
		String strFilePath = "C:/Users/ueda tatsuya/Desktop/poisample-master/test.doc";
		String strCopyPath = strFilePath + "_" + System.currentTimeMillis() + ".html";


		DocHtmlTest objWordTest = new DocHtmlTest();
		objWordTest.wordSetMask(strFilePath, strCopyPath, strMaskMsg);

		// 処理後の時刻を取得
		long endTime = System.currentTimeMillis();

		objLog.info("開始時刻：" + startTime + " ms");
		objLog.info("終了時刻：" + endTime + " ms");
		objLog.info("処理時間：" + (endTime - startTime) + " ms");
		File objMakeFile = new File(strCopyPath);
		try {
			Desktop.getDesktop().open(objMakeFile);
		} catch (IOException e) {
			e.printStackTrace();
		} //try


	} //main


	/**
	 * @param strFilePath_i
	 * @param strOutPath_i
	 * @param strMaskMsg_i
	 */
	public void wordSetMask(String strFilePath_i, String strOutPath_i, String strMaskMsg_i) {

		try {

		    HWPFDocumentCore wordDocument = WordToHtmlUtils.loadDoc(new FileInputStream(strFilePath_i));

		    WordToHtmlConverter wordToHtmlConverter = new WordToHtmlConverter(
		            DocumentBuilderFactory.newInstance().newDocumentBuilder()
		                    .newDocument());
		    wordToHtmlConverter.processDocument(wordDocument);
		    org.w3c.dom.Document htmlDocument = wordToHtmlConverter.getDocument();
		    ByteArrayOutputStream out = new ByteArrayOutputStream();
		    DOMSource domSource = new DOMSource(htmlDocument);
		    StreamResult streamResult = new StreamResult(out);

		    TransformerFactory tf = TransformerFactory.newInstance();
		    Transformer serializer = tf.newTransformer();
		    serializer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
		    serializer.setOutputProperty(OutputKeys.INDENT, "yes");
		    serializer.setOutputProperty(OutputKeys.METHOD, "html");
		    serializer.transform(domSource, streamResult);
		    out.close();

		    String result = new String(out.toByteArray());

			FileWriter file = new FileWriter(strOutPath_i);
			// PrintWriterクラスのオブジェクトを生成する
			PrintWriter pw = new PrintWriter(new BufferedWriter(file));

			//ファイルに書き込む
			pw.println(result);
			//ファイルを閉じる
			pw.close();


		    System.out.println(result);


		} catch (IOException e1) {
			// TODO 自動生成された catch ブロック
			e1.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} //try
	} 	//wordSetMask


} //WordTest
