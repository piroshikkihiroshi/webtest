package word;

import java.awt.Desktop;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;

public class DocxToPdf {
	static Logger objLog = Logger.getLogger(DocxToPdf.class);
//	static FontCnt objFontCls = new FontCnt();
	final String MASK_MARK = "━"; //マスクする記号
	//	final String MASK_MARK = "■"; //マスクする記号
	final int EXCEL_SPACE = 3; //Excelの文字間隔は3px(仮定)
	final String PROPORTIONAL_STR = "Ｐ"; //プロポーショナルを判定(暫定)

	public static void main(String[] args) {
		// 処理前の時刻を取得
		long startTime = System.currentTimeMillis();

		//設定
		String strMaskMsg = "メイ";

		String strFilePath = "C:/Users/ueda tatsuya/Desktop/poisample-master/test.docx";
		String strCopyPath = strFilePath + "_" + System.currentTimeMillis() + ".docx";
//		String strFilePath = "C:/Users/ueda tatsuya/Desktop/poisample-master/test.doc";
//		String strCopyPath = strFilePath + "_" + System.currentTimeMillis() + ".doc";


		DocxToPdf objWordTest = new DocxToPdf();
		objWordTest.wordSetMask(strFilePath, strCopyPath, strMaskMsg);

		// 処理後の時刻を取得
		long endTime = System.currentTimeMillis();

		objLog.info("開始時刻：" + startTime + " ms");
		objLog.info("終了時刻：" + endTime + " ms");
		objLog.info("処理時間：" + (endTime - startTime) + " ms");
		File objMakeFile = new File(strCopyPath);
		try {
			Desktop.getDesktop().open(objMakeFile);
		} catch (IOException e) {
			e.printStackTrace();
		} //try


	} //main


	/**
	 * @param strFilePath_i
	 * @param strOutPath_i
	 * @param strMaskMsg_i
	 */
	public void wordSetMask(String strFilePath_i, String strOutPath_i, String strMaskMsg_i) {
		XWPFDocument objDoc;
		InputStream objIS;
		try {
			objIS = new FileInputStream(strFilePath_i);
			objDoc = new XWPFDocument(objIS);

			for (XWPFParagraph objParagraph : objDoc.getParagraphs()) { //段落の取得
				List<XWPFRun> lstRuns = objParagraph.getRuns();
				if (lstRuns != null) {
					for (XWPFRun objRun : lstRuns) {
						String strText = objRun.getText(0);
						if (strText != null && strText.contains(strMaskMsg_i)) {
							strText = strText.replace(strMaskMsg_i, MASK_MARK);
							objRun.setText(strText, 0);
						} //if
					} //for
				} //if
			} //for

			//table処理
			for (XWPFTable objTbl : objDoc.getTables()) { //table
				for (XWPFTableRow objRow : objTbl.getRows()) {
					for (XWPFTableCell ObjCell : objRow.getTableCells()) {
						for (XWPFParagraph ObjParagraph : ObjCell.getParagraphs()) {
							for (XWPFRun objRun : ObjParagraph.getRuns()) {
								String strText = objRun.getText(0);
								if (strText.contains(strMaskMsg_i)) {
									strText = strText.replace(strMaskMsg_i, MASK_MARK);
									objRun.setText(strText);
								} //if
							} //for
						} //for
					} //for
				} //for
			} //for
			objDoc.write(new FileOutputStream(strOutPath_i));
			objDoc.close();
			objDoc = null;
		} catch (IOException e1) {
			// TODO 自動生成された catch ブロック
			e1.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} //try
	} 	//wordSetMask


} //WordTest
