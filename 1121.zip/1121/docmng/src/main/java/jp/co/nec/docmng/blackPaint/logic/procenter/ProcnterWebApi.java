package jp.co.nec.docmng.blackPaint.logic.procenter;

import java.io.File;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import jp.co.nec.docmng.blackPaint.entity.procenter.PrcenterConvert;
import jp.co.nec.docmng.blackPaint.entity.procenter.ProcenterEnt;

@Component

public class ProcnterWebApi {

	static Logger objLog = LoggerFactory.getLogger(ProcnterWebApi.class);

	/**
	 * PROCENTER/CのWEBAPIを呼び出す(form-urlencoded)
	 * @param String strUrl_i   webapiurl
	 * @param String strJson_i strUrl_iにわたすjsonString
	 * @return ProcenterEnt jacksonでコンバートしたbeen
	 * @throws Exception
	 */
	public ProcenterEnt getProCenterUrencode(String strUrl_i,String strJson_i) throws Exception{

		//header
		HttpHeaders objHeaders = new HttpHeaders();
		objHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

		//body
		MultiValueMap<String, String> hashQuery= new LinkedMultiValueMap<String, String>();
		String strEncoding = "UTF-8";
		String strEncJson = "";
		strEncJson=URLEncoder.encode(strJson_i, strEncoding);
		hashQuery.add("query", strEncJson);

		//Request
		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(hashQuery, objHeaders);

		RestTemplate restTemplate = new RestTemplate(new SimpleClientHttpRequestFactory());

		//Response
		ResponseEntity<String> entResponse = restTemplate.postForEntity( strUrl_i, request , String.class );

		//json convert
		PrcenterConvert prcenterConvert = new PrcenterConvert();
		ProcenterEnt procenterEnt = prcenterConvert.fromJsonString(entResponse.getBody());

		return procenterEnt;

	} //method

	/**
	 * PROCENTER/CのWEBAPIを呼び出す(multipart)
	 * ※ファイルアップロードときはこちらを呼び出す
	 * @param String strUrl_i   webapiurl
	 * @param String strJson_i strUrl_iにわたすjsonString
	 * @return ProcenterEnt jacksonでコンバートしたbeen
	 * @throws Exception
	 */
//	public ProcenterEnt getProCenterMultipart(String strUrl_i,String strSessionInfoJson_i,List<String> listFilePath_i) throws Exception{
	public String getProCenterMultipart(String strUrl_i,String strSessionInfoJson_i,List<String> listFilePath_i) throws Exception{

		//とりあえずそれっぽく 動作確認できたら修正
		String strBoundary = "---------------------------7dd24e3050716";

        //④HTTP処理用オプジェクト作成
		okhttp3.OkHttpClient client = new okhttp3.OkHttpClient();

		final String BOUNDARY = strBoundary;
        final okhttp3.MediaType TEXT =okhttp3.MediaType.parse("text/plain; charset=utf-8");

        okhttp3.MediaType objPdf = okhttp3.MediaType.parse("application/octet-stream");

		File objFile = new File(listFilePath_i.get(0));
		byte[] arrbytes = Files.readAllBytes(objFile.toPath());


		File objFile2 = new File(listFilePath_i.get(1));
		byte[] arrbytes2 = Files.readAllBytes(objFile2.toPath());


        okhttp3.RequestBody requestBody = new okhttp3.MultipartBody.Builder(BOUNDARY)
                .setType(okhttp3.MultipartBody.FORM)
                .addPart(
//                		okhttp3.Headers.of("Content-Disposition", "form-data; name=\"description\""),
                		okhttp3.Headers.of("Content-Disposition", "form-data; name=\"description\""),
                		okhttp3.RequestBody.create(TEXT, "discription")
                )
                .addFormDataPart(
                        "strBoundary\r\n",
                        "Content-Disposition: form-data; name=\"file_1\"; filename=\"sample.pdf\"",
                        okhttp3.RequestBody.create(objPdf, arrbytes)
                )
                .addFormDataPart(
                        "strBoundary\r\n",
                        "Content-Disposition: form-data; name=\"file_1\"; filename=\"sample2.pdf\"",
                        okhttp3.RequestBody.create(objPdf, arrbytes2)
                )
                .build();

        //⑥送信用リクエストを作成
        okhttp3.Request.Builder requestBuilder = new okhttp3.Request.Builder();
        requestBuilder.url(strUrl_i);
        requestBuilder.post(requestBody);
        okhttp3.Request request = requestBuilder.build();

        //⑦受信用オブジェクトを作成
        okhttp3.Call call = client.newCall(request);
        String result = "";


        //⑧送信と受信
        try {
        	okhttp3.Response response = call.execute();
        	okhttp3.ResponseBody body = response.body();
            if (body != null) {
                result = body.string();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }







        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);

        // This nested HttpEntiy is important to create the correct
        // Content-Disposition entry with metadata "name" and "filename"

		int index = 0;
		String strFileName = "";

		MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
//		index = listFilePath_i.get(0).lastIndexOf('/');
//		strFileName = listFilePath_i.get(0).substring(index + 1,listFilePath_i.get(0).length());

//		File objFile = new File(listFilePath_i.get(0));
//		byte[] arrbytes = Files.readAllBytes(objFile.toPath());
//		body.add("file", arrbytes);
//
//		HttpEntity<MultiValueMap<String, Object>> requestEntity
//		 = new HttpEntity<>(body, headers);
//
//		String serverUrl = strUrl_i;
//
//		RestTemplate restTemplate = new RestTemplate();
//		ResponseEntity<String> response = restTemplate.postForEntity(serverUrl, requestEntity, String.class);


//
//        MultiValueMap<String, String> fileMap = new LinkedMultiValueMap<>();
//        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
//        HttpEntity<MultiValueMap<String, Object>> requestEntity = null;
//
//		for (int i = 0; i < listFilePath_i.size(); i++) {
//			index = listFilePath_i.get(i).lastIndexOf('/');
//			strFileName = listFilePath_i.get(i).substring(index + 1,listFilePath_i.get(i).length());
//			File objFile = new File(listFilePath_i.get(i));
//			byte[] arrbytes = Files.readAllBytes(objFile.toPath());
//	        HttpEntity<byte[]> fileEntity = new HttpEntity<>(arrbytes, fileMap);
//	        if(i==0) {
//		        ContentDisposition contentDisposition = ContentDisposition
//		                .builder("form-data")
//		                .name("file_" + (i+1))
//		                .filename(strFileName)
//		                .build();
//		        fileMap.add(HttpHeaders.CONTENT_DISPOSITION, contentDisposition.toString());
//	        }
//
//
//	        body.add("file_" + (i+1),strFileName);
//	        body.add("file_" + (i+1), fileEntity);
//
//	        requestEntity = new HttpEntity<>(body, headers);
//
//		} //for
//
//
////        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, headers);
//        RestTemplate restTemplate = new RestTemplate(new SimpleClientHttpRequestFactory());
//        ResponseEntity<String> response=null;
//        try {
//            response = restTemplate.exchange(
//            		strUrl_i,
//                    HttpMethod.POST,
//                    requestEntity,
//                    String.class);
//        } catch (HttpClientErrorException e) {
//            e.printStackTrace();
//        }



		return "";
//		return procenterEnt;

	} //method



} //PolicyGet
