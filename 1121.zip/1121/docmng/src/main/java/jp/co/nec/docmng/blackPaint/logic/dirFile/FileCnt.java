package jp.co.nec.docmng.blackPaint.logic.dirFile;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;

public class FileCnt {
	/**
	 * File名から拡張子を抜いたファイル名を取得する。
	 * @param String strFileName_i ファイルのフルパス
	 * @return String 取得文字列
	 */
	synchronized public String getNameWithoutExtension(String strFileName_i) {
		int index = strFileName_i.lastIndexOf('.');
		if (index != -1) {
			return strFileName_i.substring(0, index);
		}
		return strFileName_i;
	} //getNameWithoutExtension


	/**
	 * strpath_iで指定したファイルを改行付きですべて読み込む
	 * @param strpath_i
	 * @return 読み込んだ文字列
	 * @throws IOException
	 */
	public String readAll(final String strpath_i) throws IOException {
		return Files.lines(Paths.get(strpath_i), Charset.forName("UTF-8"))
				.collect(Collectors.joining(System.getProperty("line.separator")));

	} //readAll

//    /**
//     * 複数のPDFを１つに結合する
//     * @param inputFiles
//     * @return 結合結果をバイナリで返す
//     */
//    public ByteArrayOutputStream PDFCombine(File[] inputFiles){
//        ByteArrayOutputStream arrBytes = new ByteArrayOutputStream();
//        List<PDDocument> pddHolder = new ArrayList<>();
//
//        try(PDDocument combiledPDFdoc= new PDDocument()){
//            for(File objFile : inputFiles){
//                try{
//                    PDDocument objPdfDoc = PDDocument.load(objFile);
//                    for(PDPage objPdfPage : objPdfDoc.getPages()) combiledPDFdoc.addPage(objPdfPage);
//                    pddHolder.add(objPdfDoc);
//                } catch (IOException ex) {
//                	System.err.println(ex);
//                }
//            }
//            combiledPDFdoc.save(arrBytes);
//            // Save後に開放可能、Save前に開放すると上手く動かない
//            pddHolder.stream().sequential().forEach(item -> {
//                try {item.close();} catch (IOException ex) {}
//            });
//        } catch (IOException ex) {
//        	System.err.println(ex);
//        } //try
//        return arrBytes;
//    } //method

    /**
     * 複数のPDFを１つに結合する(文字コード変換)
     * @param inputFiles
      * @param 文字コード
     * @return 結合結果をバイナリで返す
     */
//    public ByteArrayOutputStream PDFCombine(File[] inputFiles,String strCode_i){
        public ByteArrayOutputStream PDFCombine(File[] inputFiles){

        ByteArrayOutputStream arrBytes = new ByteArrayOutputStream();

        List<PDDocument> pddHolder = new ArrayList<>();

        try(PDDocument combiledPDFdoc= new PDDocument()){
            for(File objFile : inputFiles){
                try{
            		byte[] byteFile = null;
        			byteFile = Files.readAllBytes(objFile.toPath());
//        			String line = new String(byteFile, "SJIS");
//        			byte[] byteEnc = line.getBytes(StandardCharsets.UTF_8.toString());
//        			String line = new String(byteFile, "UTF-8");
//        			byte[] byteEnc = line.getBytes("Shift_JIS");

//                    PDDocument objPdfDoc = PDDocument.load(objFile);
//        			PDDocument objPdfDoc =PDDocument.load(byteFile);
        			PDDocument objPdfDoc =PDDocument.load(byteFile);
                    for(PDPage objPdfPage : objPdfDoc.getPages()) combiledPDFdoc.addPage(objPdfPage);
                    pddHolder.add(objPdfDoc);
                } catch (IOException ex) {
                	System.err.println(ex);
                }
            }
            combiledPDFdoc.save(arrBytes);
            // Save後に開放可能、Save前に開放すると上手く動かない
            pddHolder.stream().sequential().forEach(item -> {
                try {item.close();} catch (IOException ex) {}
            });
        } catch (IOException ex) {
        	System.err.println(ex);
        } //try
        return arrBytes;
    } //method




} //FileCnt
