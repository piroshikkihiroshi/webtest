package jp.co.nec.docmng.blackPaint.controller;

import javax.servlet.ServletContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jp.co.nec.docmng.blackPaint.logic.HtmlToPdf.HtmlToPdfModel;

/**
 * @author uedatats
 * maskしたhtmlを受け取りPDFへ変換する
 */
@Controller
public class MakePdfCnt {
	static Logger objLog = LoggerFactory.getLogger(MakePdfCnt.class);

	@Autowired
	ServletContext context;

	@PostMapping("/MakePdfCnt")
	public String postMakePdf(@RequestParam("maskPdfHtml") String strMaskPdfHtml_i,@RequestParam("tmpDir") String strTmpDir_i,Model model)  {

		String strMaskPdfHtml = strMaskPdfHtml_i;
		String strTmpDir = strTmpDir_i;
//		String strTmpDir = "tmp1567039817146/"; //debug
        String strRealPath = context.getRealPath("/");
        String strPdfName = "mask.pdf";
		String strPdfFllPath = strRealPath + "/" + strTmpDir + strPdfName;

		//pdfを作成する
		HtmlToPdfModel objPdfCls = new HtmlToPdfModel();
		//objPdfCls.convertHtmlToPdf(strMaskPdfHtml, strRealPath + strTmpDir, strPdfFllPath);
		objLog.info("pdf出力完了");
		model.addAttribute("strPdfOutPath", "/" + strTmpDir + strPdfName);

		return "blackPaint/MaskPdfVeiw";
	} //postMakePdf




}
