package jp.co.nec.docmng.blackPaint.util.api;

import java.io.File;

import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nec.docmng.blackPaint.repository.PolicyInfoMapPaint;



@RestController
public class TestPdf {

	@Autowired
	PolicyInfoMapPaint objPolicyInfoService;


	@GetMapping("/rest/aaa")
	public String getPdf(){
		String strRet = "";
        try {
            File f1 = new File("C:\\Users\\ueda tatsuya\\Desktop\\tmp1574286932168\\mask_1574286943602split\\mask_1.pdf");
            File f2 = new File("C:\\Users\\ueda tatsuya\\Desktop\\tmp1574286932168\\mask_1574286943602split\\mask_2.pdf");
            PDFMergerUtility ut = new PDFMergerUtility();
            ut.addSource(f1);
            ut.addSource(f2);
            ut.setDestinationFileName("C:\\Users\\ueda tatsuya\\Desktop\\tmp1574286932168\\mask_1574286943602split\\mask_bbbbbbbb.pdf");
            ut.mergeDocuments();


        } catch (Exception ex) {
        	System.err.println(ex);
        }
		return strRet;
	} //getPlicyAll

} //PolicyGet
