/**
 * 名称：SaveTmpDocCnt.java
 * 機能名：一時保存Control
 * 概要：一時保存機能のControlを行う。
 */

package jp.co.nec.docmng.blackPaint.controller;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.zeroturnaround.zip.ZipUtil;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.blackPaint.entity.TmpMaskDocMarkerEntBlackPaint;
import jp.co.nec.docmng.blackPaint.entity.TmpMaskDocumentEntBlackPaint;
import jp.co.nec.docmng.blackPaint.logic.dirFile.DirCnt;
import jp.co.nec.docmng.blackPaint.logic.dirFile.FileCnt;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocTmpMarkerService;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocumentService;

/**
 * 一時保存機能のControlを行う。
 */
@RestController
public class SaveTmpDocCnt {

	/**
	 * context サーブレットのRealPathを取得する
	 * objLog log出力に使用する
	 * PAGE_CLASS ページを判定するHTMLClass。ページをSplitするのに使用する
	 * ARR_HEAD ファイル名、フォルダ名を判定するために使用する
	 */
	@Autowired
	ServletContext context;
	@Autowired
	TmpMaskDocumentService tmpMaskDocumentService;
	@Autowired
	TmpMaskDocTmpMarkerService tmpMaskDocTmpMarkerService;

	static Logger objLog = LoggerFactory.getLogger(SaveTmpDocCnt.class);

	static String PAGE_CLASS = "awdiv awpage"; //splitするページのHTMLClass
	static String[] ARR_HEAD = { "mask_", "red_" }; //ファイル名、フォルダ名のヘッダー配列

	/**
	 * 一時保存メソッド
	 * 一時保存を押下したときの処理制御をする。
	 * @param strHashJson 以下の値を入れ込んだjsonString
	 * strTmpDir 黒塗り編集画面で処理したHTMLが格納されたTMPディレクトリ名。
	 * strRedHtml 黒塗り編集候補HTMLのouterHTML。
	 * strMaskHtml 黒塗り編集HTMLのouterHTML。
	 * strFileName オリジナルwordファイル名。
	 * documentId ドキュメントID
	 */
	@ResponseBody
	@PostMapping("/blackpaint/SaveTmpDocCnt")
	@ResponseStatus(HttpStatus.OK)
	public String SaveTmpDocCntRest(
			@RequestBody String strHashJson,
			@CookieValue(value = "user_id", required = false) String UserId,
			Model model) {

		//モデル初期化
		FileCnt objFileCnt = new FileCnt();
		DirCnt objDirCls = new DirCnt();

		//メンバ変数初期化
		String strTmpDir = ""; //黒塗り編集画面で処理したHTMLが格納されたTMPディレクトリ名。
		String strRedHtml = ""; //黒塗り編集候補HTMLのouterHTML。
		String strMaskHtml = ""; //黒塗り編集HTMLのouterHTML。
		String strFileName = ""; //オリジナルwordファイル名。
		int intDocumentId = -1; //documentId
		String strListJson = ""; //黒塗りリストの情報のjson

		String strBasePath = ""; //黒塗り作成時の作業フォルダ
		String strHead = ""; //ファイル名、フォルダ名のヘッダー
		String strFileOutDir = ""; //PDF出力フォルダ
		String strHtmlDir = ""; //黒塗り作成時HTMLに対するimg,css等が入っているフォルダ
		String strRealPath = context.getRealPath("/");
		String strTmpTimeStamp = ""; //tempファイルタイムスタンプ

		//以下黒塗りリスト配列
		String[] glArrBfIds = null;
		String[] glArrAfIds = null;
		String[] glArrPolicys = null;
		String[] glRemarks = null;

		strTmpTimeStamp = String.valueOf(System.currentTimeMillis());

		//POSTされたjsonをパースする
		ObjectMapper objMapper = new ObjectMapper();
		List<Map<String, String[]>> objTmpList = null;
		TypeReference<List<Map<String, String[]>>> objType = new TypeReference<List<Map<String, String[]>>>() {
		};
		try {
			objTmpList = objMapper.readValue(strHashJson, objType);
		} catch (JsonParseException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} catch (JsonMappingException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} catch (IOException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} //try

		HashMap<String, String[]> objMap = (HashMap<String, String[]>) objTmpList.get(0);

		Object objTmp = null;
		for (String strKey : objMap.keySet()) {
			switch (strKey) {
			case "tmpDir":
				strTmpDir = objMap.get(strKey)[0];
				break;
			case "strRedHtml":
				strRedHtml = objMap.get(strKey)[0];
				break;
			case "strMaskHtml":
				strMaskHtml = objMap.get(strKey)[0];
				break;
			case "strFileName":
				strFileName = objMap.get(strKey)[0];
				break;
			case "documentId":
				intDocumentId = Integer.parseInt(objMap.get(strKey)[0]);
				break;
			case "glArrBfIds":
				glArrBfIds = (String[]) objMap.get(strKey);
				break;
			case "glArrAfIds":
				glArrAfIds = (String[]) objMap.get(strKey);
				break;
			case "glArrPolicys":
				glArrPolicys = (String[]) objMap.get(strKey);
				break;
			case "glRemarks":
				glRemarks = (String[]) objMap.get(strKey);
				break;
			default:
				break;
			}//switch

		} //for

		//拡張子無しファイル名取得
		String strFileWithoutExtension = objFileCnt.getNameWithoutExtension(strFileName);

		//出力フォルダ作成
		strBasePath = strRealPath + strTmpDir;
		strFileOutDir = strRealPath + "tmp" + strTmpTimeStamp + "/";
		Path objSrcPath = Paths.get(strBasePath);
		Path objTgtPath = Paths.get(strFileOutDir);
		try {
			Files.copy(objSrcPath, objTgtPath);
			//html群をコピー
			strHtmlDir = strBasePath + strFileWithoutExtension + "/";
			File objHtmlPath = new File(strHtmlDir);
			File objTgtHtmlPath = new File(strFileOutDir + strFileWithoutExtension);
			FileUtils.copyDirectory(objHtmlPath, objTgtHtmlPath);

		} catch (IOException e1) {
			// TODO 自動生成された catch ブロック
			e1.printStackTrace();
		} //tyr

		//動的templateを作成
		String strOutHtml = "";
		strOutHtml += "<!DOCTYPE html> <html> <head> <meta http-equiv='Content-Type' content='text/html; charset=utf-8' /> <title>";
		strOutHtml += strFileWithoutExtension;
		strOutHtml += "</title> <link rel='stylesheet' type='text/css' href='";
		strOutHtml += strFileWithoutExtension;
		strOutHtml += "/styles.css' media='all' /> ";
		strOutHtml += " <link rel='stylesheet' type='text/css' href='";
		strOutHtml += strFileWithoutExtension;
		strOutHtml += "/mask.css' media='all' /> </head> ";

		//黒塗り候補HTMLの作成 黒塗りHTMLの作成
		for (int intIndex = 0; intIndex < ARR_HEAD.length; intIndex++) {
			strHead = ARR_HEAD[intIndex];
			FileWriter objFile = null;
			PrintWriter objPw = null;
			try {

				String strGetHtml = "";
				if (strHead.equals("mask_")) {
					strGetHtml = strMaskHtml;
				} else {
					strGetHtml = strRedHtml;
				} //if

				strGetHtml = strOutHtml + strGetHtml + "</body>";

				//htmlの出力
				File objTgtDir = new File(strFileOutDir + strHead);
				if (!objTgtDir.exists()) { //directoryがなかったら作成
					objTgtDir.mkdir();
				} //if
				String strOutPath = strFileOutDir + strHead + strFileWithoutExtension + ".html";
				objFile = new FileWriter(strOutPath);
				objPw = new PrintWriter(new BufferedWriter(objFile));
				objPw.println(strGetHtml);
				objPw.close();

			} catch (IOException e) {
				objLog.error("err message", e);
				e.printStackTrace();
			} //try

		} //for

		//zipに固める
		String strZipOut = strRealPath + "zip" + strTmpTimeStamp + "/" + "mask.zip";
		objDirCls.makeDirWithCheck(strRealPath + "zip" + strTmpTimeStamp + "/");
		ZipUtil.pack(new File(strFileOutDir), new File(strZipOut));

		//zipをbyte配列にする
		byte[] byteZip = null;
		File objZipFile = null;
		try {
			objZipFile = new File(strZipOut);
			byteZip = Files.readAllBytes(objZipFile.toPath());
		} catch (IOException e1) {
			// TODO 自動生成された catch ブロック
			e1.printStackTrace();
		} //try

		//DBに格納

		// システム日付を取得する
		Timestamp sysdate = Timestamp.valueOf(LocalDateTime.now());

		//エンティティインスタンス化
		TmpMaskDocumentEntBlackPaint objEnt = new TmpMaskDocumentEntBlackPaint();
		try {
			//tmp_mask_documentテーブル
			objEnt.setDocumentId(intDocumentId);
			objEnt.setUserId(UserId);
			objEnt.setHtmlZipData(byteZip);
			objEnt.setUpdateTime(null);
			objEnt.setCreateTime(sysdate);
			tmpMaskDocumentService.insertTmpMaskDocument(objEnt);

			//markerTable
			TmpMaskDocMarkerEntBlackPaint objEnt2 = null;
			for (int i = 0; i < glArrBfIds.length; i++) {
				objEnt2 = new TmpMaskDocMarkerEntBlackPaint();
				objEnt2.setDocumentId(intDocumentId);
				objEnt2.setUserId(UserId);
				objEnt2.setMarkerStartCd(glArrBfIds[i]);
				objEnt2.setMarkerEndCd(glArrAfIds[i]);
				objEnt2.setMarkerPolicy(Integer.parseInt(glArrPolicys[i]));
				if (glRemarks.length == 0) {
					objEnt2.setMarkerRemarks("");
				} else {
					objEnt2.setMarkerRemarks(glRemarks[i]);
				} //if insertTmpMaskDocument
				objEnt2.setCreateTime(sysdate);
				tmpMaskDocTmpMarkerService.insertTmpMaskDocument(objEnt2);

			} //for

			//作業ディレクトリ,ファイルかたづけ
			objDirCls.DelDirctory(strFileOutDir);
			objZipFile.delete();

		} catch (Exception e) {
			objLog.error("err message", e);
			System.err.println(e);
		} //try

		return "200";
	} //getView1

} //MaskHtmlCnt
