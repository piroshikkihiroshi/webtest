package jp.co.nec.docmng.manege.entity;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonInclude;

//@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class CategoryInfoForm {
    public String getDirectoryPass() {
		return directoryPass;
	}
	public void setDirectoryPass(String directoryPass) {
		this.directoryPass = directoryPass;
	}
	@NotBlank(message = "必須項目です。")
    private String directoryPass;
}
