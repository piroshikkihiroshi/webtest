
//グローバル変数
deleteCheck = 0;
editCheck = 0;
upCheck = 0;
downCheck = 0;
listAddBtnCheck = 0;

var isPost = false;
var addValues = {};
var addListCount = 0;
var addBtnCheck = 0;
var changedValues = {};
var deleteDBNo = [];


//アラートメッセージ
var policyNullMessage = "ポリシー名を入力後再度ボタンを押下してください。";
var blackReasonNullMessage = "黒塗り対処理由を入力後再度ボタンを押下してください。";
var deleteAddOrEditListMessage = "選択した行は現在編集中または、追加中のため削除できません。";
var selectedNotClickEditMessage = "行の選択を行った後「編集ボタン」を押下してください。";
var selectedNotClickDeleteMessage = "行の選択を行った後「削除ボタン」を押下してください。"
var selectedNotClickChangeUpMessage = "行の選択を行った後「順位▲ボタン」を押下してください。"
var selectedNotClickChangeDownMessage = "行の選択を行った後「順位▼ボタン」を押下してください。";
// var addReflectSettingCheckMessage="変更した内容を反映しますか。";
var addReflectSettingMessage = "変更が反映されました。";
var addReflectSettingFailureMessage = "設定反映に失敗しました。";
var cancelSelectedMessage = "変更内容を破棄してもよろしいでしょうか。";

//アクションが動作時に下記処理が動作をする
$(function () {

  //画面が変更または閉じられる時に動作する
  $(window).on("beforeunload", function (e) {
    // POST送信フラグが「true」の場合、ダイアログを表示しない
    if (isPost) {
      return;
    } else {
      return true;
    }
  });

  //一覧表の表示が完了した時、DBに登録されているデータが0だった場合、ボタンをdisabledに変更する
  $('.scrollBody').ready(function (e) {

    if (document.getElementById('main_scroll').childElementCount - 2 == 0) {
      //「編集ボタン」をdisableに変更する
      editCheck = 0;
      isEdit();

      //「削除ボタン」をdisableに変更する
      deleteCheck = 0;
      isDelete();

      //「順位▲ボタン」をdisableに変更する
      upCheck = 0;
      isUp();

      //「順位▼ボタン」をdisableに変更する
      downCheck = 0;
      isDown();
    }

  });

  //表をクリック時に動作し、クリックを行った時に選択した行の色が変更する
  $('.scrollBody').mousedown(function (e) {
    //表の項目以外をクリック時には色を付けない
    if (e.target.id != "main_scroll") {
      //テキストボックスに'selected'が挿入されてしまうため、判定しない
      if (e.target.className == "textbox" || e.target.className == "tr l") {
        return;
      }
      if (e.target.nodeName == "SPAN") {
        if (e.target.parentElement.parentElement.id == 'selected') {
          document.getElementById('selected').removeAttribute("id");
          return true;
        } else {
          if (document.getElementById('selected') == null) {
            e.target.parentElement.parentElement.setAttribute('id', 'selected');
          }
          document.getElementById('selected').removeAttribute("id");
          e.target.parentElement.parentElement.setAttribute('id', 'selected');
          return true;
        }
      }
      //一項目のみclick可能とする
      if (e.target.parentElement.id == 'selected') {
        document.getElementById('selected').removeAttribute("id");
      } else {
        if (document.getElementById('selected') == null) {
          e.target.parentElement.setAttribute('id', 'selected');
        }
        document.getElementById('selected').removeAttribute("id");
        e.target.parentElement.setAttribute('id', 'selected');
      }
    } else if (e.target.id == "main_scroll") {
      return false;
    }

  });
});


//新規作成ボタン押下時に動作し、一覧表の最下部に追加する
function addList() {

  //自動順位項番結果を取得する
  var objAutoRowNo = document.getElementById("main_scroll").childElementCount + 1;
  strAutoRowNo = '' + objAutoRowNo;

  //最大順位取得の取得をする
  var objChildrenCountPoint = objAutoRowNo - 2;
  strChildrenCountPoint = '' + objChildrenCountPoint;

  //黒塗りポリシーが存在するか検索する
  if (document.getElementById("main_scroll").children[objChildrenCountPoint] == undefined) {

    //新規作成する欄を作成する
    var ul = $('<ul id="selected"  class="tr l AddListTable"></ul>');
    var strPolicyNumber = $('<li class="' + addListCount + '" style="display: none;"></li>');
    var strDisplayRanktd = $('<li class="w40"></li>');
    var strPolicyNametd = $('<li class="w120" ></li>');
    var strCreateTimetd = $('<li class="w120" ></li>');
    var strCreateUserNametd = $('<li class="w90 text_align_left" ></li>');
    var strBlackReasontd = $('<li class="w140" ></li>');
    var strBlackPointKeywordtd = $('<li class="wAutoA B text_align_left" style="width: 1347px;"></li>');

    //表に取得した値を挿入する
    $(".scrollBody").append(ul);
    ul.append(strPolicyNumber).append(strDisplayRanktd).append(strPolicyNametd).append(strCreateTimetd).append(strCreateUserNametd).append(strBlackReasontd).append(strBlackPointKeywordtd);
    strPolicyNumber.html("");
    strDisplayRanktd.html(strChildrenCountPoint);
    strPolicyNametd.html("<input type='text' id='newPolicyName' class='textbox' size='10' value=" + "" + "></imput>");
    //APサーバ設定時の時刻のため、表示を行わないようにする
    strCreateTimetd.html("");
    //現在ログインしているユーザー名を取得し、入れるよう処理を追加する
    strCreateUserNametd.html("");
    strBlackReasontd.html("<input type='text' id='newBlackReason' class='textbox' size='10' value=" + "" + " ></imput>");
    //対象キーワードは後々設定されるため、記載は行わないようにする
    strBlackPointKeywordtd.html("");

    //「設定反映ボタン」をdisableに変更する
    addBtnCheck = 0;
    isAdd();

    //「編集ボタン」をdisableに変更する
    editCheck = 0;
    isEdit();

    //「新規作成ボタン」を活性化状態にする
    document.getElementById("listAddBtn").classList.toggle("on");

  }
  //最終行が新規作成テキストボックスか確認する
  else if (document.getElementById("main_scroll").children[objChildrenCountPoint].children[2].children[0] == null || document.getElementById("main_scroll").children[objChildrenCountPoint].children[5].children[0] == null || objAutoRowNo == 1) {
    //編集行を、最終行に変更する
    if (document.getElementById('selected') != null) {
      document.getElementById('selected').removeAttribute("id");
    }

    //新規作成する欄を作成する
    var ul = $('<ul id="selected"  class="tr l AddListTable"></ul>');
    var strPolicyNumber = $('<li class="' + addListCount + '" style="display: none;"></li>');
    var strDisplayRanktd = $('<li class="w40"></li>');
    var strPolicyNametd = $('<li class="w120" ></li>');
    var strCreateTimetd = $('<li class="w120" ></li>');
    var strCreateUserNametd = $('<li class="w90 text_align_left" ></li>');
    var strBlackReasontd = $('<li class="w140" ></li>');
    var strBlackPointKeywordtd = $('<li class="wAutoA B text_align_left" style="width: 1347px;"></li>');

    //表に取得した値を挿入する
    $(".scrollBody").append(ul);
    ul.append(strPolicyNumber).append(strDisplayRanktd).append(strPolicyNametd).append(strCreateTimetd).append(strCreateUserNametd).append(strBlackReasontd).append(strBlackPointKeywordtd);
    strPolicyNumber.html("");
    strDisplayRanktd.html(strChildrenCountPoint);
    strPolicyNametd.html("<input type='text' id='newPolicyName' class='textbox' size='10' value=" + "" + "></imput>");
    //APサーバ設定時の時刻のため、表示を行わないようにする
    strCreateTimetd.html("");
    //現在ログインしているユーザー名を取得し、ここに入れるようにする
    strCreateUserNametd.html("");
    strBlackReasontd.html("<input type='text' id='newBlackReason' class='textbox' size='10' value=" + "" + " ></imput>");
    //対象キーワードは後々設定されるため、記載は行わないようにする
    strBlackPointKeywordtd.html("");

    //「設定反映ボタン」をdisableに変更する
    addBtnCheck = 0;
    isAdd();

    //「編集ボタン」をdisableに変更する
    editCheck = 0;
    isEdit();

    //「新規作成ボタン」を活性化状態にする
    document.getElementById("listAddBtn").classList.toggle("on");

  } else if (document.getElementById("main_scroll").children[objChildrenCountPoint].children[2].children[0].id == "newPolicyName" || document.getElementById("main_scroll").children[objChildrenCountPoint].children[5].children[0].id == "newBlackReason") {
    //現在新規作成中の順位を取得する
    var objRowNo = document.getElementById("main_scroll").childElementCount - 2;
    strRowNo = '' + objRowNo;

    //入力されているテキストボックス内容を取得する
    var objNewPolicyNameText = document.getElementById("newPolicyName").value;
    var objNewBlackReasonText = document.getElementById("newBlackReason").value;

    //入力チェックの確認する
    if (objNewPolicyNameText == "") {
      alert(policyNullMessage);
      return false;
    } else if (objNewBlackReasonText == "") {
      alert(blackReasonNullMessage);
      return false;
    }

    //連想配列の作成する
    addValues[addListCount] = { ["policyNumber"]: strRowNo, ["policyName"]: objNewPolicyNameText, ["policyReason"]: objNewBlackReasonText };
    addListCount++;

    //テキストボックス化を解除する
    document.getElementById("newPolicyName").outerHTML = objNewPolicyNameText;
    document.getElementById("newBlackReason").outerHTML = objNewBlackReasonText;

    //非アクティブ化状態に移行するため、クラスの削除する
    document.getElementsByClassName("AddListTable")[0].classList.remove("AddListTable");

    //「設定反映ボタン」をenableに変更する
    addBtnCheck = 1;
    isAdd();

    //「新規作成ボタン」を非活性化状態にする
    document.getElementById("listAddBtn").classList.toggle("on");

    //「編集ボタン」をenableに変更する
    editCheck = 1;
    isEdit();

    //「削除ボタン」をenableに変更する
    deleteCheck = 1;
    isDelete();

    //「削除ボタン」をenableに変更する
    upCheck = 1;
    isUp();

    //「削除ボタン」をenableに変更する
    downCheck = 1;
    isDown();

    return;
  }
}


//編集ボタン押下時に動作し、選択した項目内容を変更する
function Edit() {
  //非編集状態かつ編集中ではない場合、falseを返却する
  if (document.getElementsByClassName('EditMode').length == 0 && document.getElementsByClassName("EditTable").length == 0) {
    if (document.getElementById('selected') != null) {
      //編集がアクティブ状態のため、クラス付与する
      $('#main_scroll').eq(0).addClass('EditMode');
      $('#selected').eq(0).addClass('EditTable');

      //選択行のポリシー名を取得する
      var strPolicyText = $('#selected').eq(0).children()[2].valueOf().textContent;
      //選択行の黒塗り対処理由を取得する
      var strPolicyReasonText = $('#selected').eq(0).children()[5].valueOf().textContent;

      //選択行のポリシー名をTextBox化する
      $('#selected').eq(0).children()[2].innerHTML = "<input type='text' size='10' id='changePolicyName' class='textbox' value=" + strPolicyText + " ></imput>";
      //選択行の黒塗り対処理由をTextBox化する
      $('#selected').eq(0).children()[5].innerHTML = "<input type='text' size='10' id='changeBlackReason' class='textbox' value=" + strPolicyReasonText + " ></imput>";

      //「設定反映ボタン」をdisableに変更する
      addBtnCheck = 0;
      isAdd();

      //「新規作成ボタン」をdisableに変更する
      listAddBtnCheck = 0;
      isListAdd()

      //「編集ボタン」を活性化状態にする
      document.getElementById("editBtn").classList.toggle("on");

    } else {
      alert(selectedNotClickEditMessage);
      return false;
    }
    //編集状態かつ編集中の場合動作する
  } else if (document.getElementsByClassName('EditMode').length > 0 && document.getElementsByClassName("EditTable").length > 0) {

    //追加時のリスト番号値取得する
    var strChangeRow = $(".EditTable>li[style='display: none;']").text();

    //現在新規作成中の順位を取得する
    var strRanktdNumber = document.getElementsByClassName("EditTable")[0].children[1].outerText

    //addValuesのリスト番号を取得する
    var strAddChangeRow = document.getElementsByClassName("EditTable")[0].children[0].className;

    //表示されている値の登録する
    var strTextBoxPolicyName = document.getElementById("changePolicyName").value;
    var strTextBoxBlackReason = document.getElementById("changeBlackReason").value;

    //入力チェックの確認する
    if (strTextBoxPolicyName == "") {
      alert(policyNullMessage);
      return false;
    } else if (strTextBoxBlackReason == "") {
      alert(blackReasonNullMessage);
      return false;
    }

    // 連想配列作成・追加する
    if (addValues[strAddChangeRow]) {
      addValues[strAddChangeRow]["policyName"] = strTextBoxPolicyName;
      addValues[strAddChangeRow]["policyReason"] = strTextBoxBlackReason;
      if (changedValues[strChangeRow]) {
        changedValues[strChangeRow]["policyName"] = strTextBoxPolicyName;
        changedValues[strChangeRow]["policyReason"] = strTextBoxBlackReason;
        changedValues[strChangeRow]["policyId"] = strChangeRow;
      }
    } else {
      if (!changedValues[strChangeRow]) {
        changedValues[strChangeRow] = {
          ["policyId"]: strChangeRow,
          ["policyNumber"]: strRanktdNumber,
          ["policyName"]: strTextBoxPolicyName,
          ["policyReason"]: strTextBoxBlackReason
        };
      } else {
        changedValues[strChangeRow]["policyName"] = strTextBoxPolicyName;
        changedValues[strChangeRow]["policyReason"] = strTextBoxBlackReason;
        changedValues[strChangeRow]["policyId"] = strChangeRow;
      }
    }

    //テキストボックス化を解除する
    document.getElementById("changePolicyName").outerHTML = strTextBoxPolicyName;
    document.getElementById("changeBlackReason").outerHTML = strTextBoxBlackReason;

    //非アクティブ化状態に移行するため、クラスの削除する
    document.getElementById('main_scroll').classList.remove("EditMode");
    document.getElementsByClassName("EditTable")[0].classList.remove("EditTable");

    //「設定反映ボタン」をenableに変更する
    addBtnCheck = 1;
    isAdd();

    //「新規作成ボタン」をenableに変更する
    listAddBtnCheck = 1;
    isListAdd()

    //「編集ボタン」を非活性化状態にする
    document.getElementById("editBtn").classList.toggle("on");

    return;
  }
}

//削除ボタン押下時に動作し、選択した行を削除する
function DeleteRow() {

  //選択した行があるか判定する
  if (document.getElementById('selected') != null) {

    //選択している行が編集中の場合、アラートを表示する
    if (document.getElementById("selected").classList.contains("EditTable") !== true && document.getElementById("selected").classList.contains("AddListTable") !== true) {

      //ポリシーIDの値取得する
      var strDeleteRow = $("#selected>li[style='display: none;']").text();

      //新規作成で表示されているリストの場合、classからリスト番号を取得する
      var strAddChangeRow = document.getElementById("selected").children[0].className;

      //選択した行が変更を行った行か判断する
      var changeValuesFlag = "false";

      //グローバル変数にポリシーIDの値を取得する
      deleteDBNo.push(strDeleteRow);

      //連想配列の削除する
      if (changedValues[strDeleteRow]) {
        delete changedValues[strDeleteRow];
        if (addValues[strAddChangeRow]) {
          delete addValues[strAddChangeRow];
        }
      } else if (addValues[strAddChangeRow]) {
        delete addValues[strAddChangeRow];
      }

      //選択した行の削除する
      $("#selected").remove();

      //ポリシーIDの付け直しをする
      var strAutoRowNo = document.getElementById("main_scroll").childElementCount;
      for (var i = 0; i < strAutoRowNo; i++) {
        //選択した行に非表示要素があるかの判断する
        let hiddenKey = $(".scrollBody ul").eq(i).children("li[style='display: none;']").text();
        if (hiddenKey != "") {
          if ($('.scrollBody ul').eq(i).children().eq(1)[0].innerText !== "" + (i + 1)) {
            $('.scrollBody ul').eq(i).children().eq(1).text("" + (i + 1));
            //連想配列が作成されていないことを確認する
            changeValuesFlag = "true";
          }

          // 編集済み項目がある場合連想配列の修正・作成をする
          if (changedValues[hiddenKey]) {
            // 受け渡し用の配列の順位を変更する
            changedValues[hiddenKey]['policyNumber'] = i + 1;
          } else if (changeValuesFlag === "true") {

            changedValues[hiddenKey] = { ["policyNumber"]: "" + (i + 1), ["policyId"]: hiddenKey };
            changeValuesFlag = "false";
          }

        } else {
          //選択行の行番号を取得する
          var strAddRow = $(".scrollBody ul").eq(i)[0].children[0].className;

          if (addValues[strAddRow]) {
            // 受け渡し用の配列の順位を変更する
            alert(addValues[strAddRow]['policyNumber']);
            addValues[strAddRow]['policyNumber'] = i + 1;
          }
          $(".scrollBody ul").eq(i).children()[1].valueOf().textContent = ("" + (i + 1));
        }
      }

    } else {
      alert(deleteAddOrEditListMessage);
    }
  } else {
    alert(selectedNotClickDeleteMessage);
    return false;
  }
}

//順位▲ボタン押下時に動作し、選択した行の順位を1つ上げる
function ChangeRankUp() {

  //選択した行があるか判定する
  if (document.getElementById('selected') != null) {
    // tbody要素に指定したIDを取得し、変数「tbody」に代入する
    var tbody = document.getElementById('main_scroll');
    // objのノードを取得し、変数「tr」に代入する
    var ul = document.getElementById("selected");

    // 指定している行が最終行の場合動作しない
    if (ul.previousElementSibling != null) {
      //最上位順位以外の場合動作する
      if (ul.children[1].outerText !== '1') {
        //「ul」を直後の兄弟ノードの上に挿入する
        tbody.insertBefore(ul, ul.previousElementSibling);
      }

      //ポリシーIDの付け直しをする
      var strAutoRowNo = document.getElementById("main_scroll").childElementCount;
      var changeValuesFlag = "false";

      for (var i = 0; i < strAutoRowNo; i++) {
        //選択した行に非表示要素があるかの判断する
        let hiddenKey = $(".scrollBody ul").eq(i).children("li[style='display: none;']").text();
        if (hiddenKey != "") {
          if ($('.scrollBody ul').eq(i).children().eq(1)[0].innerText !== "" + (i + 1)) {
            $('.scrollBody ul').eq(i).children().eq(1).text("" + (i + 1));
            changeValuesFlag = "true";
          }

          // 編集済み項目がある場合連想配列の作成・修正する
          if (changedValues[hiddenKey]) {
            // 受け渡し用の配列の順位を変更する
            changedValues[hiddenKey]['policyNumber'] = i + 1;
          } else if (addValues[hiddenKey]) {
            // 受け渡し用の配列の順位を変更する
            addValues[hiddenKey]['policyNumber'] = i + 1;
          } else if (changeValuesFlag === "true") {
            //変更した行の順位を変更する
            changedValues[hiddenKey] = { ["policyNumber"]: "" + (i + 1), ["policyId"]: hiddenKey };
            changeValuesFlag = "false";
          }
        } else {
          //選択行の行番号を取得する
          var strAddRow = $(".scrollBody ul").eq(i)[0].children[0].className;

          if (addValues[strAddRow]) {
            // 受け渡し用の配列の順位を変更する
            addValues[strAddRow]['policyNumber'] = i + 1;
          }
          $('.scrollBody ul').eq(i).children().eq(1).text("" + (i + 1));
        }
      }
    } else {
      return false;
    }
  } else {
    alert(selectedNotClickChangeUpMessage);
    return false;
  }
};

//順位▼ボタン押下時に動作し、選択した行の順位を1つ下げる
function ChangeRankDown() {

  //選択した行があるか判定する
  if (document.getElementById('selected') != null) {
    // tbody要素に指定したIDを取得し、変数「tbody」に代入する
    var tbody = document.getElementById('main_scroll');
    // objのノードを取得し、変数「tr」に代入する
    var ul = document.getElementById("selected");
    // 最大順位の取得する
    var strMaxRanked = '' + tbody.childElementCount;

    // 指定している行が最終行の場合動作しない
    if (ul.nextElementSibling != null) {
      //最下位順位以外動作する
      if (ul.children[1].outerText !== strMaxRanked) {
        // 「tr」を直後の兄弟ノードの上に挿入する
        tbody.insertBefore(ul.nextElementSibling, ul);
      }

      //ポリシーIDの付け直しをする
      var strAutoRowNo = document.getElementById("main_scroll").childElementCount;
      //変更箇所の表示順位の変更に伴い変更箇所のフラグ判定する
      var changeValuesFlag = "false";
      for (var i = 0; i < strAutoRowNo; i++) {
        //選択した行に非表示要素があるかの判断する
        let hiddenKey = $(".scrollBody ul").eq(i).children("li[style='display: none;']").text();
        if (hiddenKey != "") {
          if ($('.scrollBody ul').eq(i).children().eq(1)[0].innerText !== "" + (i + 1)) {
            $('.scrollBody ul').eq(i).children().eq(1).text("" + (i + 1));
            changeValuesFlag = "true";
          }

          // 編集済み項目がある場合連想配列の作成・修正する
          if (changedValues[hiddenKey]) {
            // 受け渡し用の配列の順位を変更する
            changedValues[hiddenKey]['policyNumber'] = i + 1;
          } else if (addValues[hiddenKey]) {
            // 受け渡し用の配列の順位を変更する
            addValues[hiddenKey]['policyNumber'] = i + 1;
          } else if (changeValuesFlag === "true") {
            //変更した行の順位を変更する
            changedValues[hiddenKey] = { ["policyNumber"]: "" + (i + 1), ["policyId"]: hiddenKey };
            changeValuesFlag = "false";
          }

        } else {
          //選択行の行番号を取得する
          var strAddRow = $(".scrollBody ul").eq(i)[0].children[0].className;

          if (addValues[strAddRow]) {
            // 受け渡し用の配列の順位を変更する
            addValues[strAddRow]['policyNumber'] = i + 1;
          }
          $('.scrollBody ul').eq(i).children().eq(1).text("" + (i + 1));
        }
      }
    } else {
      return false;
    }
  } else {
    alert(selectedNotClickChangeDownMessage);
    return false;
  }
};

//キャンセルボタン押下時に動作しダイアログを表示する
function Cancel() {
  blCan = confirm(cancelSelectedMessage);
  if (blCan) {
    window.close();
  } else {
    return;
  }
}


//設定反映ボタン押下時に動作し、DBに設定反映する
function postItem() {

  //変更を行うか確認を取る内容をアラート表示する
  // blCanPost = confirm(addReflectSettingCheckMessage);
  // if (blCanPost) {

  var jsonObj = new Object();

  // 削除項目のIDをデータ受け渡し用タグに格納する
  jsonObj.deleteRow = deleteDBNo;


  // 編集項目の値をデータ受け渡し用タグに格納する
  var postChangeValues = [];
  for (var cv in changedValues) {
    console.log(changedValues[cv]);
    postChangeValues.push(changedValues[cv]);
  }
  jsonObj.changedValues = postChangeValues;

  // 追加項目の値をデータ受け渡し用タグに格納する
  var postAddValues = [];
  // リクエストパラメータに合うように変更する
  for (var av in addValues) {
    console.log(addValues[av]);
    postAddValues.push(addValues[av]);
  }
  jsonObj.addValues = postAddValues;
  console.log(jsonObj);
  //POST
  $.ajax({
    url: "/manege/policy/policy_reflect",
    type: "POST",
    contentType: "application/json",
    data: JSON.stringify(jsonObj),
    // ajax通信成功時の処理をする
  }).done(function (data) {
    let successOrFailure = "";
    console.log(data);
    // 画面を更新する
    isPost = true;
    alert(addReflectSettingMessage);
    location.reload();
    // 更新フラグをON
    // ajax通信失敗時の処理をする
  }).fail(function (xhr, textStatus, errorThrown) {
    //alert(xhr.responseText + "\r\n設定反映に失敗しました。");
    alert(addReflectSettingFailureMessage);
    // 成功でも失敗でも通信終了時に必要な処理があれば追加記載する
  }).always(function () {
  });
  // } else {
  //   return;
  // }
}

//設定反映ボタンの「活性」「非活性」を判定する
function isAdd() {
  if (addBtnCheck == 0) {
    $("#addBtn").prop("disabled", true);
    return true;
  }
  $("#addBtn").prop("disabled", false);
  return false;
}

//設定反映ボタンの「活性」「非活性」を判定する
function isListAdd() {
  if (listAddBtnCheck == 0) {
    $("#listAddBtn").prop("disabled", true);
    return true;
  }
  $("#listAddBtn").prop("disabled", false);
  return false;
}

//編集ボタンの「活性」「非活性」を判定する
function isEdit() {
  if (editCheck == 0) {
    $("#editBtn").prop("disabled", true);
    return true;
  }
  $("#editBtn").prop("disabled", false);
  return false;
}

//削除ボタンの「活性」「非活性」を判定する
function isDelete() {
  if (deleteCheck == 0) {
    $("#deleteBtn").prop("disabled", true);
    return true;
  }
  $("#deleteBtn").prop("disabled", false);
  return false;
}

//順位▲ボタンの「活性」「非活性」を判定する
function isUp() {
  if (upCheck == 0) {
    $("#upBtn").prop("disabled", true);
    return true;
  }
  $("#upBtn").prop("disabled", false);
  return false;
}

//順位▼ボタンの「活性」「非活性」を判定する
function isDown() {
  if (downCheck == 0) {
    $("#downBtn").prop("disabled", true);
    return true;
  }
  $("#downBtn").prop("disabled", false);
  return false;
}

