	/**
     * 黒塗りリストの項目を選択した際、選択した行の色を変更し、備考欄を入力可能な状態にする。
     * (前提：編集ボタンがonになっていること)
     */
	$(function () {
		var element = document.getElementById("HENSHU") ;

		$('.scrollBody').mousedown(function (e){
			if (element.classList.contains("on")){
				if(glTarget!=""){
					var element1 =document.getElementsByClassName(glTarget);
					for(let i=0;i<6;i++){
						element1[i].classList.add("clsdisable");
					}
					element1[6].classList.add("clstextarea");
				}

			var rowNum = e.target.classList[1];
			glTarget = rowNum;
			var element2 =document.getElementsByClassName(rowNum);

			for(let i=0;i<6;i++){
			element2[i].classList.remove("clsdisable");
			}
			element2[6].classList.remove("clstextarea");

			}
		});
	});

	/**
     * 編集ボタン押下時、編集ボタンの色を変更する。
     * (項目を選択していた場合、選択を取り消し、備考欄を入力不可にする)
     */
	function editColumn() {
		var element = document.getElementById("HENSHU") ;
		element.classList.toggle("on");
		if (!element.classList.contains("on")){
			if(glTarget!=""){
				var element1 =document.getElementsByClassName(glTarget);
				for(let i=0;i<6;i++){
					element1[i].classList.add("clsdisable");
				}
				element1[6].classList.add("clstextarea");
			}
		}
	}


	/**
	 * 黒塗り文書作成画面を表示する
	 */
	function cancelList(){


	    var blRet = confirm("「黒塗りリスト表示画面」で編集した内容を破棄して、「黒塗り文書作成画面」に遷移してもよろしいでしょうか。");

	    if (blRet) {

	    	var strRet = makeEditMarker();

	        var objForm = document.createElement('form');
	        var objReq = document.createElement('input');
	        var objReq2 = document.createElement('input');

	        objReq.type = 'hidden'; //入力フォームが表示されないように
	        objReq.name = 'documentId';
	        objReq.value = gldocumentId;

	        objReq2.type = 'hidden'; //入力フォームが表示されないように
	        objReq2.name = 'status';
	        objReq2.value = "1"; //再開フラグ


	        objForm.appendChild(objReq);
	        objForm.appendChild(objReq2);

	        objForm.method = 'GET';
	        objForm.action = "/MaskHtmlCnt";

			document.body.appendChild(objForm);
			//POST送信フラグを「true」に設定
			isPost = true;			
	        objForm.submit();
	    } //if


	} //function

	/**
	 * 黒塗り文書作成画面を表示する
	 */
	function confirmList(){

		// var itemCom=""; //備考欄の配列
		var itemCom=[]; //備考欄の配列
		var element = document.getElementById("HENSHU") ;
		var elementCom =document.getElementsByClassName("clstextarea");

		if (!element.classList.contains("on")){

	    	var blRet = confirm("「黒塗りリスト表示画面」で編集した内容を確定して、「黒塗り文書作成画面」に遷移してもよろしいでしょうか。");

			if (blRet) {

				for (let i = 0; i < elementCom.length; i++) {
					itemCom[i]=elementCom[i].value;
				} //for
				//glblackPaintListに格納
				glblackPaintList.Remarks = itemCom;
				var strJson = JSON.stringify(glblackPaintList);

				var objForm = document.createElement('form');
				var objReq = document.createElement('input');
				var objReq2 = document.createElement('input');
				var objReq3 = document.createElement('input');
	
				objReq.type = 'hidden'; //入力フォームが表示されないように
				objReq.name = 'documentId';
				objReq.value = gldocumentId;
	
				objReq2.type = 'hidden'; //入力フォームが表示されないように
				objReq2.name = 'status';
				objReq2.value = "2"; //確定フラグ

				objReq3.type = 'hidden'; //入力フォームが表示されないように
				objReq3.name = 'blackPaintListJson';
				objReq3.value = strJson; //備考を含んだjson				
	
	
				objForm.appendChild(objReq);
				objForm.appendChild(objReq2);
				objForm.appendChild(objReq3);
	
				objForm.method = 'GET';
				objForm.action = "/MaskHtmlCnt";
	
				document.body.appendChild(objForm);
				//POST送信フラグを「true」に設定
				isPost = true;			
				objForm.submit();

			} //if
	    }//if


	} //function
