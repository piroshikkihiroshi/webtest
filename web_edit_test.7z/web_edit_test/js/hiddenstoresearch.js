

//グローバル変数、定数
const NO_SELECT = "----";
const SEARCH_URL = '../controller/googlemapfind.php';
const MAP_SCRIPT_GET = '../api/getMapJs.php';

var map;
var marker;
var infoWindow;
var marker;
var myScript
const fltTokyoLat = 35.680865;
const fltTokyoLng = 139.767036;
const intScope = 15; //倍率

//init
$(function () {

    var blRet = false;
    blRet = retDisp();  //getで「retkey」がある場合、retkeyに紐づけされた検索結果を表示する
    if (!blRet) { //getの検索結果がなく、ローカルストレージに前回の検索結果がある場合、表示する
        lastSearch();
    } //if

    //リスト初期化
    var blStroageGet = storageGet();
    //20190730 datatableの言語設定
    dataTableSetting();

    //現在地取得
    getPosition();

    //テキストボックスEnter　map検索
    $("#place_search").keypress(function (e) {
        if (e.which == 13) {
            changePin();
        } //if
    }); //function

    //googlemap設定(api keyを秘匿するためscriptを取得しevalで実行しておく)
    getGmapScript();

    //前回の検索条件を取得する
    setSearchConditions();
}); //function


// 駅情報は停止
// window.onload = function () {
// 	//駅情報作成
// 	listareasMake();
// } //onload	

//api keyを秘匿するためscriptを取得しevalで実行しておく
// //settimeoutで疑似非同期
// setTimeout(getGmapScript(), 
// 1000);

/**
* Google Map APIのスクリプトを取得、実行する
*/
function getGmapScript() {
    fetch(MAP_SCRIPT_GET).then(res => {
        return res.text();
    }).then(myScript => {
        eval(myScript);
    }).then(() => {
        initMap();
    }).catch((e) => {
        // alert('google map api取得処理でエラーが発生しました');
        console.log('google map api取得処理でエラーが発生しました');
    });
} //function


/**
* 駅情報のjsonからDOMを作成し表示する
* @param String retData_i 検索結果のjson
* @return String 作成DOM
*/
function listareasMakeDom(retData_i) {
    var strHtml = '';
    hashStationInfo = retData_i; //グローバル変数に保持
    for (var strKey in hashStationInfo) {
        if (hashStationInfo.hasOwnProperty(strKey)) {
            var objTgtElm = hashStationInfo[strKey];
            strHtml += '<option value="' + objTgtElm.name + '"></option>';
        } //if
    } //for
    return strHtml;
} //function


/**
* listareasのdivを作成する
* @return boolean
*/
function listareasMake() {
    var objListAreaDiv = document.getElementById('listareas');
    $.ajax({
        type: 'POST',
        url: '../api/station.json',
        processData: false, // Ajaxがdataを整形しない指定
        contentType: false, // contentTypeもfalseに指定(Fileをアップロード時は必要)
        async: false, //非同期false
        success: function (retData) {
            objListAreaDiv.innerHTML = listareasMakeDom(retData);
            console.log("success");
            return false;
        }, //function
        error: function (e) {
            console.log("fail");
            return false;
        } //function
    }); //ajax
} //function


//20201010
//検索結果urlをコピーする
function copyRetUrl() {
    //20201213 検索中判定基準変更
    var strMsg = document.getElementById('retmsg').innerText;
    if (strMsg.indexOf('件以上') > 0) {
        alert('現在追加検索中なので、もうしばらくお待ちください。');
        return false;
    } //if

    var strRetUrl = '';
    if (window.location.search.indexOf("retkey") > 0) { //既にretkeyがある場合そのままのURL
        strRetUrl = location.href;
    } else { //retkeyがない場合getに＋する
        strRetUrl = location.href + '?retkey=' + localStorage.getItem('retkey');
    } //if

    copyTextToClipboard(strRetUrl, '検索結果urlをコピーしました。\r\nコピーしたURLでアクセスすると現在の検索結果画面が表示されます。');


} //function

/**
* getで「retkey」がある場合、retkeyに紐づけされた検索結果を表示する
* @return boolean True:検索結果あり False:検索結果なし
*/
function retDisp() {
    var blRet = false;
    var strGetVal = window.location.search;
    if (strGetVal != "" && strGetVal != undefined) { //getparamあり
        var arrGet = strGetVal.replace('?', '').split('=');
        var strKey = arrGet[0];
        var strTgtVal = arrGet[1];
        if (strKey === 'retkey') { //retkeyなら処理を進行
            var strGetJson = '';
            $.ajax({
                type: 'GET',
                url: SEARCH_URL + window.location.search,
                processData: false, // Ajaxがdataを整形しない指定
                contentType: false, // contentTypeもfalseに指定(Fileをアップロード時は必要)
                async: false, //非同期false
                success: function (strGetJson) {
                    //20190730 datatable設定
                    dataTableSetting();
                    $('body').html(retDataMake(strGetJson));
                    $("#rettable").DataTable(); //20190730 datatable化
                    console.log("success");
                    blRet = true;
                    return false;
                }, //function
                error: function (e) {
                    console.log("fail");
                    return false;
                } //function
            }); //ajax

        } //if



    } //if
    return blRet;
} //function


/**
* 前回の検索結果がある場合、前回の検索結果を表示する
* @return boolean True:検索結果あり False:検索結果なし
*/
function lastSearch() {
    var blRet = false;
    var strLastJson = localStorage.getItem('tgtjson');
    if (strLastJson != "" && strLastJson != undefined) { //検索結果あり
        blRet = true;
        //20190730 datatable設定
        dataTableSetting();
        $('body').html(retDataMake(strLastJson));
        $("#rettable").DataTable(); //20190730 datatable化
    } //if
    return blRet;
} //function

/**
* 検索条件をlocalStorageに保存する
*/
function saveSearchConditions() {
    localStorage.setItem('inputKeyword', $('#inputKeyword').val());
    localStorage.setItem('radius', $('#radiusselect').val());
    localStorage.setItem('rankselect', $('#rankselect').val());
    localStorage.setItem('ratingstotalselect', $('#ratingstotalselect').val());
    localStorage.setItem('place_search', $('#place_search').val());
} //function

/**
* 前回の検索条件をセットする
*/
function setSearchConditions() {
    if (localStorage.getItem('inputKeyword') !== null) {
        $('#inputKeyword').val(localStorage.getItem('inputKeyword'));
    } //if
    if (localStorage.getItem('radius') !== null) {
        $('#radius').val(localStorage.getItem('radius'));
    } //if
    if (localStorage.getItem('rankselect') !== null) {
        $('#rankselect').val(localStorage.getItem('rankselect'));
    } //if	
    if (localStorage.getItem('ratingstotalselect') !== null) {
        $('#ratingstotalselect').val(localStorage.getItem('ratingstotalselect'));
    } //if
    if (localStorage.getItem('place_search') !== null) {
        $('#place_search').val(localStorage.getItem('place_search'));
    } //if

} //function	


/**
* DataTableの設定
* @return void
*/
function dataTableSetting() {
    //20190730 datatableの言語設定
    $.extend($.fn.dataTable.defaults, {
        language: {
            url: "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Japanese.json"
        },
        // "lengthMenu": [[50, 100, -1], [50, 100, "ALL"]],
        "stateSave": true, //表示状態保持
        // 件数切替機能 無効
        lengthChange: false,
        // 検索機能 無効
        searching: false,
        // ページング機能 無効
        paging: false,
        //〇〇件中〇〇件非表示
        info: false
    });
} //function

/**
* 初期表示画面に戻る際にjsonのlocalStorageをクリアする
* @return boolean True:検索結果あり False:検索結果なし
*/
function backSearchView() {
    localStorage.setItem('tgtjson', '');
    //20201010 uniqueな値を削除
    localStorage.setItem('retkey', '');
    location.href = './';
} //function


// 現在地取得処理
function getPosition() {
    if (navigator.geolocation) {
        // 現在地を取得
        navigator.geolocation.getCurrentPosition(
            // 取得成功した場合
            function (position) {
                $('#tgtlat').val(position.coords.latitude);
                $('#tgtlng').val(position.coords.longitude);

                // //20201009 map対応
                try {
                    initMap();
                } catch (error) {
                    console.log('google map 想定内エラー(マーカーを現在地に移動させる)');
                } //try
            },
            // 取得失敗した場合
            function (error) {
                switch (error.code) {
                    case 1: //PERMISSION_DENIED
                        alert("位置情報の利用が許可されていません");
                        break;
                    case 2: //POSITION_UNAVAILABLE
                        alert("現在位置が取得できませんでした");
                        break;
                    case 3: //TIMEOUT
                        alert("タイムアウトになりました");
                        break;
                    default:
                        alert("その他のエラー(エラーコード:" + error.code + ")");
                        break;
                } //switch
                return false;
            } //error func
        ); //navigator.geolocation.getCurrentPosition
    } else {
        alert("この端末では位置情報が取得できません");
        return false;
    } //if
    return true;
} //function

//main機能
//google map api で店を検索する
//param intStatus_i 1:現在地検索　2:駅から検索　3:地図(マーカー)から検索
function searchHiddenStore(intStatus_i) {
    //駅検索をなくしたのでコメントアウト
    // var strStationName = document.getElementById("areaselect").value;

    if (intStatus_i == 1) { //現在地検索
        if ($('#tgtlat').val() == '' || $('#tgtlng').val() == '') {
            alert("位置情報がないため現在地からの検索はできません。");
            return false;
        } //if
    } else if (intStatus_i == 2) { //駅検索
        if (hashStationInfo[strStationName] === undefined) {
            alert("存在しない駅です。");
            return false;
        } //if
        $('#tgtlat').val(hashStationInfo[strStationName].lat);
        $('#tgtlng').val(hashStationInfo[strStationName].lon);
    } else if (intStatus_i == 3) { //地図検索
        $('#tgtlat').val(marker.position.lat());
        $('#tgtlng').val(marker.position.lng());
    } else {
        alert("不正なステータスです");
        return false;
    } //if
    //検索条件保存
    saveSearchConditions();
    var objForm = document.getElementById('mainForm');
    var objFormData = new FormData(objForm); // FormData オブジェクトを作成
    var strHtml = "";
    strHtml += "<div class='alert alert-warning role='alert''>";
    strHtml += "検索中です。しばらくお待ちください。";
    strHtml += "</div>";
    strHtml += ' <div class="loading"></div>';
    //		$('#loadId').html(strHtml); //load中にする
    $('body').html(strHtml); //load中にする
    $.ajax({
        type: 'POST',
        url: SEARCH_URL,
        data: objFormData,
        processData: false, // Ajaxがdataを整形しない指定
        contentType: false, // contentTypeもfalseに指定(Fileをアップロード時は必要)
        success: function (retData) {
            $('body').html(retDataMake(retData));
            //jsondataをlocalStorageへ保存
            localStorage.setItem('tgtjson', retData);
            //20201010 uniqueな値を保持
            var objData = JSON.parse(retData);
            localStorage.setItem('retkey', objData.retkey);

            console.log("success");
            $("#rettable").DataTable(); //20190730 datatable化

            var objData = JSON.parse(retData);
            //※※※※※※※※※※nextステータスがある場合は再度呼ぶ※※※※※※※
            if (objData.next == "1") {
                var objReq = document.createElement('input');
                objReq.type = 'hidden'; //入力フォームが表示されないように
                objReq.name = 'next';
                objReq.value = '1';
                objForm.appendChild(objReq);
                objFormData = new FormData(objForm); // FormData オブジェクトを作成

                $.ajax({
                    type: 'POST',
                    url: SEARCH_URL,
                    data: objFormData,
                    processData: false, // Ajaxがdataを整形しない指定
                    contentType: false, // contentTypeもfalseに指定(Fileをアップロード時は必要)
                    success: function (retData) {
                        $('body').html(retDataMake(retData));
                        //jsondataをlocalStorageへ保存
                        localStorage.setItem('tgtjson', retData);
                        //20201010 uniqueな値を保持
                        var objData = JSON.parse(retData);
                        localStorage.setItem('retkey', objData.retkey);
                        console.log("success");
                        $("#rettable").DataTable(); //20190730 datatable化
                        return false;
                    }, //function
                    error: function (e) {
                        var strHtml = '';
                        strHtml += "<div class='alert alert-warning role='alert''>";
                        strHtml += "読み込みに失敗しました。管理者にお問い合わせください。<br>";
                        strHtml += 'エラーステータス：' + e.status;
                        strHtml += "</div>";
                        strHtml += '<br><a class="btn btn-primary btn-sm" onclick="backSearchView()">検索ページへ戻る</a>';
                        $('body').html(strHtml);
                        console.log("fail");
                        return false;
                    } //function
                }); //ajax
            } //if

            return false;
        }, //function
        error: function (e) {
            var strHtml = '';
            strHtml += "<div class='alert alert-warning role='alert''>";
            strHtml += "読み込みに失敗しました。管理者にお問い合わせください。<br>";
            strHtml += 'エラーステータス：' + e.status;
            strHtml += "</div>";
            strHtml += '<br><a class="btn btn-primary btn-sm" onclick="backSearchView()">検索ページへ戻る</a>';
            $('body').html(strHtml);
            console.log("fail");
            return false;
        } //function
    }); //ajax
} //function

/**
* 検索結果のjsonからDOMを作成し表示する
* @param String retData_i 検索結果のjson
* @return String 作成DOM
*/
function retDataMake(retData_i) {
    var strHtml = '<div class="container">';
    var objData = null;
    strGMapBase = 'https://www.google.com/maps/search/?api=1&query=Google&query_place_id=';

    strGReviewBase = 'https://search.google.com/local/reviews?placeid=';
    try {
        objData = JSON.parse(retData_i);
    } catch (e) {
        strHtml += "<div class='alert alert-warning role='alert''>";
        strHtml += "jsonのparseに失敗しました。管理者にお問い合わせください。<br>";
        strHtml += e;
        strHtml += "</div></div>";
        strHtml += '<br><a class="btn btn-primary btn-sm" onclick="backSearchView()">検索ページへ戻る</a>';
        return strHtml;
    } //try

    if (objData.status == "OK") {
        strHtml += "<div id='retmsg'  class='alert alert-info role='alert''>";
        strHtml += objData['msg'] + "の隠れた名店候補が見つかりました。</div>";
        strHtml += '<p><a class="btn btn-primary btn-sm" onclick="backSearchView()">検索ページへ戻る</a></p>';
        //20190808 説明をモーダル表示
        strHtml += '<hr>';
        strHtml += '<p>';
        strHtml += '	<a href="#" class="alert-link" style=" text-decoration:none;" data-toggle="modal" data-target="#descModal"><img src="../img/description.png">　Iconについて</img></a>';
        strHtml += '	<a class="btn btn-success btn-sm col-lg-offset-1" onclick="copyRetUrl()">検索結果URLコピー</a>';
        strHtml += '</p>';
        strHtml += '<div class="modal fade" id="descModal" tabindex="-1" role="dialog" aria-labelledby="basicModal"';
        strHtml += '	aria-hidden="true">';
        strHtml += '	<div class="modal-dialog">';
        strHtml += '		<div class="modal-content">';
        strHtml += '			<div class="modal-header">';
        strHtml += '				<h4>Iconについて</h4>';
        strHtml += '			</div>';
        strHtml += '			<div class="modal-body">';
        strHtml += '				<label><img src="../img/store.png">：店名　</img><img src="../img/favorite.png">：評価</img><br><br><img src="../img/kuthikomi.png">：口コミ：※クリックすると口コミの詳細を表示</img><br><br><img src="../img/time.png">：検索地からの徒歩時間(分)</img><br><br><img src="../img/map.png">：Open GoogleMap<br><br><img src="../img/copy.png">：Copy GoogleMap</img><br><br></img><br>※ヘッダを押すことで結果をソート<br><span class="sorting_asc">　　</span>：昇順<br><span class="sorting_desc">　　</span>：降順';
        strHtml += '			</div>';
        strHtml += '			<div class="modal-footer">';
        strHtml += '				<button type="button" class="btn btn-secondary" data-dismiss="modal">閉じる</button>';
        strHtml += '			</div>';
        strHtml += '		</div>';
        strHtml += '	</div>';
        strHtml += '</div>';
        // strHtml += '<p><img src="../img/store.png">：店名　</img><img src="../img/favorite.png">：評価　</img><br><br><img src="../img/kuthikomi.png">：口コミ：※クリックすると口コミの詳細が表示されます。</img><br><br><img src="../img/time.png">：検索地からの徒歩時間(分)　</img><br><br><img src="../img/map.png">：GoogleMapが開きます　<br><br><img src="../img/copy.png">：GoogleMapのアドレスをコピーします。　</img><br><br></img><br><br>※ヘッダを押すことで結果をソートできます。<br><span class="sorting_asc">　　</span>：昇順<br><span class="sorting_desc">　　</span>：降順</p>';
        strHtml += '<table id="rettable" class="table table-striped table-bordered table-hover table-responsive">';
        strHtml += '	<thead>';
        strHtml += '		<tr>';
        // strHtml += '			</td><td class="store">　</td><td class="favorite">　　</td><td class="kuthikomi">　　</td><td class="time">　　</td><td class="walk">　　</td><td class="map">　　</td><td class="copy">　　</td>';
        strHtml += '			</td><td class="store">　</td><td class="favorite">　　</td><td class="kuthikomi">　　</td><td class="time">　　</td><td class="map">　　</td><td class="copy">　　</td>';
        strHtml += '		</tr>';
        strHtml += '	</thead>';
        strHtml += '	<tbody>';
        glIntCnt = 1;
        for (var objTmp in objData) {
            if (!isNaN(objTmp)) {
                strHtml += '			<tr>';
                // strHtml += '<td>' + glIntCnt + '</td>';
                strHtml += '<td>' + objData[objTmp].name + '</td>';
                strHtml += '<td>' + objData[objTmp].rating + '</td>';
                // strHtml += '<td>' + objData[objTmp].user_ratings_total + '</td>';
                strHtml += '<td><a href=' + strGReviewBase + objData[objTmp].place_id + ' target="_blank">' + objData[objTmp].user_ratings_total + '</a></br></td>';
                var strTmpMin = objData[objTmp].legs.duration.text.replace(" mins", "").replace(" min", "");
                strHtml += '<td>' + strTmpMin + '</td>';
                // strHtml += '<td>' + objData[objTmp].legs.distance.value + 'm</td>';
                //20190801 place_idで遷移させる
                strHtml += '<td><span class="badge badge-success" onclick="window.open(' + "'" + strGMapBase + objData[objTmp].place_id + "'" + ')">MAP</span></td>';
                strHtml += '<td><span class="badge badge-info" onclick="copyTextToClipboard(' + "'" + strGMapBase + objData[objTmp].place_id + "'" + ",'GoogleMapのアドレスをコピーしました。'" + ')">COPY</span></td>';
                strHtml += '			</tr>';
                glIntCnt++;
            } //if
        } //for
        strHtml += '	</tbody></table>';
    } else {
        strHtml += "<div class='alert alert-warning role='alert''>";
        strHtml += objData.msg;
        strHtml += "</div>";
    } //if
    strHtml += '<br><a class="btn btn-primary btn-sm" onclick="backSearchView()">検索ページへ戻る</a>';
    strHtml += '</div>';
    return strHtml;

} //function

/**
* localstorageをセットする
* @return boolean True:セット成功 false:セット失敗
*/
function storageSet() {
    localStorage.setItem('inputKeyword', $('#inputKeyword').val());
    localStorage.setItem('radiusselect', $('#radiusselect').val());
    localStorage.setItem('rankselect', $('#rankselect').val());
    localStorage.setItem('ratingstotalselect', $('#ratingstotalselect').val());
    // localStorage.setItem('tgtjson', $('#tgtjson').val());
    return true;
} //function

/**
* localstorageから値を取得できたら初期値をセットする
* @return boolean True:セット成功 false:セット失敗
*/
function storageGet() {
    if (localStorage.getItem('inputKeyword') != "" && localStorage.getItem('inputKeyword') != undefined) {
        $('#inputKeyword').val(localStorage.getItem('inputKeyword'));
    } else {
        $('#inputKeyword').val('');
    } //if

    if (localStorage.getItem('radiusselect') != "" && localStorage.getItem('radiusselect') != undefined) {
        $('#radiusselect').val(localStorage.getItem('radiusselect'));
    } else {
        $('#radiusselect').val('1000');
    } //if

    if (localStorage.getItem('rankselect') != "" && localStorage.getItem('rankselect') != undefined) {
        $('#rankselect').val(localStorage.getItem('rankselect'));
    } else {
        $('#rankselect').val('3.5');
    } //if

    if (localStorage.getItem('ratingstotalselect') != "" && localStorage.getItem('ratingstotalselect') != undefined) {
        $('#ratingstotalselect').val(localStorage.getItem('ratingstotalselect'));
    } else {
        $('#ratingstotalselect').val('1000');
    } //if

    return true;
} //function

/**
 * クリップボードコピー関数
 * 入力値をクリップボードへコピーする
 * [引数]   textVal: 入力値
 * [引数]   strMsg: 成功時msg
 * [返却値] true: 成功　false: 失敗
 */
function copyTextToClipboard(textVal, strMsg) {
    // テキストエリアを用意する
    var copyFrom = document.createElement("textarea");
    // テキストエリアへ値をセット
    copyFrom.textContent = textVal;

    // bodyタグの要素を取得
    var bodyElm = document.getElementsByTagName("body")[0];
    // 子要素にテキストエリアを配置
    bodyElm.appendChild(copyFrom);

    // テキストエリアの値を選択
    copyFrom.select();
    // コピーコマンド発行
    var retVal = document.execCommand('copy');
    // 追加テキストエリアを削除
    bodyElm.removeChild(copyFrom);
    // 処理結果を返却

    alert(strMsg);

    return retVal;
} //function

//20201010 google map関係
/**
* google mapの初期表示を行う
*/
function initMap() {

    //マップ初期表示の位置設定
    var objInitTgt = document.getElementById('googlemaptgt');
    var objInitLatLang = {};
    //現在値が取れる場合は現在値　取れない場合は東京
    if ($('#tgtlat').val() == '' || $('#tgtlng').val() == '') {
        objInitLatLang = { lat: fltTokyoLat, lng: fltTokyoLng };
    } else {
        objInitLatLang = { lat: parseFloat($('#tgtlat').val()), lng: parseFloat($('#tgtlng').val()) };
    } //if

    //マップ表示
    map = new google.maps.Map(objInitTgt, {
        center: objInitLatLang,
        zoom: intScope,
    });

    // マーカーを設置
    marker = new google.maps.Marker({
        position: objInitLatLang,
        map: map
    });

    // クリックイベントを追加
    map.addListener('click', function (e) {
        setMarker(e.latLng, map);
    });

} //function


/**
* 検索した内容でgoogle mapのピンの位置を変更する
*/
function changePin() {
    var place = document.getElementById('place_search').value;
    if (place == '') {
        alert('マーカー検索に検索したい場所を入力してください');
        return;
    } //return
    var geocoder = new google.maps.Geocoder();      // geocoderのコンストラクタ

    geocoder.geocode({
        address: place
    }, function (results, status) {
        if (status == google.maps.GeocoderStatus.OK) {

            var bounds = new google.maps.LatLngBounds();

            for (var i in results) {
                if (results[0].geometry) {
                    // 緯度経度を取得
                    var latlng = results[0].geometry.location;
                    // 住所を取得
                    var address = results[0].formatted_address;
                    // 検索結果地が含まれるように範囲を拡大
                    bounds.extend(latlng);
                    // マーカーのセット
                    setMarker(latlng, map);
                    // マーカーへの吹き出しの追加
                    setInfoW(place, latlng, address);
                    // マーカーにクリックイベントを追加
                    markerEvent();
                } //if
            } //for
        } else if (status == google.maps.GeocoderStatus.ZERO_RESULTS) {
            alert(place + "は見つかりませんでした。");
        } else {
            console.log(status);
            alert("エラー発生" + "\r\n" + status);
        } //if
    }); //geocoder.geocode
} //function


// マーカーのセットを実施する
function setMarker(lat_lng, map) {

    // 座標を表示
    console.log(lat_lng.lat());
    console.log(lat_lng.lng());


    //前のマーカーを削除
    deleteMakers();

    // マーカーを設置
    marker = new google.maps.Marker({
        position: lat_lng,
        map: map
    });

    // 座標の中心をずらす
    // http://syncer.jp/google-maps-javascript-api-matome/map/method/panTo/
    map.panTo(lat_lng);
} //function


//マーカーを削除する
function deleteMakers() {
    if (marker != null) {
        marker.setMap(null);
    }
    marker = null;
}
// マーカーへの吹き出しの追加
function setInfoW(place, latlng, address) {
    infoWindow = new google.maps.InfoWindow({
        content: "<a href='http://www.google.com/search?q=" + place + "' target='_blank'>" + place + "</a><br><br>" + latlng + "<br><br>" + address + "<br><br><a href='http://www.google.com/search?q=" + place + "&tbm=isch' target='_blank'>画像検索 by google</a>"
    });
}
// クリックイベント
function markerEvent() {
    marker.addListener('click', function () {
        infoWindow.open(map, marker);
    });
}

