package controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import dirFile.FileCnt;

/**
 * Servlet implementation class HtmlCnt
 */
@WebServlet("/HtmlCnt")
public class HtmlCnt extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger objLog = Logger.getLogger(HtmlCnt.class);
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HtmlCnt() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String strPackName = "07_tomcat8";
		String strMakeFilePath = request.getParameter("wordHtmlPath");
		FileCnt objFileCnt = new FileCnt();
		objLog.info("対象パス：" + strMakeFilePath);

		String strFileName = strMakeFilePath.substring(strMakeFilePath.lastIndexOf("\\") + 1,strMakeFilePath.length());
		String strDirName = objFileCnt.getNameWithoutExtension(strFileName) + ".files";
		String strDirNamePath = strMakeFilePath.replace(strFileName,strDirName);
        String spa = getServletContext().getRealPath("/");


        try {
            Path sourcePath = Paths.get(strMakeFilePath);
            Path sourceDirPath = Paths.get(strDirNamePath);
            Path targetPath = Paths.get(spa + "/" + strFileName);
            Path targetDirPath = Paths.get(spa + "/" + strDirName);

            Files.move(sourcePath, targetPath);

            //dirは圧縮→解凍
            String strZipFromNamePath = objFileCnt.getNameWithoutExtension(strFileName) + ".zip";
            String strZipFromPath = strMakeFilePath.replace(strFileName,strZipFromNamePath);


//            String strZipToPath = spa + "/" + strZipFromNamePath + ".zip";
            //一度圧縮
            objFileCnt.zipDirectory(strDirNamePath, strZipFromPath);

            //移動
            Path sourceZipPath = Paths.get(strZipFromPath);
            Path targetZipPath = Paths.get(spa + "/" + strZipFromNamePath);
            Files.move(sourceZipPath, targetZipPath);

            //解凍先から
            objFileCnt.unzip(spa + "/" + strZipFromNamePath , spa + "/" + strDirName);


//            Files.copy(sourceDirPath, targetDirPath); //再起で処理

            objLog.info("移動が成功しました");
            response.sendRedirect("/" + strPackName + "/" + strFileName);
            objLog.info("/" + strPackName + "/" + strFileName + "へリダイレクトします。");

        } catch (IOException e) {
            e.printStackTrace();
        } //try

	} //doGet

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
