package dirFile;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;


public class FileCnt {
	/**
	 * File名から拡張子を抜いたファイル名を取得する。
	 * @param String strFileName_i ファイルのフルパス
	 * @return String 取得文字列
	 */
	synchronized public String getNameWithoutExtension(String strFileName_i) {
		int index = strFileName_i.lastIndexOf('.');
		if (index != -1) {
			return strFileName_i.substring(0, index);
		}
		return strFileName_i;
	} //getNameWithoutExtension

	/**
	 * strPath_iにstrOfficePath_iを開くbatchを作成する
	 * @param String strFileName_i ファイルのフルパス
	 * @param String strOfficePath_i 対象officeファイル
	 * @param int intStatus_i 1:Excel 2:word 3:PPT
	 * @return String 取得文字列
	 */
	public void makeOfficeBat(String strPath_i,String strOfficePath_i,int intStatus_i) {
		FileWriter objFile = null;
		PrintWriter objPw = null;

        try {
        	objFile = new FileWriter(strPath_i);
        	objPw = new PrintWriter(new BufferedWriter(objFile));

        	objPw.println("@echo off");
        	if(intStatus_i ==1) {
            	objPw.println(" start /WAIT EXCEL \"" + strOfficePath_i +  "\" ");
        	}else if(intStatus_i == 2) {
            	objPw.println(" start /WAIT WINWORD \"" + strOfficePath_i +  "\" ");
        	}else {
            	objPw.println(" start /WAIT POWERPNT \"" + strOfficePath_i +  "\" ");
        	} //if

        	objPw.println(" del /f \"%~dp0%~nx0\" ");
        	objPw.close();

		} catch (IOException e) {
			e.printStackTrace();
		} //if


	} //makeOfficeBat



	//---------zip処理--------//
		/**
		 * 指定されたディレクトリ内のファイルを ZIP アーカイブし、指定されたパスに作成。
		 * デフォルト文字コードは Shift_JIS なので、日本語ファイル名も対応可。
		 * @param directory 圧縮するディレクトリ ( 例; C:/sample )
		 * @param fullPath 圧縮後の出力ファイル名をフルパスで指定 ( 例: C:/sample.zip )
		 * @return 処理結果ステータス
		 */
		public int zipDirectory( String strDirectory_i,String strZipPath_i  ) {
			File objBaseFile = new File(strZipPath_i);
			File objFile = new File(strDirectory_i);
			ZipOutputStream objOutZip = null;
			try {
				// ZIPファイル出力オブジェクト作成
				objOutZip = new ZipOutputStream(new FileOutputStream(objBaseFile));
				archive(objOutZip, objBaseFile, objFile);
			} catch ( Exception e ) {
				// ZIP圧縮失敗
				System.err.println(e);
				return -1;
			} finally {
				// ZIPエントリクローズ
				if ( objOutZip != null ) {
					try { objOutZip.closeEntry(); } catch (Exception e) {}
					try { objOutZip.flush(); } catch (Exception e) {}
					try { objOutZip.close(); } catch (Exception e) {}
				}
			}
			return 0;
		}

		/**
		 * 指定された ArrayList のファイルを ZIP アーカイブし、指定されたパスに作成します。
		 * デフォルト文字コードは Shift_JIS ですので、日本語ファイル名も対応できます。
		 *
		 * @param filePath 圧縮後のファイル名をフルパスで指定 ( 例: C:/sample.zip )
		 * @param fileList 圧縮するファイルリスト  ( 例; {C:/sample1.txt, C:/sample2.txt} )
		 * @return 処理結果 true:圧縮成功 false:圧縮失敗
		 */
		public boolean compressFileList( String filePath, ArrayList<String> fileList ) {

			ZipOutputStream outZip = null;
			File baseFile = new File(filePath);
			try {
				// ZIPファイル出力オブジェクト作成
				outZip = new ZipOutputStream(new FileOutputStream(baseFile));
				// 圧縮ファイルリストのファイルを連続圧縮
				for ( int i = 0 ; i < fileList.size() ; i++ ) {
					// ファイルオブジェクト作成
					File file = new File((String)fileList.get(i));
					archive(outZip, baseFile, file, file.getName(), "Shift_JIS");
				}
			} catch ( Exception e ) {
				// ZIP圧縮失敗
				return false;
			} finally {
				// ZIPエントリクローズ
				if ( outZip != null ) {
					try { outZip.closeEntry(); } catch (Exception e) {}
					try { outZip.flush(); } catch (Exception e) {}
					try { outZip.close(); } catch (Exception e) {}
				}
			}
			return true;
		}

		/**
		 * ディレクトリ圧縮のための再帰処理
		 *
		 * @param outZip ZipOutputStream
		 * @param baseFile File 保存先ファイル
		 * @param file File 圧縮したいファイル
		 */
		private void archive(ZipOutputStream outZip, File baseFile, File targetFile) {
			if ( targetFile.isDirectory() ) {
				File[] files = targetFile.listFiles();
				for (File f : files) {
					if ( f.isDirectory() ) {
						archive(outZip, baseFile, f);
					} else {
						if ( !f.getAbsoluteFile().equals(baseFile)  ) {
							// 圧縮処理
							archive(outZip, baseFile, f, f.getAbsolutePath().replace(baseFile.getParent(), "").substring(1), "Shift_JIS");
						}
					}
				}
			}
		}

		/**
		 * 圧縮処理
		 *
		 * @param outZip ZipOutputStream
		 * @param baseFile File 保存先ファイル
		 * @param targetFile File 圧縮したいファイル
		 * @parma entryName 保存ファイル名
		 * @param enc 文字コード
		 */
		private boolean archive(ZipOutputStream outZip, File baseFile, File targetFile, String entryName, String enc) {
			// 圧縮レベル設定
			outZip.setLevel(5);

			// 文字コードを指定
//			outZip.setEncoding(enc);
			try {

				// ZIPエントリ作成
				outZip.putNextEntry(new ZipEntry(entryName));

				// 圧縮ファイル読み込みストリーム取得
				BufferedInputStream in = new BufferedInputStream(new FileInputStream(targetFile));

				// 圧縮ファイルをZIPファイルに出力
				int readSize = 0;
				byte buffer[] = new byte[1024]; // 読み込みバッファ
				while ((readSize = in.read(buffer, 0, buffer.length)) != -1) {
					outZip.write(buffer, 0, readSize);
				}
				// クローズ処理
				in.close();
				// ZIPエントリクローズ
				outZip.closeEntry();
			} catch ( Exception e ) {
				// ZIP圧縮失敗
				return false;
			}
			return true;
		}



    /**
     * 指定された ZIP ファイルを、指定されたパスに、ファイル名のディレクトリを作成して解凍します。 <br>
     *
     * @param zipFileFullPath ZIP ファイルのフルパス
     * @param unzipPath 解凍するパス
     * @return 処理結果 true:解凍成功 false:解凍失敗
     */
    public static boolean unzip( String zipFileFullPath, String unzipPath ) {

        File baseFile = new File(zipFileFullPath);
        File baseDir = new File(baseFile.getParent(), baseFile.getName().substring(0, baseFile.getName().lastIndexOf(".")));
        if ( !baseDir.mkdir() )
            System.out.println("Couldn't create directory because directory with the same name exists.: " + baseDir);

        ZipFile zipFile = null;
        try {
            // ZIPファイルオブジェクト作成
            zipFile = new ZipFile(zipFileFullPath);

            // ZIPファイル内のファイルを列挙
            Enumeration<? extends ZipEntry>  enumZip = zipFile.entries();

            // ZIPファイル内の全てのファイルを展開
            while ( enumZip.hasMoreElements() ) {

                // ZIP内のエントリを取得
                ZipEntry zipEntry = (java.util.zip.ZipEntry)enumZip.nextElement();

                //出力ファイル取得
                File unzipFile = new File(unzipPath);
                File outFile = new File(unzipFile.getAbsolutePath() + "/" + baseDir.getName(), zipEntry.getName());

                if ( zipEntry.isDirectory() )
                    outFile.mkdir();
                else {
                    // 圧縮ファイル入力ストリーム作成
                    BufferedInputStream in = new BufferedInputStream(zipFile.getInputStream(zipEntry));

                    // 親ディレクトリがない場合、ディレクトリ作成
                    if ( !outFile.getParentFile().exists() )
                        outFile.getParentFile().mkdirs();

                    // 出力オブジェクト取得
                    BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(outFile));

                    // 読み込みバッファ作成
                    byte[] buffer = new byte[1024];

                    // 解凍ファイル出力
                    int readSize = 0;
                    while ( (readSize = in.read(buffer)) != -1 ) {
                        out.write(buffer, 0, readSize);
                    }
                    // クローズ
                    try { out.close(); } catch (Exception e) {}
                    try { in.close(); } catch (Exception e) {}
                }
            }
            // 解凍処理成功
            return true;
        } catch(Exception e) {
            // エラーログ出力
            System.out.println(e.toString());
            // 解凍処理失敗
            return false;
        } finally {
            if ( zipFile != null )
                try { zipFile.close();    } catch (Exception e) {}
        }
    } //unzip









} //FileCnt
