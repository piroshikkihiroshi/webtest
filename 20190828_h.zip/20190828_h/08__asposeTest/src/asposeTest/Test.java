package asposeTest;


import org.apache.log4j.Logger;

import com.aspose.words.Document;
import com.aspose.words.SaveFormat;




public class Test {

	static Logger objLog = Logger.getLogger(Test.class);

	public static void main(String[] args){
		try {
			tester(args);
		} catch (Exception e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		} //try
	} //main

		/* まず簡単に変換のみを行ってみる */
	public static void tester(String[] args) throws Exception {
		// 処理前の時刻を取得
		long startTime = System.currentTimeMillis();

		// 処理後の時刻を取得
		long endTime = System.currentTimeMillis();

		String strDir = "//yoks3104/Project/NES_文書管理システム/99_tmp/上田/aspTest//";
		String strFile = "test.docx";
//		String strFile = "test.doc";
		objLog.info("開始時刻：" + startTime + " ms");
//		 変換対象のファイルの読み込み
		Document objDoc = new Document(strDir + strFile);

		objDoc.save(strDir + strFile + "asp_" + System.currentTimeMillis() + ".html" , SaveFormat.HTML);

		objLog.info("終了時刻：" + endTime + " ms");
		objLog.info("処理時間：" + (endTime - startTime) + " ms");
	} //tester


} //class
