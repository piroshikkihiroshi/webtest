package htmlMaskTest;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;

public class HtmlMaskTest_0190827 {
	static Logger objLog = Logger.getLogger(HtmlMaskTest_0190827.class);
	public static void main(String[] args) {

		HtmlMaskTest_0190827 objMe = new HtmlMaskTest_0190827();
		FileWriter file;
		PrintWriter pw;

		//全文検索モックデータ カンマ区切りで番号が来ると予想 intpos,そこからつづく,intpos,そこからつづく
		String strTestData = "0,2,9,3";
//		HashMap<Integer, Integer> hashTest = new HashMap<Integer, Integer>();
//		hashTest.put(0,2);
//		hashTest.put(9,3);


		//htmlをすべて読み込む
		String strDir = "//yoks3104/Project/NES_文書管理システム/99_tmp/上田/aspTest/";
		String strFileName = "test.docasp_1566802594082.html";
		String strDlFilePath = strDir + strFileName;
		String strAllHtml = "";
		String strOrgBody = "";
		String strNotTagBody = "";
		String strRepBody = "";
		String strMaskHtml= "";
		int intMaskStatsu = 1;
		try {
			strAllHtml = objMe.readAll(strDlFilePath);

	        //圧縮されたBodyを取得
			strOrgBody = objMe.getBody(strAllHtml);


			//tag以外の半角半角削除(つぶれてるからいらないかも)

			//全文検索エンジンに渡す用の文字列を取得する
			strNotTagBody=objMe.getIllegalText(strOrgBody);


//			※※※※※※※検索エンジンに送ったと想定※※※※※※※

			//全文検索から戻ってきた値をhashへ成型
			HashMap<Integer, Integer> hashRepPos = objMe.makePosHash(strTestData);


			//全文検索エンジンに返した結果を置換してbodyを入れ替えた文字列を取得
			strRepBody=objMe.bodyReplace(hashRepPos,strOrgBody,strNotTagBody,intMaskStatsu);
			//htmlのbodyの中身を入れ替える
			strMaskHtml = objMe.makeBody(strAllHtml,strRepBody);

			//htmlを出力する
//			//debug tmpに出力
			file = new FileWriter(strDir + "test.html");
			pw = new PrintWriter(new BufferedWriter(file));
			pw.println(strMaskHtml);
			pw.close();



//			System.out.println(strOrgBody);

		} catch (IOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		} //try


	} //main



	/**
	 * strpath_iで指定したファイルを改行付きですべて読み込む
	 * @param strpath_i
	 * @return
	 * @throws IOException
	 */
	public String readAll(final String strpath_i) throws IOException {
	    return Files.lines(Paths.get(strpath_i), Charset.forName("UTF-8"))
	        .collect(Collectors.joining(System.getProperty("line.separator")));

	} //readAll


	public String getBody(String strHtml_i) {
		String strRet = "";
		String strPattern="\\<body\\>.+\\</body\\>";
	    Pattern objPattern = Pattern.compile(strPattern);
	    Matcher objMatch = objPattern.matcher(strHtml_i);
	    boolean blRet=objMatch.find();
	    strRet = objMatch.group();

	    //改行を削除
	    strRet.replaceAll("\r\n", "");
		return strRet;
	} //getBody

	public String notTagSpaceDel(String strHtml_i) {
		String strRet = "";

		return strRet;
	} //notTagSpaceDel


	public String getIllegalText(String strHtml_i) {
		String strRet = strHtml_i;
		//tagを全て除去
		String strPattern="<(\"[^\"]*\"|'[^']*'|[^'\">])*>";
		strRet = strRet.replaceAll(strPattern, "");
		return strRet;
	} //getIllegalText


	//keyで当てはまったハッシュをすべて変換するよう成型する
	public HashMap<Integer, Integer> makePosHash(String strTextSrh_i) {
		HashMap<Integer, Integer> hashRet = new HashMap<Integer, Integer>();

		String[] arrTgt = strTextSrh_i.split(",");

		for (int i = 0; i < arrTgt.length; i++) {
			Integer intTmp =Integer.parseInt(arrTgt[i]);
			if( i % 2 == 0) { //偶数ならkeyを作成
				Integer intEnd =Integer.parseInt(arrTgt[i + 1]) + intTmp;
				for (int j = intTmp; j <= intEnd; j++) {
					hashRet.put(j, 0);
				} //for

			} //if

		} //for

		return hashRet;

	} //makePosHash



	/**
	 * @param hashTest
	 * @param strOrgBody_i
	 * @param intStatus_i 置換ステータス :マスク 2:赤文字
	 * @return
	 */
	public String bodyReplace(HashMap<Integer, Integer> hashRepPos_i,String strOrgBody_i,String strOrgTagDelBody_i,int intStatus_i) {
		String strTgtVal = strOrgBody_i;

		String objRep = "(<\\/?[^>]+>)|([^<]+)"; //タグを覗いた値を取得する
	    Pattern objPattern = Pattern.compile(objRep);
	    Matcher objMatch = objPattern.matcher(strTgtVal);

		String strRet = "";
		String tags = "";
		String others = "";
		String result = "";
        int intPos = 0; //tagを覗いた文字列の距離
        int intTagPos = 0; //タグを含めたstrが始まるまでの距離
        String strCurrentKwd = ""; //現在ヒットしている単語
        HashMap<String, Integer> hashKwdPos = new HashMap<String, Integer>(); //strCurrentKwdのポジションを格納する key:キーワード val：ポジション
        boolean blMatch = objMatch.find() ;
        do {
        		int intGroupCnt = objMatch.groupCount();
        		String strTmp = objMatch.group();
        		if (objMatch.group(2) !=null) { //タグ以外の文字列にマッチ
                  strCurrentKwd = objMatch.group(2);
                  if (hashKwdPos.containsKey(strCurrentKwd)) { //すでにKeyに入っているか確認
                      hashKwdPos.put(strCurrentKwd, hashKwdPos.get(strCurrentKwd) + 1); //次の検索へ
                  } else {
                      hashKwdPos.put(strCurrentKwd, 0); //最初の検索
                  } //if
                  intTagPos = strTgtVal.indexOf(strCurrentKwd, hashKwdPos.get(strCurrentKwd));
                  // intPos = strCurrentKwd.length
                  intPos = strOrgTagDelBody_i.indexOf(strCurrentKwd, hashKwdPos.get(strCurrentKwd));
                  //hashでヒットしていたら置換
                  if (hashRepPos_i.containsKey(intPos)) {
                      // var intEndCnt = glHashRep_i[intPos];
                      int intEndCnt = hashRepPos_i.get(intPos) - 2;
                      for (int i = 0; i < strCurrentKwd.length(); i++) {
                          strTgtVal = strTgtVal.substring(0, intTagPos + i) + "■" + strTgtVal.substring(intTagPos + i + 1, strTgtVal.length());
                          if (i > intEndCnt) {
                              break;
                          } //if
                      } //for
                  } //if
				} //if
//        		System.out.println(intGroupCnt);


//            if (arrRet[1]) {
//                // tags[tags.length] = arrRet[1];
//                // intTagPos++;
//            } else if (arrRet[2]) {
//                strCurrentKwd = arrRet[2]
//                if (strCurrentKwd in hashKwdPos) {
//                    hashKwdPos[strCurrentKwd] = hashKwdPos[strCurrentKwd] + 1;
//                } else {
//                    hashKwdPos[strCurrentKwd] = 0;
//                } //if
//                intTagPos = strTgtVal.indexOf(strCurrentKwd, hashKwdPos[strCurrentKwd]);
//                // intPos = strCurrentKwd.length
//                intPos = glOrgTagDelBody.indexOf(strCurrentKwd, hashKwdPos[strCurrentKwd]);
//                //hashでヒットしていたら置換
//                if (intPos in glHashRep_i) {
//                    // var intEndCnt = glHashRep_i[intPos];
//                    var intEndCnt = glHashRep_i[intPos] - 2;
//                    for (let i = 0; i < strCurrentKwd.length; i++) {
//                        strTgtVal = strTgtVal.substring(0, intTagPos + i) + "$" + strTgtVal.substring(intTagPos + i + 1, strTgtVal.length);
//                        if (i > intEndCnt) {
//                            break;
//                        } //if
//                    } //for
//                } //if
//            } //if


        } while (objMatch.find() ); // マッチした数だけループする


		return strTgtVal;
	} //bodyReplace


	public String makeBody(String strAllHtml_i,String strRepBody_i) {
		String strRet = strAllHtml_i;
		String strPattern="\\<body\\>.+\\</body\\>";

	    //Bodyを入れ替え
//		strRet=strRet.replaceAll(strPattern, strRepBody_i);
		strRet=strAllHtml_i.replaceFirst(strPattern, strRepBody_i);
		return strRet;
	} //getBody







} //class
