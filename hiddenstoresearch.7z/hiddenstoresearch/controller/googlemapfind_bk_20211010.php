<?php

//inifile
$arrIni = parse_ini_file("../setting/setting.ini");

//配列にいくつかの緯度経度のセットを格納
//緯度経度はカンマでつなぎ、スペースは含めない
$strLat = $_POST['tgtlat'];
$strLng = $_POST['tgtlng'];
$strRadius=$_POST['radiusselect'];
$strKeyword = $_POST['inputKeyword'];
$numBaseRank=(float)$_POST['rankselect'];
$numBaseRatingTotal=(float)$_POST['ratingstotalselect'];
$strApiKey = $arrIni['key'];

$strNextPageToken = null;
$arrPlacesInfo = array();
$arrPlacesRetInfo = array();
$strRet = '';
$intCnt = 0;
$hashRet = array('status'=>'NG');

//ajax判定
if(!ajaxJudge()){
	$hashRet['msg'] = '不正なアクセスです。Code -1';
	echo json_encode($hashRet);
	return false;		
} //if

//hiddenstore.phpからきてるか判定
if (!isset($_SERVER['HTTP_REFERER']) || strpos($_SERVER['HTTP_REFERER'],'hiddenstore') == 0)
{
	$hashRet['msg'] = '不正なアクセスです。Code -2';
	echo json_encode($hashRet);
	return false;		
} //if

$strBaseUrl = 'https://maps.googleapis.com/maps/api/place/nearbysearch/json';
$strDirectionBaseUrl = 'https://maps.googleapis.com/maps/api/directions/json'; //徒歩の距離取得

//$strUrl = $strBaseUrl.'?location='."${strLat}.${strLng}".'&radius='.$strRadius.'&language=ja&keyword='.$strKeyword.'&key='.$strApiKey;
$strUrl = $strBaseUrl.'?location='."${strLat},${strLng}".'&radius='.$strRadius.'&language=ja';
if($strKeyword != ''){
	$strUrl.='&keyword='.urlencode($strKeyword);
}else{
	$strUrl.='&types=restaurant'; //キーワード指定がないときはrestaurantを指定
} //if
$strUrl.='&key='.$strApiKey;
//$hashData= json_decode(@file_get_contents($strUrl), true);
$hashData=getApiDataCurl($strUrl);
if(empty($hashData)){
	$hashRet['msg'] = '【Places API】API Call時にエラーが発生しました。';
	echo json_encode($hashRet);
	return false;	
} //if

$strRet = getPlaceRet($hashData);
$fltDist = 0.0;
if($strRet == ''){

	//resultsをplacesList配列に結合
	$arrPlacesInfo = array_merge($arrPlacesInfo,$hashData["results"]);
	//next_page_tokenを取得
	if(array_key_exists("next_page_token",$hashData)){
		$strNextPageToken = $hashData["next_page_token"];			
	}else{
		$strNextPageToken = '';			
	} //if

}else{
	$hashRet['msg'] = $strRet;
	echo json_encode($hashRet);
	return false;
} //if

//次ページステータスが渡ってきていたら2回目なので無視
if(empty($_POST["next"])){
	//次ページ情報がある場合、最初の結果だけ先に返す
	if($strNextPageToken !== '') {
		$arrPlacesRetInfo = makePlaceInfo($arrPlacesInfo);
		//viewに返す
		$hashRet['status'] = "OK";
		$hashRet['msg'] = "検索結果が${intCnt}件以上";
		$hashRet['cnt'] = $intCnt;
		$hashRet['next'] = "1";
		$hashRet = array_merge($hashRet,$arrPlacesRetInfo); 
		echo json_encode($hashRet);
		return false;
	} //if
} //if


//next_page_tokenが取得された場合は次ページあり。
//next_page_tokenが取得できなくなるまで、
//次ページ情報の取得を繰り返す。
while ($strNextPageToken != null) {
	// sleep(2); //（連続リクエストすると取得に失敗する）
	usleep(2000000);
	$strUrl = $strBaseUrl.'?key='.$strApiKey.'&pagetoken='.$strNextPageToken;
	$hashData=getApiDataCurl($strUrl);
	if(empty($hashData)){
		$hashRet['msg'] = '【Places API】API Call時にエラーが発生しました。';
		echo json_encode($hashRet);
		return false;	
	} //if	
	$strRet = getPlaceRet($hashData);
	if($strRet == ''){
		//resultsをplacesList配列に結合
		$arrPlacesInfo = array_merge($arrPlacesInfo,$hashData["results"]);
		//next_page_tokenを取得
		if(array_key_exists("next_page_token",$hashData)){
			$strNextPageToken = $hashData["next_page_token"];			
		}else{
			$strNextPageToken = '';			
		} //if
	}else{
		$hashRet['msg'] = $strRet;
		echo json_encode($hashRet);
		return false;
	} //if	
	
} //while

//道なり距離なども足す
$arrPlacesRetInfo = makePlaceInfo($arrPlacesInfo);

$intCnt=count($arrPlacesRetInfo);
// $strGMapBase='https://maps.google.co.jp/maps?';

if($intCnt==0){
	$hashRet['msg'] = "検索結果が0件でした。";
	echo json_encode($hashRet);
	return false;	
} //if

//viewに返す
$hashRet['status'] = "OK";
$hashRet['msg'] = "検索結果${intCnt}件";
$hashRet['cnt'] = $intCnt;
$hashRet = array_merge($hashRet,$arrPlacesRetInfo); 
echo json_encode($hashRet);
return false;	

//返却hash($arrPlacesRetInfo)を作成する
//@param $arrPlacesInfo
//@return $arrPlacesRetInfo
function makePlaceInfo($arrPlacesInfo){
	global $numBaseRank, $numBaseRatingTotal,$strDirectionBaseUrl,$strLat,$strLng,$strApiKey,$intCnt;
	$arrPlacesRetInfo = array();
	//rating,user_ratings_totalが設定されていないものを
	//一旦「-1」に変更する。
	for ($i = 0; $i < count($arrPlacesInfo); $i++) {
		if (!array_key_exists("rating",$arrPlacesInfo[$i])) {
			$arrPlacesInfo[$i]["rating"] = -1;
		} //if
		if (!array_key_exists("user_ratings_total",$arrPlacesInfo[$i])) {
			$arrPlacesInfo[$i]["user_ratings_total"] = -1;
		} //if	
	} //for

	//ratingがnumBaseRank以上,user_ratings_totalがnumBaseRatingTotal以下のものだけ取得
	$intCnt = 0;
	for ($i = 0; $i < count($arrPlacesInfo); $i++) {
		if ((float)$arrPlacesInfo[$i]["rating"] >= $numBaseRank and (float)$arrPlacesInfo[$i]["user_ratings_total"] <= $numBaseRatingTotal) {
			//20190730 歩いた場合の所要時間、距離を出す
			$strTgtLat=$arrPlacesInfo[$i]["geometry"]["location"]["lat"];
			$strTgtLng=$arrPlacesInfo[$i]["geometry"]["location"]["lng"];		
			$strUrl = $strDirectionBaseUrl.'?origin='."${strLat},${strLng}".'&destination='."${strTgtLat},${strTgtLng}".'&mode=walking&region=ja';
			$strUrl.='&key='.$strApiKey;
			$hashData=getApiDataCurl($strUrl);
			if(empty($hashData)){
				$hashRet['msg'] = '【Places API】API Call時にエラーが発生しました。';
				echo json_encode($hashRet);
				return false;	
			} //if
			$arrPlacesInfo[$i]["legs"] = $hashData["routes"][0]["legs"][0];
			array_push($arrPlacesRetInfo,$arrPlacesInfo[$i]); 
			$intCnt++;
		} //if
	} //for
	return $arrPlacesRetInfo;
} //function


function getPlaceRet($hashData_i){
	if ($hashData_i["status"] == "OK") {
		return '';
	} else if ($hashData_i["status"] == "ZERO_RESULTS") {
		return "【Places API】検索結果が0件です。";
	} else if ($hashData_i["status"] == "ERROR") {
		return "【Places API】サーバ接続に失敗しました。";
	} else if ($hashData_i["status"] == "INVALID_REQUEST") {
		return "【Places API】リクエストが無効でした。";
	} else if ($hashData_i["status"] == "OVER_QUERY_LIMIT") {
		return "【Places API】リクエストの利用制限回数を超えました。";
	} else if ($hashData_i["status"] == "REQUEST_DENIED") {
		return "【Places API】サービスが使えない状態でした。";
	} else if ($hashData_i["status"] == "UNKNOWN_ERROR") {
		return "【Places API】原因不明のエラーが発生しました。";
	} //if	
} //function




function getApiDataCurl($url)
{
    $option = [
        CURLOPT_RETURNTRANSFER => true, //文字列として返す
        CURLOPT_TIMEOUT        => 10, // タイムアウト時間
    ];

    $ch = curl_init($url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); //証明書無視
    curl_setopt_array($ch, $option);

    $json    = curl_exec($ch);
    $info    = curl_getinfo($ch);
    $errorNo = curl_errno($ch);

    // OK以外はエラーなので空白配列を返す
    if ($errorNo !== CURLE_OK) {
        // 詳しくエラーハンドリングしたい場合はerrorNoで確認
        // タイムアウトの場合はCURLE_OPERATION_TIMEDOUT
        return [];
    }

    // 200以外のステータスコードは失敗とみなし空配列を返す
    if ($info['http_code'] !== 200) {
        return [];
    }

    // 文字列から変換
    $jsonArray = json_decode($json, true);

    return $jsonArray;
} //function

//ajaxか判定する。
function ajaxJudge(){
	if(isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
		return true;  
	} //if	
	return false;
} //function



?>