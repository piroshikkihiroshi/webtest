<?php
$url = "http://kamelong.com/API/RosenzuAPI/v0.1/stations";
// $url = "http://kamelong.com/API/RosenzuAPI/v0.1/stations/name/横浜";
$StationsArray = file_get_contents($url);
//$array = json_encode($StationsArray, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
$array = json_decode( $StationsArray , true ) ;
if ($array === NULL) {
   return;
}else{
   $tmpname = [];
   $tmpgID = [];
   $uniqueStations = [];
   foreach ($array as $station => $value){
       foreach ($value as $station1 => $value1)
           if (!in_array($value1['name'], $tmpname)) {
                   $tmpname[] = $value1['name'];
                   $tmpgID[] = $value1['groupID'];
                   unset($value1["id"]);
                   unset($value1['lineID']);
                   unset($value1['stationID']);
                   //unset($value1['groupID']);
                   $uniqueStations[] = $value1;
           }elseif (!in_array($value1['groupID'], $tmpgID)){
               $tmpgID[] = $value1['groupID'];
               $value1["name"] = $value1["name"].$value1["lineName"];
               unset($value1["id"]);
               unset($value1['lineID']);
               unset($value1['stationID']);
               //unset($value1['groupID']);
               $uniqueStations[] = $value1;
           }
       }
   }
//echo $array["stations"][1]["name"];
  var_dump($uniqueStations);


?>
