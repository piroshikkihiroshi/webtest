<?php
//駅情報をjsonで吐き出す

$url = "http://kamelong.com/API/RosenzuAPI/v0.1/stations";
//テスト用↓
// $url = "http://kamelong.com/API/RosenzuAPI/v0.1/stations/name/福島";
$StationsArray = file_get_contents($url);
$array = json_decode( $StationsArray , true ) ;
if ($array === NULL) {
   return;
}else{
   $tmpname = [];
   $tmpgID = [];
   $uniqueStations = [];
   foreach ($array as $station => $value){
       foreach ($value as $station1 => $value1){
           if (!in_array($value1['name'], $tmpname)) {
                   $tmpname[] = $value1['name'];
                   $tmpgID[] = $value1['groupID'];
                   unset($value1['id']);
                   unset($value1['lineID']);
                   unset($value1['stationID']);
                   unset($value1['groupID']);
                //    $uniqueStations[$value1['name']] = $value1;
                $strTmpKey = mb_convert_encoding($value1['name'],'UTF-8');
                $uniqueStations[$strTmpKey] = $value1;                
           }elseif (!in_array($value1['groupID'], $tmpgID)){
                $tmpgID[] = $value1['groupID'];
                $value1['name'] = $value1['name']."(".$value1['lineName'].")";
                unset($value1['id']);
                unset($value1['lineID']);
                unset($value1['stationID']);
                unset($value1['groupID']);
            //    $uniqueStations[$value1['name']] = $value1;
                $strTmpKey = mb_convert_encoding($value1['name'],'UTF-8');
                $uniqueStations[$strTmpKey] = $value1;                            
           }//if
       }//for
   }//for
}//if
// var_dump($uniqueStations);

$strOutFile = "../api/station.json";
$strOut = json_encode($uniqueStations, JSON_UNESCAPED_UNICODE);
file_put_contents($strOutFile,$strOut);

