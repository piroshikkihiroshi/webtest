<?php

$strOutFile = "../api/station.json";
$strOut = "上書き";
file_put_contents($strOutFile,$strOut);

