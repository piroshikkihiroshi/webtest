# coding: UTF-8
import base64
import copy
import cv2
import datetime
import glob
import io
import json
import math 
import os
import re
import shutil
import sys
import collections as cl
import numpy as np
import pandas as pd
import time
import csv

from PIL import Image
from PIL import ImageDraw
from PIL import ImageFont
from IPython.display import HTML
from IPython.display import YouTubeVideo

import matplotlib.pyplot as plt

#20200401 
import subprocess

#localで動かすのに必要なもの
#・python3＋モジュール
#・FFmpeg
#・OpenPose(CPU版でよい)

# グローバル変数
# DEBUG_FLAG = False #デバッグフラグ
DEBUG_FLAG = True #デバッグフラグ TrueだとOpenPoseまたはtf-pose-estimationを動かさない
OPEN_POSE_FLAG = True #True:OpenPose False:tf-pose-estimation にて画像解析
youTubeID = "GlCsc2rhnQ4"  # プロのYOUTUBE動画を指定   たまに、YOUTUBE側でロックがかかっている動画あり、その動画は参照不可
WK_Name = "inagawa111"  # 処理結果を格納するフォルダー名を設定
CSV_NAME='json2timeSeries.csv'

glOpenPoseBin = '/home/murakamr/openpose/build/examples/openpose/openpose.bin'
glOpenPoseHome = '/home/murakamr/openpose/'
glMp4Name = 'output.mp4'
glFontPath = '/home/murakamr/content/Fonts/'

glStartDir = '/home/murakamr/op2/content'
glInputMovie1 = '/home/murakamr/op2/minimal-django-file-upload-example/src/for_django_2-0/myproject/myapp/templates/inp.mp4'
glOutputPath1 = '/home/murakamr/op2/content/MOV1'
glOutputCsvPath1 = '/home/murakamr/op2/content/MOV1/'+CSV_NAME
glAviFile1='/home/murakamr/op2/content/MOV1/openpose.avi'
glMoveOut1 = '/home/murakamr/op2/content/MOV1'

glInputMovie2 = '/home/murakamr/op2/minimal-django-file-upload-example/src/for_django_2-0/myproject/media/documents/2020/02/03/matuyama.mp4'
glOutputPath2 = '/home/murakamr/op2/content/MOV2'
glOutputCsvPath2 = '/home/murakamr/op2/content/MOV2/'+CSV_NAME
glAviFile2='/home/murakamr/op2/content/MOV2/openpose.avi'
glMoveOut2 = '/home/murakamr/op2/content/MOV2'

#windowsならC直下にhome以降をコピーすれば動くように
if os.name == 'nt':
  glStartDir='C:'+glStartDir
  glFontPath='C:'+glFontPath
  glOpenPoseBin= "C:/home/murakamr/op2/openpose/bin/OpenPoseDemo.exe"
  glOpenPoseHome='C:/home/murakamr/op2/openpose/'  

  glInputMovie1='C:'+glInputMovie1 
  glOutputPath1='C:'+glOutputPath1 
  glOutputCsvPath1='C:'+glOutputCsvPath1
  glAviFile1='C:'+glAviFile1
  glMoveOut1='C:'+glMoveOut1

  glInputMovie2='C:'+glInputMovie2 
  glOutputPath2='C:'+glOutputPath2 
  glOutputCsvPath2='C:'+glOutputCsvPath2
  glAviFile2='C:'+glAviFile2
  glMoveOut2='C:'+glMoveOut2

def main():
  """
  main処理 
  """    
  #carrentDirectoryを移動
  # os.chdir(glStartDir)

  # def_OpenPoseによる動画解析
  analysis_OpenPose(glInputMovie1, glOutputPath1,glOutputCsvPath1)
  analysis_OpenPose(glInputMovie2,glOutputPath2,glOutputCsvPath2)

  # # AVIファイル→MP4変換
  AviToMP4(glAviFile1,glMoveOut1,glMp4Name)
  AviToMP4(glAviFile2,glMoveOut2,glMp4Name)

  # #ボーン付き動画を画像にする
  movieToPicture(glMoveOut1+'/'+glMp4Name,glMoveOut1)
  movieToPicture(glMoveOut2+'/'+glMp4Name,glMoveOut2)

  # #ボーン付き画像をトリミングする
  movieToEditedPicture(glOutputPath1+"/"+CSV_NAME,glOutputPath1)
  movieToEditedPicture(glOutputPath2+"/"+CSV_NAME,glOutputPath2)


  # # #白い画像を用意
  makeWhiteImgs(WK_Name, youTubeID)

  # # #白い画像に角度や伸長率などを記載
  draw_evolution_to_white(glOutputPath1+"/"+CSV_NAME,glOutputPath2+"/"+CSV_NAME, WK_Name)

  # # #各シーンでの写真と角度などの値を1つの画像にする
  for stage_num in range(0, 8):
      concat_risize_stage(stage_num, glOutputPath1+"/blank", glOutputPath1+"/"+CSV_NAME,
      glOutputPath2+"/"+CSV_NAME, WK_Name, youTubeID)

  # 画像を動画にする
  # picture_to_movie("/content/"+WK_Name+"WK/openpose/holizon")
  # picture_to_movie("/content/"+WK_Name+"WK/openpose/youtube/"+youTubeID)
  # picture_to_movie("/content/"+WK_Name+"WK/openpose/MOV")


  # #プロと被験者の比較　点数出力
  All_score = score(glOutputPath1+"/"+CSV_NAME,glOutputPath2+"/"+CSV_NAME)
  # print(All_score)

  # #プロ・被験者の鼻の位置の変化
  # Player1_Nose =Nose_point("/content/"+WK_Name+"WK/openpose/youtube/"+youTubeID+"/"+CSV_NAME)
  # Player2_Nose =Nose_point("/content/"+WK_Name+"WK/openpose/MOV/"+CSV_NAME)
  # print(Player1_Nose)
  # print(Player2_Nose)

  print("script end")

def show_video(file_name, width, height):
  """
  作成したビデオをエンコードしHTML5で描画できるようにする
  Args:
      file_name String: 動画ファイルのフルパス 
      width String: 動画の幅
      height String: 動画の高さ
  Return videoタグ
  """  
  import io
  import base64
  from IPython.display import HTML
  video_encoded = base64.b64encode(io.open(file_name, 'rb').read())
  return HTML(data='''<video width="{0}" height="{1}" alt="test" controls>
                      <source src="data:video/mp4;base64,{2}" type="video/mp4" />
                    </video>'''.format(width, height, video_encoded.decode('ascii')))


def picture_to_movie(inputPath):
  """
  画像を動画にする(現在未使用)
  Args:
      inputPath String: 動画directoryのフルパス 
  Return videoタグ
  """ 
  os.chdir(inputPath)

  if os.path.exists("risize.mp4"):
      os.remove("risize.mp4")
  # # !ffmpeg - framerate 15 - i "./dst/%04d.jpg" "risize.mp4"
  cmd = 'ffmpeg - framerate 15 - i "./dst/%04d.jpg" "risize.mp4"'
  proc = subprocess.Popen( cmd,shell=True )
  proc.wait()


def concat_risize_stage(stage,outputPath,youtube_csv,mov_csv,WK_name,youTubeID):
  """
  TODO
  """  
  save_All =draw_evolution_to_white(glMoveOut1+"/"+CSV_NAME,glMoveOut2+"/"+CSV_NAME,WK_name)
  
  define_youtube =define_stage(youtube_csv)
  define_mov = define_stage(mov_csv)
  
  youtube_stage_img  = glMoveOut1+"/dst/" + "{0:04d}".format(define_youtube[stage]) + ".jpg"
  mov_stage_img      = glMoveOut2+"/dst/" + "{0:04d}".format(define_mov[stage]) + ".jpg"
  
  print(youtube_stage_img)
  print(mov_stage_img)
  print(save_All[0][stage])
  print(save_All[1][stage])
  
  youtube_stage_img = cv2.imread(youtube_stage_img)
  mov_stage_img = cv2.imread(mov_stage_img)
  save_stage_youtube_img = cv2.imread(save_All[0][stage])
  save_stage_mov_img = cv2.imread(save_All[1][stage])
  
  if stage ==0:
    stage = "Start"
  elif stage == 1:
    stage = "TakeBack"
  elif stage == 2:
    stage = "BackSwing"
  elif stage == 3:
    stage = "Top"
  elif stage == 4:
    stage = "DownSwing"
  elif stage == 5:
    stage = "Impact"
  elif stage == 6:
    stage = "FollowThrough"
  elif stage == 7:
    stage = "Finish"
    
#   print(stage)
  
  concat_resize = concat_tile_resize([[youtube_stage_img, mov_stage_img],
                                       [save_stage_youtube_img, save_stage_mov_img]])
  cv2.imwrite(outputPath + "/" + stage +"/"+ stage + ".jpg", concat_resize)
  
  
# #   #2つの画像を結合した写真の内、必要なフレームの画像を取得・格納する
  
  concat_resize_human =hconcat_resize_min([youtube_stage_img, mov_stage_img])
  cv2.imwrite(outputPath + "/" + stage +"/human"+ stage + ".jpg", concat_resize_human)


def concat_tile_resize(im_list_2d, interpolation=cv2.INTER_CUBIC):
  """
  TODO
  """   
  im_list_v = [hconcat_resize_min(im_list_h, interpolation=cv2.INTER_CUBIC) for im_list_h in im_list_2d]
  return vconcat_resize_min(im_list_v, interpolation=cv2.INTER_CUBIC)


def draw_evolution_to_white(youtube_csv,mov_csv,WK_name):
  """
  比較元、比較先のフレームを取得
  Args:
    youtube_csv　:比較元CSVファイルのフルパス(Pro)
    mov_csv　:比較先CSVファイルのフルパス(uploadしたMovieのcsv)
  return: 比較元、比較先の生成物フルパス配列
  """ 
  youtube_stage = define_stage(youtube_csv)
  youtube_param =[]

  for frame in youtube_stage:
    tmpCalParam=calParameter(youtube_stage[0],frame,youtube_csv)
    youtube_param.append(tmpCalParam)
    # youtube_param.append(calParameter(youtube_stage[0],frame,youtube_csv))
  mov_stage = define_stage(mov_csv)
  mov_param =[]

  for frame in mov_stage:
    mov_param.append(calParameter(mov_stage[0],frame,mov_csv))
  save_Start_youtube         =(glMoveOut1+"/blank/Start/Start_youtube.jpg")
  save_TakeBack_youtube      =(glMoveOut1+"/blank/TakeBack/TakeBack_youtube.jpg")
  save_BackSwing_youtube     =(glMoveOut1+"/blank/BackSwing/BackSwing_youtube.jpg")
  save_Top_youtube           =(glMoveOut1+"/blank/Top/Top_youtube.jpg")
  save_DownSwing_youtube     =(glMoveOut1+"/blank/DownSwing/DownSwing_youtube.jpg")
  save_Impact_youtube        = (glMoveOut1+"/blank/Impact/Impact_youtube.jpg")
  save_FollowThrough_youtube = (glMoveOut1+"/blank/FollowThrough/FollowThrough_youtube.jpg")
  save_Finish_youtube        = (glMoveOut1+"/blank/Finish/Finish_youtube.jpg")
  
  draw_img(youtube_param[0], save_Start_youtube,WK_name)
  draw_img(youtube_param[1], save_TakeBack_youtube,WK_name)
  draw_img(youtube_param[2], save_BackSwing_youtube,WK_name)
  draw_img(youtube_param[3], save_Top_youtube,WK_name)
  draw_img(youtube_param[4], save_DownSwing_youtube,WK_name)
  draw_img(youtube_param[5], save_Impact_youtube,WK_name)
  draw_img(youtube_param[6], save_FollowThrough_youtube,WK_name)
  draw_img(youtube_param[7], save_Finish_youtube,WK_name)
  
  save_youtube =[save_Start_youtube,save_TakeBack_youtube,save_BackSwing_youtube,save_Top_youtube,
                save_DownSwing_youtube,save_Impact_youtube,save_FollowThrough_youtube,save_Finish_youtube]
  
  
  save_Start_mov         =(glMoveOut2+"/blank/Start/Start_mov.jpg")
  save_TakeBack_mov      =(glMoveOut2+"/blank/TakeBack/TakeBack_mov.jpg")
  save_BackSwing_mov     =(glMoveOut2+"/blank/BackSwing/BackSwing_mov.jpg")
  save_Top_mov           =(glMoveOut2+"/blank/Top/Top_mov.jpg")
  save_DownSwing_mov     =(glMoveOut2+"/blank/DownSwing/DownSwing_mov.jpg")
  save_Impact_mov        = (glMoveOut2+"/blank/Impact/Impact_mov.jpg")
  save_FollowThrough_mov = (glMoveOut2+"/blank/FollowThrough/FollowThrough_mov.jpg")
  save_Finish_mov        = (glMoveOut2+"/blank/Finish/Finish_mov.jpg")


  draw_img(mov_param[0], save_Start_mov,WK_name)
  draw_img(mov_param[1], save_TakeBack_mov,WK_name)
  draw_img(mov_param[2], save_BackSwing_mov,WK_name)
  draw_img(mov_param[3], save_Top_mov,WK_name)
  draw_img(mov_param[4], save_DownSwing_mov,WK_name)
  draw_img(mov_param[5], save_Impact_mov,WK_name)
  draw_img(mov_param[6], save_FollowThrough_mov,WK_name)
  draw_img(mov_param[7], save_Finish_mov,WK_name)
  
  save_mov =[save_Start_mov,save_TakeBack_mov,save_BackSwing_mov,save_Top_mov,save_DownSwing_mov,
              save_Impact_mov,save_FollowThrough_mov,save_Finish_mov]
  
  save_all =[save_youtube,save_mov]
  
  return save_all

def draw_img(print_number,save_path,WK_name):
  """
  白い画像に評価値を書き込むメソッド
  """ 
  img = Image.open(glStartDir+"/blank.jpg")
  draw = ImageDraw.Draw(img)
  font = ImageFont.truetype(glFontPath+"MEIRYOB.TTC", 27) #必ず C:\Windows\Fonts を /content/drive/My Drive/Fontsにコピーする！！
  draw.text((50, 10),"\n" + "右腕の角度(肩から手首):"      + print_number[0] + "度"
                    + "\n" + "体幹(首から尻の中心):"        + print_number[1] + "度"
                    + "\n" + "右足の角度(膝から足首):"      + print_number[2] + "度"
                    + "\n" + "左足の角度(膝から足首):"      + print_number[3] + "度"
                    + "\n" + "両腕の角度(右肘・右手・左肘):"+ print_number[4] + "度"
                    + "\n" + "肩のひねり(肩の長さ):"        + print_number[5] + "度"
                    + "\n" + "右腕の伸び率(首から手首):"    + print_number[6] + "%"
                    + "\n" + "右足の伸び率(尻から親指):"    + print_number[7] + "%"
                    + "\n" + "左足の伸び率(尻から親指):"    + print_number[8] + "%", fill=(255, 0, 0), font=font)
  
  img.save(save_path)


def makeWhiteImgs(WK_name,youTubeID):
  """
  白い画像と結果格納用ディレクトリを作成する
  """  

  horizontalImgDir   = glMoveOut1+"/holizon/dst/"
  height = 0
  width = 0
  channels = 0

  if os.path.exists(horizontalImgDir):
    shutil.rmtree(horizontalImgDir)
  os.makedirs(horizontalImgDir)

  #プロ と 被験者の画像を連番で横に連結する
  for i in range(0,len(glob.glob(glMoveOut1+"/dst/*"))):
    youtubeData_dst    = glMoveOut1+"/dst/" + "{0:04d}".format(i) + ".jpg"
    movData_dst        = glMoveOut2+"/dst/" + "{0:04d}".format(i) + ".jpg"
    horizontalData_dst = horizontalImgDir                       + "{0:04d}".format(i) + ".jpg"
    youtubeImg = cv2.imread(youtubeData_dst)
    movImg = cv2.imread(movData_dst)
  
#       print(youtubeImg)
#       print(movImg)

#       img_horizontal_resize = hconcat_resize_min([youtubeImg, movImg]) #hconcat_resize_minメソッドを使用
#       height, width, channels = img_horizontal_resize.shape[:3] #連結画像の縦横サイズを取得する
#       mixImg_horizontal_resize = cv2.resize(img_horizontal_resize , (int((width // 2) * 2), int((height //2) * 2 ))) #必ず画像サイズを偶数にする ※奇数だと画像から動画変換できない
#       cv2.imwrite(horizontalData_dst, mixImg_horizontal_resize)
#       height, width, channels = mixImg_horizontal_resize.shape[:3] #連結画像の取得

  blanks = glMoveOut1+"/blank"
  if os.path.exists(blanks):
    shutil.rmtree(blanks)
  os.makedirs(blanks)

  #blankディレクトリにリストのディレクトリを作成する
  os.chdir(blanks)
  path_list = ["Start","TakeBack","BackSwing","Top","DownSwing","Impact","FollowThrough","Finish"]
  for blanks in path_list:
      os.makedirs(blanks, exist_ok=True)
      
  
  blanks = glMoveOut2+"/blank"
  if os.path.exists(blanks):
    shutil.rmtree(blanks)
  os.makedirs(blanks)

  #blankディレクトリにリストのディレクトリを作成する
  os.chdir(blanks)
  path_list = ["Start","TakeBack","BackSwing","Top","DownSwing","Impact","FollowThrough","Finish"]
  for blanks in path_list:
      os.makedirs(blanks, exist_ok=True)


#     height, width, channels = mixImg_horizontal_resize.shape[:3] #連結画像の取得
#     #連結画像から評価用の白い画像を作成
  hei = (150 // 2) #縦幅の調整 ※変更可
  wid = (120 // 2) #横幅の調整 ※変更不可！！
  blank = np.zeros((hei, wid, 3))
  blank += 255 #画像の色の調整←白色)[255,255,255]になる

  cv2.imwrite(glMoveOut1+"/blank/blank.jpg",blank) #白い画像を１つ用意


def hconcat_resize_min(im_list, interpolation=cv2.INTER_CUBIC):
  """
  サイズが違う画像を縦幅を揃えて横に連結する
  """   
#     print(im_list)
#     print(im for im in im_list)
  h_min = min(im.shape[0] for im in im_list)

  im_list_resize = [cv2.resize(im, (int(im.shape[1] * h_min / im.shape[0]), h_min), interpolation=interpolation)
                    for im in im_list]
  return cv2.hconcat(im_list_resize)

    
def vconcat_resize_min(im_list, interpolation=cv2.INTER_CUBIC):
  """
  サイズが違う画像を横幅を揃えて縦に連結する
  """  
  w_min = min(im.shape[1] for im in im_list)
  im_list_resize = [cv2.resize(im, (w_min, int(im.shape[0] * w_min / im.shape[1])), interpolation=interpolation)
                    for im in im_list]
  return cv2.vconcat(im_list_resize)

def movieToEditedPicture(csvFile,in_outputPath):
  """
  MP4から、OpenPoseのボーンを加え必要部分をカットした画像データを作成する
  Args:
      csvFile String: CSVファイルpath
      in_outputPath String: input outputするファイルpath
  """  
  dstImgDir = in_outputPath+"/dst"
  jpgImgDir = in_outputPath+"/jpg"
  
  if os.path.exists(dstImgDir):    
    shutil.rmtree(dstImgDir)
  os.makedirs(dstImgDir)
  
  
  #csvからX,Yの最小値最大値を取得  [x_max,x_min,y_max,y_min]に格納
  MinMax = readMinMax(csvFile)
    
  def crop_center(pil_img, crop_width, crop_height):
    """
    X,Yの最大最小値から指定したサイズ分伸ばして画像をトリミングする
    ※関数内関数
    """  
    return pil_img.crop(((MinMax[1] - crop_width),
                         (MinMax[3] - crop_height),
                         (MinMax[0] + crop_width),
                         (MinMax[2] + crop_height)))
  
  jpgImgFiles = glob.glob("{}/*.jpg".format(jpgImgDir))
  jpgImgFiles.sort() #ソートしないとバラバラの写真になる
  for i, file in enumerate(jpgImgFiles):
    im = Image.open(file)  
    im_crop = crop_center(im, 100, 50) #上下左右に画像サイズ50分伸ばしてトリミングする
    dst_file = "{dir}/{index:04d}.jpg".format(dir=dstImgDir,index=i)  
    im_crop.save(dst_file)


def Nose_point(csvFile):
  """
  CSVから鼻の位置を出す(現在未使用)
  Args:
      csvFile String: CSVファイルpath
  """    
  # df = pd.read_csv(csvFile,header=None,usecols=[1])
  df = pd.read_csv(csvFile,skiprows=1,header=None,usecols=[1])
  df = df.rename(columns={1:"Nose"})
  df = df.replace(0,np.nan)
  df = df.fillna(method ="ffill")
  
  frame =define_stage(csvFile)
  Nose_answer =[]
  Nose_answer_dif =[]
  
  for i in frame:
    Nose_answer.append(round(df.loc[i,"Nose"]))
  for i in range(0,8):
    Nose_answer_dif.append((round(Nose_answer[i]*(100/Nose_answer[0])-100))*-1)                       #Startframeを100とした場合の差分
    
  return Nose_answer_dif


def score(Player1_csv,Player2_csv):  
  """
  比較元、比較先とのスコアを出す
  """   
  Player1_frame =define_stage(Player1_csv)
  Player2_frame =define_stage(Player2_csv)

  Player1_palam =[]

  for frame in Player1_frame:
    Player1_palam.append(calParameter(Player1_frame[0],frame,Player1_csv))
  Player2_palam =[]  

  for frame in Player2_frame:
    Player2_palam.append(calParameter(Player2_frame[0],frame,Player2_csv))

  Player_frame =len(Player1_frame)
  Player_palam =len(Player1_palam)

  All_param =[]

  for i in range(0,Player_frame):
    All_param_pre = []
    for j in range(Player_palam):
      #i:flame j:flameに対する値 player2,1の差分を取得し絶対値化
      All_param_pre_pre=(abs(int(Player2_palam[i][j])-int(Player1_palam[i][j])))   #絶対値化はintでなければならないので、intにキャストする
      
      if All_param_pre_pre >300:             #角度が、0度・360度を超えてしまった場合、本来であれば近しいのに、大きな差が発生するため補正する
        All_param_pre_pre =360-All_param_pre_pre
      All_param_pre.append(All_param_pre_pre)
    All_param.append(All_param_pre)
    
  answer =[]

  for i in range(len(All_param)):
    Sum_point =0
    point =0
    for j in range(5):
      
      point =chackPoint(All_param[i][j])
      Sum_point =Sum_point + point
      
    Sum_point =round((Sum_point/100)*100)     #100%に補正　数値は、j rangeの数×20点に合わせる
    answer.append(Sum_point)

  frame_score =["Address_frame: {}％".format(answer[0]),"Take_Back_frame：{}％ ".format(answer[1]),"BackSwing_frame：{}％ ".format(answer[2]),
                "Top_frame：{}％ ".format(answer[3]),"DownSwing_frame：{}％ ".format(answer[4]),
                "ImpactFrame：{}％ ".format(answer[5]),"Follow_through_frame：{}％ ".format(answer[6]),
                "Finish_frame：{}％ ".format(answer[7])]

  answer_total =round((answer[0]+answer[1]+answer[2]+(answer[3] * 0.5)+(answer[4] * 1.5)+(answer[5] * 1.5)+(answer[6] * 1.5)+(answer[7] * 0.5))/8.5)      #「ダウンスイング・インパクト・フォロースルー」に重みを乗せた
                                                                                                                                                          #誤差の出やすいトップ・フィニッシュの割合を下げる
  
  sum_score =("一致率：{}％".format(answer_total))
  #各部分ごとの一致率
  body_score =[]
  for i in range(0,len(All_param)):
    
    Wrist_score =chackPoint(All_param[i][0])
    Wrist_score =Wrist_score * 5   #100点に補正
    
    Trunk_score =chackPoint(All_param[i][1])
    Trunk_score =Trunk_score * 5
  
    Rleg_score  =chackPoint(All_param[i][2])
    Rleg_score  =Rleg_score * 5
    
    Lleg_score  =chackPoint(All_param[i][3])
    Lleg_score  =Lleg_score * 5
    
    if i ==0:
      name ="Address"
    elif i ==1:
      name ="TakeBack"
    elif i ==2:
      name ="BackSwing"
    elif i ==3:
      name ="Top"
    elif i ==4:
      name ="DownSwing"
    elif i ==5:
      name ="Impact"
    elif i ==6:
      name ="FollowThrough"
    elif i ==7:
      name ="Finish"
  
    body_score_pre =["{}'s Wrist_score: {}％".format(name,Wrist_score),"{}'s Trunk_score: {}％".format(name,Trunk_score),"{}'s Rleg_score: {}％".format(name,Rleg_score),
                      "{}'s Lleg_score: {}％".format(name,Lleg_score)]
  
    body_score.append(body_score_pre)
      
  for i in range(0,8):
    All_param[i][0] = All_param[i][0]*5
    All_param[i][1] = All_param[i][1]*5
    All_param[i][2] = All_param[i][2]*5
    All_param[i][3] = All_param[i][3]*5
    if All_param[i][0] >= 100:
      All_param[i][0] =100
    if All_param[i][1] >= 100:
      All_param[i][1] =100
    if All_param[i][2] >= 100:
      All_param[i][2] =100
    if All_param[i][3] >= 100:
      All_param[i][3] =100
      
  stock = [["No","Address_frame","Take_Back_frame","BackSwing_frame","Top_frame","DownSwing_frame","ImpactFrame","Follow_through_frame","Finish_frame","Total"], [1, answer[0],answer[1],answer[2],answer[3],answer[4],answer[5],answer[6],answer[7],answer_total]]
      
#       stock = [["No","Address_frame","Take_Back_frame","BackSwing_frame","Top_frame","DownSwing_frame","ImpactFrame","Follow_through_frame","Finish_frame","Total"], 
#              [1, answer[0],answer[1],answer[2],answer[3],answer[4],answer[5],answer[6],answer[7],answer_total],
#              ["Address's Wrist_score","Address's Trunk_score","Address's Rleg_score","Address's Lleg_score"],
#              [All_param[0][0],All_param[0][1],All_param[0][2],All_param[0][3]],
#               ["TakeBack's Wrist_score","TakeBack's Trunk_score","TakeBack's Rleg_score","TakeBack's Lleg_score"],
#               [All_param[1][0],All_param[1][1],All_param[1][2],All_param[1][3]],
#               ["BackSwing's Wrist_score","BackSwing's Trunk_score","BackSwing's Rleg_score","BackSwing's Lleg_score"],
#               [All_param[2][0],All_param[2][1],All_param[2][2],All_param[2][3]],
#               ["Top's Wrist_score","Top's Trunk_score","Top's Rleg_score","Top's Lleg_score"],
#               [All_param[3][0],All_param[3][1],All_param[3][2],All_param[3][3]],
#               ["DownSwing's Wrist_score","DownSwing's Trunk_score","DownSwing's Rleg_score","DownSwing's Lleg_score"],
#               [All_param[4][0],All_param[4][1],All_param[4][2],All_param[4][3]],
#               ["Impact''s Wrist_score","Impact''s Trunk_score","Impact''s Rleg_score","Impact''s Lleg_score"],
#               [All_param[5][0],All_param[5][1],All_param[5][2],All_param[5][3]],
#               ["FollowThrough's Wrist_score","FollowThrough's Trunk_score","FollowThrough's Rleg_score","FollowThrough's Lleg_score"],
#               [All_param[6][0],All_param[6][1],All_param[6][2],All_param[6][3]],
#               ["Finish's Wrist_score","Finish's Trunk_score","Finish's Rleg_score","Finish's Lleg_score"],
#               [All_param[7][0],All_param[7][1],All_param[7][2],All_param[7][3]]]
  
  with open(glStartDir+'/point.csv', 'w') as f:
    writer = csv.writer(f)  # writerオブジェクトを作成
    writer.writerows(stock)
    
  return frame_score,sum_score,body_score


def chackPoint(param_num):
  """
  player1,2の差分をポイント化する
  """   
  if param_num <=3:
    point =20
  elif param_num <=5:
    point =17
  elif param_num <=7:
    point =13
  elif param_num <=10:
    point =8
  elif param_num <=15:
    point =5
  elif param_num <=20:
    point =2.5
  else:
    point =0
    
  return point


def calParameter(Start_frame,frame,csvFile):
  """
  角度・ねじり・伸長率を計算する
  Args:
      Start_frame : Impactが格納されたフレーム
      frame : Impact、Top、DownSwing、Address、BackSwing、TakeBack、Follow-through、Finishの順番で格納されたフレーム
      csvFile String: CSVファイルpath
  Return:
      各計算結果
  """    
  # df = pd.read_csv(csvFile,header=None,usecols=[1,3,4,6,7,9,10,12,13,15,16,18,19,21,22,24,25,27,28,30,31,33,34,36,37,39,40,42,43,57,58,66,67])
  df = pd.read_csv(csvFile,skiprows=1,header=None,usecols=[1,3,4,6,7,9,10,12,13,15,16,18,19,21,22,24,25,27,28,30,31,33,34,36,37,39,40,42,43,57,58,66,67])
  df = df.rename(columns={1:"Nose",3:"Neck_x",4:"Neck_y",6:"RShoulder_x",7:"RShoulder_y",9:"RElbow_x",10:"RElbow_y",12:"RWrist_x",13:"RWrist_y",15:"LShoulder_x",16:"LShoulder_y",\
                          18:"LElbow_x",19:"LElbow_y",21:"LWrist_x",22:"LWrist_y",24:"MidHip_x",25:"MidHip_y",27:"RHip_x",28:"RHip_y",30:"RKnee_x",31:"RKnee_y",33:"RAnkle_x",34:"RAnkle_y",\
                          36:"LHip_x",37:"LHip_y",39:"LKnee_x",40:"LKnee_y",42:"LAnkle_x",43:"LAnkle_y",57:"LBigToe_x",58:"LBigToe_y",66:"RBigToe_x",67:"RBigToe_y"})
  df = df.replace(0,np.nan)
  
  #結果表示にString型が必要なため、各数値をキャストする
  #※始点は左上が0スタートだが、yは下に行くほど大きくなる(第四象限ぽいのにyはプラス)
  #※角度は内接で出している為、180で引く

  #手首角度=右肩から右手首の角度
  degree_Wrist     = str(180-(round(deg_ground(df.at[frame,'RShoulder_x']  ,df.at[frame,'RShoulder_y'],df.at[frame,'RWrist_x'],df.at[frame,'RWrist_y']))))  #角度計算を右からに補正
  degree_Trunk     = str(180-(round(deg_ground(df.at[frame,'Neck_x']  ,df.at[frame,'Neck_y']  ,df.at[frame,'MidHip_x'],df.at[frame,'MidHip_y']))))
  degree_right_leg = str(180-(round(deg_ground(df.at[frame,'RKnee_x'] ,df.at[frame,'RKnee_y'] ,df.at[frame,'RAnkle_x'],df.at[frame,'RAnkle_y']))))
  degree_left_leg  = str(180-(round(deg_ground(df.at[frame,'LKnee_x'] ,df.at[frame,'LKnee_y'] ,df.at[frame,'LAnkle_x'],df.at[frame,'LAnkle_y']))))
  
  #肩の捻り
  twist_Shoulder   = str(round(deg_twist(df.at[Start_frame,'RShoulder_x'],df.at[Start_frame,'RShoulder_y'],df.at[Start_frame,'LShoulder_x'],df.at[Start_frame,'LShoulder_y'],\
                                     df.at[frame,'RShoulder_x'],df.at[frame,'RShoulder_y'],df.at[frame,'LShoulder_x'],df.at[frame,'LShoulder_y'])))
 
  #手首の伸縮率
  stretch_Wrist    = str(round((per_stretch(df.at[Start_frame,'RWrist_x'],df.at[Start_frame,'RWrist_y'],df.at[Start_frame,'Neck_x'] ,df.at[Start_frame,'Neck_y'],\
                                 df.at[frame,'RWrist_x'],df.at[frame,'RWrist_y'],df.at[frame,'Neck_x']  ,df.at[frame,'Neck_y']))*100))
  stretch_right_leg= str(round(per_stretch(df.at[Start_frame,'RHip_x'] ,df.at[Start_frame,'RHip_y'] ,df.at[Start_frame,'RBigToe_x'],df.at[Start_frame,'RBigToe_y'],\
                                 df.at[frame,'RHip_x'] ,df.at[frame,'RHip_y'] ,df.at[frame,'RBigToe_x'],df.at[frame,'RBigToe_y'])*100))
  stretch_left_leg = str(round(per_stretch(df.at[Start_frame,'LHip_x'] ,df.at[Start_frame,'LHip_y'] ,df.at[Start_frame,'LBigToe_x'],df.at[Start_frame,'LBigToe_y'],\
                                 df.at[frame,'LHip_x'] ,df.at[frame,'LHip_y'] ,df.at[frame,'LBigToe_x'],df.at[frame,'LBigToe_y'])*100))
  
  
  
  RL_arm_deg       =str(round(arms_deg(df.at[frame,'RElbow_x'],df.at[frame,'RElbow_y'],df.at[frame,'LElbow_x'],df.at[frame,'LElbow_y'],df.at[frame,'RWrist_x'],df.at[frame,'RWrist_y'])))

  return degree_Wrist,degree_Trunk,degree_right_leg,degree_left_leg,RL_arm_deg,twist_Shoulder,stretch_Wrist,stretch_right_leg,stretch_left_leg



def arms_deg(x1, y1, x2, y2, x3, y3):
  """
  左右の肘の角度
  Args:
      x1(現在の右肘x)
      y1(現在の右肘y)
      x2(現在の左肘x)
      y2(現在の左肘x)
      x3(現在の右手首x)
      y3(現在の右手首y)
  Return:
      肘の角度
  """    
  ab =math.sqrt(((x2-x1)**2)+((y2-y1)**2))
  ac =math.sqrt(((x3-x1)**2)+((y3-y1)**2))
  bc =math.sqrt(((x3-x2)**2)+((y3-y2)**2))
  
  cosAnswer =(((ac)**2)+((bc)**2)-((ab)**2))/(2*ac*bc)
  
  return math.degrees(math.acos(cosAnswer))
  

def per_stretch(x1, y1, x2, y2, xr1, yr1, xr2, yr2):
  """
  伸縮率を計算
  Args:
      x1(Impact時(初期時)のx)
      y1(Impact時(初期時)のy)
      x2(Impact時(初期時)のx)
      y2(Impact時(初期時)のy)
      xr1(現在フレームx)
      yr1(現在フレームy)
      xr2(現在フレームx)
      yr2(現在フレームy)
  Return:
      伸縮率(割合)
  """  
  sqrt_start = math.sqrt( (y2-y1)**2 + (x2-x1)**2 )
  sqrt_now   = math.sqrt( (yr2-yr1)**2 + (xr2-xr1)**2 )
  return sqrt_now / sqrt_start

def deg_twist(x1, y1, x2, y2, xr1, yr1 ,xr2, yr2):
  """
  肩の捻りを計算
  Args:
      x1(Impact時(初期時)の右肩x)
      y1(Impact時(初期時)の右肩y)
      x2(Impact時(初期時)の左肩x)
      y2(Impact時(初期時)の左肩y)
      xr1(現在フレームの右肩x)
      yr1(現在フレームの右肩y)
      xr2(現在フレームの左肩x)
      yr2(現在フレームの左肩y)
  Return:
      角度(度)
  """        
  sqrt_start = ( (y2-y1)**2 + (x2-x1)**2 ) #平方根を出すためのtmp値(基準値：Impact) 基準(1)とする
  sqrt_now   = ( (yr2-yr1)**2 + (xr2-xr1)**2 ) #現在の平方根を出すためのtmp値
  sqrt = math.sqrt( sqrt_now / sqrt_start ) #sqrt_now / sqrt_startのルートを出すことで(基準値：Impact)との傾きを出す
  if sqrt >= 1:     #初期位置の肩の長さを超えた場合、1を設定する
      sqrt = 1
  return math.degrees(math.acos(sqrt))


def deg_ground(x1, y1, x2, y2):
  """
  タンジェントからラジアンを出力
  そのラジアンを角度に変換して返す
  Args:
      x1(Cosθ1)
      y1(Sinθ1)
      x2(Cosθ2)
      y2(Sinθ2)
  Return:
      角度(度)
  """  
  radian=math.atan2(y2-y1,x2-x1)
  degRet = math.degrees(radian)
  return degRet
  # return math.degrees(math.atan2(y2-y1,x2-x1))


def define_stage(csvFile):
  """
  CSVファイルから以下の以下の場面で使用するフレームを求める
  Impact、Top、DownSwing、Address、BackSwing、TakeBack、Follow-through、Finish
  """  
  # df = pd.read_csv(csvFile, header=None, usecols=[12, 13, 67])
  df = pd.read_csv(csvFile,skiprows=1,header=None, usecols=[12, 13, 67])  
  df = df.rename(columns={12: 'RWrist_x', 13: 'RWrist_y', 67: "RBigToe_y"})
  df = df.replace(0, np.nan)

  #Impactframeを計算し取得
  ImpactFrame = defineImpact(csvFile)

  #残りのフレームは「ImpactFrame」を基準にRWist(右手首)の最大位置、最小位置などから計算

  #Top
  df_before_impact = df[0:ImpactFrame]
  Top_frame = df_before_impact.sort_values("RWrist_y").index[0]

  #DownSwing
  df_Top_to_impact = df[Top_frame:ImpactFrame]
  DownSwing_frame = df_Top_to_impact.sort_values("RWrist_x").index[0]

  #Address
  df_before_Top = df[0:Top_frame]
  Address_frame = df_before_Top.sort_values(
      "RWrist_y", ascending=False).index[0]

  #BackSwing
  df_BackSwing = df[Address_frame:Top_frame]
  BackSwing_frame = df_BackSwing.sort_values("RWrist_x").index[0]

  #TakeBack
  df_Take_Back = df[Address_frame:BackSwing_frame]
  df_Take_Back = abs(df_Take_Back.diff())
  Take_Back_frame = df_Take_Back.sort_values(
      'RWrist_x', ascending=False).index[0]

  #Follow-through
  df_Follow_through = df[ImpactFrame:len(df.index)]
  Follow_through_frame = df_Follow_through.sort_values(
      'RWrist_x', ascending=False).index[0]

  #Finish
  df_Finish = df[Follow_through_frame:len(df.index)]
  Finish_frame = df_Finish.sort_values('RWrist_y').index[0]

  return Address_frame, Take_Back_frame, BackSwing_frame, Top_frame, DownSwing_frame, ImpactFrame, Follow_through_frame, Finish_frame


def defineImpact(csvFile):
  """
  Impactで使用するフレームを計算する
  Args:
      csvFile String: csvファイルのフルパス 
  Return Impactで使用するフレームのCSV行
  """  
  # df = pd.read_csv(csvFile,header=None,usecols=[12,13,24,25])
  df = pd.read_csv(csvFile,skiprows=1,header=None,usecols=[12,13,24,25])
  df = df.replace(0,np.nan)
  df = df.rename(columns={12: 'RWrist_x',13:'RWrist_y',24: 'MidHip_x',25: 'MidHip_y'})


  #差分を取得
  df['dif'] = abs(df['RWrist_x'].diff()) #行のdiffを取得し、絶対値化する
  df = df.sort_values('dif',ascending = False) #dif列でソート(降順)

  df_diff = df.head(15).copy() #使用する15行目までコピー
  #(RWrist_x列(範囲15行)-MidHip_x列(範囲15行)の2乗)+(RWrist_y列(範囲15行)-MidHip_y列(範囲15行)^2)の(1/2)乗　※どのような公式か確認必要
  df_diff['dist'] = ((df_diff.loc[:,'RWrist_x']-df_diff.loc[:,'MidHip_x'])**2+(df_diff.loc[:,'RWrist_y']-df_diff.loc[:,'MidHip_y'])**2)**(1/2)
  df_diff = df_diff.sort_values('dist')
  
  retFlame = df_diff.index[0]
  return retFlame
  # return df_diff.index[0]


def readMinMax(csvFile):
  """
  CSVよりx,yの最小値、最大値を取得する
  Args:
      csvFile String: CSVファイルpath
  Return:
      x_max,x_min,y_max,y_min
  """
  # df = pd.read_csv(csvFile,header=None,usecols=[12,13,67])
  df = pd.read_csv(csvFile,skiprows=1,header=None,usecols=[12,13,67])
  df = df.replace(0,np.nan)
  df = df.rename(columns={12: 'RWrist_x',13:'RWrist_y',67:"RBigToe_y"})

  #最大のXを取得
  df_x_max = df.sort_values('RWrist_x',ascending=False).index[0]
  x_max = round(df.loc[df_x_max,'RWrist_x'],-1)

  #最少のXを取得
  df_x_min = df.sort_values('RWrist_x').index[0]
  x_min =round(df.loc[df_x_min,"RWrist_x"],-1)

  #最大のYを取得
  df_y_max = df.sort_values('RBigToe_y',ascending=False).index[0]
  y_max = round(df.loc[df_y_max,'RBigToe_y'],-1)

  #最少のYを取得
  df_y_min = df.sort_values('RWrist_y').index[0]
  y_min = round(df.loc[df_y_min,'RWrist_y'],-1)  
  return x_max,x_min,y_max,y_min


#OpenPose_Golf内では直接参照しない関数
#
def movieToPicture (aviFile,outputPath):
  """
  MP4を画像ファイルへ変換する
  Args:
      aviFile String: aviのpath
      outputPath String: 作成画像の出力先
  """  
  jpgOutput = outputPath + "/jpg"
  
  if os.path.exists(jpgOutput):    
    shutil.rmtree(jpgOutput)
  os.makedirs(jpgOutput)

  # !ffmpeg -i {aviFile} -vf fps=30 -start_number 0 {jpgOutput}"/%04d.jpg"
  cmd='ffmpeg -i '+aviFile+' -vf fps=30 -start_number 0 '+jpgOutput+'"/%04d.jpg"'
  proc = subprocess.Popen( cmd,shell=True )
  proc.wait()  


def AviToMP4(aviFile,outputPath,outFileName):
  """
  AVIファイルをMP4へ変換する
  Args:
      aviFile String: aviのpath
      outputPath String: MP4ファイルの出力先directory
      outFileName String: 出力ファイル名(拡張子つき)
  Return: outputFile
  """
  outputFile =  outputPath + "/" + outFileName

  if os.path.exists(outputFile):
    os.remove(outputFile)
  # convert Avi to MP4
  cmd='ffmpeg -y -loglevel info -i '+aviFile+' '+outputFile
  proc = subprocess.Popen( cmd,shell=True )
  proc.wait()

  return outputFile



def analysis_OpenPose(inputFile,outputPath,outputCsvPath):
  """
  OpenPoseを実行しJsonとaviファイルの作成をする
  Args:
      inputFile String: 動画ファイルのフルパス 例：/templates/inp.mp4
      outputPath String: OpenPoseを実行した際出力されるjsonファイルを格納する 例：/home/op2/content/MOV1
      outputCsvPath String: OpenPoseを実行した際出力されるjsonを加工したCSVファイルのフルパス 例：/home/op2/content/MOV1/json2timeSeries.csv
  """
  outputJsonPath = outputPath+"/json" 

  #出力先の初期化
  if os.path.exists(outputJsonPath) and not DEBUG_FLAG: #デバッグ時は初期化処理を行わない
    shutil.rmtree(outputJsonPath)
    os.makedirs(outputJsonPath)

  #OpenPoseを実行しJsonとaviファイルの作成をする
  cmd=glOpenPoseBin+' --video '+inputFile+' --write_json '+outputPath+'/json --display 0 --write_video '+outputPath+'/openpose.avi --number_people_max 1'
  if not DEBUG_FLAG: #デバッグ時は時間がかかるのでOpenPoseを走らせない
    if OPEN_POSE_FLAG: #OpenPoseで画像解析
      os.chdir(glOpenPoseHome) #openposeのホームディレクトリでないと動作しない
      proc = subprocess.Popen( cmd,shell=True )
      proc.wait()
    else:
      tfPoseEstimationMain(video=inputFile,
      write_json=outputPath+'/json',
      no_display=True,
      write_video=outputPath+'/openpose.avi', 
      number_people_max=1)      

  #※※TODO ここいります？
  #jsonに空のデータある時は、0を書き込む
  # for i in range(0,len(glob.glob(outputJsonPath))):
  #   key_json = outputJsonPath + "/inp_" + "{0:012d}".format(i) + "_keypoints.json" #対象Json名
  #   with open(key_json, 'r') as file:
  #     json_data = json.load(file)
  #     if "'people': []}" in str(json_data):  
  #       ys =dict( {"version":1.3,"people":[{"person_id":[-1],"pose_keypoints_2d":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],"face_keypoints_2d":[],"hand_left_keypoints_2d":[],"hand_right_keypoints_2d":[],"pose_keypoints_3d":[],"face_keypoints_3d":[],"hand_left_keypoints_3d":[],"hand_right_keypoints_3d":[]}]} )
  #       with open(key_json,'w') as fw:
  #         json.dump(ys,fw,separators=(',', ':'))  #入力するときの空白を埋める
  #※※TODO ここいります？

  # #20200403 可読性が悪いのでjsonをループしてCSVを作成する
  if os.path.exists(outputCsvPath): #一度CSV削除
    os.remove(outputCsvPath)
  csvFile = open(outputCsvPath, 'a', encoding='utf-8')
  files = glob.glob(outputJsonPath+"/*.json")
  files.sort() #ソートしないと順番通りに行かない
  for i,tgtFilePath in enumerate(files): #出力下jsonファイル全て処理
    strTmpVal = ''
    openfile = open(tgtFilePath, 'r')
    json_data = json.load(openfile)
    print('tgtFilePath:'+tgtFilePath)
    dicTgtJson = json_data['people'][0]['pose_keypoints_2d'] #取得は「pose_keypoints_2d」のみ
    if i==0: #csvのヘッダーを書き込む
      #doc https://github.com/CMU-Perceptual-Computing-Lab/openpose/blob/master/doc/output.md
      strHeader = 'Nose_x,Nose_y,Nose_p,Neck_x,Neck_y,Neck_p,RShoulder_x,RShoulder_y,RShoulder_p,RElbow_x,RElbow_y,RElbow_p,RWrist_x,RWrist_y,RWrist_p,LShoulder_x,LShoulder_y,LShoulder_p,LElbow_x,LElbow_y,LElbow_p,LWrist_x,LWrist_y,LWrist_p,MidHip_x,MidHip_y,MidHip_p,RHip_x,RHip_y,RHip_p,RKnee_x,RKnee_y,RKnee_p,RAnkle_x,RAnkle_y,RAnkle_p,LHip_x,LHip_y,LHip_p,LKnee_x,LKnee_y,LKnee_p,LAnkle_x,LAnkle_y,LAnkle_p,REye_x,REye_y,REye_p,LEye_x,LEye_y,LEye_p,REar_x,REar_y,REar_p,LEar_x,LEar_y,LEar_p,LBigToe_x,LBigToe_y,LBigToe_p,LSmallToe_x,LSmallToe_y,LSmallToe_p,LHeel_x,LHeel_y,LHeel_p,RBigToe_x,RBigToe_y,RBigToe_p,RSmallToe_x,RSmallToe_y,RSmallToe_p,RHeel_x,RHeel_y,RHeel_p'+"\n"
      strTmpVal+=strHeader
    for strJsonVal in dicTgtJson:
      
      strTmpVal+=str(strJsonVal) + ','
    strTmpVal = strTmpVal[:-1] + "\n" #末尾削除+改行
    csvFile.write(strTmpVal)
    openfile.close()
  csvFile.close()    


  # !sed -e 's/..version".1.3,"people"..."person_id"..-1.."pose_keypoints_2d"..//g' /home/murakamr/op2/content/MOV1/json/inp_000000000???_keypoints.json| rev | cut -c 188- | rev > /home/murakamr/op2/content/MOV1/json2timeSeries.csv
  print("OpenPose json csvOutEnd:"+inputFile)


def MovToMP4(movFile,outputPath,startTime,period):
  """
  TODO
  """   
  movDir = outputPath+"/MOV"
  
  if os.path.exists(movDir):    
    shutil.rmtree(movDir)
  os.makedirs(movDir)
  
  outputFile = movDir +"/video.mp4"

  #convert Avi to MP4
  # !ffmpeg -y -loglevel info -i {movFile} -ss {startTime} -t {period} {outputFile}

  return outputFile

def tfPoseEstimationMain(video=''
  ,resolution='432x368'
  ,model='mobilenet_thin'
  ,no_bg=False
  ,write_json='/tmp/'
  ,no_display=False
  ,resize_out_ratio=4.0
  ,number_people_max=1
  ,frame_first=0
  ,write_video=None
  ,tensorrt="False"):
    """
    tf-pose-estimationによる二次元ポーズ推定を行う
    video String: 動画ファイルのフルパス
    resolution String: 解像度 例 432x368'
    model String: 使用するモデル 左記の順で精度が高く、右記の順で速度が早い cmu (trained in 656x368) mobilenet_thin (trained in 432x368) mobilenet_v2_large (trained in 432x368) mobilenet_v2_small (trained in 432x368)
    no_bg boolean: 骨格のみ出力する
    write_json String: 推定した二次元の関節位置情報をJSONフォーマットでファイルに出力する。
    no_display boolean: Trueだと画面描写を行わない
    resize_out_ratio
    number_people_max int: ポーズ推定の対象となる人数の最大値を指定      
    frame_first int: 解析対象となる最初のフレームの番号を指定
    write_video ポーズ推定の結果を動画ファイルとして出力
    """

    # import argparse
    import logging
    # import time
    # import sys
    # import cv2
    # import numpy as np
    # import os

    from tf_pose.estimator import TfPoseEstimator
    from tf_pose.networks import get_graph_path, model_wh
    def str2bool(v):
      return v.lower() in ("yes", "true", "t", "1")
    logger = logging.getLogger('TfPoseEstimator-Video')
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    formatter = logging.Formatter('[%(asctime)s] [%(name)s] [%(levelname)s] %(message)s')
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    fps_time = 0

    logger.debug('initialization %s : %s' % (model, get_graph_path(model)))
    w, h = model_wh(resolution)
    e = TfPoseEstimator(get_graph_path(model), target_size=(w, h), trt_bool=str2bool(tensorrt))
    cap = cv2.VideoCapture(video)

    if cap.isOpened() is False:
      logger.error("Error opening input video stream or file: {0}".format(video))
      sys.exit(1)


    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    if write_video is not None:
      fourcc = cv2.VideoWriter_fourcc(*'XVID')
      out = cv2.VideoWriter(write_video, fourcc, 30.0, (width, height))
      # out = cv2.VideoWriter(write_video, fourcc, 5.0, (width, height))
    
    sys.stdout.write("frame: ")
    frame = 0
    detected = False
    while cap.isOpened():
      ret_val, image = cap.read()
      if not ret_val:
        break
      if frame < frame_first:
        frame += 1
        continue
      
      sys.stdout.write('\rframe: {:5}'.format(frame))
      humans = e.inference(image, resize_to_default=(w > 0 and h > 0), upsample_size=resize_out_ratio)
      if len(humans) > 0:
        detected = True
      del humans[number_people_max:]
      if no_bg:
        image = np.zeros(image.shape)
      image = TfPoseEstimator.draw_humans(image, humans, imgcopy=False, frame=frame, output_json_dir=write_json)
      frame += 1
      # 動画にFPSを書きたい場合コメントアウトを外す
      # cv2.putText(image, "FPS: %f" % (1.0 / (time.time() - fps_time)), (10, 10),  cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
      if not no_display:
        cv2.imshow('tf-pose-estimation result', image)
      if write_video is not None:
        out.write(image)
      fps_time = time.time()
      if cv2.waitKey(1) == 27:
        break

    sys.stdout.write("\n")

    if write_video is not None:
      out.release()

    if frame <= frame_first:
      logger.error('No frame is processed: frame_first = {0}, frame = {1}'.format(frame_first, frame))
      sys.exit(1)

    if not detected:
      logger.error('No human is detected in the video: {0}'.format(video))
      sys.exit(1)

    cv2.destroyAllWindows()
    logger.debug('finished+')

#main関数呼び出し
if __name__ == '__main__':
  main()
