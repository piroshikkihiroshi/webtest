package jp.co.nec.docmng.blackPaint.logic.procenter;

import java.io.File;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import jp.co.nec.docmng.blackPaint.entity.procenter.PrcenterConvert;
import jp.co.nec.docmng.blackPaint.entity.procenter.ProcenterEnt;

@Component

public class ProcnterWebApi {

	static Logger objLog = LoggerFactory.getLogger(ProcnterWebApi.class);

	/**
	 * PROCENTER/CのWEBAPIを呼び出す(form-urlencoded)
	 * @param String strUrl_i   webapiurl
	 * @param String strJson_i strUrl_iにわたすjsonString
	 * @return ProcenterEnt jacksonでコンバートしたbeen
	 * @throws Exception
	 */
	public ProcenterEnt getProCenterUrencode(String strUrl_i,String strJson_i) throws Exception{

		//header
		HttpHeaders objHeaders = new HttpHeaders();
		objHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

		//body
		MultiValueMap<String, String> hashQuery= new LinkedMultiValueMap<String, String>();
		String strEncoding = "UTF-8";
		String strEncJson = "";
		strEncJson=URLEncoder.encode(strJson_i, strEncoding);
		hashQuery.add("query", strEncJson);

		//Request
		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(hashQuery, objHeaders);

		RestTemplate restTemplate = new RestTemplate(new SimpleClientHttpRequestFactory());

		//Response
		ResponseEntity<String> entResponse = restTemplate.postForEntity( strUrl_i, request , String.class );

		//json convert
		PrcenterConvert prcenterConvert = new PrcenterConvert();
		ProcenterEnt procenterEnt = prcenterConvert.fromJsonString(entResponse.getBody());

		return procenterEnt;

	} //method

	/**
	 * PROCENTER/CのWEBAPIを呼び出す(multipart)
	 * ※ファイルアップロードときはこちらを呼び出す
	 * @param String strUrl_i   webapiurl
	 * @param String strJson_i strUrl_iにわたすjsonString
	 * @return ProcenterEnt jacksonでコンバートしたbeen
	 * @throws Exception
	 */
	public ProcenterEnt getProCenterMultipart(String strUrl_i,String strSessionInfoJson_i,List<String> listFilePath_i) throws Exception{

		String strBoundary = "---------------------------7dd24e3050716";

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);

        // This nested HttpEntiy is important to create the correct
        // Content-Disposition entry with metadata "name" and "filename"

		int index = listFilePath_i.get(0).lastIndexOf('/');
		String strFileName = listFilePath_i.get(0).substring(index + 1,listFilePath_i.get(0).length());

        MultiValueMap<String, String> fileMap = new LinkedMultiValueMap<>();
        ContentDisposition contentDisposition = ContentDisposition
                .builder("form-data")
                .name("file")
                .filename(strFileName)
                .build();
        fileMap.add(HttpHeaders.CONTENT_DISPOSITION, contentDisposition.toString());
		File objFile = new File(listFilePath_i.get(0));
		byte[] arrbytes = Files.readAllBytes(objFile.toPath());

        HttpEntity<byte[]> fileEntity = new HttpEntity<>(arrbytes, fileMap);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("file", fileEntity);

        HttpEntity<MultiValueMap<String, Object>> requestEntity =
                new HttpEntity<>(body, headers);
        RestTemplate restTemplate = new RestTemplate(new SimpleClientHttpRequestFactory());
        try {
            ResponseEntity<String> response = restTemplate.exchange(
            		strUrl_i,
                    HttpMethod.POST,
                    requestEntity,
                    String.class);
        } catch (HttpClientErrorException e) {
            e.printStackTrace();
        }



		return null;
//		return procenterEnt;

	} //method



} //PolicyGet
