//グローバル変数
Count = 0;
deleterCount = 0;
objDeleteAllCount = 0;
editCheck = 0;
AddBtnCheck = 0;
editCancelCheck = 0;
reflectCheck = 0;
addkeyValue = 0;
reflectflag = 0;

// POST送信フラグ
var isPost = false;

$(function () {

  /**
   * 画面が変更または閉じれる時に動作
   * ダイアログを表示する
   * messageboxで表示を行いたいが、検知の限界が存在する為「beforeunload」を使用する
   * 参考サイト：https://teratail.com/questions/51831
  **/
  $(window).on("beforeunload", function (e) {
    // POST送信フラグが「true」の場合、ダイアログを表示しない
    if (isPost) {
      return;
    } else {
      return true;
    }
  });

  /**
   * 表の表示時に動作
  **/
  $('.scrollBody').ready(function (e) {

    // サーバー側で設定反映が完了したかメッセージを出力する
    var saved = $('#saveStatus').attr('value');
    if (saved == "success") {
      alert('変更が反映されました。');
    } else if (saved == "failure") {
      alert('設定反映に失敗しました。');
    }

    //ボタンの状態設定(disable)
    // 編集キャンセルボタンをdisable
    editCancelCheck = 0;
    isEditCancel();

    // 反映ボタンをdisable
    reflectCheck = 0;
    isReflect();

    //表示項番の設定
    DisplayNo();

  });// function

  /**
   * 表をクリック時に動作
   * クリックを行った時に選択した行の色が変更される
  **/
  $('.scrollBody').mousedown(function (e) {
    //表の項目以外をクリック時には色を付けない
    if (e.target.id != "main_scroll") {
      if (e.target.className != "tr l") {
        if (e.target.nodeName == "A") {
          if (e.target.parentElement.parentElement.id == 'selected') {
            document.getElementById('selected').removeAttribute("id");
            return true;
          } else {
            if (document.getElementById('selected') == null) {
              e.target.parentElement.parentElement.setAttribute('id', 'selected');
            }// if
            document.getElementById('selected').removeAttribute("id");
            e.target.parentElement.parentElement.setAttribute('id', 'selected');
            return true;
          }// if
        }// if
        //一項目のみclick可能とする
        if (e.target.parentElement.id == 'selected') {
          document.getElementById('selected').removeAttribute("id");
        } else {
          if (document.getElementById('selected') == null) {
            e.target.parentElement.setAttribute('id', 'selected');
          }// if
          document.getElementById('selected').removeAttribute("id");
          e.target.parentElement.setAttribute('id', 'selected');
        }// if
      } else {
        return false;
      }// if
    } else if (e.target.id == "main_scroll") {
      return false;
    }// if

  });// function
  $('#displayName').mousedown(function (e) {
	  reflectCheck = 0;
	  isReflect();
  });// function
  $('#serverName').mousedown(function (e) {
	  reflectCheck = 0;
	  isReflect();
  });// function
  $('#directoryPath').mousedown(function (e) {
	  reflectCheck = 0;
	  isReflect();
  });// function
  $('#loginUserName').mousedown(function (e) {
	  reflectCheck = 0;
	  isReflect();
  });// function
  $('#loginPassword').mousedown(function (e) {
	  reflectCheck = 0;
	  isReflect();
  });// function
});// function

/**
 * 表示項番を新しくする
**/
function DisplayNo() {
  for (let i = 1; i < document.getElementById('main_scroll').childElementCount + 1; i++) {
    document.getElementById('main_scroll').children[i - 1].children[1].innerText = "" + i;
    Count++;
  }// for
}// function

//グローバル変数
var changedValues = {};
var addValues = {};
var addListCount = 0;

/**
* 反映ボタンクリック時に動作
**/
function check() {
  var objDisplayName = document.getElementById('displayName');
  var objServerName = document.getElementById('serverName');
  var objDirectoryPath = document.getElementById('directoryPath');
  var objLoginUserName = document.getElementById('loginUserName');
  var objLoginPassword = document.getElementById('loginPassword');
  var objAutoRowNo = document.getElementById("main_scroll").childElementCount + 1;
  strAutoRowNo = '' + objAutoRowNo;
  //未入力チェック
  if (objDisplayName.value == "") {
    alert('『表示名』が未入力です。');
    return false;
  } else if (objServerName.value == "") {
    alert('『対象サーバ』が未入力です。');
    return false;
  } else if (objDirectoryPath.value == "") {
    alert('『フォルダパス』が未入力です。');
    return false;
  }// if

  //編集状態がアクティブ化しているか判断を行う
  if (document.getElementsByClassName('EditMode').length == 0) {
    Count++;
    //連想配列の作成
    addValues[addListCount] = { ["displayName"]: objDisplayName.value, ["serverName"]: objServerName.value, ["directoryPath"]: objDirectoryPath.value, ["loginUserName"]: objLoginUserName.value, ["loginPassword"]: objLoginPassword.value };

    // 登録されているkey, valueを順に取得する
    var ul = $('<ul class="tr l " '+ addListCount +'></ul>');
    var strDisplay = $('<li class="w40"></li>');
    var strServer = $('<li class="w120"></li>');
    var strjServerName = $('<li class="w120"></li>');
    var strUserName = $('<li class="w140"></li>');
    var objFilePass = $('<li class="wAutoA B text_align_left"></li>');
    addListCount++;

    //表に取得した値を挿入する
    $(".scrollBody").append(ul);
    ul.append(strDisplay).append(strServer).append(strjServerName).append(strUserName).append(objFilePass);
    strDisplay.html(objAutoRowNo);
    strServer.html(objDisplayName.value);
    strjServerName.html(objServerName.value);
    strUserName.html(objLoginUserName.value);
    objFilePass.html('<a href="#" data-clm="directoryPath">'+objDirectoryPath.value+'</a>');

    //テキストボックス内の文字列削除
    objDisplayName.value = "";
    objServerName.value = "";
    objDirectoryPath.value = "";
    objLoginUserName.value = "";
    objLoginPassword.value = "";

    //反映ボタンをdisable
    reflectCheck = 0;
    isReflect();

    fillDomWidth();
    console.log(addValues);

    //編集状態アクティブ化の場合
  } else if (document.getElementsByClassName('EditMode').length > 0) {
    //項番の値取得
    var strChangeRow = $(".EditTable>li[style='display: none;']").text();

    //DB、または新規追加行か判別を行う
    if (document.getElementsByClassName("EditTable")[0].children[0].getAttribute("data-clm") == "server_id") {
      for (let index = 2; index < 6; index++) {
        if (index == 2) {
          document.getElementsByClassName("EditTable")[0].children[index].valueOf().textContent = objDisplayName.value;
        } else if (index == 3) {
          document.getElementsByClassName("EditTable")[0].children[index].valueOf().textContent = objServerName.value;
        } else if (index == 4) {
          document.getElementsByClassName("EditTable")[0].children[index].valueOf().textContent = objLoginUserName.value;
        } else if (index == 5) {
          document.getElementsByClassName("EditTable")[0].children[index].children[0].valueOf().textContent = objDirectoryPath.value;
        }// if
      }// for

      // 連想配列作成・追加
      if (!changedValues[strChangeRow]) {
        changedValues[strChangeRow] = { ["displayName"]: objDisplayName.value, ["serverName"]: objServerName.value, ["loginUserName"]: objLoginUserName.value, ["directoryPath"]: objDirectoryPath.value };
      } else {
        changedValues[strChangeRow]['displayName'] = objDisplayName.value;
        changedValues[strChangeRow]['serverName'] = objServerName.value;
        changedValues[strChangeRow]['loginUserName'] = objLoginUserName.value;
        changedValues[strChangeRow]['directoryPath'] = objDirectoryPath.value;
      }// if

      //テキストボックス内の文字列削除
      objDisplayName.value = "";
      objServerName.value = "";
      objDirectoryPath.value = "";
      objLoginUserName.value = "";
      objLoginPassword.value = "";

      console.log(changedValues);
    } else {

      //新規作成で表示されているリストの場合、classからリスト番号を取得
      var strAddChangeRow = document.getElementsByClassName("EditTable")[0].classList[0];

      for (let index = 1; index < 5; index++) {
        if (index == 1) {
          document.getElementsByClassName("EditTable")[0].children[index].valueOf().textContent = objDisplayName.value;
        } else if (index == 2) {
          document.getElementsByClassName("EditTable")[0].children[index].valueOf().textContent = objServerName.value;
        } else if (index == 3) {
          document.getElementsByClassName("EditTable")[0].children[index].valueOf().textContent = objLoginUserName.value;
        } else if (index == 4) {
          document.getElementsByClassName("EditTable")[0].children[index].valueOf().children[0].textContent = objDirectoryPath.value;
        }// if
      }// for

      //追加項目の変更
      addValues[strAddChangeRow]['displayName'] = objDisplayName.value;
      addValues[strAddChangeRow]['serverName'] = objServerName.value;
      addValues[strAddChangeRow]['loginUserName'] = objLoginUserName.value;
      addValues[strAddChangeRow]['directoryPath'] = objDirectoryPath.value;
      addValues[strAddChangeRow]['loginPassword'] = objLoginPassword.value;

      //テキストボックス内の文字列削除
      objDisplayName.value = "";
      objServerName.value = "";
      objDirectoryPath.value = "";
      objLoginUserName.value = "";
      objLoginPassword.value = "";

      console.log(addValues);
    }// if

    //非アクティブ化状態に移行するため、クラスの削除
    document.getElementById('main_scroll').classList.remove("EditMode");
    document.getElementsByClassName("EditTable")[0].classList.remove("EditTable");

    //ボタンの状態設定(disable)
    //編集ボタンを活性化にする
    /*editCheck = 1;
    isEdit();*/
    document.getElementById("editBtn").classList.toggle("on");

    //設定反映ボタンを活性化にする
    AddBtnCheck = 1;
    isAdd();

    //編集キャンセルボタンをdisable
    editCancelCheck = 0;
    isEditCancel();

    //反映ボタンをdisable
    reflectCheck = 0;
    isReflect();

  }// if

}// funcrion

/**
 * キャンセルボタン押下時に動作
 * ダイアログを表示する
**/
function Cancel() {
  blCan = confirm("変更内容を破棄してもよろしいでしょうか。");
  if (blCan) {
    window.close();
    sessionStorage.clear();
  } else {
    return;
  }// if
}// function

/**
 * 編集キャンセルボタン押下時に動作
 * 編集状態を解除し、テキストボックス内を空にする
**/
function editCancel() {
  if (document.getElementsByClassName('EditMode').length > 0) {
    var objDisplayName = document.getElementById('displayName');
    var objServerName = document.getElementById('serverName');
    var objDirectoryPath = document.getElementById('directoryPath');
    var objLoginUserName = document.getElementById('loginUserName');
    var objLoginPassword = document.getElementById('loginPassword');

    //テキストボックス内の文字列削除
    objDisplayName.value = "";
    objServerName.value = "";
    objDirectoryPath.value = "";
    objLoginUserName.value = "";
    objLoginPassword.value = "";

    //非アクティブ化状態に移行するため、クラスの削除
    document.getElementById('main_scroll').classList.remove("EditMode");
    document.getElementsByClassName("EditTable")[0].classList.remove("EditTable");

    //設定反映ボタンを活性化にする
    AddBtnCheck = 1;
    isAdd();

      //編集ボタンを活性化状態にする
      document.getElementById("editBtn").classList.toggle("on");

    //編集キャンセルボタンを活性化状態にする
    editCancelCheck = 0;
    isEditCancel();

    //認証ボタン成功後か確認を行う
    if (reflectflag == 1) {

      //反映ボタンをdisable
      reflectCheck = 0;
      isReflect();

      //認証状態解除
      reflectflag = 0;
    }//if

  }// if
}// function

/**
 * 削除ボタン押下時に動作
 * 選択した行を削除する
**/
//グローバル変数
//DBデータの削除した項番
var deleteDBNo = [];

//行の削除を行う
function DeleteRow() {
  if (document.getElementById('selected') !== null) {

    if (!document.getElementById("selected").classList.contains("EditTable")) {
      Count--;

      //項番の値取得
      var strDeleteRow = $("#selected>li[style='display: none;']").text();

      //新規作成で表示されているリストの場合、classからリスト番号を取得
      var strAddChangeRow = document.getElementById("selected").classList[0];

      //グローバル変数に項番の値を設定する
      deleteDBNo.push(strDeleteRow);

      //連想配列の削除を行う
      if (changedValues[strDeleteRow]) {
        delete changedValues[strDeleteRow];
        if (addValues[strAddChangeRow]) {
          delete addValues[strAddChangeRow];
        }// if
      } else if (addValues[strAddChangeRow]) {
        delete addValues[strAddChangeRow];
      }// if

      //選択した行の削除
      $("#selected").remove();

      //項番付け直し
      var strAutoRowNo = document.getElementById("main_scroll").childElementCount;
      for (var i = 0; i < strAutoRowNo; i++) {
        //選択した行に非表示要素があるかの判断
        let hiddenKey = $(".scrollBody ul").eq(i).children("li[style='display: none;']").text();
        if (hiddenKey != "") {
          $('.scrollBody ul').eq(i).children().eq(1).text("" + (i + 1));
        } else {
          $(".scrollBody ul").eq(i).children()[0].valueOf().textContent = ("" + (i + 1));
        }// if
      }// for
    } else {
      alert("選択した行は現在編集中のため削除できません。");
    }//if
  } else {
    alert("行を選択後、ボタンを押下してください");
  }// if
}// function

/**
   * 編集ボタン押下時に動作
   * 選択した項目を変更する
  **/
function Edit() {

  //テキストボックスの変数化
  var objDisplayName = document.getElementById('displayName');
  var objServerName = document.getElementById('serverName');
  var objDirectoryPath = document.getElementById('directoryPath');
  var objLoginUserName = document.getElementById('loginUserName');

  if (document.getElementById('selected') != null || document.getElementsByClassName('EditMode').length != 0) {
    //編集状態アクティブ化か判断を行う
    if (document.getElementsByClassName('EditMode').length == 0) {
      //編集がアクティブ状態のため、クラス付与
      $('#main_scroll').eq(0).addClass('EditMode');
      $('#selected').eq(0).addClass('EditTable');

      // 認証時チェック
      if (!objDisplayName.value) {

        //DB、または新規追加行か判別を行う
        if (document.getElementById("selected").children[0].getAttribute("data-clm") == "server_id") {
          for (let index = 2; index < 6; index++) {
            var strDisplayList = document.getElementById("selected").children[index].outerText;
            if (index == 2) {
              objDisplayName.value = strDisplayList;
            } else if (index == 3) {
              objServerName.value = strDisplayList;
            } else if (index == 4) {
              objLoginUserName.value = strDisplayList;
            } else if (index == 5) {
              objDirectoryPath.value = strDisplayList;
            }// if
          }// for

        } else {
          for (let index = 1; index < 5; index++) {
            var strDisplayList = document.getElementById("selected").children[index].outerText;
            if (index == 1) {
              objDisplayName.value = strDisplayList;
            } else if (index == 2) {
              objServerName.value = strDisplayList;
            } else if (index == 3) {
              objLoginUserName.value = strDisplayList;
            } else if (index == 4) {
              objDirectoryPath.value = strDisplayList;
            }// if
          }// for
        }// if
      }

      //設定反映ボタンを非活性化をする
      AddBtnCheck = 0;
      isAdd();

      //編集ボタンを活性化状態にする
      document.getElementById("editBtn").classList.toggle("on");

      //編集キャンセルボタンを活性化状態にする
      editCancelCheck = 1;
      isEditCancel();

      //認証ボタン成功後か確認を行う
      if (reflectflag == 1) {

        //反映ボタンをdisable
        reflectCheck = 0;
        isReflect();

        //認証状態解除
        reflectflag = 0;
      }//if
      return;

    } else if (document.getElementById('selected') == null || document.getElementsByClassName('EditMode').length != 0) {
      //非アクティブ化状態に移行するため、クラスの削除
      document.getElementById('main_scroll').classList.remove("EditMode");
      document.getElementsByClassName("EditTable")[0].classList.remove("EditTable");

      //テキストボックス内の文字列削除
      objDisplayName.value = "";
      objServerName.value = "";
      objDirectoryPath.value = "";
      objLoginUserName.value = "";
      editCheck = 0;

      //設定反映ボタンを活性化状態にする
      AddBtnCheck = 1;
      isAdd();

      //編集キャンセルボタンを非活性化にする
      editCancelCheck = 0;
      isEditCancel();

      //編集ボタンを活性化状態にする
      document.getElementById("editBtn").classList.toggle("on");

      //認証ボタン成功後か確認を行う
      if (reflectflag == 1) {

        //反映ボタンをdisable
        reflectCheck = 0;
        isReflect();

        //認証状態解除
        reflectflag = 0;
      }//if
      return;
    }// if

  } else {
    alert("行の選択を行った後「編集ボタン」を押下してください");

    //設定反映ボタンを活性化にしない
    editCheck = 1;

    return false;
  }//if
}//function

/**
* 特定文字列カウント用function
*/
var counter = function (str, seq) {
  return str.split(seq).length - 1;
}// function

/**
* 設定反映ボタン押下時に動作
*/
function postItem() {

  // 削除項目のIDをデータ受け渡し用タグに格納する
  $("input[name='deleteRow']").attr('value', deleteDBNo.toString());

  // 編集項目の値をデータ受け渡し用タグに格納する
  $("input[name='editValue']").attr('value', JSON.stringify(changedValues));

  // 追加項目の値をデータ受け渡し用タグに格納する
  alert(JSON.stringify(addValues));
  $("input[name='addValue']").attr('value', JSON.stringify(addValues));

  // POST送信フラグを「true」に設定
  isPost = true;
}

/**
* 設定反映ボタンの「活性」「非活性」を判定する
*/
function isAdd() {
    if (AddBtnCheck == 0) {
      $("#addBtn").prop("disabled", true);
      return true;
    }// if
    $("#addBtn").prop("disabled", false);
    return false;
}// function

/**
* 編集ボタンの「活性」「非活性」を判定する
*/
function isEdit() {
  if (editCheck == 0) {
    $("#editBtn").prop("disabled", true);
    return true;
  }// if
  $("#editBtn").prop("disabled", false);
  return false;
}// function

/**
* 編集キャンセルボタンの「活性」「非活性」を判定する
*/
function isEditCancel() {
    if (editCancelCheck == 0) {
      $("#editCancelBtn").prop("disabled", true);
      return true;
    }// if
    $("#editCancelBtn").prop("disabled", false);
    return false;
}// function

/**
* 反映ボタンの「活性」「非活性」を判定する
*/
function isReflect() {
    if (reflectCheck == 0) {
      $("#reflectBtn").prop("disabled", true);
      return true;
    }// if
    $("#reflectBtn").prop("disabled", false);
    return false;
}// function

$(function () {
  // Ajax通信テスト ボタンクリック
  $("#auth_btn").click(function () {
    var objDisplayName = $('#displayName').val();
    var objServerName = $('#serverName').val();
    var objDirectoryPath = $('#directoryPath').val();
    var objLoginUserName = $('#loginUserName').val();
    var objLoginPassword = $('#loginPassword').val();

    //未入力チェック
    if (objDisplayName == "") {
      alert('『表示名』が未入力です。');
      return false;
    } else if (objServerName == "") {
      alert('『対象サーバ』が未入力です。');
      return false;
    } else if (objDirectoryPath == "") {
      alert('『フォルダパス』が未入力です。');
      return false;
    }// if

    // コントローラに渡すjsonオブジェクトを作成する
    var jsonObj = new Object();
    jsonObj.displayName = objDisplayName;
    jsonObj.serverName = objServerName;
    jsonObj.directoryPath = objDirectoryPath;
    jsonObj.loginUserName = objLoginUserName;
    jsonObj.loginPassword = objLoginPassword;

    $.ajax({
      url: "http://localhost:8080/manege/search_server",
      type: "POST",
      contentType: "application/json",
      data: JSON.stringify(jsonObj),
      dataType: "json"
      // ajax通信成功時の処理
    }).done(function (data, textStatus, jqXHR) {
      let successOrFailure = "";
      if (data == "success") {
        alert('認証に成功しました。');
        // 反映ボタンを有効にする
        reflectCheck = 1;
        isReflect();
        reflectflag = 1;
      } else if (data == "86") {
        if (reflectflag == 1) {
          // 反映ボタンを無効にする
          reflectCheck = 0;
          isReflect();
          reflectflag = 0;
        }
        alert('パスワードが間違っています。');
      } else if (data == "1219") {
        if (reflectflag == 1) {
          // 反映ボタンを無効にする
          reflectCheck = 0;
          isReflect();
          reflectflag = 0;
        }
        alert('現在ファイルを開いております。');
      } else if (data == "failure") {
        if (reflectflag == 1) {
          // 反映ボタンを無効にする
          reflectCheck = 0;
          isReflect();
          reflectflag = 0;
        }
        alert('認証に失敗しました。');
      }
      console.log(jqXHR.status);
      // ajax通信失敗時の処理
    }).fail(function (jqXHR, textStatus, errorThrown) {
      console.log(jqXHR.status);
      // 成功でも失敗でも通信終了時に必要な処理があれば
    }).always(function () {
    });

    console.log(jsonObj);

  });
});
