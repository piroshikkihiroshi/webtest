/**
************通常関数************
*/

/**
* 初期表示：ユーザー名を表示する。
*/
function showUserName() {
	var COOKIE_USER = document.cookie.split(';');
	for(let i=0 ; i< COOKIE_USER.length  ; i++){
		var objUserKey = COOKIE_USER[i].split('=')
    	if( objUserKey[0] === " user_name"){
    		var objUserDom = document.getElementById("USER_NAME");
    		objUserDom.innerText =objUserDom.innerText + objUserKey[1];
    	}
	}
} //function

/**
* 初期表示：ユーザー名IDを表示する。
*/
function showUserId() {
	var COOKIE_USER = document.cookie.split(';');
	for(let i=0 ; i< COOKIE_USER.length  ; i++){
		var objUserKey = COOKIE_USER[i].split('=')
    	if( objUserKey[0] === " user_id"){
    		var objUserDom = document.getElementById("USER_ID");
    		objUserDom.innerText =objUserDom.innerText + objUserKey[1];
    	}
	}
} //function

/**
* 初期表示：ファイル名を表示する。
*/
function showFileName (){
	var fileName = glFileName.split(".")[0];
	var objFileDom = document.getElementById("FILE_NAME");
	objFileDom.innerText =objFileDom.innerText + fileName;
} //function


