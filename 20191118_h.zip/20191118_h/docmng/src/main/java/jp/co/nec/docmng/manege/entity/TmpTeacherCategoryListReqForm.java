package jp.co.nec.docmng.manege.entity;

import java.util.List;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonInclude;

//@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class TmpTeacherCategoryListReqForm {
    @NotBlank(message = "必須項目です。")
    private String savePath;
    @NotBlank(message = "必須項目です。")
    private String userName;
    @NotBlank(message = "必須項目です。")
    private List<TmpTeacherCategoryList> tmpTeacherCategoryList;

    public String getSavePath() {
        return savePath;
    }
    public void setSavePath(String savePath) {
        this.savePath = savePath;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public List<TmpTeacherCategoryList> getTmpTeacherCategoryList() {
        return tmpTeacherCategoryList;
    }
    public void setTmpTeacherCategoryList(List<TmpTeacherCategoryList> tmpTeacherCategoryList) {
        this.tmpTeacherCategoryList = tmpTeacherCategoryList;
    }
}


