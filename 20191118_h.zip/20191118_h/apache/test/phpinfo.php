<?php
phpinfo();
//jsonパーステスト



?>
