<?php
//request
$objRequest = file_get_contents('php://input');
$objRequest = mb_convert_encoding($objRequest,"utf-8","auto");
echo $objRequest;
// $strPost=urldecode($_POST['query']);
// try {
//     $test=json_decode($strPost);
//     var_dump($test);
// } catch (\Throwable $th) {
//     echo "error";
// } //try


?>
