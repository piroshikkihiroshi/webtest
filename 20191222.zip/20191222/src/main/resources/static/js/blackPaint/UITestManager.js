/*
 * @class UITestManager
 * @param param.targetButtons
 *  ボタンのトグルを行う
 * @description
 */
'use strict'
class UITestManager {
    constructor(param) {
        console.log(param)
        this.targetButtons = param.targetButtons;
        this.initButtons();
        this.tergetIframes = param.tergetIframes;
        this.initIframe();
    }
    initIframe(){
        Array.from(item => {
            item.addEventListener("click", this.IframeClick.bind(this))
        })
    }
    IframeClick(event){
        console.log(event)
    }
    initButtons(){
        Array.from(this.targetButtons).map(item => {
            item.addEventListener("click", event => {
                console.log(event.target.className)
                if (event.target.className.match(" on") || event.target.className.match("on ")) {
                    event.target.className = event.target.className.replace(" on", "");
                    event.target.className = event.target.className.replace("on ", "");
                } else {
                    console.log(event.target.className)
                    event.target.className = event.target.className + " on";
                }
            })
        })
    }
}