package ppt;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFNotes;
import org.apache.poi.xslf.usermodel.XSLFSlide;
import org.apache.poi.xslf.usermodel.XSLFTextParagraph;
import org.apache.poi.xslf.usermodel.XSLFTextShape;


public class PptTest {
	/**
	 * PPTファイルのbodyとnoteを取得(Apache poi使用)
	 * @param String strPptName_i 					対象PPTファイルパス
	 * @param ArrayList<String> listBodys_i	bodyのlist
	 * @param ArrayList<String> listNotes_i		Noteのlist
	 * @return int 成否ステータス
	 */
	public int getPptInfo(
			String strPptName_i,
			ArrayList<String> listBodys_i,
			ArrayList<String> listNotes_i){

		//空のPPTファイルを作成
		File objPptFile=new File(strPptName_i);
		XMLSlideShow objPptSlide = null;
		try {
			//PPTを開く
			objPptSlide = new XMLSlideShow(new FileInputStream(objPptFile));
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}

		//スライドリストを取得
		List<XSLFSlide> listSlides = objPptSlide.getSlides();
		String strTmp = "";
		for (int i = 0; i < listSlides.size(); i++) {
			StringBuilder objSb = null;
			XSLFTextShape[] objShapes =  listSlides.get(i).getPlaceholders();

			//body取得
			objSb = new StringBuilder();
			for (int j = 0; j < objShapes.length; j++) {
				XSLFTextShape objTgtShape = listSlides.get(i).getPlaceholder(j);
				objSb.append(objTgtShape.getText() + "\r\n");
			}
			strTmp = objSb.toString().replaceAll("[\r\n]","。");	//改行あると音声出力できないので、置換
			listBodys_i.add(strTmp);
			objSb = null;


			//Notes取得
			objSb = new StringBuilder();
			XSLFNotes objNotes= listSlides.get(i).getNotes();
			if (objNotes !=null){
				List<List<XSLFTextParagraph>> listNotes=  objNotes.getTextParagraphs();
				//listNotesはListの入れ子だが、notesの本文が入っているのは要素1
				for (int j = 0; j < listNotes.size(); j++) {
					List<XSLFTextParagraph> listNoteBody = listNotes.get(j);
					for (int k = 0; k < listNoteBody.size(); k++) {
						XSLFTextParagraph objXSLFText = listNoteBody.get(k);
						try {
							int intTest = Integer.parseInt(objXSLFText.getText());
						} catch (Exception e) {
							//パース出来たら、ページが載っている要素なので無視
							String strGetText = objXSLFText.getText();
							if(!(strGetText.equals(""))) objSb.append(objXSLFText.getText() + "\r\n");
						}

					}
				}

				strTmp = objSb.toString().replaceAll("[\r\n]","。");	//改行あると音声出力できないので、置換
				listNotes_i.add(strTmp);
			}else{
				listNotes_i.add("");
			} //if

			objSb = null;

		} //for

		try {
			objPptSlide.close();
		} catch (IOException e) {
			e.printStackTrace();
			return -1;
		} //try

		return 0;
	} //getPptInfo
} //PptTest
