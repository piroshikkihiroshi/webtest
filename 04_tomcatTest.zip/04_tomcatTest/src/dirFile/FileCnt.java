package dirFile;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class FileCnt {
	/**
	 * File名から拡張子を抜いたファイル名を取得する。
	 * @param String strFileName_i ファイルのフルパス
	 * @return String 取得文字列
	 */
	synchronized public String getNameWithoutExtension(String strFileName_i) {
		int index = strFileName_i.lastIndexOf('.');
		if (index != -1) {
			return strFileName_i.substring(0, index);
		}
		return strFileName_i;
	} //getNameWithoutExtension

	/**
	 * strPath_iにstrOfficePath_iを開くbatchを作成する
	 * @param String strFileName_i ファイルのフルパス
	 * @param String strOfficePath_i 対象officeファイル
	 * @param int intStatus_i 1:Excel 2:word 3:PPT
	 * @return String 取得文字列
	 */
	public void makeOfficeBat(String strPath_i,String strOfficePath_i,int intStatus_i) {
		FileWriter objFile = null;
		PrintWriter objPw = null;

        try {
        	objFile = new FileWriter(strPath_i);
        	objPw = new PrintWriter(new BufferedWriter(objFile));

        	objPw.println("@echo off");
        	if(intStatus_i ==1) {
            	objPw.println(" start /WAIT EXCEL \"" + strOfficePath_i +  "\" ");
        	}else if(intStatus_i == 2) {
            	objPw.println(" start /WAIT WINWORD \"" + strOfficePath_i +  "\" ");
        	}else {
            	objPw.println(" start /WAIT POWERPNT \"" + strOfficePath_i +  "\" ");
        	} //if

        	objPw.println(" del /f \"%~dp0%~nx0\" ");
        	objPw.close();

		} catch (IOException e) {
			e.printStackTrace();
		} //if


	} //makeOfficeBat


//	public void aaa() {
//		File a = new File("");
//	}


} //FileCnt
