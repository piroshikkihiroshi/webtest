package test;

import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;



public class Test3  {

	   public static void main(String[] args) {

			BufferedImage objTmpImg = new BufferedImage(100, 100, BufferedImage.TYPE_3BYTE_BGR);
			Graphics2D g = objTmpImg.createGraphics();
//			setBackground(Color.white);

            int strWidth;
//            setBackground(Color.white);
            g.setFont(new Font("Serif" , Font.PLAIN , 20));

            FontMetrics fo = g.getFontMetrics();
            strWidth = fo.stringWidth("Kitty on your lap");

            g.drawString("Kitty on your lap" , 200 - strWidth / 2 , 100);
	    }

}
