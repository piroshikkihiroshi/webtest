package test;

import com.jacob.activeX.ActiveXComponent;
import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

//import jp.ne.so_net.ga2.no_ji.jcom.*;

public class ExcelPdf {
	static final int wdDoNotSaveChanges = 0;// Don't save the changes pending.
	static final int wdFormatPDF = 17;// Word to PDF format
	static final int ppSaveAsPDF = 32;// PPT to PDF format

	public static void main(String[] args) {
		String pathx = "\\\\192.168.33.1\\poitest\\test_mod.xlsx";
		String strPdfPath = "\\\\192.168.33.1\\poitest\\test_mod_aaa.pdf";

		ExcelPdf objMe = new ExcelPdf();

		objMe.excel2pdf(pathx, strPdfPath);

	} //main

	public void excel2pdf(String source, String target) {
		System.out.println("Start Excel");
		long start = System.currentTimeMillis();
		ActiveXComponent app = new ActiveXComponent("Excel.Application"); // Start Excel(Excel.Application)
		try {
			app.setProperty("Visible", false);
			//			  app.setProperty("Visible", true);
			Dispatch workbooks = app.getProperty("Workbooks").toDispatch();
			System.out.println("Open the document" + source);
			Dispatch workbook = Dispatch.invoke(workbooks, "Open", Dispatch.Method,
					new Object[] { source, new Variant(false), new Variant(false) }, new int[3]).toDispatch();
			Dispatch.invoke(workbook, "SaveAs", Dispatch.Method, new Object[] {
					target, new Variant(57), new Variant(false),
					new Variant(57), new Variant(57), new Variant(false),
					new Variant(true), new Variant(57), new Variant(true),
					new Variant(true), new Variant(true) }, new int[1]);
			Variant f = new Variant(false);
			System.out.println("Convert the document to PDF " + target);
			Dispatch.call(workbook, "Close", f);
			long end = System.currentTimeMillis();
			System.out.println("When the conversion is complete: " + (end - start) + "ms.");
		} catch (Exception e) {
			System.out.println("========Error: document conversion failed: " + e.getMessage());
		} finally {
			if (app != null) {
				app.invoke("Quit", new Variant[] {});
			} //if
		} //try
	} //excel2pdf

}
