package test;

import com.jacob.activeX.ActiveXComponent;
import com.jacob.com.ComThread;
import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class Test2 {

	   public static void main(String[] args) {
	        ActiveXComponent xl = new ActiveXComponent("Excel.Application");
	        Object xlo = xl.getObject();
	        try {
	            xl.setProperty("Visible", new Variant(true));
	            Dispatch workbooks = xl.getProperty("Workbooks").toDispatch();
	            Dispatch workbook = com.jacob.com.Dispatch.get(workbooks,"Add").toDispatch();
	            Dispatch sheet = com.jacob.com.Dispatch.get(workbook,"ActiveSheet").toDispatch();
	            String retu[] = {"A","B","C", "D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T"};
	            for(int i = 1; i <= 10; i++){
	                for(int j = 0; j < 10; j++){
	                    String col = retu[j] + i;
	                    Dispatch a1 = Dispatch.invoke(sheet, "Range", Dispatch.Get,new Object[] {col},new int[1]).toDispatch();
	                    int k = i + j - 1;
	                    Dispatch.put(a1, "Value", String.valueOf(k));
	                }
	            }

//	            Dispatch.call(workbook, "SaveAs", "c:\\work\\test.xls");
	            Variant f = new Variant(false);
	            Dispatch.call(workbook, "Close", f);
	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	            xl.invoke("Quit", new Variant[] {});
	            ComThread.Release();
	        }
	    }

}
