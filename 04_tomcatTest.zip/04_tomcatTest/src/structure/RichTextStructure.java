package structure;

import org.apache.poi.xssf.usermodel.XSSFColor;

//リッチテキスト用代替構造体
public class RichTextStructure {
	public String strTgt = ""; //リッチテキストの文字(1文字)
	public double dblStrWidth = 0.0; //strTgtの文字幅
	public boolean blMask = false; //マスク対象か True;マスク対象
	public String strFontStyle=""; //フォント名 ：ＭＳ Ｐゴシック等
	public int intSize=0; //フォントサイズ
	public int intFontType=0; //線の種類 PLAIN:0 BOLD:1 ITALIC:2 3:BOLD + ITALIC

	public boolean isThemed = true; //テーマの色かどうか
	public short shColor; //テーマの色のフォントの色
	public XSSFColor objXSSFColor; //テーマの色でない時のフォントの色

	public byte bteUnderline; //アンダーライン
	public boolean blStrikeout; //取り消し線
	public double dblStrAllWidth=0.0; //元のリッチテキスト全体の文字幅
	public boolean blPFlag=false; //プロポーショナルフラグ


} //RichTextStructure
