package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import dirFile.DirCnt;
import dirFile.FileCnt;
import excel.ExcelTestServer;
import test.ExcelPdf;
/**
 * Servlet implementation class ExcelCnt
 */

//memo
//※IE限定
//信頼済みサイトに登録()ドメイン以下は特に正規表現とかいらない
//レベルのカスタマイズ
//ActiveXコントロールとプラグイン
//ActiveXコントロールとプラグインの実行 有効
//スクリプトを実行しても安全だとマークされていないActiveXコントロールの初期化とスクリプト実行　有効


@WebServlet("/ExcelCnt")
public class ExcelCnt extends HttpServlet {


	static Logger objLog = Logger.getLogger(ExcelCnt.class);
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public ExcelCnt() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ExcelTestServer objExcelTestServer = new ExcelTestServer();
		ExcelPdf objExcelPdf = new ExcelPdf();
		DirCnt objDirCls = new DirCnt();
		FileCnt objFileCntCls = new FileCnt();
		int intRet = 0;
		// 処理前の時刻を取得
		long startTime = System.currentTimeMillis();
		//設定
		String strTmpDir = this.getServletContext().getRealPath("") + "\\tmp";
		request.setCharacterEncoding("UTF8");
		String strMaskMsg = request.getParameter("inputKeyword");
		if(strMaskMsg.equals("")) {
			strMaskMsg = "メイ" ;
		} //if

		String strBassPath = "\\\\192.168.33.1\\poitest\\test_mod";
		String strFilePath = strBassPath + ".xlsx";
		String strCopyPath = strFilePath + "_" + System.currentTimeMillis() + ".xlsx";
		String strPdfPath = strCopyPath + "_.pdf";
//		String strBatDir = request.getContextPath() + "\\" + strTmpDir;
		String strOrgBatPath = strTmpDir + "\\" + "orgExcel.bat";
		String strMaskBatPath = strTmpDir + "\\" + "MaskExcel.bat";

		try {
			//mask
			objExcelTestServer.excelSetMask(strFilePath, strCopyPath, strMaskMsg);
			objExcelTestServer = null;
			//pdf
//			objExcelPdf.excel2pdf(strCopyPath,strPdfPath);

			//batch作成
			intRet = objDirCls.makeDirWithCheck(strTmpDir);
			if(intRet != -1) {
				objFileCntCls.makeOfficeBat(strOrgBatPath, strFilePath, 1);
				objFileCntCls.makeOfficeBat(strMaskBatPath, strCopyPath, 1);
			} //if


		} catch (Exception e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}


		// 処理後の時刻を取得
		long endTime = System.currentTimeMillis();

		objLog.info("開始時刻：" + startTime + " ms");
		objLog.info("終了時刻：" + endTime + " ms");
		objLog.info("処理時間：" + (endTime - startTime) + " ms");

		// 呼び出し先Jspに渡すデータセット
		request.setAttribute("strFilePath", strFilePath.replace("\\","\\\\"));
		request.setAttribute("strCopyPath", strCopyPath.replace("\\","\\\\"));
		request.setAttribute("strPdfPath", strPdfPath.replace("\\","\\\\"));
		request.setAttribute("strPastePath", strCopyPath);

		request.setAttribute("strOrgBatPath", strOrgBatPath.replace("\\","\\\\"));
		request.setAttribute("strMaskBatPath", strMaskBatPath.replace("\\","\\\\"));

		// result.jsp にページ遷移
		RequestDispatcher dispatch = request.getRequestDispatcher("excelret.jsp");
		dispatch.forward(request, response);

	} //doget

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

