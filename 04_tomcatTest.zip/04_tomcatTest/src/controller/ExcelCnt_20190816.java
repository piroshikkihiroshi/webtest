package controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import excel.ExcelTestServer;
import test.ExcelPdf;
/**
 * Servlet implementation class ExcelCnt
 */
@WebServlet("/ExcelCnt_20190816")
public class ExcelCnt_20190816 extends HttpServlet {


	static Logger objLog = Logger.getLogger(ExcelCnt.class);
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public ExcelCnt_20190816() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		objLog.info("st");
		ExcelTestServer objExcelTestServer = new ExcelTestServer();
		ExcelPdf objExcelPdf = new ExcelPdf();
		// 処理前の時刻を取得
		long startTime = System.currentTimeMillis();
		//設定
		String strMaskMsg = "メイ";
		String strBassPath = "\\\\192.168.33.1\\poitest\\test_mod";
		String strFilePath = strBassPath + ".xlsx";
		String strCopyPath = strFilePath + "_" + System.currentTimeMillis() + ".xlsx";
		String strPdfPath = strCopyPath + "_.pdf";

		try {
			//mask
			objExcelTestServer.excelSetMask(strFilePath, strCopyPath, strMaskMsg);
			//pdf
			objExcelPdf.excel2pdf(strCopyPath,strPdfPath);
		} catch (Exception e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}

		// 処理後の時刻を取得
		long endTime = System.currentTimeMillis();

		objLog.info("開始時刻：" + startTime + " ms");
		objLog.info("終了時刻：" + endTime + " ms");
		objLog.info("処理時間：" + (endTime - startTime) + " ms");
		File objMakeFile = new File(strCopyPath);
		//クライアントでのExcel起動
		String strTmp;
		String strRet = "";
		try {

			//			Desktop.getDesktop().open(objMakeFile);

			String strPsCmd="";
//			strPsCmd+="$excel = New-Object -ComObject Excel.Application; $excel.Visible = $true; $book = $excel.Workbooks.Open('" + strCopyPath + "')";
			strPsCmd="notepad.exe";
//			String[] Command = { "powershell", strPsCmd }; // 起動コマンドを指定する
			String[] Command = { strPsCmd }; // 起動コマンドを指定する

			Runtime runtime = Runtime.getRuntime(); // ランタイムオブジェクトを取得する
			Process objProc = runtime.exec(Command);
			int intRet = objProc.waitFor();
			objLog.info("process 戻り値：" + intRet);


            InputStream objIs = objProc.getInputStream();
            InputStreamReader objIsR = new InputStreamReader(objIs,"Shift_JIS");
            BufferedReader objBr = new BufferedReader(objIsR);
            while ((strTmp = objBr.readLine()) != null) {
            	strRet+=strTmp;
            } //while

            objLog.info("process メッセージ：" + strRet);


		} catch (Exception e) {
			e.printStackTrace();
		} //try



	} //

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
