package jp.co.nec.docmng.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import jp.co.nec.docmng.dao.entity.SearchServerInfoEntity;


@Mapper
public interface SearchServerInfoMapper {
    @Select("select * from admin.search_server_info where server_id = #{serverId}")
    SearchServerInfoEntity findOneMapper(String strId_i);

    @Select("select * from admin.search_server_info order by server_id")
    public List<SearchServerInfoEntity> findAll();

    @Select("select server_id from admin.search_server_info order by server_id")
    public List<Integer> selectServerId();

    public void insertAll(@Param("searchServerInfoList") List<SearchServerInfoEntity> searchServerInfoList);

    public void insert(SearchServerInfoEntity searchServerInfo);

    public void update(SearchServerInfoEntity searchServerInfo);

    public void updateDisplayOrder(@Param("displayOrder") Integer displayOrder, @Param("serverId") Integer serverId);

    public void deleteById(Integer id);

}
