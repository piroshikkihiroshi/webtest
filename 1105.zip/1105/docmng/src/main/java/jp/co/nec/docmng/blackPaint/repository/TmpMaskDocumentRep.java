package jp.co.nec.docmng.blackPaint.repository;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 *******bytea[BLOB]が入っているテーブルがSelectできないのでjdbcテンプレートを暫定で使用
 *
 */
@Repository
public class TmpMaskDocumentRep {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	/**
	 * zipで固めたhtml群を取得する
	 * @param documentId ドキュメントID
	 * @param userID ユーザID クッキーで保持しているものを使用する
	 * @return byte[] html群のバイト配列
	 */
	public byte[] getHtmlZip(int documentId, String userId) {
		String strQuery = "SELECT html_zip_data FROM common.tmp_mask_document WHERE document_id = ? and user_id = ?";
		Map<String, Object> objMap = jdbcTemplate.queryForMap(strQuery, documentId, userId);
		ByteArrayOutputStream objBarr = new ByteArrayOutputStream();
		ObjectOutputStream objOs = null;
		try {
			objOs = new ObjectOutputStream(objBarr);
			objOs.writeObject(objMap.get("html_zip_data"));
			objOs.close();
			objBarr.close();
		} catch (IOException e) {
			e.printStackTrace();
		} //try
		byte[] arrRet = (byte[]) objMap.get("html_zip_data");

		return arrRet;
	} //method

	/**
	 * 一時保存テーブルにレコードが保存されているか判定する
	 * @param documentId ドキュメントID
	 * @param userID ユーザID クッキーで保持しているものを使用する
	 * @return boolean true 保存されている false 保存されていない
	 */
	public boolean isTmpDoc(int documentId, String userId) {
		String strQuery = "SELECT count(*) as count FROM common.tmp_mask_document WHERE document_id = ? and user_id = ?";
		Map<String, Object> objMap = jdbcTemplate.queryForMap(strQuery, documentId, userId);

		boolean blRet = false;
		int intRet= Integer.parseInt(objMap.get("count").toString()) ;
		if (intRet>0) {
			blRet = true;
		} //if

		return blRet;
	} //method




} //TmpMaskDocumentRep
