package jp.co.nec.docmng.blackPaint.logic.dirFile;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Collectors;

public class FileCnt {
	/**
	 * File名から拡張子を抜いたファイル名を取得する。
	 * @param String strFileName_i ファイルのフルパス
	 * @return String 取得文字列
	 */
	synchronized public String getNameWithoutExtension(String strFileName_i) {
		int index = strFileName_i.lastIndexOf('.');
		if (index != -1) {
			return strFileName_i.substring(0, index);
		}
		return strFileName_i;
	} //getNameWithoutExtension


	/**
	 * strpath_iで指定したファイルを改行付きですべて読み込む
	 * @param strpath_i
	 * @return 読み込んだ文字列
	 * @throws IOException
	 */
	public String readAll(final String strpath_i) throws IOException {
		return Files.lines(Paths.get(strpath_i), Charset.forName("UTF-8"))
				.collect(Collectors.joining(System.getProperty("line.separator")));

	} //readAll







} //FileCnt
