package jp.co.nec.docmng.blackPaint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.blackPaint.entity.TmpMaskDocMarkerEntBlackPaint;
import jp.co.nec.docmng.blackPaint.repository.TmpMaskDocTmpMarkerMapPaint;

@Service
public class TmpMaskDocTmpMarkerService {
	@Autowired
	private TmpMaskDocTmpMarkerMapPaint tmpMaskDocTmpMarkerMapPaint;

	@Transactional
	public void insertTmpMaskDocument(TmpMaskDocMarkerEntBlackPaint objEnt2) {
		tmpMaskDocTmpMarkerMapPaint.insertTmpMaskDocMarker(objEnt2);
	} //insertTmpMaskDocument


	@Transactional
	public List<TmpMaskDocMarkerEntBlackPaint> selectTmpMaskDocMarker(Integer documentId,String userId) {
		return tmpMaskDocTmpMarkerMapPaint.selectTmpMaskDocMarker(documentId, userId);

	} //insertTmpMaskDocument


} //PolicyInfoServiceApi
