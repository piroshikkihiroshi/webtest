package jp.co.nec.docmng.manege.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.manege.entity.TmpTeacherPolicyList;
import jp.co.nec.docmng.manege.util.map.TmpTeacherPolicyListMapManege;

@Service
public class TmpTeacherPolicyService {

    @Autowired
    private TmpTeacherPolicyListMapManege tmpTeacherPolicyListMapper;

    @Transactional
    public List<TmpTeacherPolicyList> findAll(){
        List<TmpTeacherPolicyList> entityList = tmpTeacherPolicyListMapper.findAll();
        return entityList;
    }

    @Transactional
    public void deleteAll(){
        tmpTeacherPolicyListMapper.deleteAll();
    }

    @Transactional
    public void insert(TmpTeacherPolicyList tmpTeacherPolicyList){
        tmpTeacherPolicyListMapper.insert(tmpTeacherPolicyList);
    }


}
