/**
 * 名称：CategoryServicePaint.java
 * 機能名：黒塗り処理カテゴリー情報連携
 * 概要：黒塗り処理にて使用するカテゴリー情報への連携用サービス
 */

package jp.co.nec.docmng.blackPaint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.blackPaint.entity.CategoryEntPaint;
import jp.co.nec.docmng.blackPaint.repository.CategoryMapPaint;

/**
 * 黒塗り処理カテゴリー情報連携
 */
@Service
public class CategoryServicePaint {

	@Autowired
	private  CategoryMapPaint objCategoryMapper;

	/**
	 * 全件取得
	 * @return 検索結果
	 */
	@Transactional
	public List<CategoryEntPaint> findAll() {
		// 全件
		return objCategoryMapper.findAll();
	} //findAll

} //PolicyInfoServicePaint
