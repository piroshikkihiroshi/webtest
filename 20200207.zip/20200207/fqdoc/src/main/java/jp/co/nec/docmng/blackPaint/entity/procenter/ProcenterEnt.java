/**
 * 名称：PrcenterConvert.java
 * 機能名：PORCENTER beenクラス
 * 機能:PORCENTERのbeenクラス
 */

package jp.co.nec.docmng.blackPaint.entity.procenter;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * PORCENTER beenクラス
 */
public class ProcenterEnt {

	/**
	 * 結果
	 */
	private String result;

	/**
	 * 時間
	 */
	private long time;

	/**
	 * PROCENTER Return管理
	 */
	private Return procenterEntReturn;

	/**
	 * PROCENTER エラー
	 */
	private ExceptionClass exception;

	/**
	 * result getter
	 * @return result
	 */
	@JsonProperty("result")
	public String getResult() {
		return result;
	}
	/**
	 * result setter
	 * @param value
	 */
	@JsonProperty("result")
	public void setResult(String value) {
		this.result = value;
	}

	/**
	 * time getter
	 * @return time
	 */
	@JsonProperty("time")
	public long getTime() {
		return time;
	}
	/**
	 * time setter
	 * @param value
	 */
	@JsonProperty("time")
	public void setTime(long value) {
		this.time = value;
	}

	/**
	 * procenterEntReturn getter
	 * @return procenterEntReturn
	 */
	@JsonProperty("return")
	public Return getProcenterEntReturn() {
		return procenterEntReturn;
	}
	/**
	 * procenterEntReturn setter
	 * @param value
	 */
	@JsonProperty("return")
	public void setProcenterEntReturn(Return value) {
		this.procenterEntReturn = value;
	}

	/**
	 * exception getter
	 * @return exception
	 */
	@JsonProperty("exception")
	public ExceptionClass getException() {
		return exception;
	}
	/**
	 * exception setter
	 * @param value
	 */
	@JsonProperty("exception")
	public void setException(ExceptionClass value) {
		this.exception = value;
	}
}
