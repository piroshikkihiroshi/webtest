/**
 * 名称：CategoryInfoService.java
 * 機能名：管理系カテゴリー情報連携
 * 概要：管理系にて使用するカテゴリー情報への連携用サービス
 */

package jp.co.nec.docmng.manage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.manage.entity.CategoryInfo;
import jp.co.nec.docmng.manage.util.map.CategoryInfoMapManage;

/**
 * 管理系カテゴリー情報連携
 */
@Service
public class CategoryInfoService {

    @Autowired
    private CategoryInfoMapManage categoryInfoMapper;

	/**
	 * 全件取得
	 * @return 検索結果
	 */
    @Transactional
    public List<CategoryInfo> findAll(){
        List<CategoryInfo> entityList = categoryInfoMapper.findAll();
        return entityList;
    }

	/**
	 * データ取得_カテゴリー指定
	 * @param categoryId カテゴリーID
	 * @return 検索結果
	 */
    @Transactional
    public List<CategoryInfo> findOther(Integer categoryId){
        List<CategoryInfo> entityList = categoryInfoMapper.findOther(categoryId);
        return entityList;
    }

	/**
	 * データ登録
	 * @param categoryInfo 登録情報
	 */
    @Transactional
    public void insert(CategoryInfo categoryInfo) {
        categoryInfoMapper.insertCategoryList(categoryInfo);
    }

	/**
	 * データ登録（category_id 指定）
	 * @param categoryInfo 登録情報
	 */
    @Transactional
    public void insertOther(CategoryInfo categoryInfo) {
        categoryInfoMapper.insertOther(categoryInfo);
    }

	/**
	 * カテゴリー名更新
	 * @param deleteRow 更新情報
	 */
    @Transactional
    public void delete(Integer deleteRow) {
        categoryInfoMapper.deleteCategoryList(deleteRow);
    }

	/**
	 * データ削除_カテゴリー指定
	 * @param categoryInfo カテゴリーID
	 */
    @Transactional
    public void update(CategoryInfo categoryInfo) {
        categoryInfoMapper.updateCategoryList(categoryInfo);

    }
}
