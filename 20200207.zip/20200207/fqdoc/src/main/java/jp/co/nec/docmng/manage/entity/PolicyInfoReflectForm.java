/**
 * 名称：PolicyInfoReflectForm.java
 * 機能名：
 * 概要：
 */

package jp.co.nec.docmng.manage.entity;

import java.util.List;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * 
 */
@JsonInclude
public class PolicyInfoReflectForm {
    private List<AddValues> addValues;
    private List<ChangedValues> changedValues;
    private List<Integer> deleteRow;
    private String policyAuthor;

    /**
     * addValues getter
     * @return addValues
     */
    public List<AddValues> getAddValues() {
        return addValues;
    }

    /**
     * addValues setter
     * @param addValues
     */
    public void setAddValues(List<AddValues> addValues) {
        this.addValues = addValues;
    }

    /**
     * changedValues getter
     * @return changedValues
     */
    public List<ChangedValues> getChangedValues() {
        return changedValues;
    }

    /**
     * changedValues setter
     * @param changedValues
     */
    public void setChangedValues(List<ChangedValues> changedValues) {
        this.changedValues = changedValues;
    }

    /**
     * deleteRow getter
     * @return deleteRow
     */
    public List<Integer> getDeleteRow() {
        return deleteRow;
    }

    /**
     * deleteRow setter
     * @param deleteRow
     */
    public void setDeleteRow(List<Integer> deleteRow) {
        this.deleteRow = deleteRow;
    }

    /**
     * policyAuthor getter
     * @return policyAuthor
     */
    public String getPolicyAuthor() {
        return policyAuthor;
    }

    /**
     * policyAuthor setter
     * @param policyAuthor
     */
    public void setPolicyAuthor(String policyAuthor) {
        this.policyAuthor = policyAuthor;
    }

    /**
     * 
     */
    public static class AddValues {
        @NotBlank(message = "必須項目です。")
        private String policyName;
        @NotBlank(message = "必須項目です。")
        private Integer policyNumber;
        @NotBlank(message = "必須項目です。")
        private String policyReason;

        /**
         * policyName getter
         * @return policyName
         */
        public String getPolicyName() {
            return policyName;
        }

        /**
         * policyName setter
         * @param policyName
         */
        public void setPolicyName(String policyName) {
            this.policyName = policyName;
        }

        /**
         * policyNumber getter
         * @return policyNumber
         */
        public Integer getPolicyNumber() {
            return policyNumber;
        }

        /**
         * policyNumber setter
         * @param policyNumber
         */
        public void setPolicyNumber(Integer policyNumber) {
            this.policyNumber = policyNumber;
        }

        /**
         * policyReason getter
         * @return policyReason
         */
        public String getPolicyReason() {
            return policyReason;
        }

        /**
         * policyReason setter
         * @param policyReason
         */
        public void setPolicyReason(String policyReason) {
            this.policyReason = policyReason;
        }
    }

    /**
     * 
     */
    public static class ChangedValues {
        @NotBlank(message = "必須項目です。")
        private Integer policyId;
        @NotBlank(message = "必須項目です。")
        private String policyName;
        @NotBlank(message = "必須項目です。")
        private Integer policyNumber;
        @NotBlank(message = "必須項目です。")
        private String policyReason;

        /**
         * policyId getter
         * @return policyId
         */
        public Integer getPolicyId() {
            return policyId;
        }

        /**
         * policyId setter
         * @param policyId
         */
        public void setPolicyId(Integer policyId) {
            this.policyId = policyId;
        }

        /**
         * policyName getter
         * @return policyName
         */
        public String getPolicyName() {
            return policyName;
        }

        /**
         * policyName setter
         * @param policyName
         */
        public void setPolicyName(String policyName) {
            this.policyName = policyName;
        }

        /**
         * policyNumber getter
         * @return policyNumber
         */
        public Integer getPolicyNumber() {
            return policyNumber;
        }

        /**
         * policyNumber setter
         * @param policyNumber
         */
        public void setPolicyNumber(Integer policyNumber) {
            this.policyNumber = policyNumber;
        }

        /**
         * policyReason getter
         * @return policyReason
         */
        public String getPolicyReason() {
            return policyReason;
        }

        /**
         * policyReason setter
         * @param policyReason
         */
        public void setPolicyReason(String policyReason) {
            this.policyReason = policyReason;
        }
    }

}


