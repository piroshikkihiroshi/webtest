/**
 * 名称：PolicyInfoService.java
 * 機能名：管理系ポリシー情報連携
 * 概要：管理系にて使用するポリシー情報への連携用サービス
 */

package jp.co.nec.docmng.manage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.manage.entity.PolicyInfoEntity;
import jp.co.nec.docmng.manage.util.map.PolicyInfoMapManage;

/**
 * 管理系ポリシー情報連携
 */
@Service
public class PolicyInfoService {

    @Autowired
    private PolicyInfoMapManage policyMapper;

	/**
	 * 全件取得
	 * @return 検索結果
	 */
    @Transactional
    public List<PolicyInfoEntity> findAll(){
        List<PolicyInfoEntity> entityList = policyMapper.findAll();
        return entityList;
    }

	/**
	 * データ登録
	 * @param policyInfo 登録情報
	 */
    @Transactional
    public void insert(PolicyInfoEntity policyInfo) {
        policyMapper.insert(policyInfo);
    }

	/**
	 * データ更新_ポリシー指定
	 * @param policyInfo 更新情報
	 */
    @Transactional
    public void update(PolicyInfoEntity policyInfo) {
        policyMapper.update(policyInfo);
    }

	/**
	 * データ削除_ポリシー指定
	 * @param id ポリシーID
	 */
    @Transactional
    public void deleteById(Integer id){
        policyMapper.deleteById(id);
    }

}
