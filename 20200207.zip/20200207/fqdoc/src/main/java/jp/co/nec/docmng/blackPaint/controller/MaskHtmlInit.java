/**
 * 名称：MaskHtmllnit.java
 * 機能名：
 * 概要：
 */

package jp.co.nec.docmng.blackPaint.controller;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * 
 */
@Controller
public class MaskHtmlInit {

	/**
	 * 黒塗り文書作成画面初期処理メソッド
	 * @param response HTTPレスポンス
	 * @param model 引渡しパラメータ用モデル
	 * @return 遷移先アドレス
	 */
	@GetMapping("blackPaint/MaskHtmlInit")
	public String getblackTextTest(HttpServletResponse response,Model model) {

		//testデータを入れる
		String ALL_SEARCH_MOCK_DATA = "2:9:1+15:5:2";

		String DOCUMENT_ID = "568";

		//ユーザはクッキーで取得予定なので仮で設定
//		Cookie cookie = new Cookie("user_id", "testUser");
//	    cookie.setMaxAge(60*3600);
//	    cookie.setPath("/");
//		response.addCookie(cookie);
//
//		Cookie cookie2 = new Cookie("user_name", "testName");
//	    cookie2.setMaxAge(60*3600);
//	    cookie2.setPath("/");
//		response.addCookie(cookie2);
//		Cookie cookie3 = new Cookie("ai_data", ALL_SEARCH_MOCK_DATA);
//	    cookie3.setMaxAge(60*3600);
//	    cookie3.setPath("/");
//		response.addCookie(cookie3)

//		String[] strArr = {"userId","0001","userName","文書太郎"};
//
//		Cookie cookie = new Cookie("user_info", strArr[0]);
//	    cookie.setMaxAge(60*3600);
//	    cookie.setPath("/");
//		response.addCookie(cookie);


		model.addAttribute("DOCUMENT_ID", DOCUMENT_ID);


		return "blackPaint/MaskHtmlInit";
	} //getView1

} //MaskHtmlCnt
