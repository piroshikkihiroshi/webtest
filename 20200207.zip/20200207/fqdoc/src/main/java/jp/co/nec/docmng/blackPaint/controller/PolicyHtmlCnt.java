/**
 * 名称：PolicyInfoControllerファイル
 * 機能名：黒塗りポリシー設定画面コントローラー
 * 概要：黒塗りポリシー設定画面の制御を実施する
 */
package jp.co.nec.docmng.blackPaint.controller;

import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jp.co.nec.docmng.manage.entity.PolicyInfoEntity;
import jp.co.nec.docmng.manage.entity.PolicyKeywordInfo;
import jp.co.nec.docmng.manage.service.PolicyInfoService;
import jp.co.nec.docmng.manage.service.PolicyKeywordInfoService;

/**
 * 黒塗りポリシー設定画面のリクエストを制御する
 *@param model
 *@param policyInfoEntities
 *@param policyInfo
 *@param policyKeywordInfos
 *@param request
 *@return
 */
@Controller
@RequestMapping("/PolicyHtmlCnt")
public class PolicyHtmlCnt {


	private static Logger objLog = LoggerFactory.getLogger(PolicyHtmlCnt.class);

	/**
     * 非表示対象ポリシー名1
     */
    private static final String DISPLAY_NON_POLICY1 = "その他ポリシー";
    /**
     * 非表示対象ポリシー名2
     */
    private static final String DISPLAY_NON_POLICY2 = "図・表";


    private static final int DISPLAY_LIMIT_PIECE = 3;


    @Autowired
    PolicyInfoService policyInfoService;
    @Autowired
    PolicyKeywordInfoService policyKeywordInfoService;
    /**
     * <p>黒塗りポリシー設定画面初期表示メソッド</p>
     * 処理内容：黒塗りポリシー初期表示に必要なデータを取得し表示する。<br>
     * @param form 検索対象追加用フォーム
     * @param model モデル
     * @return 検索対象サーバ設定画面のURL
     */
    @GetMapping
    public String getPolicyInfo(
    		@RequestParam("policySelect") String policySelect,
            Model model
            ) {


    	 objLog.info("getPolicyInfo request start");
         // 全件取得
         List<PolicyInfoEntity> policyInfoEntities = policyInfoService.findAll();
         List<PolicyKeywordInfo> policyKeywordInfos = policyKeywordInfoService.findAll();

         // 50文字を超える対象黒塗りポリシー該当キーワードの51文字目以降を省略する
         int keywordCnt = 0;
         int tmpPolicyId = -1;
         for (int i = 0; i < policyKeywordInfos.size(); i++) {
             // 該当キーワードを取得する
             String keyword = policyKeywordInfos.get(i).getPolicyKeyword();
             // 該当キーワードが50文字を超える場合
//             if (DISPLAY_LIMIT_NUM < keyword.length()) {
//                 // 51文字目以降を切り取る
//                 String cutStr = StringUtils.substring(keyword, 0, DISPLAY_LIMIT_NUM);
//                 // エンティティにセットしなおす
//                 policyKeywordInfos.get(i).setPolicyKeyword(cutStr + "...");
//             }
             // 前要素のポリシーIDと今回のポリシーIDを比較し同じ時カウンターを+1
             if (tmpPolicyId == policyKeywordInfos.get(i).getPolicyId()) {
                 keywordCnt++;
                 // 前回のポリシーIDと変化があった時初期化
             } else {
                 // カウンター初期化
                 keywordCnt = 0;
             }
             // ビュー側で表示切替が難しいためコントローラで同一ポリシーのキーワード4個目以降を非表示とするフラグを設定
             if (DISPLAY_LIMIT_PIECE <= keywordCnt) {
                 policyKeywordInfos.get(i).setViewFlag(false);

             }
             // ポリシーID保持
             tmpPolicyId = policyKeywordInfos.get(i).getPolicyId();
         }

         // 図・表およびその他ポリシーを削除（リストの後ろから削除）
         for (int i = policyInfoEntities.size() - 1 ; i >= 0 ; i--) {
             PolicyInfoEntity pe = policyInfoEntities.get(i);
             if (Objects.equals(pe.getPolicyName(), DISPLAY_NON_POLICY1)) {
                 policyInfoEntities.remove(i);
             } else
             // 図・表
             if (Objects.equals(pe.getPolicyName(), DISPLAY_NON_POLICY2)) {
                 policyInfoEntities.remove(i);
             }
         }

         // レスポンス情報セット
         model.addAttribute("policyInfo", policyInfoEntities);
         model.addAttribute("policyKeywordInfos", policyKeywordInfos);
         model.addAttribute("policySelect", policySelect);
         objLog.trace("policyInfoEntities:{}", policyInfoEntities);
         objLog.trace("policyInfoEntities:{}", policyInfoEntities);
         objLog.info("getPolicyInfo request end (success)");
        return "blackPaint/SelectPolicyHtmlVeiw";
    }


}
