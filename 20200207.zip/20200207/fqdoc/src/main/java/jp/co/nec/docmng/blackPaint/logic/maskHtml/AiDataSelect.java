/**
 * 名称：HtmlStructurel.java
 * 機能名：HTML格納クラス
 * 概要：HTMLのchar毎の情報を格納するクラス
 */

package jp.co.nec.docmng.blackPaint.logic.maskHtml;

import java.util.HashMap;

/**
 * HTMLのchar毎の情報を格納するクラス<br>
 * HashMap<Integer, HtmlStructure> の形で格納し、keyは置換対象外文字やtagを含んだポジション
 * (&lt;div&gt;タグ等を含む)を格納する
 */
public class AiDataSelect {
	/**
	 * 全文検索エンジンに返した結果を置換してbodyを入れ替え、または赤文字変換した文字列を取得
	 * @param aiData 
	 * @param hashRepPos_i AIから帰ってきた黒塗り対象情報をハッシュで格納したもの key：マスク箇所 value連続したポジションのステータス:ポリシーID
	 * @param hashBodyStructure_i HTMLのchar毎の情報を格納するクラスを格納したhash key：HTMLのindex : val HTMLのchar(index)毎の情報を格納するクラス
	 * @param intStatus_i 置換ステータス :マスク 2:赤文字
	 * @return String配列 0　置換したBody文字列 1　黒塗り先頭ID:黒塗り終了ID:policyID構成 複数ある場合は+でセパレート
	 */
	public String selectAiData(
			String aiData,
			String policySelect
			) {
		
		String selectAiData ="";
		String[] arrSelectPolicy = policySelect.split(",");
		String[] arrAiData = aiData.split("\\+");
		if(aiData!="") {
	        for (int i = 0; i < arrAiData.length; i++) {
	            String[] arrTmp = arrAiData[i].split(":");
	            for (int j = 0; j < arrSelectPolicy.length; j++){
	            	if(arrSelectPolicy[j].indexOf(arrTmp[2])>=0 ) {   
	            		selectAiData += arrTmp[0]+":";
	            		selectAiData += arrTmp[1]+":";
	            		selectAiData += arrTmp[2]+"+";
		            }
	            }
	        } //for
	        if(selectAiData!="") {
	        	selectAiData = selectAiData.substring(0,selectAiData.length()-1 );
	        }
		}
		return selectAiData;
	} //bodyReplace

} //class
