/**
 * 名称：SaveProvMaskCnt.java
 * 機能名：保存画面のControlを行う。
 * 概要：保存画面のControlを行う。
 */

package jp.co.nec.docmng.blackPaint.controller;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.ResourceBundle;
import java.util.UUID;

import javax.servlet.ServletContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jp.co.nec.docmng.blackPaint.entity.DocumentInfoEntPaint;
import jp.co.nec.docmng.blackPaint.logic.HtmlToPdf.HtmlToPdfModel;
import jp.co.nec.docmng.blackPaint.logic.dirFile.DirCnt;
import jp.co.nec.docmng.blackPaint.logic.dirFile.FileCnt;
import jp.co.nec.docmng.blackPaint.logic.maskHtml.MaskHtmlModel;
import jp.co.nec.docmng.blackPaint.service.DocInfoServicePaint;
//import jp.co.nec.docmng.library.docclassifier.DocClassifier;


/**
 * 保存画面のControlを行う。
 */

@Controller
public class SaveProvMaskCnt {

	/**
	 * context サーブレットのRealPathを取得する
	 */
	@Autowired
	ServletContext context;

	@Autowired
	DocInfoServicePaint docInfoService;
    @Autowired
    private ResourceLoader resourceLoader;

	/**
	 * objLog log出力に使用する
	 */
	static Logger objLog = LoggerFactory.getLogger(SaveProvMaskCnt.class);

	/**
	 * PAGE_CLASS ページを判定するHTMLClass。ページをSplitするのに使用する
	 */
	static String PAGE_CLASS = "awdiv awpage";

	/**
	 * ARR_HEAD ファイル名、フォルダ名を判定するために使用する
	 */
	static String[] ARR_HEAD = {"mask_","red_"};

	static String PAGE_PATH = "blackPaint/MaskProvSave";

	/**
	 * 保存画面初期表示メソッド：保存画面初期表示の処理をする。
	 * @param strTmpDir_i 黒塗り編集画面で処理したHTMLが格納されたTMPディレクトリ名
	 * @param strRedHtml_i 黒塗り編集候補HTMLのouterHTML
	 * @param strMaskHtml_i 黒塗り編集HTMLのouterHTML
	 * @param strListJson_i 黒塗りリスト情報JSON
	 * @param strFileName_i オリジナルファイル名
	 * @param documentId ドキュメントID
	 * @param strFilePath ファイルパス
	 * @param UserId ユーザID
	 * @param UserName ユーザ名
	 * @param model 引渡しパラメータ用モデル
	 * @return PAGE_PATH
	 * @throws Exception 想定外エラー
	 */
	@PostMapping("/SaveProvMaskCnt")
	public synchronized String getblackPaintInfo(
//			@CookieValue(value = "strTmpDirName") String strTmpDir_i,
			@RequestParam("tmpDir") String strTmpDir_i,
			@RequestParam("strRedHtml") String strRedHtml_i,
			@RequestParam("strMaskHtml") String strMaskHtml_i,
			@RequestParam("listJson") String strListJson_i,
			@RequestParam("strFileName") String strFileName_i,
			@RequestParam("documentId") String documentId,
			@RequestParam("strFilePath") String strFilePath,
			@CookieValue(value = "user_id", required = false) String UserId,
			@CookieValue(value = "user_name", required = false) String UserName,
			Model model) throws Exception{

		if (UserId==null) UserId="";
		if (UserName==null) UserName="";

		if (!strListJson_i.equals("")) {
			objLog.info("json："+strListJson_i);
		} //if

		objLog.info("UserId:"+UserId);
		objLog.info("UserName:"+UserName);

		//モデル初期化
		FileCnt objFileCnt = new FileCnt();
		HtmlToPdfModel objPdfCls = new HtmlToPdfModel();
		MaskHtmlModel objHtmllCls = new MaskHtmlModel();

		objLog.info("作業フォルダ：" + strTmpDir_i);

		//メンバ変数初期化
		Document objDoc=null;
		String strBasePath =""; //黒塗り作成時の作業フォルダ
		String strHead=""; //ファイル名、フォルダ名のヘッダー
		String strFileOutDir=""; //PDF出力フォルダ
		String strHtmlDir=""; //黒塗り作成時HTMLに対するimg,css等が入っているフォルダ
		String strRealPath = context.getRealPath("/");
		String strOrgFileName = strFileName_i; //オリジナルwordファイル名
		int intPages = 0; //PDFページ枚数
//		String strTmpUuid=""; //tempファイルタイムスタンプ
//		strTmpUuid=String.valueOf(System.currentTimeMillis());
		String strTmpUuid = UUID.randomUUID().toString() ;
		//拡張子無しファイル名取得
		String strFileWithoutExtension = objFileCnt.getNameWithoutExtension(strOrgFileName);

		int sizeRedPdf = 0; //黒塗り候補文書PDFのファイルサイズの合計
		int sizeMaskPdf = 0; //黒塗り文書PDFのファイルサイズの合計
		int sizeMaskListPdf = 0; //黒塗り文書リストPDFのファイルサイズ

		String strSizeRedPdf = ""; //黒塗り候補文書PDFのファイルサイズの合計
		String strSizeMaskPdf = ""; //黒塗り文書PDFのファイルサイズの合計
		String strSizeMaskListPdf = ""; //黒塗り文書リストPDFのファイルサイズ

		String strDocumentContents = ""; //DocumentContents(全文検索用テキスト)
		int intCategoryId = 0; //分類APIから取得した分類ID

		strBasePath=strRealPath + strTmpDir_i ;


		//DocumentIDでdocument_infoから情報を取得
		List<DocumentInfoEntPaint> listDoc=null;
		listDoc =docInfoService.selectDocInfo(Integer.parseInt(documentId));
		strFilePath = listDoc.get(0).getFilePath();

		// 20200131 DocumentContents(全文検索用テキスト)から分類を取得
		strDocumentContents = listDoc.get(0).getDocumentContents();
		intCategoryId  =getCategoryIdFromAiserver(strDocumentContents);

		//返却用のmodelに先に入れらるものは入れておく
		model.addAttribute("strTmpDir", strTmpDir_i); //親作業directory
		model.addAttribute("strListJson", strListJson_i); //黒塗りリスト情報
		model.addAttribute("strFileName", strFileName_i); //オリジナルファイルネーム
		model.addAttribute("strTmpTimeStamp", strTmpUuid); //今回の作業derectory
		model.addAttribute("intPages",  "1"); //PDFページ数(暫定)
		model.addAttribute("documentId", documentId); //ドキュメントID
		model.addAttribute("strFilePath", strFilePath); //オリジナルファイルパス
		model.addAttribute("intCategoryId", intCategoryId); //分類ID

		//黒塗りリスト(ファイルサイズ測る用)作成
        //******resources配下コピーしておく(controllerでないとできない)
		objLog.info("resouce配下dir作成");
        String strMakeAllDir = strRealPath + strTmpDir_i+"resources/static/css/blackPaint/";
        FileUtils.forceMkdir(new File(strMakeAllDir));
        strMakeAllDir = strRealPath + strTmpDir_i+"resources/templates/blackPaint";
        FileUtils.forceMkdir(new File(strMakeAllDir));

        strMakeAllDir = strRealPath + strTmpDir_i+"resources/static/css/images/";
        FileUtils.forceMkdir(new File(strMakeAllDir));

		//デプロイ時にコピーできないため修正
		org.springframework.core.io.Resource resource =null;

//		String[] arrCopyCss = {"/templates/blackPaint/MaskListPrevTemplate.html","/static/css/blackPaint/common.css","/static/css/blackPaint/style.css","/static/css/blackPaint/03.list.css"
//				,"/static/css/images/l_file_node.gif","/static/css/images/l_file_word.gif","/static/css/images/logo_s.png"};
		String[] arrCopyCss = {"/templates/blackPaint/MaskListPrevTemplate.html","/static/css/blackPaint/common.css","/static/css/blackPaint/style.css","/static/css/blackPaint/03.list.css"
				,"/static/css/images/l_file_node.gif","/static/css/images/l_file_word.gif","/static/css/images/logo_s.png","/static/css/blackPaint/style.css","/static/css/blackPaint/mask.css"
				,"/static/css/images/l_file_pdf.gif","/static/css/images/l_file_excel.gif","/static/css/images/l_file_powerpoint.gif"};

		for (int i = 0; i < arrCopyCss.length; i++) {
			synchronized (this) {
				String strCssPath = arrCopyCss[i];
				resource = resourceLoader.getResource("classpath:" + strCssPath);
				objLog.info(strCssPath +"存在判定：判定："+ resource.exists());
				InputStream objIs = resource.getInputStream();
				byte[] arrByte = null;
				arrByte = IOUtils.toByteArray(objIs);
				FileOutputStream objOutSr = null;
				objOutSr=new FileOutputStream(strBasePath + "resources" + strCssPath);
				objOutSr.write(arrByte);//出力（dataのbyte列をファイルに書き込む）
				objOutSr.close();//閉じる(fosを使ったファイル操作を終えた時に実行)
			} //synchronized
		} //for

		objLog.info("ファイル、イメージ配備完了");

		String strListOutDir = strBasePath+strHead+"listAll/";
		String strListAllPath = objHtmllCls.makeBrackPaint("["+strListJson_i+"]",UserName,strListOutDir,strRealPath,strFileWithoutExtension,strFilePath,strOrgFileName);
		//pdf化 sizeの取得
		String strListPdfPath = "";

		objLog.info("strListOutDir：" + strListOutDir);
		try {
			strListPdfPath = strListOutDir+"MaskListPrev.pdf";

			objLog.info("strListPdfPath：" + strListPdfPath);

			strListPdfPath = objPdfCls.convertHtmlToPdf(strListAllPath, strListPdfPath,listDoc);
			if (strListPdfPath == null) {
				return errorProc(model, "黒塗りリストPDF出力処理が失敗しました。");
			}
			File maskListfile = new File(strListPdfPath);
			sizeMaskListPdf += maskListfile.length();

		} catch (Exception e) {
//			objLog.error("err message", e);
			objLog.error("黒塗りリストPDF化時エラー発生：", e);
			return errorProc(model, "黒塗りリストPDF出力処理が失敗しました。");
		} finally {
			//GCを明示的によんでメモリ解放
			//System.gc();
		} //try

		objLog.info("黒塗り・黒塗り候補PDF化処理開始");

		//黒塗り候補PDFの作成 黒塗りPDFの作成
		for (int intIndex = 0; intIndex < ARR_HEAD.length; intIndex++) {
			strHead=ARR_HEAD[intIndex];
			strBasePath=strRealPath + strTmpDir_i ;
			PrintWriter objPw=null;
			File objHtmlPath=null;
			File objTgtHtmlPath=null;
			try {

				String strGetHtml = "";
				String strOutHtml = "";
				synchronized (this) {

					//出力フォルダ作成
					strFileOutDir=strBasePath+strHead+strTmpUuid+"split"+"/";
					Path objSrcPath = Paths.get(strBasePath);
					Path objTgtPath = Paths.get(strFileOutDir);
					Files.copy(objSrcPath, objTgtPath);

					//html群をコピー
					strHtmlDir=strBasePath+documentId+"/";
					objHtmlPath = new File(strHtmlDir);
					objTgtHtmlPath = new File(strFileOutDir+documentId);
					FileUtils.copyDirectory(objHtmlPath, objTgtHtmlPath);

					//動的templateを作成
					if (listDoc.get(0).getExtension().equals("txt")) {
						strOutHtml+="<!DOCTYPE html> <html> <head> <meta http-equiv='Content-Type' content='text/html; charset=utf-8' /> <title>";
						strOutHtml+=strFileWithoutExtension;
						strOutHtml+="</title> </head> <body>";
						strOutHtml+=" <link rel='stylesheet' type='text/css' href='";
						strOutHtml+="../resources/static/css/blackPaint/mask.css' media='all' /> </head> <body>";
					}else if(listDoc.get(0).getExtension().contains("doc")) { //word

						strOutHtml+="<!DOCTYPE html> <html> <head> <meta http-equiv='Content-Type' content='text/html; charset=utf-8' /> <title>";
						strOutHtml+=strFileWithoutExtension;
						strOutHtml+="</title> <link rel='stylesheet' type='text/css' href='";
						strOutHtml+=documentId;
						strOutHtml+="/styles.css' media='all' /> ";
						strOutHtml+=" <link rel='stylesheet' type='text/css' href='";
						strOutHtml+=documentId;
						strOutHtml+="/mask.css' media='all' /> </head> <body>";

					}else if(listDoc.get(0).getExtension().contains("ppt")) { //ppt

						strOutHtml+="<!DOCTYPE html> <html> <head> <meta http-equiv='Content-Type' content='text/html; charset=utf-8' /> <title>";
						strOutHtml+=strFileWithoutExtension;
						strOutHtml+="</title> <link rel='stylesheet' type='text/css' href='";
						strOutHtml+=documentId;
						strOutHtml+="/style.css' media='all' /> ";
						strOutHtml+=" <link rel='stylesheet' type='text/css' href='";
						strOutHtml+=documentId;
						strOutHtml+="/mask.css' media='all' /> </head> <body>";

					}else if(listDoc.get(0).getExtension().contains("xls")) { //excel

						strOutHtml+="<!DOCTYPE html> <html> <head> <meta http-equiv='Content-Type' content='text/html; charset=utf-8' /> <title>";
						strOutHtml+=strFileWithoutExtension;
						strOutHtml+="</title> <link rel='stylesheet' type='text/css' href='";
						strOutHtml+=documentId;
						strOutHtml+="/style.css' media='all' /> ";
						strOutHtml+=" <link rel='stylesheet' type='text/css' href='";
						strOutHtml+=documentId;
						strOutHtml+="/mask.css' media='all' /> </head> <body>";

					} //if

					//PDF作成処理
					if(strHead.equals("mask_")) {
						strGetHtml = strMaskHtml_i;
					}else {
						strGetHtml = strRedHtml_i;
					} //if

				} //synchronized

				objDoc = Jsoup.parse(strGetHtml);
				Elements elmCls= objDoc.getElementsByClass(PAGE_CLASS);
				int intSize=elmCls.size();

//				for (int i = 0; i < elmCls.size(); i++) {
				for (int i = 0; i < intSize; i++) {

					//一度オブジェクトを開放してから処理を行う
					objDoc = Jsoup.parse(strGetHtml);
					elmCls= objDoc.getElementsByClass(PAGE_CLASS);

					String strOutPath ="";
//						synchronized (this) {
						//html out
						Element elmTgt = elmCls.get(i);
						//txtの場合フォントサイズを変更してhtmlとpdfの出力をあわせる
						if (listDoc.get(0).getExtension().equals("txt")) {
//							elmTgt.getElementsByClass("awdiv awpage").get(0).attr("style","awdiv awpage' style='word-break: break-all;padding:5px;font-size: 12px; line-height: 1.9; width:98%; text-align: justify; height:581pt;font-family: \"VL Gothic\";'>");
//							elmTgt.getElementsByClass("awdiv awpage").get(0).attr("style","awdiv awpage' style='word-break: break-all;padding:5px;font-size: 12px; line-height: 1.9; text-align: justify; width:595.3pt; height:841.9pt;font-family: \"VL Gothic\";'>");
							elmTgt.getElementsByClass("awdiv awpage").get(0).attr("style","awdiv awpage' style='word-break: break-all;padding:5px;font-size: 12px; line-height: 1.9; text-align: justify; width:580.3pt; height:841.9pt;font-family: \"VL Gothic\";'>");
						} //if
						String strGetOuterHtml = elmTgt.outerHtml();
						if (listDoc.get(0).getExtension().equals("txt")) {
							//jsopがspanに改行 スペースを加えるので除去
							strGetOuterHtml = strGetOuterHtml.replaceAll("(<span.*)\n", "$1");
							strGetOuterHtml = strGetOuterHtml.replace(" <span", "<span");
							strGetOuterHtml = strGetOuterHtml.replaceAll("\n", "");

						} //if

						strOutPath = strFileOutDir+strHead+ (i + 1) + ".html";
						//html out
						String strRepHtml=strOutHtml;

						// 20200131 PDFのstyle情報を組み込む
						String strStyle = "";
						if (listDoc.get(0).getExtension().equals("pdf")) {
					        strStyle+="<style>";
					        strStyle+=".tagMsk{";
					        strStyle+="    color: black;";
					        strStyle+="    display: inline-grid;";
					        strStyle+="    overflow: hidden;";
					        strStyle+="    background-color: black;";
					        strStyle+="}";
					        strStyle+="</style>";
							strRepHtml+=strStyle;
							strGetOuterHtml= strGetOuterHtml.replaceAll("<span class=\"tagMsk\" .* style=\"width: 0px;\">■</span>","");
						} //if

						strRepHtml+=strGetOuterHtml;
						strRepHtml+="</body> </html>";

						objPw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(
							       new FileOutputStream(strOutPath, true),"utf-8")));
						objPw.println(strRepHtml);
						objPw.close();

						//html end
//						} //synchronized

					//pdfout
					String strOutPdfPath = strFileOutDir+strHead+ (i + 1) + ".pdf";
					String strHeadForMessage = strHead.substring(0,strHead.length()-1);
					try {
						String ret = objPdfCls.convertHtmlToPdf(strOutPath,strOutPdfPath,listDoc);
						if (ret == null) {
							return errorProc(model, strHeadForMessage + "PDF出力処理が失敗しました。");
						}
						if(strHead.equals("mask_")) {
							File maskfile = new File(strOutPdfPath);
							sizeMaskPdf += maskfile.length();

						}else {
							File redfile = new File(strOutPdfPath);
							sizeRedPdf += redfile.length();

						} //if

						objLog.info(strHeadForMessage + (i + 1) +"枚目pdf出力完了");
					} catch (Exception e) {
						objLog.info("※※※※"+strHeadForMessage + (i + 1) +"枚目pdf出力時Errorが発生");
						objLog.error( "err message", e );
						return errorProc(model, strHeadForMessage + "PDF出力処理が失敗しました。");
					} //try

					//GCを明示的によんでメモリ解放
					//System.gc();

				} //for

				//クライアントにわたす情報格納
				intPages = intSize;
				// strRelativePath="/"+strTmpDir_i+strHead+"split"+"/"+strHead;
				objLog.info(strHead.substring(0,strHead.length()-1)+ "のpdf出力処理すべて完了");

			} catch (IOException e) {
				objLog.error("err message", e);
				return errorProc(model, "PDF出力処理が失敗しました。");
			} finally {
				objPw=null;
				objHtmlPath=null;
				objTgtHtmlPath=null;
				//GCを明示的によんでメモリ解放
				//System.gc();
			} //try

		} //for

		//ファイルサイズを三桁区切りで表示
		strSizeRedPdf = String.format("%,d", sizeRedPdf/1000); //黒塗り候補文書PDFのファイルサイズの合計
		strSizeMaskPdf = String.format("%,d", sizeMaskPdf/1000); //黒塗り文書PDFのファイルサイズの合計
		strSizeMaskListPdf = String.format("%,d", sizeMaskListPdf/1000); //黒塗り文書リストPDFのファイルサイズ

		//格納情報(今回のPoCのみ
		ResourceBundle objRb = ResourceBundle.getBundle("config/procenter");
		String strSaveDir = objRb.getString("save_directory");


		model.addAttribute("intPages",  String.valueOf(intPages)); //PDFページ数
		model.addAttribute("sizeRedPdf",  strSizeRedPdf); //黒塗り候補文書PDFのファイルサイズの合計 (KB)
		model.addAttribute("sizeMaskPdf", strSizeMaskPdf); //黒塗り文書PDFのファイルサイズの合計 (KB)
		model.addAttribute("sizeMaskListPdf", strSizeMaskListPdf); //黒塗り文書リストPDFのファイルサイズ (KB)
		model.addAttribute("strSaveDir", strSaveDir);
		model.addAttribute("blackPaintErrorStatus", false);
		model.addAttribute("blackPainteErrorMessage", "");


		return PAGE_PATH;
	} //getView1


	/**
	 * AIサーバから分類軸IDを取得する
	 * @param fileText 文書テキスト
	 * @return int 分類軸ID
	 * @throws Exception 想定外エラー
	 */
	protected int getCategoryIdFromAiserver(String fileText) throws Exception {
		int ret = 0;

		// AIサーバから分類軸IDを取得する
//		ret = (new DocClassifier()).classifyDocument(fileText);

		return ret;
	}


	/**
	 * エラー発生時専用遷移メソッド
	 * エラー発生であることを知らせる状態で画面を表示させる。
	 * @param model モデル
	 * @param message エラーメッセージ。
	 */
	private String errorProc(Model model, String message) {
		model.addAttribute("blackPaintErrorStatus", true);
		model.addAttribute("blackPaintErrorMessage", message);
		return PAGE_PATH;
	}


	/**
	 * エラー画面遷移(黒塗り処理)
     * @param e 発生したエラー
     * @param request HTTPリクエスト
     * @param response HTTPレスポンス
     * @param model 引渡しパラメータ用モデル
     * @return 遷移先アドレス
	 */
	@ExceptionHandler(Exception.class)
	public String handleException(
			Exception e,
			HttpServletRequest request,
			HttpServletResponse response,
			Model model
			) {

		//GCを明示的によんでメモリ解放
		//System.gc();


		//モデル初期化
		DirCnt objDirCls = new DirCnt();
		Cookie cookie[] = request.getCookies();
		String strTmpDir_i = "";
		if (cookie != null){
			for (int i = 0 ; i < cookie.length ; i++){
				if (cookie[i].getName().equals("strTmpDirName")){
					strTmpDir_i = cookie[i].getValue();
				} //if
			} //for
		} //if

		//作業ディレクトリかたずけ
		if(strTmpDir_i.equals(""))  {
			objLog.info("作業ディレクトリの取得が失敗しました");
		}else {
			try {
				//作業ディレクトリ,ファイルかたづけ
				objDirCls.delDirectory(context.getRealPath("/") + strTmpDir_i);
				objLog.info("作業ディレクトリ削除完了");
			} catch (Exception e1) {
				objLog.info("作業ディレクトリ削除失敗");
			} //try

		} //if


		response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		objLog.error("Error occurred.", e);
		StringWriter objSw = new StringWriter();
		PrintWriter objPw = new PrintWriter(objSw);
		e.printStackTrace(objPw);
		objPw.flush();
		String strError = objSw.toString();
		try {
			if (objSw != null) {
				objSw.close();
			}
			if (objPw != null) {
				objPw.close();
			}
		} catch (IOException e1) {
			objLog.error("objSw or objPw closing.：", e1);
			e1.printStackTrace();
		} //try

		model.addAttribute("errorMessage", e.getMessage() + "\r\n" + "StackTrace" + "\r\n" + strError) ;

		return "blackPaint/Fail";
	} //method

} //MaskHtmlCnt
