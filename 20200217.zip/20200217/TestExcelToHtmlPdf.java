package com.example.officeHtml;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.log4j.Logger;

import com.aspose.cells.Cell;
import com.aspose.cells.CellValueType;
import com.aspose.cells.Cells;
import com.aspose.cells.ColumnCollection;
import com.aspose.cells.FontSetting;
import com.aspose.cells.PdfSaveOptions;
import com.aspose.cells.RowCollection;
import com.aspose.cells.Shape;
import com.aspose.cells.ShapeCollection;
import com.aspose.cells.Style;
import com.aspose.cells.StyleFlag;
import com.aspose.cells.TextAlignmentType;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.pdf.Document;
import com.aspose.pdf.HtmlSaveOptions;
import com.aspose.pdf.LettersPositioningMethods;

/**
 * aspose変換excel→html→pdfの変換テスト
 *
 */
public class TestExcelToHtmlPdf {
	static Logger objLog = Logger.getLogger(TestExcelToHtmlPdf.class);

	public static void main(String[] args) {
		try {
			tester();
		} catch (Exception e) {
			e.printStackTrace();
		} // try
	} // main

	public static void tester() throws IOException {

		// ※※※※※グラフ等の参照が困難なため、excel→pdf→html→pdfの変換とする※※※※※

		String strDir = "C:/Users/Public/Documents/test/Excel/";
//		String strDir = "/home/ueda/デスクトップ/Excel2/";

		String strDirRet = strDir + "result/";
		objLog.info("対象Directory：" + strDir);
		objLog.info("結果格納Directory：" + strDirRet);
		makeDirWithCheck(strDirRet);

		// Fileクラスのオブジェクトを生成する
		File dir = new File(strDir);

		// listFilesメソッドを使用して一覧を取得する
		File[] list = dir.listFiles();
		String dstHtmlFile = "";
		String dstPdfFile = "";
		String strFileName = "";

		String strRetFile = "excel_" + String.valueOf(System.currentTimeMillis()) + ".csv";
		StringBuilder objSb = new StringBuilder(); // 結果格納用
		String strTmpRet = "";

		objLog.info("test start:" + String.valueOf(System.currentTimeMillis()));

		String strOs = System.getProperty("os.name").toLowerCase();
		String strDefFont = "";

		if (strOs.indexOf("windows") >= 0) {
			strDefFont = "MS Gothic";
		} else {
			strDefFont = "VL Gothic";
		} // if

		// headerを格納
		objSb.append("No,File名,HTML変換,SheetExcel名,SVG,PDF変換\r\n");
		int intCnt = 0;
		for (int i = 0; i < list.length; i++) {
			strFileName = list[i].getName();
			String strExtension = strFileName.substring(strFileName.lastIndexOf(".") + 1, strFileName.length());
			if (list[i].isFile() && list[i].getName().contains(".xls")) {
				intCnt++;
				strTmpRet = intCnt + "," + strFileName + ",";
				dstHtmlFile = strFileName.substring(0, strFileName.lastIndexOf(".")) + ".html";
				dstPdfFile = strFileName.substring(0, strFileName.lastIndexOf(".")) + ".pdf";

				// 一度PDF変換をかませる
				String dstPdfTmp = strFileName.substring(0, strFileName.lastIndexOf(".")) + "_tmp.pdf";
				String dstXlsTmp = strFileName.substring(0, strFileName.lastIndexOf(".")) + "_tmp.xlsx";

				/* excel→PDF convert start */
				objLog.info("対象ファイル：" + strFileName);
				objLog.info("excel→PDF convert start");

				try {
					// tmpのexcelを作成
					Workbook workbook = new Workbook(strDir + strFileName);
					WorksheetCollection worksheetCollection = workbook.getWorksheets();

					for (int intSheetIdx = 0; intSheetIdx < worksheetCollection.getCount(); intSheetIdx++) { // SheetLoop
						Worksheet workSheet = workbook.getWorksheets().get(intSheetIdx);


						boolean isHeader = false;

						for (int j = 0; j <= 2; j++) {
							String strHeader= workSheet.getPageSetup().getHeader(j);
							String strMakeHeader="";
							if(strHeader!=null) {
								if(strHeader.equals("&D")) {
									//"&D"は本日日付なので日付を設定する
							        Calendar calender = Calendar.getInstance();
							        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd");
							        strHeader = "　"+simpleDateFormat.format(calender.getTime());
								}
								strMakeHeader = "&\""+strDefFont+"\""+"&5"+strHeader;
								workSheet.getPageSetup().setHeader(j, strMakeHeader);
								isHeader=true;
							} //if

						} //for
						for (int j = 0; j <= 2; j++) {
							String strFooter= workSheet.getPageSetup().getFooter(j);
							String strMakeFooter="";
							if(strFooter!=null) {
								if(strFooter.equals("&D")) {
									//"&D"は本日日付なので日付を設定する
							        Calendar calender = Calendar.getInstance();
							        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd");
							        strFooter = "　"+simpleDateFormat.format(calender.getTime());
								}
								strMakeFooter = "&\""+strDefFont+"\""+"&5"+strFooter;
								workSheet.getPageSetup().setFooter(j, strMakeFooter);
							} //if

						} //for

						if(isHeader) {
							workSheet.getPageSetup().setLeftMargin(0.0);
							workSheet.getPageSetup().setTopMargin(0.7);
							workSheet.getPageSetup().setHeaderMargin(0);
						}else {
							//sheetの印刷余白設定(上左余白無し)
							workSheet.getPageSetup().setLeftMargin(0.0);
							workSheet.getPageSetup().setTopMargin(0.0);
							workSheet.getPageSetup().setHeaderMargin(0);

						} //if

						Cells cells = workSheet.getCells();
						Style style = workbook.createStyle();

						// 基本スタイル
						style.getFont().setName(strDefFont); // font

						// StyleFlagを適応することでStyleを当てることが可能
						StyleFlag styleFlag = new StyleFlag();
						styleFlag.setFontName(true);
						styleFlag.setIndent(true);
						styleFlag.setFontSize(true);

						// cellsで全てに当てると折返し判定ができないのですべてのcellを回す
//						cells.applyStyle(style, styleFlag);
						RowCollection rowCollection = cells.getRows();
						ColumnCollection columnCollection = cells.getColumns();


						for (int j = 0; j < cells.getMaxRow() + 1; j++) {
							for (int k = 0; k < cells.getMaxColumn() + 1; k++) {
								Cell cell = cells.get(j, k);
								String strCellVal = "";

								Object objCellVal = cell.getValue();
								if (objCellVal == null) { // nullの場合無視
									continue;
								} // if

//								objLog.info(cell.getStyle().getNumber());

								Style cellStyle = cell.getStyle();
								if(cellStyle.getHorizontalAlignment() == TextAlignmentType.RIGHT) {
									style.setIndentLevel(cellStyle.getIndentLevel() + 1); // 1インデント
								} //if

								//日付判定
								if (cell.getType() == CellValueType.IS_DATE_TIME) {

									System.out.println(cell.toString());
									System.out.println(cellStyle.getCultureCustom());
									Calendar calendar = cell.getDateTimeValue().toCalendar();

									SimpleDateFormat sdf = new SimpleDateFormat(cellStyle.getCultureCustom());
									System.out.println(sdf.format(calendar.getTime()));





									// Date型の場合値を取得し、cellは文字列にする
									strCellVal = cell.getDateTimeValue().toString().substring(0, 10).replace("-", "/");

									cellStyle.setHorizontalAlignment(TextAlignmentType.LEFT); //日付で長くなるので左寄せ
									cell.setValue(strCellVal);
									style.setNumber(CellValueType.IS_STRING);
								} else {
									style.setNumber(cellStyle.getNumber());

								} // if

								// インデントと等幅ででかくなる可能性を考えフォントサイズを下げる

								FontSetting[] fnts = cell.getCharacters();
								if(fnts==null) {
									double dblFontSize = cellStyle.getFont().getDoubleSize();
									style.getFont().setDoubleSize(dblFontSize *0.7);

									cell.setStyle(style, styleFlag);
								}else {
									//リッチテキスト対応
									for (int l = 0; l < fnts.length; l++) {
										fnts[l].getFont().setName(strDefFont);
										double dblFontSize = fnts[l].getFont().getDoubleSize();
										fnts[l].getFont().setDoubleSize(dblFontSize * 0.7);

									} //for
									cell.setCharacters(fnts);

								} //if

							} // for

						} // for

						// 図形処理
						ShapeCollection shapeCollection = workSheet.getShapes();
						for (int j = 0; j < shapeCollection.getCount(); j++) {
							Shape shape = shapeCollection.get(j);
							if (shape.getText() != null) {

								ArrayList<FontSetting> listShapes = shape.getCharacters();
								for (int k = 0; k < listShapes.size(); k++) {
									FontSetting fontSetting = listShapes.get(k);
									double dblFontSize = fontSetting.getFont().getDoubleSize();
									fontSetting.getFont().setDoubleSize(dblFontSize *0.7);
									fontSetting.getFont().setName(strDefFont);

								} //for
							} // if
						} // for
					} // for

					workbook.save(strDirRet + dstXlsTmp);
					if (workbook != null)
						workbook.dispose();
					// tmpのexcelからpdf作成
					PdfSaveOptions pdfSaveOptions = new PdfSaveOptions();

					Workbook workbook2 = new Workbook(strDirRet + dstXlsTmp);


					workbook2.save(strDirRet + dstPdfTmp, pdfSaveOptions);
					if (workbook2 != null)
						workbook2.dispose();

				} catch (Exception e) {
					objLog.error("excel→PDF convertでエラー発生");
					objLog.error(e);
					strTmpRet += "×,-,-,\r\n";
					objSb.append(strTmpRet);
					continue;
				} // try

				/* PDF→html convert start */
				Document pdf = null;
				try {
					pdf = new Document(strDirRet + dstPdfTmp);

					HtmlSaveOptions newOptions = new HtmlSaveOptions();
					// SaveOption設定
					newOptions.LettersPositioningMethod = LettersPositioningMethods.UseEmUnitsAndCompensationOfRoundingErrorsInCss;
					newOptions.FontSavingMode = HtmlSaveOptions.FontSavingModes.AlwaysSaveAsEOT;
					// newOptions.FontSavingMode = HtmlSaveOptions.FontSavingModes.SaveInAllFormats;

					newOptions.setDefaultFontName(strDefFont);

					pdf.save(strDirRet + dstHtmlFile, newOptions);
					objLog.info("PDF→HTML convert OK");
				} catch (Exception e) {
					objLog.error("PDF→HTML convertでエラー発生");
					objLog.error(e);
					strTmpRet += "×,-,-,\r\n";
					objSb.append(strTmpRet);
					continue;
				} // try
				if (pdf != null)
					pdf.dispose();

				strTmpRet += "○,";

				objLog.info("PDF→HTML convert end");
				/* excel→HTML convert end */

				// style.cssを整形する
				objLog.info("style.css Shape Start");
				shapeStyleCss(strDirRet + strFileName.substring(0, strFileName.lastIndexOf(".")) + "_files/style.css");
				objLog.info("style.css Shape End");

				// shape html
				shapeTgtHtml(strDirRet + dstHtmlFile);

//				objLog.info("SVG CHECK start");
//				String strHtml = "";
//				strHtml = readAll(strDirRet + dstHtmlFile);
//				strHtml = strHtml.replaceAll("\r\n", "");
//				if (strHtml.contains("svg")) {
//					strTmpRet += "有,";
//					objLog.info("SVGタグあり");
//				} else {
//					strTmpRet += "無,";
//					objLog.info("SVGタグ無し");
//				} // if
//
//				objLog.info("SVG CHECK end");

				/* HTML→PDF convert start */
//				objLog.info("HTML→PDF convert start");
//
//				InputStream fileStream = null;
//				fileStream = new FileInputStream(strDirRet + dstHtmlFile);
//				HTMLDocument htmlDocument = new HTMLDocument(fileStream, strDirRet + dstHtmlFile);
//
//				HtmlRenderer renderer = new HtmlRenderer();
//				FileOutputStream objOs = null;
//				PdfDevice objPdfDevice = null;
//				objOs = new FileOutputStream(strDirRet + dstPdfFile, true);
//				// pdf用サイズ
//				PdfRenderingOptions pdf_options = new PdfRenderingOptions();
//				pdf_options.getPageSetup().setAdjustToWidestPage(true);
//				objPdfDevice = new PdfDevice(pdf_options, objOs);
//
//				try {
////					renderer.render(objPdfDevice, htmlDocument);
//					objLog.info("HTML→PDF  convert ok");
//				} catch (Exception e) {
//					objLog.error("HTML→PDF convertでエラー発生");
//					objLog.error(e);
//					strTmpRet += "×\r\n";
//					objSb.append(strTmpRet);
//					if (renderer != null)
//						renderer.dispose();
//					if (objPdfDevice != null)
//						objPdfDevice.dispose();
//					if (objOs != null)
//						objOs.close();
//					if (fileStream != null)
//						fileStream.close();
//					continue;
//				} finally {
//					if (renderer != null)
//						renderer.dispose();
//					if (objPdfDevice != null)
//						objPdfDevice.dispose();
//					if (objOs != null)
//						objOs.close();
//					if (fileStream != null)
//						fileStream.close();
//				} // try
				strTmpRet += "○\r\n";
				objSb.append(strTmpRet);
				objLog.info("HTML→PDF convert end");
				/* HTML→PDF convert end */
				System.gc();

			} // if

		} // for
		File newfile = new File(strDirRet + "/" + strRetFile);
		PrintWriter filewriter = new PrintWriter(
				new BufferedWriter(new OutputStreamWriter(new FileOutputStream(newfile), "Shift-JIS")));
		filewriter.write(objSb.toString());
		filewriter.close();
		objLog.info("test end:" + String.valueOf(System.currentTimeMillis()));

	} // tester

	/**
	 * html shaping
	 *
	 * @param strpath_i
	 * @return 読み込んだ文字列
	 * @throws IOException
	 */
	public static String shapeTgtHtml(final String strCsspath_i) throws IOException {
		Path file = Paths.get(strCsspath_i);
		List<String> list = Files.readAllLines(file, Charset.forName("UTF-8"));
		StringBuilder objSb = new StringBuilder();
		for (int i = 0; i < list.size(); i++) {
			String strTmp = list.get(i);
			// visibility: hidden;対応
			if (strTmp.contains("visibility:hidden;")) {
				strTmp = strTmp.replace("visibility:hidden;", "visibility: visible;");
			} // if
			objSb.append(strTmp + "\r\n");
		} // for
		File newfile = new File(strCsspath_i);
		PrintWriter filewriter = new PrintWriter(
				new BufferedWriter(new OutputStreamWriter(new FileOutputStream(newfile), "UTF-8")));
		filewriter.write(objSb.toString());

		if (filewriter != null)
			filewriter.close();

		return objSb.toString();

	} // readAll

	/**
	 * style.cssを整形する
	 *
	 * @param strpath_i
	 * @return 読み込んだ文字列
	 * @throws IOException
	 */
	public static String shapeStyleCss(final String strCsspath_i) throws IOException {
		Path file = Paths.get(strCsspath_i);
		List<String> list = Files.readAllLines(file, Charset.forName("UTF-8"));
		StringBuilder objSb = new StringBuilder();
		for (int i = 0; i < list.size(); i++) {
			String strTmp = list.get(i);
			if (strTmp.matches("\tfont-size: .*")) {
				float intFontSize = Float.parseFloat(strTmp.replace("font-size:", "").replace("em;", "").trim());
				intFontSize -= 0.01;
//				intFontSize -= 0.1;
				strTmp = "	font-size: " + intFontSize + "em;";
			} else if (strTmp.matches("\tline-height: .*")) {
				float intLineHeight = Float.parseFloat(strTmp.replace("line-height:", "").replace("em;", "").trim());
//				intLineHeight += 0.5;
				strTmp = "	line-height: " + intLineHeight + "em;";
			} else if (strTmp.matches("\tfont-family: .*")) {
//				strTmp = "	font-family: \"VL PGothic\";";
				strTmp = "	font-family: \"VL Gothic\";";
			} // if
			objSb.append(strTmp + "\r\n");
		} // for
		File newfile = new File(strCsspath_i);
		PrintWriter filewriter = new PrintWriter(
				new BufferedWriter(new OutputStreamWriter(new FileOutputStream(newfile), "UTF-8")));
		filewriter.write(objSb.toString());

		if (filewriter != null)
			filewriter.close();

		return objSb.toString();

	} // readAll

	/**
	 * strpath_iで指定したファイルを改行なしですべて読み込む
	 *
	 * @param strpath_i
	 * @return 読み込んだ文字列
	 * @throws IOException
	 */
	public static String readAll(final String strpath_i) throws IOException {
		Path file = Paths.get(strpath_i);
		List<String> list = Files.readAllLines(file, Charset.forName("UTF-8"));
		StringBuilder objSb = new StringBuilder();
		for (int i = 0; i < list.size(); i++) {
			objSb.append(list.get(i));
		}
		file = null;
		return objSb.toString();

	} // readAll

	/**
	 * ディレクトリを作成する。
	 *
	 * @param strDirPath_i 作成ディレクトリパス
	 * @return 成否ステータス（0以外は失敗）
	 */
	public static int makeDirWithCheck(String strDirPath_i) {

		// strDirPath_iの長さが10未満なら処理しない(フェールセーフ)
		if (strDirPath_i.length() <= 10) {
			return -2;
		} // if

		objLog.info("対象フォルダ：" + strDirPath_i);

		File objTgtDir = new File(strDirPath_i);
		if (!objTgtDir.exists()) {

			if (objTgtDir.mkdir()) {
				objLog.info("フォルダの作成に成功しました");
			} else {
				objLog.info("フォルダの作成に失敗しました");
				return -1;
			} // it
		} // if
		return 0;
	} // method

}
