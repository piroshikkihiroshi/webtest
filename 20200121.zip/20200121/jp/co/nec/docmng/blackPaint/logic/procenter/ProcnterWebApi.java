package jp.co.nec.docmng.blackPaint.logic.procenter;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.List;

import org.apache.log4j.Logger;

import jp.co.nec.docmng.blackPaint.entity.procenter.PrcenterConvert;
import jp.co.nec.docmng.blackPaint.entity.procenter.ProcenterEnt;



public class ProcnterWebApi {

	static Logger objLog = Logger.getLogger(ProcnterWebApi.class);
	private static final String EOL = "\r\n";


	/**
	 * PROCENTER/CのWEBAPIを呼び出す(form-urlencoded)
	 * @param String strUrl_i   webapiurl
	 * @param String strJson_i strUrl_iにわたすjsonString
	 * @return ProcenterEnt jacksonでコンバートしたbeen
	 * @throws Exception
	 */
	public ProcenterEnt proPost(String strUrl_i,String strJson_i) throws Exception{

		String strRet = "";
		String method = "POST";
		String strEncJson  = "";
		int intRet=0;
		//connection open
		HttpURLConnection objCon = (HttpURLConnection) new URL(strUrl_i).openConnection();

		//header
		objCon.setDoOutput(true);
		objCon.setRequestMethod(method);
		objCon.setUseCaches(false);
		objCon.setRequestProperty("User-Agent","PROCENTER_C_WEBAPI_CLIENT");
		objCon.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

		//body
		OutputStream objOS = null;
		String strSendStr = "query="+strJson_i;
		try {
			objOS = objCon.getOutputStream();
			objOS.write(strSendStr.getBytes(StandardCharsets.UTF_8));
		} finally {
			if (objOS!=null) objOS.close();
		} //try

		objOS.flush();
		InputStream obIin = null;
		StringBuilder textBuilder=null;
		try {
			//結果取得
			intRet = objCon.getResponseCode();
			obIin = objCon.getInputStream();
		    textBuilder = new StringBuilder();
		    try (Reader reader = new BufferedReader(new InputStreamReader
		      (obIin, Charset.forName(StandardCharsets.UTF_8.name())))) {
		        int intc = 0;
		        while ((intc = reader.read()) != -1) {
		            textBuilder.append((char) intc);
		        } //while
		    } //try
			strRet = textBuilder.toString();
		} catch (Exception e) {
			objLog.error(e);
		} finally {
			//keep-aliveなので切断なし
//			objCon.disconnect();
			textBuilder=null;
		} //try

		objLog.info("result:"+strRet);


		//json convert
		PrcenterConvert prcenterConvert = new PrcenterConvert();
		ProcenterEnt procenterEnt = prcenterConvert.fromJsonString(strRet);

		return procenterEnt;
	} //method

	/**
	 * PROCENTER/CのWEBAPIを呼び出す(form-urlencoded)
	 * @param String strUrl_i   webapiurl
	 * @param String strJson_i strUrl_iにわたすjsonString
	 * @return ProcenterEnt jacksonでコンバートしたbeen
	 * @throws Exception
	 */
	public String proPostString(String strUrl_i,String strJson_i) throws Exception{

		String strRet = "";
		String method = "POST";
		String strEncJson  = "";
		int intRet=0;
		//connection open
		HttpURLConnection objCon = (HttpURLConnection) new URL(strUrl_i).openConnection();

		//header
		objCon.setDoOutput(true);
		objCon.setRequestMethod(method);
		objCon.setUseCaches(false);
		objCon.setRequestProperty("User-Agent","PROCENTER_C_WEBAPI_CLIENT");
		objCon.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

		//body
		OutputStream objOS = null;
		String strSendStr = "query="+strJson_i;
		try {
			objOS = objCon.getOutputStream();
			objOS.write(strSendStr.getBytes(StandardCharsets.UTF_8));
		} finally {
			if (objOS!=null) objOS.close();
		} //try

		objOS.flush();
		InputStream obIin = null;
		StringBuilder textBuilder=null;
		try {
			//結果取得
			intRet = objCon.getResponseCode();
			obIin = objCon.getInputStream();
		    textBuilder = new StringBuilder();
		    try (Reader reader = new BufferedReader(new InputStreamReader
		      (obIin, Charset.forName(StandardCharsets.UTF_8.name())))) {
		        int intc = 0;
		        while ((intc = reader.read()) != -1) {
		            textBuilder.append((char) intc);
		        } //while
		    } //try
			strRet = textBuilder.toString();
		} catch (Exception e) {
			objLog.error(e);
		} finally {
			//keep-aliveなので切断なし
//			objCon.disconnect();
			textBuilder=null;
		} //try

		objLog.info("result:"+strRet);



		return strRet;
	} //method

	/**
	 * PROCENTER/CのWEBAPIを呼び出す(multipart)
	 * ※ファイルアップロードときはこちらを呼び出す
	 * ※100MB制限があるので1ファイルずつ送る
	 * @param List<String> listFilePath 送付するファイルの
	 * @param String strUrl_i   webapiurl
	 * @param String strJson_i strUrl_iにわたすjsonString
	 * @return ProcenterEnt jacksonでコンバートしたbeen
	 * @throws Exception
	 */

		public int proPostMultipart(String strUrl_i,String strSessionInfoJson_i,String strFullPath_i) throws Exception {

			String method = "POST";
			String strBoundary = "-----------------------------7dd24e3050716";
			String strEncJson  = "";
			//connection open
			HttpURLConnection objCon = (HttpURLConnection) new URL(strUrl_i).openConnection();

			//header
			objCon.setDoOutput(true);
			objCon.setRequestMethod(method);
			objCon.setUseCaches(false);
			objCon.setRequestProperty("User-Agent","PROCENTER_C_WEBAPI_CLIENT");
			objCon.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + strBoundary);
			OutputStream objOS = objCon.getOutputStream();
			objOS.write((EOL + EOL+strBoundary+ EOL).getBytes(StandardCharsets.UTF_8)); //最初の区切り
			//セッションと結合
			String strJson = "";
			strJson+="{\"files\":[\"file_1\"]}";

			//※※※※※※session infoと結合

			//転送パラメタ名
			objOS.write(("Content-Disposition: form-data; name=\"query\"; " +
					strSessionInfoJson_i+","+strJson + EOL +
					strBoundary).getBytes(StandardCharsets.UTF_8));
//			objOS.write(("Content-Disposition: form-data; name=\"query\"; " +
//					"query="+strSessionInfoJson_i+","+strJson + EOL +
//					strBoundary).getBytes(StandardCharsets.UTF_8));
			//実ファイル転送準備
			String filename = strFullPath_i.substring(strFullPath_i.lastIndexOf('/')+1,strFullPath_i.length());
			FileInputStream objFile = new FileInputStream(strFullPath_i);
			objOS.write((EOL +
					"Content-Disposition: form-data; name=\"file_1\";" +
					"filename=\"" + filename + "\"" + EOL +
					"Content-Type: application/octet-stream" + EOL + EOL)
							.getBytes(StandardCharsets.UTF_8));
			byte[] arrBuffer = new byte[128];
			int intSize = -1;
			while (-1 != (intSize = objFile.read(arrBuffer))) {
				objOS.write(arrBuffer, 0, intSize);
			} //while

			objOS.write((strBoundary + "--").getBytes(StandardCharsets.UTF_8));
			objFile.close();
			objOS.flush();

			int intRet = 0;

			try {
				intRet = objCon.getResponseCode();
			} catch (Exception e) {
				System.err.println(e);
			} finally {
				//keep-aliveなので切断なし
//				objCon.disconnect();
			} //try

			return intRet;

		} //method


//	/**
//	 * PROCENTER/CのWEBAPIを呼び出す(multipart)
//	 * ※ファイルアップロードときはこちらを呼び出す
//	 * ※100MB制限があるので1ファイルずつ送る
//	 * @param List<String> listFilePath 送付するファイルの
//	 * @param String strUrl_i   webapiurl
//	 * @param String strJson_i strUrl_iにわたすjsonString
//	 * @return ProcenterEnt jacksonでコンバートしたbeen
//	 * @throws Exception
//	 */
//
//		public int proPostMultipart(String strUrl_i,String strSessionInfoJson_i,String strFullPath_i) throws Exception {
//
//			String method = "POST";
//			String strBoundary = "---------------------------7dd24e3050716";
//			String strEncJson  = "";
//			//connection open
//			HttpURLConnection objCon = (HttpURLConnection) new URL(strUrl_i).openConnection();
//
//			//header
//			objCon.setDoOutput(true);
//			objCon.setRequestMethod(method);
//			objCon.setUseCaches(false);
//			objCon.setRequestProperty("User-Agent","PROCENTER_C_WEBAPI_CLIENT");
//			objCon.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + strBoundary);
//			OutputStream objOS = objCon.getOutputStream();
//
//			//セッションと結合
//			String strJson = "";
//			strJson+="{\"files\":[\"file_1\"]}";
//			//※※※※※※session infoと結合
//
//			strEncJson=URLEncoder.encode(strJson, "UTF-8");
//
//			objOS.write(("--" + strBoundary + EOL +
//					"Content-Disposition: form-data; name=\"query\"; " +
////							strEncJson + EOL).getBytes(StandardCharsets.UTF_8)) ;
//					strEncJson + EOL +
//					"Content-Type: application/octet-stream" + EOL + EOL)
//							.getBytes(StandardCharsets.UTF_8));
//			//実ファイル送付
//			String filename = strFullPath_i.substring(strFullPath_i.lastIndexOf('/')+1,strFullPath_i.length());
//			FileInputStream objFile = new FileInputStream(strFullPath_i);
//			objOS.write(("--" + strBoundary + EOL +
//					"Content-Disposition: form-data; name=\"file_1"+"\"; " +
//					"filename=\"" + filename + "\"" + EOL +
//					"Content-Type: application/octet-stream" + EOL + EOL)
//							.getBytes(StandardCharsets.UTF_8));
//			byte[] arrBuffer = new byte[128];
//			int intSize = -1;
//			while (-1 != (intSize = objFile.read(arrBuffer))) {
//				objOS.write(arrBuffer, 0, intSize);
//			}
//			objFile.close();
//
//
//
//			objOS.write((EOL + "--" + strBoundary + "--" + EOL).getBytes(StandardCharsets.UTF_8));
//			objOS.flush();
//
//			int intRet = 0;
//
//			try {
//				intRet = objCon.getResponseCode();
//			} catch (Exception e) {
//				System.err.println(e);
//			} finally {
//				//keep-aliveなので切断なし
////				objCon.disconnect();
//			} //try
//
//			return intRet;
//
//		} //method


	/**
	 * PROCENTER/CのWEBAPIを呼び出す(multipart)
	 * ※ファイルアップロードときはこちらを呼び出す
	 * ※100MB制限があるので1ファイルずつ送る
	 * @param List<String> listFilePath 送付するファイルの
	 * @param String strUrl_i   webapiurl
	 * @param String strJson_i strUrl_iにわたすjsonString
	 * @return ProcenterEnt jacksonでコンバートしたbeen
	 * @throws Exception
	 */

		public int proPostMultipart(List<String> listFilePath, String strUrl_i) throws Exception {

			String method = "POST";
			String strBoundary = "---------------------------7dd24e3050716";
			String strEncJson  = "";
			//connection open
			HttpURLConnection objCon = (HttpURLConnection) new URL(strUrl_i).openConnection();

			//header
			objCon.setDoOutput(true);
			objCon.setRequestMethod(method);
			objCon.setUseCaches(false);
			objCon.setRequestProperty("User-Agent","PROCENTER_C_WEBAPI_CLIENT");
			objCon.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + strBoundary);
			OutputStream objOS = objCon.getOutputStream();

			for (int i = 0; i <= listFilePath.size(); i++) {
				if(i==0) { //jsonの作成
					//セッションと結合
					String strJson = "";
					strJson+="\"files\": [";
					for (int j = 0; j < listFilePath.size(); j++) {
						strJson+="\"file_"+(j+1)+"\",";
					} //for
					strJson = strJson.substring(0,strJson.length()-1);
					strJson +="]";

					//※※※※※※session infoと結合

					strEncJson=URLEncoder.encode(strJson, "UTF-8");

					objOS.write(("--" + strBoundary + EOL +
							"Content-Disposition: form-data; name=\"query\"; " +
//							strEncJson + EOL).getBytes(StandardCharsets.UTF_8)) ;
							strEncJson + EOL +
							"Content-Type: application/octet-stream" + EOL + EOL)
									.getBytes(StandardCharsets.UTF_8));
//					byte[] arrBuffer = new byte[128];
//					int intSize = -1;
//					while (-1 != (intSize = objFile.read(arrBuffer))) {
//						objOS.write(arrBuffer, 0, intSize);
//					}
				}else { //実ファイル送付
					String filename = listFilePath.get(i - 1);
					FileInputStream objFile = new FileInputStream(filename);
					objOS.write(("--" + strBoundary + EOL +
							"Content-Disposition: form-data; name=\"file_"+(i)+"\"; " +
							"filename=\"" + filename + "\"" + EOL +
							"Content-Type: application/octet-stream" + EOL + EOL)
									.getBytes(StandardCharsets.UTF_8));
					byte[] arrBuffer = new byte[128];
					int intSize = -1;
					while (-1 != (intSize = objFile.read(arrBuffer))) {
						objOS.write(arrBuffer, 0, intSize);
					}
					objFile.close();

				} //if


			} //for
			objOS.write((EOL + "--" + strBoundary + "--" + EOL).getBytes(StandardCharsets.UTF_8));
			objOS.flush();

			int intRet = 0;

			try {
				intRet = objCon.getResponseCode();
			} catch (Exception e) {
				System.err.println(e);
			} finally {
				//keep-aliveなので切断なし
//				objCon.disconnect();
			} //try

			return intRet;

		} //method


} //PolicyGet
