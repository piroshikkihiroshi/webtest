package jp.co.nec.docmng.blackPaint.util.api;

import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.blackPaint.entity.procenter.ProcenterEnt;
import jp.co.nec.docmng.blackPaint.logic.procenter.ProcnterWebApi;


public class ProcenterTest {

	static Logger objLog = Logger.getLogger(ProcenterTest.class);


	public String postTest() throws Exception{
		ProcenterTest objMe = new ProcenterTest();
		ObjectMapper objMapper = new ObjectMapper();
		JsonNode objRoot = null;

		//暫定
		int intNodeId=100; //createDraftNodeにて必要だが、重複はNG どのように空いているNodeIDを取得するか不明
		String strFileOutDir = "C:/Temp/result/"; //PROCENTER/Cに保存するファイル格納DIR
		String strFileName = "test.docx";
		//暫定 end

		objLog.info("処理開始");


		ProcenterEnt procenterSessionEnt = null; //PORCENTER beenクラス(session用)
		ProcenterEnt procenterEnt = null; //PORCENTER beenクラス
		String strRet = "";
		//設定ファイル取得
		ResourceBundle objRb = ResourceBundle.getBundle("config/procenter");
		String strBaseUrl = objRb.getString("procenter_url");
		String strProcenterUserId = objRb.getString("procenter_user_id");
		String strProcenterPassword = objRb.getString("procenter_user_password");
		String strJson = "";
		String strSessionInfoJson="";

		ProcnterWebApi objProCls = new ProcnterWebApi();


		//login処理
		strJson="";
		strJson+="{";
		strJson+="\"credentials\":{";
		strJson+="\"userId\":\""+strProcenterUserId+"\",";
		strJson+="\"password\":\""+strProcenterPassword+"\",";
		strJson+="\"locale\":\"ja\"";
		strJson+="}";
		strJson+="}";

		objLog.info("ログイン開始");

		String strLoginUrl = strBaseUrl + "webapi/RepositoryWebAPI/login/call.rmt"; //login用url
		try {
//			procenterSessionEnt = objProCls.proPost(strLoginUrl, strJson);
//			strRet=procenterSessionEnt.getResult();

			strRet = objProCls.proPostString(strLoginUrl, strJson);
			objMapper = new ObjectMapper();
			objRoot = objMapper.readTree(strRet);


			if (objRoot.get("result").equals("success")) {
				objLog.info("PROCENTER/C LOGIN OK");
			} else {
				objLog.error("PROCENTER/C LOGIN NG \r\n" + objRoot.get("exception").get("message"));
				throw new Exception(objRoot.get("exception").get("message").toString());
			} //if

		} catch (Exception e) {
			objLog.error("err message", e);
			objMe.proLogout(strBaseUrl,strSessionInfoJson); //logout処理を入れる
			throw new Exception(e);
		} //try

		//session infoは使い回すのでsession infoのjsonStringを作成しておく
		strSessionInfoJson="";
		strSessionInfoJson+="";
		strSessionInfoJson+="\"sessionInfo\":{";
		strSessionInfoJson+="\"sessionId\":\""+objRoot.get("return").get("sessionId")+"\",";
		strSessionInfoJson+="\"userId\":\""+strProcenterUserId+"\",";
		strSessionInfoJson+="\"locale\":\"ja\",";
		if (objRoot.get("return").get("clientCode")!=null) {
			strSessionInfoJson+="\"clientCode\":\""+objRoot.get("return").get("clientCode")+"\",";
		} //if
		strSessionInfoJson+="\"serverAddress\":\""+objRoot.get("return").get("serverAddress")+"\",";
		strSessionInfoJson+="\"userAgent\":\""+objRoot.get("return").get("userAgent")+"\"";
		strSessionInfoJson+="}";

//		strSessionInfoJson="";
//		strSessionInfoJson+="";
//		strSessionInfoJson+="\"sessionInfo\":{";
//		strSessionInfoJson+="\"sessionId\":\""+procenterSessionEnt.getProcenterEntReturn().getSessionID()+"\",";
//		strSessionInfoJson+="\"userId\":\""+strProcenterUserId+"\",";
//		strSessionInfoJson+="\"locale\":\"ja\",";
//		if (procenterSessionEnt.getProcenterEntReturn().getClientCode()!=null) {
//			strSessionInfoJson+="\"clientCode\":\""+procenterSessionEnt.getProcenterEntReturn().getClientCode()+"\",";
//		} //if
//		strSessionInfoJson+="\"serverAddress\":\""+procenterSessionEnt.getProcenterEntReturn().getServerAddress()+"\",";
//		strSessionInfoJson+="\"userAgent\":\""+procenterSessionEnt.getProcenterEntReturn().getServerAddress()+"\"";
//		strSessionInfoJson+="}";


		//1ファイルずつ送付
//		procenterSessionEnt = objProCls.proPostMultipart("http://localhost/test/parsejson.php?XDEBUG_SESSION_START=xdebug",strSessionInfoJson,strFileOutDir);
//		objProCls.proPostMultipart("http://localhost/test/parsejson.php?XDEBUG_SESSION_START=xdebug",strSessionInfoJson,strFileOutDir+strFileName);
//		strRet = objProCls.getProCenterMultipart("http://localhost/test/parsejson.php?XDEBUG_SESSION_START=xdebug",strSessionInfoJson,objSendPath);




		//※※※※※※getChildNodetest※※※※※※
		String strparrntId="2011";
		strJson="";
		strJson+="{";
		strJson+=strSessionInfoJson;
		strJson+=",";
		strJson+="\"parentId\":"+strparrntId+",";
		strJson+="\"depthLevel\":1,";
		strJson+="\"accessLogEnabled\":true,";
		strJson+="\"responseFilter\":{";
		strJson+="\"nameList\":[";
		strJson+="\"ID\",";
		strJson+="\"NAME\",";
		strJson+="\"LASTMODIFIED\",";
		strJson+="\"REMARK\"";
		strJson+="]";
		strJson+="}";
		strJson+="}";

		String strgetChildNodeUrl = strBaseUrl + "webapi/NodeManagerWebAPI/getChildNodes/call.rmt";
		try {
			strRet = objProCls.proPostString(strgetChildNodeUrl, strJson);
			objMapper = new ObjectMapper();
			objRoot = objMapper.readTree(strRet);

			if (objRoot.get("result").equals("success")) {
				objLog.info("PROCENTER/C LOGIN OK");
			} else {
				objLog.error("PROCENTER/C LOGIN NG \r\n" + objRoot.get("exception").get("message"));
				throw new Exception(objRoot.get("exception").get("message").toString());
			} //if

//			strRet=procenterEnt.getResult();
//			if (strRet.equals("success")) {
//				objLog.info("PROCENTER/C getChildNode OK");
//			} else {
//				objLog.error("PROCENTER/C getChildNode NG \r\n" + procenterEnt.getException().getMessage());
//				objMe.proLogout(strBaseUrl,strSessionInfoJson); //logout処理を入れる
//				throw new Exception(procenterEnt.getException().getMessage());
//			} //if

		} catch (Exception e) {
			objLog.error("err message", e);
			objMe.proLogout(strBaseUrl,strSessionInfoJson); //logout処理を入れる
			throw new Exception(e);
		} //try

		//※※※※※※getChildNodetest end※※※※※※


		//createDraftNode処理
		strJson="";
		strJson+="{";
		strJson+=strSessionInfoJson;
		strJson+=",";
		strJson+="\"nodeId\":"+intNodeId+",";
		strJson+="\"responseFilter\":{";
		strJson+="\"nameList\":[";
		strJson+="\"ID\",";
		strJson+="\"NAME\",";
		strJson+="\"LASTMODIFIED\",";
		strJson+="\"REMARK\"";
		strJson+="]";
		strJson+="}";
		strJson+="}";

		String strCreateDraftNodeUrl = strBaseUrl + "webapi/RepositoryWebAPI/createDraftNode/call.rmt"; //criateDraftNode用url
		String strCreateNodeUrl = strBaseUrl + "webapi/RepositoryWebAPI/createNode/call.rmt"; //criateNode用url
		try {


			//1ファイルずつ送付
//			procenterSessionEnt = objProCls.getProCenterMultipart("http://localhost/test/parsejson.php?XDEBUG_SESSION_START=xdebug",strSessionInfoJson,objSendPath);
//			strRet = objProCls.getProCenterMultipart("http://localhost/test/parsejson.php?XDEBUG_SESSION_START=xdebug",strSessionInfoJson,objSendPath);

		} catch (Exception e) {
			objLog.error("err message", e);
			objMe.proLogout(strBaseUrl,strSessionInfoJson); //logout処理を入れる
			throw new Exception(e);
		} //try

		objLog.info("Logout処理開始");
		objMe.proLogout(strBaseUrl,strSessionInfoJson); //logout処理を入れる




		//承認画面呼び出し

		return strRet;

	} //method

	public void proLogout(String strBaseUrl_i,String strSessionInfoJson_i) throws Exception {

		//logout処理
		if(!strSessionInfoJson_i.equals("")) { //strSessionInfoJson_iが空→loginできていない
			ProcnterWebApi objProCls = new ProcnterWebApi();
			String strLogoutUrl = strBaseUrl_i + "webapi/RepositoryWebAPI/logout/call.rmt"; //logout用url
			try {
//				objProCls.proPost(strLogoutUrl, strSessionInfoJson_i);
				objProCls.proPostString(strLogoutUrl, strSessionInfoJson_i);
				objLog.info("logout成功");
			}catch (Exception e) {
				objLog.info("logout失敗");
				objLog.error(e);
				throw new Exception(e);
			} //try
		} //if

	} //method



} //PolicyGet
