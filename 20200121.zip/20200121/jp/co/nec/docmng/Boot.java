package jp.co.nec.docmng;

import jp.co.nec.docmng.blackPaint.util.api.ProcenterTest;

public class Boot {

	public static void main(String[] args) {
		ProcenterTest objTgt = new ProcenterTest();
		try {
			objTgt.postTest();
		} catch (Exception e) {

			e.printStackTrace();
		}

	} //methoc

} //class
