package jp.co.nec.docmng.blackPaint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.blackPaint.entity.MaskDocumentEntBlackPaint;
import jp.co.nec.docmng.blackPaint.repository.MaskDocumentMapPaint;

@Service
public class MaskDocumentService {
	@Autowired
	private MaskDocumentMapPaint maskDocumentMapPaint;

	//table mask_document

	@Transactional
	public List<MaskDocumentEntBlackPaint> getHtmlZip(Integer document_id,String user_id){
		return maskDocumentMapPaint.getHtmlZip(document_id, user_id);

	} //method


	@Transactional
	public List<MaskDocumentEntBlackPaint> listDoc(Integer document_id,String user_id) {
		return maskDocumentMapPaint.isDoc(document_id, user_id);
	} //findOneService

	@Transactional
	public void insertMaskDocument(MaskDocumentEntBlackPaint MaskDocumentEnt) {
		maskDocumentMapPaint.insertMaskDocument(MaskDocumentEnt);
	} //insertMaskDocument

	@Transactional
    public void deleteDoc(Integer document_id,String user_id) {
		maskDocumentMapPaint.deleteDoc(document_id, user_id);
	} //deleteDoc


} //PolicyInfoServiceApi
