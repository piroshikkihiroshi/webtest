package jp.co.nec.docmng.dao.accesser.common;

import java.io.Reader;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import jp.co.nec.docmng.dao.entity.common.MaskDocumentMarker;
import jp.co.nec.docmng.dao.entity.common.MaskDocumentMarkerExample;
import jp.co.nec.docmng.dao.mapper.common.MaskDocumentMarkerMapper;

/**
 * MaskDocumentMarkerDao
 * 黒塗り文書黒塗り箇所保存テーブルの全件を取得する。
 */
public class MaskDocumentMarkerDao {
	
	/**
	 * 黒塗り文書黒塗り箇所保存テーブルの情報を表示する。
	 * @return List<MaskDocumentMarker> maskDocumentMarkerList 黒塗り文書黒塗り箇所保存テーブルの情報リストを取得する。
	 * @throws Exception テーブル情報を取得できない場合
	 */
	
	public List<MaskDocumentMarker> getMaskDocumentMarkerAll() {
		
	List<MaskDocumentMarker> maskDocumentMarkerList = null;
	
	try (Reader readerConfig = Resources.getResourceAsReader("mybatis-config.xml");) {

		// 読み込んだ設定ファイルからSqlSessionFactoryを生成する
		SqlSessionFactory sqlFactory = new SqlSessionFactoryBuilder().build(readerConfig);

		// SQLセッションを取得する
		try (SqlSession sqlSession = sqlFactory.openSession()) {

			// 黒塗り文書黒塗り箇所保存テーブルのMapperを取得する
			MaskDocumentMarkerMapper maskDocumentMarkerMapper = sqlSession.getMapper(MaskDocumentMarkerMapper.class);

			// 黒塗り文書黒塗り箇所保存テーブルの条件検索用クラスを生成する
			MaskDocumentMarkerExample maskDocumentMarkerExample = new MaskDocumentMarkerExample();
			
			maskDocumentMarkerExample.setOrderByClause("mask_id");

			// 上記の条件でテーブルを検索する
			maskDocumentMarkerList = maskDocumentMarkerMapper.selectByExample(maskDocumentMarkerExample);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	return maskDocumentMarkerList;
	}
}
