/**
 * 名称：SaveTmpReopenCnt.java
 * 機能名：一時保存再開Control
 * 概要：一時保存再開機能のControlを行う。
 */

package jp.co.nec.docmng.blackPaint.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.zeroturnaround.zip.ZipUtil;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.blackPaint.entity.TmpMaskDocMarkerEntBlackPaint;
import jp.co.nec.docmng.blackPaint.entity.TmpMaskDocumentEntBlackPaint;
import jp.co.nec.docmng.blackPaint.logic.dirFile.DirCnt;
import jp.co.nec.docmng.blackPaint.service.DocInfoService;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocTmpMarkerService;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocumentService;

/**
 * 一時保存再開機能のControlを行う。
 */
@RestController
public class SaveTmpReopenCnt {

	/**
	 * context サーブレットのRealPathを取得する
	 * objLog log出力に使用する
	 * PAGE_CLASS ページを判定するHTMLClass。ページをSplitするのに使用する
	 * ARR_HEAD ファイル名、フォルダ名を判定するために使用する
	 */
	@Autowired
	ServletContext context;
	@Autowired
	TmpMaskDocumentService tmpMaskDocumentService;
	@Autowired
	TmpMaskDocTmpMarkerService tmpMaskDocTmpMarkerService;
	@Autowired
	DocInfoService docInfoService;

	static Logger objLog = LoggerFactory.getLogger(SaveTmpReopenCnt.class);

	static String PAGE_CLASS = "awdiv awpage"; //splitするページのHTMLClass
	static String[] ARR_HEAD = { "mask_", "red_" }; //ファイル名、フォルダ名のヘッダー配列

	/**
	 * 一時保存再開メソッド
	 * 一時保存再開を押下したときの処理制御をする。
	 * @param strHashJson 以下の値を入れ込んだjsonString
	 * documentId ドキュメントID
	 */
	@ResponseBody
	@PostMapping("/blackpaint/SaveTmpReopen")
	@ResponseStatus(HttpStatus.OK)
	public synchronized String SaveTmpDocCntRest(
			@RequestBody String documentId,
			@CookieValue(value = "user_id") String UserId,
			@CookieValue(value = "strTmpDirName",required=false) String strTmpDir,
			HttpServletResponse response,Model model) {

		if(strTmpDir.equals("")) {
//			strTmpDir="tmp" + System.currentTimeMillis() + "/";
			strTmpDir="tmp" + UUID.randomUUID().toString() + "/";
			Cookie cookie = new Cookie("strTmpDirName", strTmpDir);
		    cookie.setMaxAge(60*3600);
		    cookie.setPath("/");
			response.addCookie(cookie);
		} //if

		if (UserId==null) UserId="";

		objLog.info("UserId:"+UserId);

		//モデル初期化
//		FileCnt objFileCnt = new FileCnt();
		DirCnt objDirCls = new DirCnt();

		//メンバ変数初期化
		String strTmpTimeStamp = ""; //tempファイルタイムスタンプ
		int intDocumentId = Integer.parseInt(documentId); //documentId

		String strBasePath = ""; //黒塗り作成時の作業フォルダ
		String strFileOutDir = ""; //出力フォルダ
		String strRealPath = context.getRealPath("/");


		//一時保存したzipをDBから取得
		List<TmpMaskDocumentEntBlackPaint> listZip = null;
		byte[] arrHtmlZip = null;
		List<TmpMaskDocMarkerEntBlackPaint> listInfo = null;

		try {
			listZip = tmpMaskDocumentService.getTmpHtmlZip(intDocumentId, UserId);
			arrHtmlZip = listZip.get(0).getHtmlZipData();
			//policy等取得
			listInfo = tmpMaskDocTmpMarkerService.selectTmpMaskDocMarker(intDocumentId, UserId);

		} catch (Exception e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} //try

		//file出力
		//出力フォルダ作成
		strBasePath = strRealPath + strTmpDir;
		strFileOutDir = strRealPath + "tmp" + strTmpTimeStamp + "/";
		String strZipPath = strFileOutDir + "mask.zip";
		String strUnZipPath = strRealPath + "zip" + strTmpTimeStamp + "/";
		Path objZipPath = Paths.get(strZipPath);
		try {
			objDirCls.makeDirWithCheck(strFileOutDir);
			//zipファイル出力
			Files.write(objZipPath, arrHtmlZip);
			//unzipする
			//			ZipUtil.unpack(new File(strZipPath), new File(strUnZipPath));
			//現在のhtmlと入れ替える
			//			objDirCls.delDirectory(strBasePath); //一旦削除
			//			FileUtils.moveDirectory(new File(strUnZipPath), new File(strBasePath));

			//セッションで削除できないためそのままunzip
			ZipUtil.unpack(new File(strZipPath), new File(strBasePath));

			//作業ディレクトリかたづけ
			objDirCls.delDirectory(strFileOutDir);
    		objLog.info("作業directoryかたずけ完了：" + strFileOutDir);

		} catch (IOException e1) {
			objLog.error("err message", e1);
			e1.printStackTrace();
		} //try
		catch (Exception e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} //try

		String strRet = "";
		//jsonにしてpolicy等の情報を返す
		ObjectMapper objMapper = new ObjectMapper();
		try {
			strRet = objMapper.writeValueAsString(listInfo);
		} catch (JsonProcessingException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} //if

		return strRet;

	} //getView1

	/**
	 * エラー画面遷移(黒塗り処理)
	 */
	@ExceptionHandler(Exception.class)
	public String handleException(Exception e, HttpServletResponse response, Model model) {

		//GCを明示的によんでメモリ解放
		//System.gc();

		response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		objLog.error("Error occurred.", e);
		StringWriter objSw = new StringWriter();
		PrintWriter objPw = new PrintWriter(objSw);
		e.printStackTrace(objPw);
		objPw.flush();
		String strError = objSw.toString();
		try {
			objSw.close();
			objPw.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		} //try

		model.addAttribute("errorMessage", e.getMessage() + "\r\n" + "StackTrace" + "\r\n" + strError) ;

		return "blackPaint/Fail";
	} //method

} //MaskHtmlCnt
