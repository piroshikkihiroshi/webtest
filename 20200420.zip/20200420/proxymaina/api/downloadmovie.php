<?php
// ファイルのパス
$filepath = "C:\home\murakamr\op2\content\MOV1\output.mp4";
// リネーム後のファイル名
$filename = 'test.mp4';
// ファイルタイプにPDFを指定
header('Content-Type: video/mp4');
 
// ファイルサイズを取得し、ダウンロードの進捗を表示
header('Content-Length: '.filesize($filepath));
 
// ファイルのダウンロード、リネームを指示
header('Content-Disposition: attachment; filename="'.$filename.'"');
 
// ファイルを読み込みダウンロードを実行
readfile($filepath);

?>
