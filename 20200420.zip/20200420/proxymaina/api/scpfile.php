<?php
/** 
 * 分析結果ビデオをプロキシサーバ上までダウンロードする 
*/

//inifile
$arrIni = parse_ini_file("../setting/setting.ini");

$strHost = $arrIni['host'];
$intPort = $arrIni['port'];
$strUser=$arrIni['user'];
$strPass=$arrIni['password'];
$strGetMovie1='/home/murakamr/op2/content/MOV1/output.mp4';
$strGetMovie2='/home/murakamr/op2/content/MOV2/output.mp4';
$strOutMovie1='../content/MOV1/output.mp4';
$strOutMovie2='../content/MOV2/output.mp4';

$connection = ssh2_connect($strHost, $intPort);
ssh2_auth_password($connection, $strUser, $strPass);
ssh2_scp_recv($connection, $strGetMovie1, $strOutMovie1);
ssh2_scp_recv($connection, $strGetMovie2, $strOutMovie2);

return false;

?>
