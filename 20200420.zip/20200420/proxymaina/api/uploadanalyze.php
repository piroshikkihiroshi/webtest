<?php
/** 
 * 分析結果ビデオをプロキシサーバ上、分析サーバ上にアップロードし、分析スクリプトを実行する。 
*/

//inifile
$arrIni = parse_ini_file("../setting/setting.ini");

$strHost = $arrIni['host'];
$intPort = $arrIni['port'];
$strUser=$arrIni['user'];
$strPass=$arrIni['password'];
$strFileOutPath='/home/ueda/Desktop/';

if ($_FILES['file_select']['error']!=0) {
    echo "fileアップロード時にエラーが発生しました。uploadサイズは200mbまでです";
} //if

$strTmpFilePath = $_FILES['file_select']['tmp_name'];
$strTimestamp = str_replace(" ","",str_replace(".","",microtime())); //uuidのほうがいいが面倒なので
$strFileName = $strTimestamp . $_FILES['file_select']['name'];
//scp
$connection = ssh2_connect($strHost, $intPort);
ssh2_auth_password($connection, $strUser, $strPass);
ssh2_scp_send($connection, $strTmpFilePath, $strFileOutPath . $strFileName ,0755);

//cmd発行
$stream = ssh2_exec($connection, 'ls -ltr');

return false;

?>
