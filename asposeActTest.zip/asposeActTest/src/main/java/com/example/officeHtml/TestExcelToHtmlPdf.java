package com.example.officeHtml;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.Logger;

import com.aspose.cells.Cell;
import com.aspose.cells.Cells;
import com.aspose.cells.Column;
import com.aspose.cells.ColumnCollection;
import com.aspose.cells.PdfSaveOptions;
import com.aspose.cells.Row;
import com.aspose.cells.RowCollection;
import com.aspose.cells.Style;
import com.aspose.cells.StyleFlag;
import com.aspose.cells.TextAlignmentType;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;
import com.aspose.html.HTMLDocument;
import com.aspose.html.rendering.HtmlRenderer;
import com.aspose.html.rendering.pdf.PdfDevice;
import com.aspose.html.rendering.pdf.PdfRenderingOptions;
import com.aspose.pdf.Document;
import com.aspose.pdf.HtmlSaveOptions;
import com.aspose.pdf.LettersPositioningMethods;

/**
 * aspose変換excel→html→pdfの変換テスト
 *
 */
public class TestExcelToHtmlPdf {
	static Logger objLog = Logger.getLogger(TestExcelToHtmlPdf.class);

	public static void main(String[] args) {
		try {
			tester();
		} catch (Exception e) {
			e.printStackTrace();
		} //try
	} //main

	public static void tester() throws IOException {

		//※※※※※svgタグができてしまい、pdf化時に落ちてしまうため、excel→pdf→html→pdfの変換とする※※※※※

		String strDir = "C:/Users/Public/Documents/test/Excel/";
//		String strDir = "/home/ueda/デスクトップ/test/";

		String strDirRet = strDir + "result/";
		objLog.info("対象Directory：" + strDir);
		objLog.info("結果格納Directory：" + strDirRet);
		makeDirWithCheck(strDirRet);

		//Fileクラスのオブジェクトを生成する
		File dir = new File(strDir);

		//listFilesメソッドを使用して一覧を取得する
		File[] list = dir.listFiles();
		String dstHtmlFile = "";
		String dstPdfFile = "";
		String strFileName = "";

		String strRetFile = "excel_" + String.valueOf(System.currentTimeMillis()) + ".csv";
		StringBuilder objSb = new StringBuilder(); //結果格納用
		String strTmpRet = "";

		objLog.info("test start:" + String.valueOf(System.currentTimeMillis()));

		String strOs = System.getProperty("os.name").toLowerCase();
		String strDefFont = "";

		if (strOs.indexOf("windows") >= 0) {
			strDefFont = "MS Gothic";
		} else {
			strDefFont = "VL Gothic";
		} //if

		//headerを格納
		objSb.append("No,File名,HTML変換,SheetExcel名,SVG,PDF変換\r\n");
		int intCnt = 0;
		for (int i = 0; i < list.length; i++) {
			strFileName = list[i].getName();
			String strExtension = strFileName.substring(strFileName.lastIndexOf(".") + 1, strFileName.length());
			if (list[i].isFile() && list[i].getName().contains(".xls")) {
				intCnt++;
				strTmpRet = intCnt + "," + strFileName + ",";
				dstHtmlFile = strFileName.substring(0, strFileName.lastIndexOf(".")) + ".html";
				dstPdfFile = strFileName.substring(0, strFileName.lastIndexOf(".")) + ".pdf";

				//一度PDF変換をかませる
				String dstPdfTmp = strFileName.substring(0, strFileName.lastIndexOf(".")) + "_tmp.pdf";
				String dstXlsTmp = strFileName.substring(0, strFileName.lastIndexOf(".")) + "_tmp.xlsx";

				/* excel→PDF convert start */
				objLog.info("対象ファイル：" + strFileName);
				objLog.info("excel→PDF convert start");


				try {
					//tmpのexcelを作成
					Workbook workbook = new Workbook(strDir + strFileName);
					WorksheetCollection worksheetCollection = workbook.getWorksheets();
					for (int intSheetIdx = 0; intSheetIdx < worksheetCollection.getCount(); intSheetIdx++) { //SheetLoop
//					for (int intSheetIdx = 0; intSheetIdx < 1; intSheetIdx++) { //SheetLoop(1Sheetのみ対象)
						Worksheet workSheet = workbook.getWorksheets().get(intSheetIdx);
						Cells cells = workSheet.getCells();
						Style style = workbook.createStyle();

						//基本スタイル
						style.getFont().setName(strDefFont); //font
//						style.setTextWrapped(true); //折返し
						style.setHorizontalAlignment(TextAlignmentType.LEFT); //左揃え
//						style.setIndentLevel(1); //1インデント

						// StyleFlagを適応することでStyleを当てることが可能
						StyleFlag styleFlag = new StyleFlag();
						styleFlag.setAlignments(true);
						styleFlag.setFontName(true);
						styleFlag.setWrapText(true);
						styleFlag.setAlignments(true);
						styleFlag.setIndent(true);

						//cellsで全てに当てると折返し判定ができないのですべてのcellを回す
//						cells.applyStyle(style, styleFlag);
						RowCollection rowCollection = cells.getRows();
						ColumnCollection columnCollection = cells.getColumns();

						//列幅を追加するための連想配列を作っておく
						//key：Column Value：0、値なし 1、値あり
						HashMap<Integer, Integer> hashClmState = new HashMap<Integer, Integer>();
						for (int j = 0; j < cells.getMaxColumn() + 1; j++) {
							hashClmState.put(j, 0); //初期化
						} //for

						for (int j = 0; j < cells.getMaxRow() + 1; j++) {
							for (int k = 0; k < cells.getMaxColumn() + 1; k++) {
								Cell cell = cells.get(j, k);

								Object objCellVal = cell.getValue();
								if(objCellVal==null) { //nullの場合無視
									continue;
								} else {
									hashClmState.put(k, 1); //値フラグ
								} //

								Style cellStyle= cell.getStyle();
								if(cellStyle.isTextWrapped()) {
									style.setTextWrapped(true); //折返し
								}else {
									style.setTextWrapped(false); //折返し
								} //if
								if(cellStyle.getIndentLevel()==0) {
									style.setIndentLevel(1); //1インデント
								} else {
									style.setIndentLevel(cellStyle.getIndentLevel()+1); //1インデント
								} //
								cell.setStyle(style, styleFlag);
							} //for

						} //for

						//Autoで合わせた後行の高さを上げる
						for (int j = 0; j < cells.getMaxRow() + 1; j++) {
							Row row = rowCollection.get(j);
							row.setHeight(row.getHeight()+12.0);
						} //for

						double dblRowWidth = 9.0;
						for (int j = 0; j < cells.getMaxColumn() + 1; j++) {
							if(hashClmState.get(j)==1) { //値フラグがあるときだけ幅を広げる
								Column column = columnCollection.get(j);
								column.setWidth(column.getWidth()+dblRowWidth);
							} //if
						} //for


					} //for

					workbook.save(strDirRet + dstXlsTmp);
					if (workbook != null) workbook.dispose();
					//tmpのexcelからpdf作成
					PdfSaveOptions pdfSaveOptions = new PdfSaveOptions();
//					pdfSaveOptions.setGridlineType(GridlineType.HAIR);

					Workbook workbook2 = new Workbook(strDirRet + dstXlsTmp);
					//日付がズレ内容local修正
					workbook2.getSettings().setLocale(Locale.CHINA);

					workbook2.save(strDirRet + dstPdfTmp, pdfSaveOptions);
					if (workbook2 != null) workbook2.dispose();


				} catch (Exception e) {
					objLog.error("excel→PDF convertでエラー発生");
					strTmpRet += "×,-,-,\r\n";
					objSb.append(strTmpRet);
					continue;
				} //try

				/* PDF→html convert start */
				try {
					Document pdf = new Document(strDirRet + dstPdfTmp);

					HtmlSaveOptions newOptions = new HtmlSaveOptions();
					//SaveOption設定
					newOptions.LettersPositioningMethod = LettersPositioningMethods.UseEmUnitsAndCompensationOfRoundingErrorsInCss;
					newOptions.FontSavingMode = HtmlSaveOptions.FontSavingModes.AlwaysSaveAsEOT;
					//        			newOptions.FontSavingMode = HtmlSaveOptions.FontSavingModes.SaveInAllFormats;

					newOptions.setDefaultFontName(strDefFont);

					pdf.save(strDirRet + dstHtmlFile, newOptions);
					objLog.info("PDF→HTML convert OK");
				} catch (Exception e) {
					objLog.error("PDF→HTML convertでエラー発生");
					strTmpRet += "×,-,-,\r\n";
					objSb.append(strTmpRet);
					continue;
				} //try

				strTmpRet += "○,";

				objLog.info("PDF→HTML convert end");
				/* excel→HTML convert end */

				//style.cssを整形する
				objLog.info("style.css Shape Start");
				shapeStyleCss(strDirRet + strFileName.substring(0, strFileName.lastIndexOf(".")) + "_files/style.css");
				objLog.info("style.css Shape End");

				objLog.info("SVG CHECK start");
				String strHtml = "";
				strHtml = readAll(strDirRet + dstHtmlFile);
				strHtml = strHtml.replaceAll("\r\n", "");
				if (strHtml.contains("svg")) {
					strTmpRet += "有,";
					objLog.info("SVGタグあり");
				} else {
					strTmpRet += "無,";
					objLog.info("SVGタグ無し");
				} //if

				objLog.info("SVG CHECK end");

				/* HTML→PDF convert start */
				objLog.info("HTML→PDF convert start");

				InputStream fileStream = null;
				fileStream = new FileInputStream(strDirRet + dstHtmlFile);
				HTMLDocument htmlDocument = new HTMLDocument(fileStream, strDirRet + dstHtmlFile);

				HtmlRenderer renderer = new HtmlRenderer();
				FileOutputStream objOs = null;
				PdfDevice objPdfDevice = null;
				objOs = new FileOutputStream(strDirRet + dstPdfFile, true);
				//pdf用サイズ
				PdfRenderingOptions pdf_options = new PdfRenderingOptions();
				//                pdf_options.getPageSetup().setAnyPage(new Page(new Size(1280, 750),new Margin(0,10,0,0)));
				//
				//        		objPdfDevice = new PdfDevice(pdf_options,objOs);
				objPdfDevice = new PdfDevice(objOs);

				try {
//					renderer.render(objPdfDevice, htmlDocument);
					objLog.info("HTML→PDF  convert ok");
				} catch (Exception e) {
					objLog.error("HTML→PDF convertでエラー発生");
					strTmpRet += "×\r\n";
					objSb.append(strTmpRet);
					if (renderer != null)
						renderer.dispose();
					if (objPdfDevice != null)
						objPdfDevice.dispose();
					if (objOs != null)
						objOs.close();
					;
					if (fileStream != null)
						fileStream.close();
					continue;
				} finally {
					if (renderer != null)
						renderer.dispose();
					if (objPdfDevice != null)
						objPdfDevice.dispose();
					if (objOs != null)
						objOs.close();
					if (fileStream != null)
						fileStream.close();
				} //try
				strTmpRet += "○\r\n";
				objSb.append(strTmpRet);
				objLog.info("HTML→PDF convert end");
				/* HTML→PDF convert end */

			} //if

		} //for
		File newfile = new File(strDirRet + "/" + strRetFile);
		PrintWriter filewriter = new PrintWriter(
				new BufferedWriter(new OutputStreamWriter(new FileOutputStream(newfile), "Shift-JIS")));
		filewriter.write(objSb.toString());
		filewriter.close();
		objLog.info("test end:" + String.valueOf(System.currentTimeMillis()));

	} //tester

	/**
	 * style.cssを整形する
	 * @param strpath_i
	 * @return 読み込んだ文字列
	 * @throws IOException
	 */
	public static String shapeStyleCss(final String strCsspath_i) throws IOException {
		Path file = Paths.get(strCsspath_i);
		List<String> list = Files.readAllLines(file, Charset.forName("UTF-8"));
		StringBuilder objSb = new StringBuilder();
		for (int i = 0; i < list.size(); i++) {
			String strTmp = list.get(i);
			if (strTmp.matches("\tfont-size: .*")) {
				float intFontSize = Float.parseFloat(strTmp.replace("font-size:", "").replace("em;", "").trim());
				intFontSize -= 0.07;
//				intFontSize -= 0.05;
				strTmp = "	font-size: " + intFontSize + "em;";
//			} else if (strTmp.matches("\tfont-family: .*")) {
//				strTmp = "	font-family: \"VL Gothic\";";
//				strTmp = "	font-family: \"Mplus 1p\";";
			} //if
			objSb.append(strTmp + "\r\n");
		} //for
		File newfile = new File(strCsspath_i);
		PrintWriter filewriter = new PrintWriter(
				new BufferedWriter(new OutputStreamWriter(new FileOutputStream(newfile), "UTF-8")));
		filewriter.write(objSb.toString());

		if (filewriter != null)
			filewriter.close();

		return objSb.toString();

	} //readAll

	/**
	 * strpath_iで指定したファイルを改行なしですべて読み込む
	 * @param strpath_i
	 * @return 読み込んだ文字列
	 * @throws IOException
	 */
	public static String readAll(final String strpath_i) throws IOException {
		Path file = Paths.get(strpath_i);
		List<String> list = Files.readAllLines(file, Charset.forName("UTF-8"));
		StringBuilder objSb = new StringBuilder();
		for (int i = 0; i < list.size(); i++) {
			objSb.append(list.get(i));

		}
		return objSb.toString();

	} //readAll

	/**
	 * ディレクトリを作成する。
	 * @param strDirPath_i 作成ディレクトリパス
	 * @return 成否ステータス（0以外は失敗）
	 */
	public static int makeDirWithCheck(String strDirPath_i) {

		//strDirPath_iの長さが10未満なら処理しない(フェールセーフ)
		if (strDirPath_i.length() <= 10) {
			return -2;
		} //if

		objLog.info("対象フォルダ："+strDirPath_i);

		File objTgtDir = new File(strDirPath_i);
		if (!objTgtDir.exists()) {
			if (objTgtDir.mkdir()) {
				objLog.info("フォルダの作成に成功しました");
			} else {
				objLog.info("フォルダの作成に失敗しました");
				return -1;
			} //if
		} //if

		return 0;
	} //



}
