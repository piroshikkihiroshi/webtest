package com.example.officeHtml;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.log4j.Logger;

import com.aspose.html.HTMLDocument;
import com.aspose.html.rendering.HtmlRenderer;
import com.aspose.html.rendering.pdf.PdfDevice;

/**
 * aspose変換word→html→pdfの変換テスト
 *
 */
public class TestHtmlToPdf {
	static Logger objLog = Logger.getLogger(TestWordToHtmlPdf.class);

	public static void main(String[] args) {
		try {
			tester();
		} catch (Exception e) {
			e.printStackTrace();
		} //try
	} //main

	public static void tester() throws IOException {

		String strDir = "C:/Users/Public/Documents/test/01_html/";
		objLog.info("対象Directory：" + strDir);

		String dstHtmlFile = "";
		String dstPdfFile = "";
		String strFileName = "";

		objLog.info("test start:" + String.valueOf(System.currentTimeMillis()));

		dstHtmlFile = "図入り文書.html";
		dstPdfFile = "図入り文書.pdf";

		/* HTML→PDF convert start */
		objLog.info("HTML→PDF convert start");

		InputStream fileStream = null;
		fileStream = new FileInputStream(strDir + dstHtmlFile);
		HTMLDocument htmlDocument = new HTMLDocument(fileStream, strDir + dstHtmlFile);

		HtmlRenderer renderer = new HtmlRenderer();
		FileOutputStream objOs = null;
		PdfDevice objPdfDevice = null;
		objOs = new FileOutputStream(strDir + dstPdfFile, true);
		objPdfDevice = new PdfDevice(objOs);

		try {
			renderer.render(objPdfDevice, htmlDocument);
			objLog.info("HTML→PDF OK");
		} catch (Exception e) {
			objLog.error("HTML→PDF convertでエラー発生");
			objLog.error(e);

			if (renderer != null)
				renderer.dispose();
			if (objPdfDevice != null)
				objPdfDevice.dispose();
			if (objOs != null)
				objOs.close();
			;
			if (fileStream != null)
				fileStream.close();

		} finally {
			if (renderer != null)
				renderer.dispose();
			if (objPdfDevice != null)
				objPdfDevice.dispose();
			if (objOs != null)
				objOs.close();
			if (fileStream != null)
				fileStream.close();
		} //try

		objLog.info("HTML→PDF convert end");
		/* HTML→PDF convert end */

		objLog.info("test end:" + String.valueOf(System.currentTimeMillis()));

	} //tester


}