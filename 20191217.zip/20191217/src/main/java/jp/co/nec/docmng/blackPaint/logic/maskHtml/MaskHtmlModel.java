package jp.co.nec.docmng.blackPaint.logic.maskHtml;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.blackPaint.logic.dirFile.DirCnt;
import jp.co.nec.docmng.blackPaint.logic.dirFile.FileCnt;

public class MaskHtmlModel {
	static String MASK_MSG = "■";
	static int STATE_MASK = 1;
	static int STATE_RED = 2;
	static int ID_COUNT=1000000;
	static String POS_INIT = "INIT";
	static String POS_NORMAL = "NORMAL";
	static String POS_END = "END";


	//黒塗りにもspanがあったほうが制御しやすいため追加
	//idを付与する仕様へ変更
//	static String MASK_BF = "<span class='tagMsk'>";
	static String MASK_BF = "<span class='tagMsk' id='msk";
	static String MASK_BF_INIT= "<span class='tagMsk tagMskInit' id='msk";
	static String MASK_BF_END= "<span class='tagMsk tagMskEnd' id='msk";
	static String MASK_AF = "</span>";

//	static String RED_BF = "<span class='tagRed'>";
	static String RED_BF = "<span class='tagRed' id='red";
	static String RED_BF_INIT= "<span class='tagRed tagRedInit' id='red";
	static String RED_BF_END= "<span class='tagRed tagRedEnd' id='red";
	static String RED_AF = "</span>";

	static Logger objLog = LoggerFactory.getLogger(MaskHtmlModel.class);

	/**
	 * 全文検索エンジンに返した結果を置換してbodyを入れ替え、または赤文字変換した文字列を取得
	 * @param hashRepPos_i AIから帰ってきた黒塗り対象情報をハッシュで格納したもの key：マスク箇所 value連続したポジションのステータス:ポリシーID
	 * @param hashBodyStructure_i HTMLのchar毎の情報を格納するクラスを格納したhash key：HTMLのindex : val HTMLのchar(index)毎の情報を格納するクラス
	 * @param intStatus_i 置換ステータス :マスク 2:赤文字
	 * @return String配列 0　置換したBody文字列 1　黒塗り先頭ID:黒塗り終了ID:policyID構成 複数ある場合は+でセパレート
	 */
	public String[] bodyReplace(
			HashMap<Integer, String> hashRepPos_i,
			HashMap<Integer, HtmlStructure> hashBodyStructure_i,
			int intStatus_i) {
		String[] arrRet=new String[2];
		String strIdMaker="";
		String strActPolicys = "";
		StringBuilder strRepBody = new StringBuilder();
		int intStatus = 0;
		int intNotTagPos = 0;
		int intIdCnt = ID_COUNT;
		for (int i = 1; i < hashBodyStructure_i.size() + 1; i++) {
			HtmlStructure objHtmlStructure = hashBodyStructure_i.get(i);
			intStatus=objHtmlStructure.intStatus;
			intNotTagPos=objHtmlStructure.intNotTagPos;
			if (intStatus==1) { //通常文字の場合
				if (hashRepPos_i.containsKey(intNotTagPos)) { //置換対象
					if (intStatus_i == 1) {
						strActPolicys=hashRepPos_i.get(intNotTagPos);
						String[] arrActPolicys = strActPolicys.split(":");
						if (arrActPolicys[0].equals(POS_INIT)) {
							strRepBody.append(MASK_BF_INIT+intIdCnt + "' >" +MASK_MSG+MASK_AF); //マスク
							strIdMaker +="msk" + intIdCnt+":";
						}else if (arrActPolicys[0].equals(POS_NORMAL)) {
							strRepBody.append(MASK_BF+intIdCnt + "' >" +MASK_MSG+MASK_AF); //マスク
						} else {
							strRepBody.append(MASK_BF_END+intIdCnt + "' >" +MASK_MSG+MASK_AF); //マスク
							strIdMaker +=(":msk" + intIdCnt)+":"+arrActPolicys[1] + "+";
						} //if

						intIdCnt++;
					}else {
						strActPolicys=hashRepPos_i.get(intNotTagPos);
						String[] arrActPolicys = strActPolicys.split(":");
						if (arrActPolicys[0].equals(POS_INIT)) {
							strRepBody.append(RED_BF_INIT +intIdCnt + "' >" + objHtmlStructure.strTgt + RED_AF); //赤塗り
							strIdMaker +="red" + intIdCnt+":";
						}else if (arrActPolicys[0].equals(POS_NORMAL)) {
							strRepBody.append(RED_BF +intIdCnt + "' >" + objHtmlStructure.strTgt + RED_AF); //赤塗り
						}else {
							strRepBody.append(RED_BF_END +intIdCnt + "' >" + objHtmlStructure.strTgt + RED_AF); //赤塗り
							strIdMaker +=("red" + intIdCnt)+":"+arrActPolicys[1] + "+";
						} //if
						intIdCnt++;
					} //if

				}else {
					strRepBody.append(objHtmlStructure.strTgt);
				} //if
			}else { //その他の場合そのまま出力する
				strRepBody.append(objHtmlStructure.strTgt);
			} //if
		} //for

		if(!strIdMaker.equals("")) {
			strIdMaker = strIdMaker.substring(0,strIdMaker.length()-1);
		} //if
		arrRet[0]=strRepBody.toString();
		arrRet[1]=strIdMaker;
		return arrRet;
	} //bodyReplace



	/**
	 * bodyの構造体hashを取得
	 * @param strOrgBody_i
	 * @return HtmlStructureのハッシュ
	 */
	public HashMap<Integer, HtmlStructure> getBodyStructure(
			String strOrgBody_i) {
		String strTgtVal = strOrgBody_i;

		HashMap<Integer, HtmlStructure> hashRetStructure = new HashMap<Integer, HtmlStructure>();
		List <Integer> listLastNotTagPos = new ArrayList<Integer>(); //intNotTagPosを格納していく
		String strRegrep = "(<\\/?[^>]+>)|([^<]+)"; //タグとタグを除いた値をグループで取得する
		Pattern objPattern = Pattern.compile(strRegrep);
		Matcher objMatch = objPattern.matcher(strTgtVal);

		String strRegrep2 = "\r|\n|\t";; //改行、タブ判定
		Pattern objPattern2 = Pattern.compile(strRegrep2);
//		Matcher objMatch2 = objPattern.matcher(strTgtVal);
		Matcher objMatch2 = null;
		boolean blCrLf = false;

		String strCurrentKwd = ""; //現在ヒットしている単語
		int intCurrentPos = 0;
		while(objMatch.find()){
			strCurrentKwd = objMatch.group(2);

			if (strCurrentKwd != null) {
				objMatch2 = objPattern2.matcher(strCurrentKwd);
				if (objMatch2.find()) {
					blCrLf=true;
				} //if
			} //if


			if (strCurrentKwd == null) { //タグの処理
				strCurrentKwd = objMatch.group(1);
				searchAnalysis(hashRetStructure,listLastNotTagPos,strCurrentKwd,intCurrentPos,2);
			}else if (strCurrentKwd.equals(" ")) { //半角スペース処理
				searchAnalysis(hashRetStructure,listLastNotTagPos,strCurrentKwd,intCurrentPos,0);
				continue; //半角スペースはスキップ
			}else if(blCrLf) { //改行 タブ処理
				String[] arrTmp = strCurrentKwd.split(""); //strCurrentKwdをさらに分割して通常文字と改行、タブを見分ける
				for (int i = 0; i < arrTmp.length; i++) {
					String strTgt = arrTmp[i];
					objMatch2 = objPattern2.matcher(strTgt);
					if (objMatch2.find()) { //改行 タブ処理判定
						searchAnalysis(hashRetStructure,listLastNotTagPos,strTgt,intCurrentPos,3);
					} else { //通常文字判定
						searchAnalysis(hashRetStructure,listLastNotTagPos,strTgt,intCurrentPos,1);
					} //
				} //if
				continue;
			} else { //通常文字
				searchAnalysis(hashRetStructure,listLastNotTagPos,strCurrentKwd,intCurrentPos,1);
			} //if
			blCrLf=false;
			intCurrentPos = hashRetStructure.size();
		}  //while

		return hashRetStructure;
	} //getBodyStructure


	/**
	* 検索結果からbodyの構造体hashを作成する
	* @param HashMap<Integer, HtmlStructure> hashRetStructure_i 参照渡しのハッシュ
	* HtmlStructureはHTMLのchar毎の情報を格納するクラス
	* HashMap<Integer, HtmlStructure> の形で格納し、keyは置換対象外文字やtagを含んだポジション(<div>タグ等を含む)を格納する
	* @param strCurrentKwd_i 現在正規表現でヒットしている文字列
	* @param intCurrentPos_i タグを含めた現在のposition
	* @param intStatus_i 0：置換対象外(半角文字等) 1：対象 2：tag
	*/
	public void searchAnalysis(
			HashMap<Integer, HtmlStructure> hashRetStructure_i,
			List <Integer> listLastNotTagPos_i ,
			String strCurrentKwd_i,
			int intCurrentPos_i,
			int intStatus_i) {
		int intCntPos = hashRetStructure_i.size();
		int intNotTagPos = 0;
		HtmlStructure objHtmlStructure =null;
		String[] arrTmp = strCurrentKwd_i.split("");
		String strTgt="";

		if(listLastNotTagPos_i.size() !=0) { //tag抜き文字の最終を取得する
			intNotTagPos = listLastNotTagPos_i.get(listLastNotTagPos_i.size() - 1);
		} //if

		for (int i = 0; i < arrTmp.length; i++) {
			objHtmlStructure = new HtmlStructure();
			strTgt = arrTmp[i];
			objHtmlStructure.strTgt=strTgt;
			objHtmlStructure.intStatus=intStatus_i;
//			if(intStatus_i==1) { //通常文字はintNotTagPosをカウント
			if(intStatus_i==1||intStatus_i==3) { //通常文字はintNotTagPosをカウント
				intNotTagPos++;
				objHtmlStructure.intNotTagPos = intNotTagPos;
			} //if
			hashRetStructure_i.put(intCntPos + (i + 1),objHtmlStructure);
		} //for

		if(intStatus_i==1||intStatus_i==3) { //通常時はtag抜き文字の最終を格納
			listLastNotTagPos_i.add(intNotTagPos);
		} //if

	} //searchAnalysis



	/**
	 * タグを削除する
	 * @param strText_i タグを削除したい文字列
	 * @return タグ無し連結文字列
	 */
	public String getNoTabText(String strText_i) {
		String strRet = strText_i;
		//tagを全て除去
		String strPattern = "<(\"[^\"]*\"|'[^']*'|[^'\">])*>";
		strRet = strRet.replaceAll(strPattern, "");

		return strRet;
	} //getNoTabText



	/**
	 * htmlのbodyの中身を入れ替え、置換HTMLを作成する
	 * @param strAllHtml_i
	 * @param strRepBody_i
	 * @return 置換処理を行ったHTMLString
	 */
	public String makeBody(String strAllHtml_i, String strRepBody_i) {
		String strRet = strAllHtml_i;
		//改行を削除
		strRet = strRet.replaceAll("\r\n", " ");
		//tag以外で必要以外の半角スペース削除
		strRet.replaceAll("\\s+\\s", " ");

		String strPattern = "\\<body\\>.+\\</body\\>";

		//Bodyを入れ替え
		strRet = strRet.replaceFirst(strPattern, strRepBody_i);
		return strRet;
	} //getBody

	/**
	 * スタイルシートのパスを埋め込む
	 * @param strAllHtml_i
	 * @param strRepBody_i
	 * @return 置換処理を行ったHTMLString
	 */
	public String insertStyle(String strAllHtml_i, String strStyleSheet_i) {
		String strRet = strAllHtml_i;
		String strTgt = strStyleSheet_i;
		//debug jqueyも入れる
//		strTgt += " <script src='//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js'></script> ";
//		String strPattern = "</head>";
		String strPattern = "<body>";

		//Bodyを入れ替え
//		strRet = strRet.replaceFirst(strPattern, " " + strTgt+ " " + strPattern);
		strRet = strRet.replaceFirst(strPattern, " " + strPattern + " " + strTgt );

		//debug bodyのズームも理れる
		strTgt += " <body style='zoom: 0.7;'>";
		strPattern = "<body>";
		strRet = strRet.replaceFirst(strPattern,strTgt);
		return strRet;
	} //getBody

	/**
	 * スタイルシートのパスを埋め込む(txt用)
	 * @param strAllHtml_i
	 * @param strRepBody_i
	 * @return 置換処理を行ったHTMLString
	 */
	public String insertStyleTxt(String strAllHtml_i, String strStyleSheet_i) {
		String strRet = strAllHtml_i;
		String strTgt = strStyleSheet_i;
		String strPattern = "<body>";

		//Bodyを入れ替え
		strRet = strRet.replaceFirst(strPattern, " " + strPattern + " " + strTgt );

//		//幅を合わせる
		strTgt += " <body style='margin:0px'>";
		strPattern = "<body>";
		strRet = strRet.replaceFirst(strPattern,strTgt);
//		strTgt += " <body class='awdiv awpage' style='word-break: break-all;width:97%;padding:5px;font-family: Courier, Monaco, monospace;font-size: 14px; line-height: 1.2; '>";
//		strPattern = "<body>";
//		strRet = strRet.replaceFirst(strPattern,strTgt);

		return strRet;
	} //getBody



	/**
	 * strpath_iで指定したファイルを改行付きですべて読み込む
	 * @param strpath_i
	 * @return 読み込んだ文字列
	 * @throws IOException
	 */
	public String readAll(final String strpath_i) throws IOException {
		return Files.lines(Paths.get(strpath_i), Charset.forName("UTF-8"))
				.collect(Collectors.joining(System.getProperty("line.separator")));

	} //readAll

	/**
	 * strHtml_i(htmlString)のBodyを正規表現で抜き出す(改行 必要以外の半角スペース削除)
	 * @param strHtml_i
	 * @return 抜き出したBody
	 */
	public String getBodyCompress(String strHtml_i) {
		String strRet = strHtml_i;

		//改行を削除
		strRet = strRet.replaceAll("\r\n", "");

		//2つ以上の半角スペースを一つにまとめる
		strRet = strRet.replaceAll("\\s+", " ");

		String strPattern = "\\<body\\>.+\\</body\\>";
		Pattern objPattern = Pattern.compile(strPattern);
		Matcher objMatch = objPattern.matcher(strRet);
		boolean blRet = objMatch.find();
		strRet = objMatch.group();

		return strRet;
	} //getBody

	/**
	 * 全文検索エンジンに渡す用の文字列を取得する
	 * @param strBody_i HTML文字列からBody要素だけを抜き出したもの
	 * @return タグ無し連結文字列
	 */
	public String getIllegalText(String strBody_i) {
		String strRet = strBody_i;
		//tagを全て除去
		String strPattern = "<(\"[^\"]*\"|'[^']*'|[^'\">])*>";
		strRet = strRet.replaceAll(strPattern, "");
		//trim
		strRet = strRet.trim();

		//半角スペース記号置換
		//		strPattern="&#xa0;";
		//		strRet = strRet.replace(strPattern, " ");

		return strRet;
	} //getIllegalText



	/**
	 * 全文検索から戻ってきた値をkeyで当てはまったハッシュをすべて変換するよう成型する
	 * ※来るデータはカンマ区切りで「startポジション,startポジションから〇〇文字」を想定
	 * @param strTextSrh_i 全文検索から帰ってきた文字列
	 * @return 成型したハッシュ key：マスク箇所 value連続したポジションのステータス:ポリシーID
	 * 　　　　　　　　　　　　　　　　　　　　　　　 ※連続したポジションのステータス→INIT NORMAL END
	 */
	public HashMap<Integer, String> makePosHash(String strTextSrh_i) {
		HashMap<Integer, String> hashRet = new HashMap<Integer, String>();

		//ペアは意識しないので+は:に置換
		strTextSrh_i = strTextSrh_i.replaceAll("\\+", ":");
		String[] arrTgt = strTextSrh_i.split(":");
//		String[] arrTgt = strTextSrh_i.split(",");

		for (int i = 0; i < arrTgt.length; i++) {
			Integer intTmp = Integer.parseInt(arrTgt[i]);
//			if (i % 2 == 0) { //偶数ならkeyを作成
			if (i % 3 == 0) { //ポリシー対応で3の倍数ならキーとする
				if (intTmp <= 0) { //※1文字目からカウントするので
					String strErrMtg = "文字は1文字目からカウントします。置換対象文字位置「" + intTmp + "」";
					throw new IllegalArgumentException(strErrMtg);
				} //if
//				Integer intEnd = Integer.parseInt(arrTgt[i + 1]) + (intTmp - 1);
				Integer intEnd = intTmp + (Integer.parseInt(arrTgt[i + 1]) - 1) - (intTmp - 1);
				Integer intPolicy = Integer.parseInt(arrTgt[i + 2]); //policy
				String strPosState = POS_INIT;
				for (int j = intTmp; j <= intEnd; j++) {
//					hashRet.put(j, 0);
					if (j==intTmp) { //policy対応
						strPosState=POS_INIT;
					}else if(j==intEnd) {
						strPosState=POS_END;
					}else {
						strPosState=POS_NORMAL;
					} //if
					hashRet.put(j, strPosState+":"+intPolicy);
				} //for

			} //if

		} //for

		return hashRet;

	} //makePosHash



	/**
	 * 黒塗りリストの保存用データを作成する
	 *******resources配下はcontrollerでないとアクセスできないので事前に行っておく
	 * @param strJson 黒塗りリストに必要なデータ
	 * @param strName 名前はクッキーなので引数
	 * @param strFileOutDir 出力フォルダ
	 * @return
	 */
	public String makeBrackPaint(String strJson,
			String strName,
			String strFileOutDir,
			String strRealPath,
			String strFileWithoutExtension,
			String strFilePath,
			String strFileName_i) {

		//モデル初期化
		FileCnt objFileCnt = new FileCnt();
		DirCnt objDirCls = new DirCnt();

		FileWriter objFile=null;
		PrintWriter objPw=null;

		//メンバ変数初期化
		String strTmpDir = ""; //黒塗り編集画面で処理したHTMLが格納されたTMPディレクトリ名。
		String strRedHtml = ""; //黒塗り編集候補HTMLのouterHTML。
		String strMaskHtml = ""; //黒塗り編集HTMLのouterHTML。
		String strFileName = ""; //オリジナルwordファイル名。
		int intDocumentId = -1; //documentId
		String strListJson = ""; //黒塗りリストの情報のjson

		String strBasePath = ""; //黒塗り作成時の作業フォルダ
		String strHead = ""; //ファイル名、フォルダ名のヘッダー
		String strHtmlDir = ""; //黒塗り作成時HTMLに対するimg,css等が入っているフォルダ
		String strTmpTimeStamp = ""; //tempファイルタイムスタンプ

		String updateTime =""; //更新日時
		String retentionPeriod=""; //保存期間
		String[] arrPrint = null; //印刷範囲のインデックス true：印刷 false 印刷無し
		String[] arrMaskPaths = null; //黒塗りpdfパス
		String[] arrRedPaths = null; //黒塗り候補pdfパス

		//以下黒塗りリスト配列
		String[] keywords=null;
		String[] pages=null;
		String[] policyNames=null;
		String[] Reasons=null;
		String[] Remarks=null;

		//以下黒塗りリスト配列
		String[] glArrBfIds = null;
		String[] glArrAfIds = null;
		String[] glArrPolicys = null;

		byte[] byteZip = null; //zipにした際のbyte配列
		File objZipFile = null;



		//POSTされたjsonをパースする
		ObjectMapper objMapper = new ObjectMapper();
		List<Map<String, String[]>> objTmpList = null;
		TypeReference<List<Map<String, String[]>>> objType = new TypeReference<List<Map<String, String[]>>>() {
		};
		try {
			objTmpList = objMapper.readValue(strJson, objType);
		} catch (JsonParseException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} catch (JsonMappingException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} catch (IOException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} //try

		HashMap<String, String[]> objMap = (HashMap<String, String[]>) objTmpList.get(0);

		Object objTmp = null;
		for (String strKey : objMap.keySet()) {
			switch (strKey) {
			case "tmpDir":
				strTmpDir = objMap.get(strKey)[0];
				break;
			case "strFileName":
				strFileName = objMap.get(strKey)[0];
				break;
			case "updateTime":
				updateTime = objMap.get(strKey)[0];
				break;
			case "retentionPeriod":
				retentionPeriod = objMap.get(strKey)[0];
				break;
			case "documentId":
				intDocumentId = Integer.parseInt(objMap.get(strKey)[0]);
				break;
			case "arrPrint":
				arrPrint = (String[]) objMap.get(strKey);
				break;
			case "arrMaskPaths":
				arrMaskPaths = (String[]) objMap.get(strKey);
				break;
			case "arrRedPaths":
				arrRedPaths = (String[]) objMap.get(strKey);
				break;
				//*******以下黒塗りリスト用
			case "keywords":
				keywords = (String[]) objMap.get(strKey);
				break;
			case "pages":
				pages = (String[]) objMap.get(strKey);
				break;
			case "policyNames":
				policyNames = (String[]) objMap.get(strKey);
				break;
			case "Reasons":
				Reasons = (String[]) objMap.get(strKey);
				break;
			case "Remarks":
				Remarks = (String[]) objMap.get(strKey);
				break;
			case "glArrBfIds":
				glArrBfIds = (String[]) objMap.get(strKey);
				break;
			case "glArrAfIds":
				glArrAfIds = (String[]) objMap.get(strKey);
				break;
			case "glArrPolicys":
				glArrPolicys = (String[]) objMap.get(strKey);
				break;
			default:
				break;
			}//switch

		} //for

		//拡張子無しファイル名取得
		String strOutPath="";


		try {
			//出力ディレクトリ
			String strOutDir=strFileOutDir;
			strBasePath = strFileOutDir.substring(0,strFileOutDir.substring(0,strFileOutDir.length() - 1).lastIndexOf("/"));
			objDirCls.makeDirWithCheck(strOutDir);

			//テンプレートを読み込んでjsopで変換していく
			String strListPath = strBasePath + "/resources/templates/blackPaint/MaskListPrevTemplate.html";

			String strOrgHtml = objFileCnt.readAll(strListPath);
			String strRepHtml = strOrgHtml;

			Document objDoc=null;
			String strMakeList = "";
			objDoc = Jsoup.parse(strRepHtml);
			Element elmTgt = null;
			//ユーザー名変更
			if (strName==null) strName = "";
			objLog.info("ユーザー名："+strName);
			objDoc.getElementById("USER_NAME_SPAN").html(strName);

			//アイコン変更
			String strEx = strFilePath.substring(strFilePath.lastIndexOf(".") + 1);
			objLog.info("拡張子："+strEx);
			String strImgPath = "";

			if(strEx.indexOf("txt")>=0) {
				strImgPath=Paths.get(strBasePath + "/resources/static/css/images/l_file_node.gif").toUri().toString();
			}else {
				strImgPath=Paths.get(strBasePath + "/resources/static/css/images/l_file_word.gif").toUri().toString();
			} //if
			objDoc.getElementsByClass("icon_l").get(0).attr("src",strImgPath);
			objLog.info("imgpath："+strImgPath);
			//フルパス埋め込み
			String strFolPath = strFilePath.substring( 0, strFilePath.length() - strFileName_i.length() -1);
			objDoc.getElementById("SHONIN_STATUS").html(strFolPath);
			objLog.info("filePath："+strFilePath);

			//フルパス埋め込み
			strFileName = strFileName_i.substring(0, strFileName_i.lastIndexOf("."));
			objDoc.getElementById("FILE_NAME").html(strFileName);
			objLog.info("fileName："+strFileName);

			//リストを埋め込む

			elmTgt = objDoc.getElementById("rettable");

			//arrPrintがnullなら全出力 配列があったらtrueのリストだけ出力
			if (arrPrint == null || !(Arrays.asList(arrPrint).contains("false")) ) {
				objLog.info("全ページ出力");

				for (int i = 0; i < glArrBfIds.length; i++) {
					strMakeList += "<ul class=\"tr l\">";
					strMakeList += "<li class=\"w40 row" + i + " clsdisable def\">" + (i + 1) + "</li>";
					strMakeList += "<li class=\"w150 row" + i + " clsdisable def\">" + keywords[i] + "</li>";
					strMakeList += "<li class=\"w80 row" + i + " clsdisable def\">" + pages[i] + "ページ目 </li>";
					strMakeList += "<li class=\"w150 row" + i + " clsdisable def\">" + policyNames[i] + "</li>";
					strMakeList += "<li class=\"w120 row" + i + " clsdisable def\">" + Reasons[i] + "</li>";
					strMakeList += "<li class=\"row" + i + "\">";
					if(Remarks.length!=0) {
						strMakeList +=Remarks[i] + "</li>";
					}else {
						strMakeList +="</li>";
					} //if

					strMakeList += "</ul>";
				} //for
				elmTgt.html(strMakeList);
			} else {
				objLog.info("指定ページのみ出力");
				for (int i = 0; i < glArrBfIds.length; i++) {
					for (int j = 0; j < arrPrint.length; j++) {
						if (arrPrint[j] == "true" && Integer.parseInt(pages[i]) ==  j) {
							strMakeList += "<ul class=\"tr l\">";
							strMakeList += "<li class=\"w40 row" + i + " clsdisable def\">" + (i + 1) + "</li>";
							strMakeList += "<li class=\"w150 row" + i + " clsdisable def\">" + keywords[i] + "</li>";
							strMakeList += "<li class=\"w80 row" + i + " clsdisable def\">" + pages[i]
									+ "ページ目 </li>";
							strMakeList += "<li class=\"w150 row" + i + " clsdisable def\">" + policyNames[i] + "</li>";
							strMakeList += "<li class=\"w120 row" + i + " clsdisable def\">" + Reasons[i] + "</li>";
							strMakeList += "<li class=\"row" + i + "\">";
							if (Remarks.length != 0) {
								strMakeList +=  Remarks[i] + "</li>";
							} else {
								strMakeList += "</li>";
							} // if

							strMakeList += "</ul>";
							objLog.info("黒塗りリスト"+pages[i]+"出力");
						} //if

					} //for
				} // for
				elmTgt.html(strMakeList);
			} //if

			//file出力
			strOutPath = strOutDir + "MaskListPrev.html";
			objLog.info("黒塗りリストhtmlpath:"+strOutPath);

			objPw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(
			        new FileOutputStream(strOutPath, true),"utf-8")));
			objPw.println(objDoc.outerHtml());
			objPw.close();
			objDoc=null;


		} catch (Exception e1) {
			objLog.error("err message", e1);
			e1.printStackTrace();
		} //try


		//ファイルパスを返す
		return strOutPath;


	} //method


	/**
	 * bodyにページネーション用tagをつける
	 * @param hashBodyStructure_i HTMLのchar毎の情報を格納するクラスを格納したhash key：HTMLのindex : val HTMLのchar(index)毎の情報を格納するクラス
	 * @param int intPageLen_i   page区切りの文字数
	 * @return String 置換したBody文字列
	 */
	public String bodyMakePaginate(
			HashMap<Integer, HtmlStructure> hashBodyStructure_i,
			int intPageLen_i) {
		StringBuilder strRepBody = new StringBuilder();
		int intNotTagPos = 0;
		int intActPage = 1;
		int intStBody = 6;
		int intOffcetBase=30; //改行時オフセットの文字数
//		int intOffcetBase=75; //改行時オフセットの文字数
//		int intOffcetBase=130; //改行時オフセットの文字数
		int intActOffcet = 0;
		String strRegrep = "\r\n|\n";
		Pattern objPattern = Pattern.compile(strRegrep);
		String strTgt = "";

		boolean blInit = true;
		boolean blPageState = false; //ページtagの出力判定 //true tagを追加 false 通常

//		String strPageTag = "<div class='awdiv awpage' style='word-break: break-all;padding:5px;font-family: Courier, Monaco, monospace;font-size: 14px; line-height: 1.2; width:97%; height:581pt;white-space:pre-wrap;'>";
//		String strPageTag = "<div class='awdiv awpage' style='word-break: break-all;padding:5px;font-family: Courier, Monaco, monospace;font-size: 14px; line-height: 1.2; width:97%; height:581pt;'>"
//		String strPageTag = "<div class='awdiv awpage' style='word-break: break-all;padding:5px;font-family: Courier, Monaco, monospace;font-size: 14px; line-height: 1.2; width: 580pt; height:581pt;'>";
//		String strPageTag = "<div class='awdiv awpage' style='word-break: break-all;padding:5px;font-family: Courier, Monaco, monospace;font-size: 14px; line-height: 1.2; width:98%; height:581pt;'>";
//		String strPageTag = "<div class='awdiv awpage' style='word-break: break-all;padding:5px;font-size: 14px; line-height: 1.2; text-align: justify;\"; width:98%; height:581pt;'>";
//		String strPageTag = "<div class='awdiv awpage' style='word-break: break-all;padding:5px;font-size: 14px; line-height: 1.2; width:98%; text-align: justify; height:581pt;font-family: \"MS Gothic\";'>";
		String strPageTag = "<div class='awdiv awpage' style='word-break: break-all;padding:5px;font-size: 14px; line-height: 1.2; width:98%; text-align: justify; height:581pt;font-family: \"Yu Mincho\";'>";
		for (int i = 1; i < hashBodyStructure_i.size() + 1; i++) {
			HtmlStructure objHtmlStructure = hashBodyStructure_i.get(i);
			intNotTagPos=objHtmlStructure.intNotTagPos;
			strTgt = objHtmlStructure.strTgt;
			Matcher objMatch = objPattern.matcher(strTgt);
			if(objMatch.find()) { //cr or lf ならオフセット
				intActOffcet+=intOffcetBase;
			} //if

			if(intStBody<=0&& blInit) { //最初の<body>を飛ばす
				strRepBody.append(strPageTag); //最初にページtag追加
//				strRepBody.append(objHtmlStructure.strTgt);
				blInit=false;

			//※※※ページtagの出力条件※※※
			//初期処理まえではない「intStBody<=0」 &
			//現在のinnerTextと改行オフセットが現在のページを超えている「(intNotTagPos+intActOffcet)>=(intPageLen_i*(intActPage))」 &
				//通常ステータス「!blPageState)」
			} else if(intStBody<=0&&(intNotTagPos+intActOffcet)>=(intPageLen_i*(intActPage))&&(!blPageState)) {
				blPageState=true;
				intActOffcet=0;
			} //if

			if(blPageState) { //閉じtagと新規ページ
				strRepBody.append(objHtmlStructure.strTgt + "</div> "+strPageTag); //閉じtagと新規ページ
				intActPage++;

				blPageState=false;
			}else { //その他は通常出力
				strRepBody.append(objHtmlStructure.strTgt);
			} //if

			intStBody--;

		} //for

		String strRet = strRepBody.toString();
		//</body>の前に閉じtagを入れる
		strRet = strRet.substring(0,strRet.length()-7) + "</div></body>";

		//改行コードを</br>に変更する
		strRet = strRet.replaceAll(strRegrep, "<br />");

		return strRet;
	} //method


//	/**
//	 * bodyにページネーション用tagをつける
//	 * @param hashBodyStructure_i HTMLのchar毎の情報を格納するクラスを格納したhash key：HTMLのindex : val HTMLのchar(index)毎の情報を格納するクラス
//	 * @param int intPageLen_i   page区切りの文字数
//	 * @return String 置換したBody文字列
//	 */
//	public String bodyMakePaginate(
//			HashMap<Integer, HtmlStructure> hashBodyStructure_i,
//			int intPageLen_i) {
//		StringBuilder strRepBody = new StringBuilder();
//		int intNotTagPos = 0;
//		int intActPage = 1;
//		int intStBody = 6;
//		int intOffcetBase=75; //改行時オフセットの文字数
//		int intActOffcet = 0;
//		String strRegrep = "\r\n";
//		Pattern objPattern = Pattern.compile(strRegrep);
//
//		boolean blInit = true;
//
////		String strPageTag = "<div class='awdiv awpage' style='word-break: break-all;padding:5px;font-family: Courier, Monaco, monospace;font-size: 14px; line-height: 1.2; width:97%; height:581pt;white-space:pre-wrap;'>";
////		String strPageTag = "<div class='awdiv awpage' style='word-break: break-all;padding:5px;font-family: Courier, Monaco, monospace;font-size: 14px; line-height: 1.2; width:97%; height:581pt;'>"
////		String strPageTag = "<div class='awdiv awpage' style='word-break: break-all;padding:5px;font-family: Courier, Monaco, monospace;font-size: 14px; line-height: 1.2; width: 580pt; height:581pt;'>";
//		String strPageTag = "<div class='awdiv awpage' style='word-break: break-all;padding:5px;font-family: Courier, Monaco, monospace;font-size: 14px; line-height: 1.2; width:98%; height:581pt;'>";
//		for (int i = 1; i < hashBodyStructure_i.size() + 1; i++) {
//			HtmlStructure objHtmlStructure = hashBodyStructure_i.get(i);
//			intNotTagPos=objHtmlStructure.intNotTagPos;
//
//			if(intStBody<=0&& blInit) { //最初の<body>を飛ばす
//				strRepBody.append(strPageTag); //最初にページtag追加
//				strRepBody.append(objHtmlStructure.strTgt);
//				blInit=false;
//			} else if(intStBody<=0&&intNotTagPos==(intPageLen_i*intActPage)) {
//				strRepBody.append(objHtmlStructure.strTgt + "</div> "+strPageTag); //閉じtagと新規ページ
//				intActPage++;
//
//			}else { //その他は通常出力
//				strRepBody.append(objHtmlStructure.strTgt);
//			} //if
//
//			intStBody--;
//
//		} //for
//
//		String strRet = strRepBody.toString();
//		//</body>の前に閉じtagを入れる
//		strRet = strRet.substring(0,strRet.length()-7) + "</div></body>";
//
//		//改行コードを</br>に変更する
//		String strPattern = "\r\n";
//		strRet = strRet.replaceAll(strPattern, "<br />");
//
//		return strRet;
//	} //method



} //class

