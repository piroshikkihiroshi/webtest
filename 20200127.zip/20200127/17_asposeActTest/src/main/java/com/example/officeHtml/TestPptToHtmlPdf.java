package com.example.officeHtml;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.apache.log4j.Logger;

import com.aspose.html.HTMLDocument;
import com.aspose.html.drawing.Margin;
import com.aspose.html.drawing.Page;
import com.aspose.html.drawing.Size;
import com.aspose.html.rendering.HtmlRenderer;
import com.aspose.html.rendering.pdf.PdfDevice;
import com.aspose.html.rendering.pdf.PdfRenderingOptions;
import com.aspose.pdf.Document;
import com.aspose.pdf.HtmlSaveOptions;
import com.aspose.pdf.LettersPositioningMethods;
import com.aspose.slides.Presentation;
import com.aspose.slides.SaveFormat;


/**
 * aspose変換ppt→html→pdfの変換テスト
 *
 */
public class TestPptToHtmlPdf {
	static Logger objLog = Logger.getLogger(TestPptToHtmlPdf.class);
	public static void main(String[] args){
		try {
			tester();
		} catch (Exception e) {
			e.printStackTrace();
		} //try
	} //main

	public static void tester() throws IOException {


		//※※※※※svgタグができてしまい、pdf化時に落ちてしまうため、ppt→pdf→html→pdfの変換とする※※※※※

		String strDir = "C:/Users/Public/Documents/test/PPT格納場所/";
		objLog.info("対象Directory："+strDir);

		//Fileクラスのオブジェクトを生成する
        File dir = new File(strDir);

        //listFilesメソッドを使用して一覧を取得する
        File[] list = dir.listFiles();
        String dstHtmlFile ="";
        String dstPdfFile ="";
        String strFileName ="";

        String strRetFile ="ppt_"+ String.valueOf(System.currentTimeMillis())+".csv" ;
        StringBuilder objSb = new StringBuilder(); //結果格納用
        String strTmpRet = "";

        objLog.info("test start:"+String.valueOf(System.currentTimeMillis()));

        //headerを格納
        objSb.append("No,File名,HTML変換,SVG,PDF変換\r\n");
        int intCnt=0;
        for(int i=0; i<list.length; i++) {
        	if(!list[i].isFile()) continue;
        	strFileName = list[i].getName();
    		String strExtension = strFileName.substring(strFileName.lastIndexOf(".")+1,strFileName.length());
        	if(strExtension.equals("ppt")||strExtension.equals("pptx")||strExtension.equals("pptm")) {
        		intCnt++;
        		strTmpRet=intCnt+","+strFileName+",";
        		dstHtmlFile=strFileName.substring(0,strFileName.lastIndexOf("."))+".html";

        		//一度PDF変換をかませる
        		String dstPdfTmp=strFileName.substring(0,strFileName.lastIndexOf("."))+"_tmp.pdf";
        		dstPdfFile=strFileName.substring(0,strFileName.lastIndexOf("."))+".pdf";


        		/* PPT→HTML convert start */
        		objLog.info("対象ファイル："+strFileName);
        		objLog.info("PPT→PDF convert start");

    			// PowerPointファイルの読み込み
    			Presentation presentation = new Presentation(strDir + strFileName);
        		try {

        			// PowerPointのHTML変換
        			presentation.save(strDir + dstPdfTmp, SaveFormat.Pdf);
        			objLog.info("PPT→PDF convert OK");
				} catch (Exception e) {
					objLog.error("PPT→PDF convertでエラー発生");
					strTmpRet+="×,-,-,\r\n";
					objSb.append(strTmpRet);
					continue;
				} //try
        		if(presentation!=null) presentation.dispose();


        		objLog.info("PPT→PDF convert end");

        		objLog.info("PDF→HTML convert start");

    			// PowerPointファイルの読み込み

        		try {
        			Document pdf = new Document(strDir + dstPdfTmp);

        			HtmlSaveOptions newOptions = new HtmlSaveOptions();
        			//SaveOption設定
//        			newOptions.PartsEmbeddingMode = HtmlSaveOptions.PartsEmbeddingModes.EmbedAllIntoHtml;
        			newOptions.LettersPositioningMethod = LettersPositioningMethods.UseEmUnitsAndCompensationOfRoundingErrorsInCss;
//        			newOptions.RasterImagesSavingMode = HtmlSaveOptions.RasterImagesSavingModes.AsEmbeddedPartsOfPngPageBackground;
        			newOptions.FontSavingMode = HtmlSaveOptions.FontSavingModes.SaveInAllFormats;
        			newOptions.setFixedLayout(true);
        			newOptions.setPreventGlyphsGrouping(true);

        			pdf.save(strDir + dstHtmlFile, newOptions);
        			objLog.info("PDF→HTML convert OK");
				} catch (Exception e) {
					objLog.error("PDF→HTML convertでエラー発生");
					strTmpRet+="×,-,-,\r\n";
					objSb.append(strTmpRet);
					continue;
				} //try
        		if(presentation!=null) presentation.dispose();

        		strTmpRet+="○,";

        		objLog.info("PDF→HTML convert end");


        		objLog.info("SVG CHECK start");
        		String strHtml="";
        		strHtml = readAll(strDir + dstHtmlFile);
        		strHtml = strHtml.replaceAll("\r\n", "");
        		if (strHtml.contains("svg")) {
            		strTmpRet+="有,";
            		objLog.info("SVGタグあり");
				}else {
            		strTmpRet+="無,";
            		objLog.info("SVGタグ無し");
				} //if

        		objLog.info("SVG CHECK end");

        		/* HTML→PDF convert start */
        		objLog.info("HTML→PDF convert start");

        		InputStream fileStream=null;
        		fileStream = new FileInputStream(strDir + dstHtmlFile);
        		HTMLDocument htmlDocument = new HTMLDocument(fileStream,strDir + dstHtmlFile);

        		HtmlRenderer renderer = new HtmlRenderer();
        		FileOutputStream objOs = null;
        		PdfDevice objPdfDevice=null;
        		objOs = new FileOutputStream(strDir + dstPdfFile, true);
        		//pdf用サイズ
                PdfRenderingOptions pdf_options = new PdfRenderingOptions();
                pdf_options.getPageSetup().setAnyPage(new Page(new Size(1280, 750),new Margin(0,10,0,0)));

        		objPdfDevice = new PdfDevice(pdf_options,objOs);
//        		objPdfDevice = new PdfDevice(objOs);

        		try {
            		renderer.render(objPdfDevice, htmlDocument);
            		objLog.info("HTML→PDF  convert ok");
				} catch (Exception e) {
					objLog.error("HTML→PDF convertでエラー発生");
					strTmpRet+="×\r\n";
					objSb.append(strTmpRet);
	        		if(renderer!=null) renderer.dispose();
	        		if(objPdfDevice!=null) objPdfDevice.dispose();
	        		if(objOs!=null) objOs.close();;
	        		if(fileStream!=null) fileStream.close();
	        		continue;
				} finally {
	        		if(renderer!=null) renderer.dispose();
	        		if(objPdfDevice!=null) objPdfDevice.dispose();
	        		if(objOs!=null) objOs.close();
	        		if(fileStream!=null) fileStream.close();
				} //try
        		strTmpRet+="○\r\n";
        		objSb.append(strTmpRet);
        		objLog.info("HTML→PDF convert end");
        		/* HTML→PDF convert end */

        	} //if

        } //for
        File newfile = new File(dir+"/"+strRetFile);
        PrintWriter filewriter = new PrintWriter(new BufferedWriter
                (new OutputStreamWriter(new FileOutputStream(newfile),"Shift-JIS")));
        filewriter.write(objSb.toString());
        filewriter.close();
        objLog.info("test end:"+String.valueOf(System.currentTimeMillis()));

	} //tester


	/**
	 * strpath_iで指定したファイルを改行付きですべて読み込む
	 * @param strpath_i
	 * @return 読み込んだ文字列
	 * @throws IOException
	 */
	public static String readAll(final String strpath_i) throws IOException {
		Path file = Paths.get(strpath_i);
		List<String> list = Files.readAllLines(file, Charset.forName("UTF-8"));
		StringBuilder objSb = new StringBuilder();
		for (int i = 0; i <list.size(); i++) {
			objSb.append(list.get(i));

		}
		return objSb.toString();

	} //readAll

}