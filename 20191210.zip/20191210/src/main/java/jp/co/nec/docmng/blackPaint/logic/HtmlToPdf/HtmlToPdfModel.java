package jp.co.nec.docmng.blackPaint.logic.HtmlToPdf;





import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import com.aspose.html.HTMLDocument;
import com.aspose.html.rendering.HtmlRenderer;
import com.aspose.html.rendering.pdf.PdfDevice;





public class HtmlToPdfModel {

	/**
	 * strHtml_iからPDFを作成する
	 * @param strHtml_i
	 * @param strPath_i 相対パスを絶対パスに変更する必要があるのでimgが格納されているDirを指定
	 * @param strPdfOutPath_i pdf出力先のファイル名を含めたフルパス
	 * @return String
	 */

	public String convertHtmlToPdf(String strPath_i,String strPdfOutPath_i){

		//※※※※※※動かなかったらこちらを使う/※※※※※※
		HTMLDocument htmlDocument = new HTMLDocument(strPath_i);
		HtmlRenderer renderer = new HtmlRenderer();
//		PdfRenderingOptions objPdfOpt = new PdfRenderingOptions();
		FileOutputStream objOs = null;
		PdfDevice objPdfDevice=null;
		try {
			objOs = new FileOutputStream(strPdfOutPath_i, true);
			objPdfDevice = new PdfDevice(objOs);
		} catch (FileNotFoundException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}

		renderer.render(objPdfDevice, htmlDocument);
//		objPdfOpt=null;
		renderer=null;
		htmlDocument=null;
		objOs=null;
		objPdfDevice=null;

		return strPdfOutPath_i;

	} //convertHtmlToPdf

} //class

