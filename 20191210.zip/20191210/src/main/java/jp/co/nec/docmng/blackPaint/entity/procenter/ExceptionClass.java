package jp.co.nec.docmng.blackPaint.entity.procenter;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ExceptionClass {
	private String message;

	@JsonProperty("message")
	public String getMessage() {
		return message;
	}

	@JsonProperty("message")
	public void setMessage(String value) {
		this.message = value;
	}
}
