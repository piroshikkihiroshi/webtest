<?php
$strUrl = "http://kamelong.com/API/RosenzuAPI/v0.1/stations";
$strStations = file_get_contents($strUrl);
$arrGetStations = json_decode( $strStations , true ) ;
if ($arrGetStations === NULL) {
   return;
}else{
    $hashRet = []; //result hash Key:駅名 value:駅名情報のhash  
    foreach ($arrGetStations as $station => $value){
        foreach ($value as $station1 => $hashStationInfo){
            $strTmpKey = mb_convert_encoding($hashStationInfo['name'],'UTF-8'); 
            $blExist = array_key_exists($strTmpKey, $hashRet);
            if($blExist){ //駅名:lat:lonが同じ場合別の県とみなして無視
                //駅名:lat:lonが別の場合、別の県とみなして格納(小数点以下は切り捨て)            
                if( (int)($hashStationInfo['lat'] != (int)$hashRet[$strTmpKey]['lat']) && ( (int)$hashStationInfo['lon'] != (int)$hashRet[$strTmpKey]['lon']) ){                    
                    $strTmpKey.='「'.$hashStationInfo['lineName'].'」';
                } //if
            }//if
            $hashRet[$strTmpKey] = $hashStationInfo;
        } //foreach
    } //foreach
} //if    
var_dump($hashRet);
?>
