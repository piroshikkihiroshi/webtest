<?php

//配列にいくつかの緯度経度のセットを格納
//緯度経度はカンマでつなぎ、スペースは含めない
//$latlngList = array("43.041403,141.31998", "43.157152,141.39035", "43.12192,141.374715", "43.042741,141.395135");
//$latlngList = array("43.041403,141.31998");
$latlngList = array("35.5131212,139.69138049999998");
$key = 'AIzaSyA8TME2nXxpNfoYl6iBljiIsGmuV2qXgW0';
$keyword = 'ラーメン';
foreach($latlngList as $latlng){
    $url = 'https://maps.googleapis.com/maps/api/place/nearbysearch/json?location='.$latlng.'&radius=10000&language=ja&keyword='.$keyword.'&key='.$key;
    $data= json_decode(@file_get_contents($url), true);
    foreach($data["results"] as $info){
        $lat = $info["geometry"]["location"]["lat"]; //対象施設の緯度
        $lng = $info["geometry"]["location"]["lng"]; //対象施設の経度
        //緯度経度をもとに日本語の住所を取得
//        $geo = json_decode(@file_get_contents('http://maps.google.com/maps/api/geocode/json?latlng='.$lat.','.$lng.'&sensor=false&language=ja'), true);
//        $address = $geo['results'][0]['formatted_address'];
        //緯度、経度、施設名、住所をカンマ区切りで画面に出力
		echo $lat.",".$lng.",".$info["name"].$info["vicinity"]."<br>";
    } //foreach 
} //foreach	 


?>
