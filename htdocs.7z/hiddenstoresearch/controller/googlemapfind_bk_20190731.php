<?php

//配列にいくつかの緯度経度のセットを格納
//緯度経度はカンマでつなぎ、スペースは含めない
//$latlngList = array("43.041403,141.31998", "43.157152,141.39035", "43.12192,141.374715", "43.042741,141.395135");
//$latlngList = array("43.041403,141.31998");
//$latlngList = array("35.5131212,139.69138049999998");
//$strLat = "35.5131212,139";
//$strLng = "69138049999998";
//$strRadius='1000';
//$numBaseRank=3.5;
//$numBaseRatingTotal=50;
$strLat = $_POST['tgtlat'];
$strLng = $_POST['tgtlng'];
$strRadius=$_POST['radiusselect'];
$strKeyword = $_POST['inputKeyword'];
$numBaseRank=(float)$_POST['rankselect'];
$numBaseRatingTotal=(float)$_POST['ratingstotalselect'];
//$strApiKey = 'AIzaSyA8TME2nXxpNfoYl6iBljiIsGmuV2qXgW0'; api test
//$strApiKey = 'AIzaSyBwIoqdYplBxQoLyzYE2rtbyiivvSbgbiY';
$strApiKey = 'AIzaSyAyoDkShrMGaPcrbRQ29o5Ll42m7uTyImo'; //my first project

$strNextPageToken = null;
$arrPlacesInfo = array();
$arrPlacesRetInfo = array();
$strRet = '';
$intCnt = 0;
$hashRet = array('status'=>'NG');

//ajax判定
if(!ajaxJudge()){
	$hashRet['msg'] = '不正なアクセスです。Code -1';
	echo json_encode($hashRet);
	return false;		
} //if

//hiddenstore.phpからきてるか判定
if (!isset($_SERVER['HTTP_REFERER']) || strpos($_SERVER['HTTP_REFERER'],'hiddenstore') == 0)
{
	$hashRet['msg'] = '不正なアクセスです。Code -2';
	echo json_encode($hashRet);
	return false;		
} //if

//$debug=true;
$debug=false;
if($debug){ //モックを返す
	$strTestJson='{   "html_attributions" : [],   "next_page_token" : "CqQCIAEAAH5AG3rlOsDlgmLO_2sh__I8DtjqB3YJ5ooFa8b59Ywt5KThVrxdV1PW7_XMh8YKM8DEIWrOM5trrGNrYcMUdc9tXuKdL-Iiyh_QVoxapoUd5YthE46Wl4Ounk7FdtiSYaatuSwxj202d6fE8UZa9L-_uhjL-FZq1Eoi0xnWl8KTuISTMLuVZVsAHptvyqsmnytj5dSTE7B2LUfFbgfMZyMmZNIgS8i2A-e4bOlFjYUBxl6B2Ccg8KzSry8rtme5fuQ3ovKJgqQmR93Gh5-zLk0PGz1Iw7qY7OXwKBmIH8NKmvzfb3bPpr-FCS0N_4oMi6eSiwMJb5HfDBSRrOXKxiq8IvR3Ry59QIktvOLnZGk_RCPG9RxlZ-pwFDo3zCRB1xIQBhP2OJBnLbByMQYL5Bi1UxoU_dsSuU8MZq-gGlZl8hx1G4Lhstk",   "results" : [      {         "geometry" : {            "location" : {               "lat" : 35.5156997,               "lng" : 139.6940134            },            "viewport" : {               "northeast" : {                  "lat" : 35.51706242989273,                  "lng" : 139.6954220298927               },               "southwest" : {                  "lat" : 35.51436277010728,                  "lng" : 139.6927223701073               }            }         },         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/restaurant-71.png",         "id" : "ce40d6a1c432d05ad487dda587fc12396b6a4183",         "name" : "味噌らーめん虎のみそ",         "opening_hours" : {            "open_now" : true         },         "photos" : [            {               "height" : 3024,               "html_attributions" : [                  "\u003ca href=\"https://maps.google.com/maps/contrib/113778141475223153669/photos\"\u003e小池さん\u003c/a\u003e"               ],               "photo_reference" : "CmRaAAAAbyYlzdxKLQxs-2e3FooNYGkj7ii2Ck6jU-hsxhzLgaORAhRQFL_DauSxLFTbJ6xagZ1G6Cwx1DQOllb63Lqjq0swuYVeEeSqpSaEJe9FYlFZNAmnbRyOUkfASYjlwop9EhA979wP9yGTKX6WY-uENELfGhSNUHSWjm6lShjQQM2LZ_5jvNNl5g",               "width" : 4032            }         ],         "place_id" : "ChIJsVp8c6lgGGAR0oN1_TgTM8A",         "plus_code" : {            "compound_code" : "GM8V+7J 川崎市, 日本、神奈川県",            "global_code" : "8Q7XGM8V+7J"         },         "price_level" : 2,         "rating" : 3.3,         "reference" : "ChIJsVp8c6lgGGAR0oN1_TgTM8A",         "scope" : "GOOGLE",         "types" : [ "restaurant", "food", "point_of_interest", "establishment" ],         "user_ratings_total" : 274,         "vicinity" : "川崎市川崎区京町２丁目２−２"      },      {         "geometry" : {            "location" : {               "lat" : 35.5215366,               "lng" : 139.6826229            },            "viewport" : {               "northeast" : {                  "lat" : 35.52288642989271,                  "lng" : 139.6839727298927               },               "southwest" : {                  "lat" : 35.52018677010727,                  "lng" : 139.6812730701072               }            }         },         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/restaurant-71.png",         "id" : "1a4dc12b881fbc62c095ae767abaa0dd7adc8bce",         "name" : "梅三容",         "photos" : [            {               "height" : 960,               "html_attributions" : [                  "\u003ca href=\"https://maps.google.com/maps/contrib/102290186486709784770/photos\"\u003eねもととしゆき\u003c/a\u003e"               ],               "photo_reference" : "CmRaAAAAUKEAfYGGKEjeit7NP6u31ahFKaduA9sTdnLTBW-g_qQFJ2U6kUKTvCpQ7IBwvkRJK75wGhRhHholKFHMcpjXxy0dQMqF2-tukD7DDjSJdUnH6mlviy3kHpge7mjymrFMEhBa6FF1hGod0u9e6KxPa3q_GhRXVM755AdIc3-Inj5NopQh9xO5jA",               "width" : 1920            }         ],         "place_id" : "ChIJ7Wk6sxleGGAR9OBgZvdJrYU",         "plus_code" : {            "compound_code" : "GMCM+J2 横浜市, 日本、神奈川県",            "global_code" : "8Q7XGMCM+J2"         },         "rating" : 3.8,         "reference" : "ChIJ7Wk6sxleGGAR9OBgZvdJrYU",         "scope" : "GOOGLE",         "types" : [ "restaurant", "food", "point_of_interest", "establishment" ],         "user_ratings_total" : 11,         "vicinity" : "横浜市鶴見区元宮１丁目９−３９"      },      {         "geometry" : {            "location" : {               "lat" : 35.5122116,               "lng" : 139.6820247            },            "viewport" : {               "northeast" : {                  "lat" : 35.51356142989273,                  "lng" : 139.6833745298927               },               "southwest" : {                  "lat" : 35.51086177010728,                  "lng" : 139.6806748701073               }            }         },         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/restaurant-71.png",         "id" : "6f5e6cf2b003b714e3d69d548aacec7503dcc91d",         "name" : "海老庵",         "opening_hours" : {            "open_now" : false         },         "photos" : [            {               "height" : 3968,               "html_attributions" : [                  "\u003ca href=\"https://maps.google.com/maps/contrib/116384641035949633298/photos\"\u003eTMNR MTO\u003c/a\u003e"               ],               "photo_reference" : "CmRaAAAAgcV2LmY4g1UQGaJEgTSo3Ux32anIyBxXzYE7PO-INhm1l0xZb3M7oJTbvZZQ74oa5jruuKktrzSsQQ5ZzjRbzm2t8z2gLaCdmtBBphAJDOd7NUUgDcEtYrtI000jwqEbEhDmO5x5DUcCVrWez0Sm60s7GhRTOkczfZ9U3yX7yxadM4q3YIPyvA",               "width" : 2976            }         ],         "place_id" : "ChIJq6qedQVeGGARCoVH-qFo4Go",         "plus_code" : {            "compound_code" : "GM6J+VR 横浜市, 日本、神奈川県",            "global_code" : "8Q7XGM6J+VR"         },         "price_level" : 1,         "rating" : 3.7,         "reference" : "ChIJq6qedQVeGGARCoVH-qFo4Go",         "scope" : "GOOGLE",         "types" : [ "restaurant", "food", "point_of_interest", "establishment" ],         "user_ratings_total" : 29,         "vicinity" : "横浜市鶴見区鶴見中央２丁目１４−５ 階, １ 鶴見マンション"      },      {         "geometry" : {            "location" : {               "lat" : 35.5093536,               "lng" : 139.6808509            },            "viewport" : {               "northeast" : {                  "lat" : 35.51070342989272,                  "lng" : 139.6822007298927               },               "southwest" : {                  "lat" : 35.50800377010727,                  "lng" : 139.6795010701072               }            }         },         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/restaurant-71.png",         "id" : "9f1d437767c2c80ddea1cb53524edee3843c1ef3",         "name" : "楓(かえで)",         "opening_hours" : {            "open_now" : false         },         "photos" : [            {               "height" : 3024,               "html_attributions" : [                  "\u003ca href=\"https://maps.google.com/maps/contrib/114743512796398731737/photos\"\u003e平澤昌弘\u003c/a\u003e"               ],               "photo_reference" : "CmRaAAAAlitJb4_UPryHaaza0IHpYmLFh3REdJvOqBYxlXOAMXmsrJeexOZTkgYUDQzYoRSfNiA3brbDCpH2KY7tgb8n9k8DQZGF02WGfG6KKeT9zj9SSou5Pp-Cgucb3ClvY6aPEhCEI5-OrE3QaeB_QdAdsddlGhTYqUIXLoW5qb3YIL60K8QdF4mwZA",               "width" : 4032            }         ],         "place_id" : "ChIJrfC3qgheGGARg0uyQbDalpw",         "plus_code" : {            "compound_code" : "GM5J+P8 横浜市, 日本、神奈川県",            "global_code" : "8Q7XGM5J+P8"         },         "price_level" : 2,         "rating" : 3.6,         "reference" : "ChIJrfC3qgheGGARg0uyQbDalpw",         "scope" : "GOOGLE",         "types" : [ "restaurant", "food", "point_of_interest", "establishment" ],         "user_ratings_total" : 166,         "vicinity" : "横浜市鶴見区鶴見中央３丁目１−２７"      },      {         "geometry" : {            "location" : {               "lat" : 35.5074579,               "lng" : 139.6796273            },            "viewport" : {               "northeast" : {                  "lat" : 35.50880772989272,                  "lng" : 139.6809771298927               },               "southwest" : {                  "lat" : 35.50610807010727,                  "lng" : 139.6782774701072               }            }         },         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/restaurant-71.png",         "id" : "dd9abd6476d3a4712ae3a5de04c89c4a1a41a321",         "name" : "らー麺土俵 鶴嶺峰",         "opening_hours" : {            "open_now" : false         },         "photos" : [            {               "height" : 2531,               "html_attributions" : [                  "\u003ca href=\"https://maps.google.com/maps/contrib/115121208889535273141/photos\"\u003eHiroshi O\u003c/a\u003e"               ],               "photo_reference" : "CmRaAAAAWch-y4VU6maTCcB2mgCU21VYRHubo6tsNtRpKeIKxEJ3VbDOb1Kaq3RtOh9r3Ow8g5hhuuBVi5kTFjkDHHcNv51ybvfFDhUe8Qu2tw13RENDRtr2dXOW00rpsF1WvGmPEhCqlqXf61S2qKKsHhyMMYAKGhRALBz1cCSRc5ZVfj0itAo59TEiFw",               "width" : 2693            }         ],         "place_id" : "ChIJGx1b6wheGGARDzwv9MPgK6c",         "plus_code" : {            "compound_code" : "GM4H+XV 横浜市, 日本、神奈川県",            "global_code" : "8Q7XGM4H+XV"         },         "price_level" : 2,         "rating" : 4.1,         "reference" : "ChIJGx1b6wheGGARDzwv9MPgK6c",         "scope" : "GOOGLE",         "types" : [ "restaurant", "food", "point_of_interest", "establishment" ],         "user_ratings_total" : 386,         "vicinity" : "横浜市鶴見区鶴見中央４丁目２５−６"      },      {         "geometry" : {            "location" : {               "lat" : 35.50912,               "lng" : 139.6982244            },            "viewport" : {               "northeast" : {                  "lat" : 35.51042582989272,                  "lng" : 139.6995903798927               },               "southwest" : {                  "lat" : 35.50772617010728,                  "lng" : 139.6968907201073               }            }         },         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/restaurant-71.png",         "id" : "1db8ebfe2bea1131235bd7001d101cd905030a7b",         "name" : "手打ち中華そば 酒田",         "opening_hours" : {            "open_now" : false         },         "photos" : [            {               "height" : 2448,               "html_attributions" : [                  "\u003ca href=\"https://maps.google.com/maps/contrib/114497504074608110860/photos\"\u003eT K\u003c/a\u003e"               ],               "photo_reference" : "CmRaAAAA3pyDr-6aD1SAsnfuiGbHgR_7RYJwuMdH9DtdP6YhuXKyQNQc4YalrE79NN-uBdDFvpiIEHZPunusVKCHj1tfQPjxkbn8cmBK2JlDLMXMZhbaQGo9hbJS_06sI5TSozwlEhDkYZgydQ49RFNGkeE-NVyqGhSHRtdG9CtQtO4u447aAZ0pI4ljpw",               "width" : 2448            }         ],         "place_id" : "ChIJ09CsNsdnGGAR122T2RVJGtM",         "plus_code" : {            "compound_code" : "GM5X+J7 川崎市, 日本、神奈川県",            "global_code" : "8Q7XGM5X+J7"         },         "price_level" : 2,         "rating" : 4.1,         "reference" : "ChIJ09CsNsdnGGAR122T2RVJGtM",         "scope" : "GOOGLE",         "types" : [ "restaurant", "food", "point_of_interest", "establishment" ],         "user_ratings_total" : 93,         "vicinity" : "川崎市川崎区京町３丁目１３−１０"      },      {         "geometry" : {            "location" : {               "lat" : 35.5181525,               "lng" : 139.6952843            },            "viewport" : {               "northeast" : {                  "lat" : 35.51948832989272,                  "lng" : 139.6965757798927               },               "southwest" : {                  "lat" : 35.51678867010728,                  "lng" : 139.6938761201073               }            }         },         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/restaurant-71.png",         "id" : "f97733a8a94b888e13e65600fa047c43a376672c",         "name" : "龍平家",         "opening_hours" : {            "open_now" : true         },         "photos" : [            {               "height" : 2448,               "html_attributions" : [                  "\u003ca href=\"https://maps.google.com/maps/contrib/105514820196811314496/photos\"\u003eHiroki Kawanishi\u003c/a\u003e"               ],               "photo_reference" : "CmRaAAAAip-0Nz9dnDHespVHk1SOPeUYaiScd2kK0Xl4naLrfKImEdMb7flZ8NrIDorTa3hbiJSGxUY9fN8w_3no3V2bDWP-BexBYrL7umCTWcJP5Df9TSRlOOd7lRWf29rpTnRqEhA_bbcG0ymVu7XgA8n1uy88GhSB4l0WzPeTsVsCMyAzZiAZZjZy9Q",               "width" : 3264            }         ],         "place_id" : "ChIJ__8vxahgGGARFirTrEpKj88",         "plus_code" : {            "compound_code" : "GM9W+74 川崎市, 日本、神奈川県",            "global_code" : "8Q7XGM9W+74"         },         "price_level" : 2,         "rating" : 3.6,         "reference" : "ChIJ__8vxahgGGARFirTrEpKj88",         "scope" : "GOOGLE",         "types" : [ "restaurant", "food", "point_of_interest", "establishment" ],         "user_ratings_total" : 39,         "vicinity" : "川崎市川崎区渡田山王町１９−２"      },      {         "geometry" : {            "location" : {               "lat" : 35.5070137,               "lng" : 139.6799397            },            "viewport" : {               "northeast" : {                  "lat" : 35.50836352989273,                  "lng" : 139.6812895298928               },               "southwest" : {                  "lat" : 35.50566387010728,                  "lng" : 139.6785898701073               }            }         },         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/restaurant-71.png",         "id" : "a3b476a34ea7a139e5cfddd59891b272c25bcb7c",         "name" : "家系ラーメン 介一家(すけいちや)鶴見東口店",         "opening_hours" : {            "open_now" : true         },         "photos" : [            {               "height" : 4032,               "html_attributions" : [                  "\u003ca href=\"https://maps.google.com/maps/contrib/101288100402742959966/photos\"\u003eRogério Almeida\u003c/a\u003e"               ],               "photo_reference" : "CmRaAAAAdv3-tJykVjUhPdCvtFub2qiuG6JWYEzXXcQSscMW_qgFMtBQCdBWGHWeZQfTiTgLa6bHV_ncAswA6Mc5vIwQEKDTMtuAghJWayNBjsVjH-4OrcUq-9Ou0NDUkbO3JiBtEhBBGgVvlFw2GyjrgqOLP3YyGhTtg24qUzeBCOnPF3RrkeNuXkYjzg",               "width" : 3024            }         ],         "place_id" : "ChIJrRYOjAheGGAR5648tHNPNZI",         "plus_code" : {            "compound_code" : "GM4H+RX 横浜市, 日本、神奈川県",            "global_code" : "8Q7XGM4H+RX"         },         "price_level" : 2,         "rating" : 3.3,         "reference" : "ChIJrRYOjAheGGAR5648tHNPNZI",         "scope" : "GOOGLE",         "types" : [ "restaurant", "food", "point_of_interest", "establishment" ],         "user_ratings_total" : 105,         "vicinity" : "横浜市鶴見区鶴見中央４丁目２０−４"      },      {         "geometry" : {            "location" : {               "lat" : 35.510007,               "lng" : 139.677994            },            "viewport" : {               "northeast" : {                  "lat" : 35.51135682989273,                  "lng" : 139.6793438298927               },               "southwest" : {                  "lat" : 35.50865717010728,                  "lng" : 139.6766441701073               }            }         },         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/restaurant-71.png",         "id" : "58d5b7874217c7266d8cdb2679f88fdd4c50c5ce",         "name" : "らーめん信楽茶屋",         "opening_hours" : {            "open_now" : true         },         "photos" : [            {               "height" : 2160,               "html_attributions" : [                  "\u003ca href=\"https://maps.google.com/maps/contrib/111568814461610657834/photos\"\u003eshirokichi momoya\u003c/a\u003e"               ],               "photo_reference" : "CmRaAAAAAkugfFd60PCuU0XDPLgK6-ar7Z7frn2szn0IekLYBueZ-lT-tARyAMwrM3bmIJmaHXxheKumjVQeCqaxZdMMzW5h8ajM9DdGSSwcqOTozgDVw1cPq72jeuCJGU2-0ld3EhC1iwXpmUiKRInrv1qaBXiGGhQPpFCHcvsPWfKomyaCs9AXwuAF9Q",               "width" : 3840            }         ],         "place_id" : "ChIJC_5p-w5eGGARt474WwHmVQA",         "plus_code" : {            "compound_code" : "GM6H+25 横浜市, 日本、神奈川県",            "global_code" : "8Q7XGM6H+25"         },         "price_level" : 2,         "rating" : 3.7,         "reference" : "ChIJC_5p-w5eGGARt474WwHmVQA",         "scope" : "GOOGLE",         "types" : [ "restaurant", "food", "point_of_interest", "establishment" ],         "user_ratings_total" : 257,         "vicinity" : "横浜市鶴見区鶴見中央１丁目１８−２"      },      {         "geometry" : {            "location" : {               "lat" : 35.5184311,               "lng" : 139.6949495            },            "viewport" : {               "northeast" : {                  "lat" : 35.51979437989272,                  "lng" : 139.6963556298927               },               "southwest" : {                  "lat" : 35.51709472010727,                  "lng" : 139.6936559701072               }            }         },         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/restaurant-71.png",         "id" : "112a66269bdfe99cb6fd1a246ea438cc3ff5a362",         "name" : "札幌ラーメン くまごろう",         "opening_hours" : {            "open_now" : true         },         "photos" : [            {               "height" : 1840,               "html_attributions" : [                  "\u003ca href=\"https://maps.google.com/maps/contrib/105105425114615407460/photos\"\u003eIshida Makoto\u003c/a\u003e"               ],               "photo_reference" : "CmRaAAAAxQHDyWismYulwV9bSFFmZ0T-I3Ccw7FCWA-DODGwcVawyZKzCktuboyoEVnWnfImMomMLyxJKFD3BtLdlyusr3hSCkFmYV76mrBATBb2SlgJTYdmjQTscSpIk3iVwkBREhDMNjxGu3PWS6QWxsH9G8q-GhTDHKiiWXlPDmYp_P3GA3q9hV0s0g",               "width" : 2448            }         ],         "place_id" : "ChIJVVUulahgGGARbrV8Ljo2Nx4",         "plus_code" : {            "compound_code" : "GM9V+9X 川崎市, 日本、神奈川県",            "global_code" : "8Q7XGM9V+9X"         },         "price_level" : 2,         "rating" : 4.2,         "reference" : "ChIJVVUulahgGGARbrV8Ljo2Nx4",         "scope" : "GOOGLE",         "types" : [ "restaurant", "food", "point_of_interest", "establishment" ],         "user_ratings_total" : 187,         "vicinity" : "川崎市川崎区京町１丁目９−７"      },      {         "geometry" : {            "location" : {               "lat" : 35.5050012,               "lng" : 139.6932749            },            "viewport" : {               "northeast" : {                  "lat" : 35.50641627989272,                  "lng" : 139.6946371798928               },               "southwest" : {                  "lat" : 35.50371662010728,                  "lng" : 139.6919375201073               }            }         },         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/restaurant-71.png",         "id" : "61e402aac476d98160d986b89ca107803ab28bbc",         "name" : "大雄ラーメン向井町店",         "opening_hours" : {            "open_now" : false         },         "photos" : [            {               "height" : 810,               "html_attributions" : [                  "\u003ca href=\"https://maps.google.com/maps/contrib/106046197541958818288/photos\"\u003e岩渕伸也\u003c/a\u003e"               ],               "photo_reference" : "CmRaAAAAfjgfc1-qIYY9-qUsQr9VHDtCAoiSDfLfq3HQ8C91QIJV2GaAZ2vL-X7bLUbLOBrzbueF26kHlkfcNoh1A12NicQJaLWp15m1gWfhranhFk6GeyC3NnwYKVgGn7FwA8MfEhC9Sl0qo8MGe30ZivbnpKFrGhRkQjVIIWAwmKeYJm1Vnd1LA5PBzQ",               "width" : 1080            }         ],         "place_id" : "ChIJL-8ZeVZnGGARdn5uNk3UCTA",         "plus_code" : {            "compound_code" : "GM4V+28 横浜市, 日本、神奈川県",            "global_code" : "8Q7XGM4V+28"         },         "price_level" : 2,         "rating" : 3.9,         "reference" : "ChIJL-8ZeVZnGGARdn5uNk3UCTA",         "scope" : "GOOGLE",         "types" : [ "restaurant", "food", "point_of_interest", "establishment" ],         "user_ratings_total" : 102,         "vicinity" : "横浜市鶴見区向井町４丁目９１−２５"      },      {         "geometry" : {            "location" : {               "lat" : 35.503835,               "lng" : 139.684723            },            "viewport" : {               "northeast" : {                  "lat" : 35.50518482989272,                  "lng" : 139.6860728298927               },               "southwest" : {                  "lat" : 35.50248517010728,                  "lng" : 139.6833731701072               }            }         },         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/restaurant-71.png",         "id" : "7b26b13610b7275d1f181b93bf145d6bd0b0bc8b",         "name" : "ラーメンショップ",         "opening_hours" : {            "open_now" : false         },         "photos" : [            {               "height" : 480,               "html_attributions" : [                  "\u003ca href=\"https://maps.google.com/maps/contrib/107685299279969243143/photos\"\u003eaki ishida\u003c/a\u003e"               ],               "photo_reference" : "CmRaAAAAx69W_0zrphFkVAYc9V2cNtAYTsoad5ra8zJHsFy4_Jq-BWf-IVGBwK0_xVMXMmr8EQzqWkOlbr5zyA-RCcszYlUkPBh_kw1xMSr0zR0UU96po-UxwqCw3pS6tcIDRnMfEhCl6dIXlzdJ1kuC1dM5MGevGhSVQulLY5bTeUgCxPgtzeNjd0bWAg",               "width" : 640            }         ],         "place_id" : "ChIJ1-oMSvxdGGARn5CNtnCSpM8",         "plus_code" : {            "compound_code" : "GM3M+GV 横浜市, 日本、神奈川県",            "global_code" : "8Q7XGM3M+GV"         },         "price_level" : 2,         "rating" : 3.6,         "reference" : "ChIJ1-oMSvxdGGARn5CNtnCSpM8",         "scope" : "GOOGLE",         "types" : [ "restaurant", "food", "point_of_interest", "establishment" ],         "user_ratings_total" : 58,         "vicinity" : "横浜市鶴見区潮田町２丁目８７−３ ホンダハイツ 1F"      },      {         "geometry" : {            "location" : {               "lat" : 35.5091442,               "lng" : 139.6864583            },            "viewport" : {               "northeast" : {                  "lat" : 35.51049402989272,                  "lng" : 139.6878081298927               },               "southwest" : {                  "lat" : 35.50779437010728,                  "lng" : 139.6851084701073               }            }         },         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/restaurant-71.png",         "id" : "615f375279414ce833edcaab6521d1428438fc6f",         "name" : "ポッポ鶴見店",         "photos" : [            {               "height" : 1536,               "html_attributions" : [                  "\u003ca href=\"https://maps.google.com/maps/contrib/111967591288061477375/photos\"\u003eeisin saito\u003c/a\u003e"               ],               "photo_reference" : "CmRaAAAAMlpfqu_Tm1Dfl_BCh7vJUedc-h_mYJYWSAIGgXrDmu2r7cDtPx97sO0eDKm8ulIPvAXgN9qxKCJCdHuccXHMATUc_S05NJ-d4QGEgajTW8PLbbsWBqShqoAWaQG4KNprEhDZkjWqhUypPlVjZCzvScVhGhSmfzQIG7BizfB1xzthOchk6JU6Ew",               "width" : 2048            }         ],         "place_id" : "ChIJlTNC0wBeGGARbXVRO9OCdDI",         "plus_code" : {            "compound_code" : "GM5P+MH 横浜市, 日本、神奈川県",            "global_code" : "8Q7XGM5P+MH"         },         "price_level" : 1,         "rating" : 3.5,         "reference" : "ChIJlTNC0wBeGGARbXVRO9OCdDI",         "scope" : "GOOGLE",         "types" : [ "restaurant", "food", "point_of_interest", "establishment" ],         "user_ratings_total" : 11,         "vicinity" : "横浜市鶴見区鶴見中央３丁目１５−３０ イトーヨーカドー"      },      {         "geometry" : {            "location" : {               "lat" : 35.5227919,               "lng" : 139.695753            },            "viewport" : {               "northeast" : {                  "lat" : 35.52422012989273,                  "lng" : 139.6970353298927               },               "southwest" : {                  "lat" : 35.52152047010728,                  "lng" : 139.6943356701073               }            }         },         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/restaurant-71.png",         "id" : "496dfebb7568fafa4a56438f186d45ea7c527ac6",         "name" : "ラーメン道楽 川崎店",         "opening_hours" : {            "open_now" : true         },         "photos" : [            {               "height" : 3264,               "html_attributions" : [                  "\u003ca href=\"https://maps.google.com/maps/contrib/103076565014598509634/photos\"\u003e岩崎修\u003c/a\u003e"               ],               "photo_reference" : "CmRZAAAALf3Wjar_acJsEjaa9iU7AaRebo47OWJCgh9zdCZXUmGsuxho6D78TmQekr11XiIKkwheq5l7m1YgsFLuu_BSqREdi86kcOo4TYSpi0SJ2_U03f7L_EPWog6Gt1z_0UmZEhBHnLde9h3VY_tyYal5iuX_GhQOzqY2fNkO6Od-E4q1d5nWzU3g2w",               "width" : 2448            }         ],         "place_id" : "ChIJTUbehKZgGGARR6pL1ew5gN8",         "plus_code" : {            "compound_code" : "GMFW+48 川崎市, 日本、神奈川県",            "global_code" : "8Q7XGMFW+48"         },         "price_level" : 2,         "rating" : 3.5,         "reference" : "ChIJTUbehKZgGGARR6pL1ew5gN8",         "scope" : "GOOGLE",         "types" : [ "restaurant", "food", "point_of_interest", "establishment" ],         "user_ratings_total" : 288,         "vicinity" : "川崎市川崎区元木２丁目３−２３ 1F"      },      {         "geometry" : {            "location" : {               "lat" : 35.5118004,               "lng" : 139.6789982            },            "viewport" : {               "northeast" : {                  "lat" : 35.51315022989272,                  "lng" : 139.6803480298927               },               "southwest" : {                  "lat" : 35.51045057010728,                  "lng" : 139.6776483701072               }            }         },         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/restaurant-71.png",         "id" : "925ee350931d2a042c648bbf624de05ef43e6bfe",         "name" : "自家製麺てんか",         "opening_hours" : {            "open_now" : false         },         "photos" : [            {               "height" : 3464,               "html_attributions" : [                  "\u003ca href=\"https://maps.google.com/maps/contrib/117760775575094194636/photos\"\u003eTトム\u003c/a\u003e"               ],               "photo_reference" : "CmRaAAAA93K-7e1EyC4JgvaX1MLdsB-sJ7gmuaA8cDcPiUXQbLvavnooUv1_ozD2VXOQ0HyCgTaBhu4QtguqhTEVt3wkQdjBji0uxXQNOsojy8bhJoOS1ufdaZpQ8s5jJ_QC30uHEhB1arkIBmpFGYT4nAyfuiWBGhQdlEXyalvdT7GFxak_gdegre9Ojg",               "width" : 4618            }         ],         "place_id" : "ChIJa2qrsA9eGGARSiJQBbamfTY",         "plus_code" : {            "compound_code" : "GM6H+PH 横浜市, 日本、神奈川県",            "global_code" : "8Q7XGM6H+PH"         },         "price_level" : 2,         "rating" : 4.1,         "reference" : "ChIJa2qrsA9eGGARSiJQBbamfTY",         "scope" : "GOOGLE",         "types" : [ "restaurant", "food", "point_of_interest", "establishment" ],         "user_ratings_total" : 239,         "vicinity" : "横浜市鶴見区鶴見中央２丁目９−１７"      },      {         "geometry" : {            "location" : {               "lat" : 35.507324,               "lng" : 139.6790566            },            "viewport" : {               "northeast" : {                  "lat" : 35.50867382989272,                  "lng" : 139.6804064298927               },               "southwest" : {                  "lat" : 35.50597417010727,                  "lng" : 139.6777067701073               }            }         },         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/restaurant-71.png",         "id" : "14b32d482b76bdffd44737a3447e86eece00743e",         "name" : "鶴見家",         "opening_hours" : {            "open_now" : true         },         "photos" : [            {               "height" : 2048,               "html_attributions" : [                  "\u003ca href=\"https://maps.google.com/maps/contrib/117750484846163682454/photos\"\u003enaoe shoji\u003c/a\u003e"               ],               "photo_reference" : "CmRaAAAAfnTek9ZmLv-x6r1qmsd6jAp4cUjELiJnNp31sRuFq1v_HCtCU66f-GxpHh1iM5hdPSKqeqv_UMyKBMO5ZeOl709LX7hrUuOacpov6nn68J5t4Yd9KjgEVdJqxpM24kVQEhD6KwRAXYlsV257daOL4KYtGhQJJtBk0Sfvmk0t2cmpu_l-UhPw4w",               "width" : 1536            }         ],         "place_id" : "ChIJJ-xp6AheGGARVztsMommkcM",         "plus_code" : {            "compound_code" : "GM4H+WJ 横浜市, 日本、神奈川県",            "global_code" : "8Q7XGM4H+WJ"         },         "price_level" : 2,         "rating" : 3.5,         "reference" : "ChIJJ-xp6AheGGARVztsMommkcM",         "scope" : "GOOGLE",         "types" : [ "restaurant", "food", "point_of_interest", "establishment" ],         "user_ratings_total" : 160,         "vicinity" : "横浜市鶴見区鶴見中央４丁目２５−１５"      },      {         "geometry" : {            "location" : {               "lat" : 35.5172689,               "lng" : 139.6952327            },            "viewport" : {               "northeast" : {                  "lat" : 35.51864727989272,                  "lng" : 139.6967028798927               },               "southwest" : {                  "lat" : 35.51594762010728,                  "lng" : 139.6940032201073               }            }         },         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/restaurant-71.png",         "id" : "bfaa207f0c51ae1cb0da40d8f1daffabbae7e9fb",         "name" : "元祖ニュータンタンメン本舗 京町店",         "opening_hours" : {            "open_now" : true         },         "photos" : [            {               "height" : 3464,               "html_attributions" : [                  "\u003ca href=\"https://maps.google.com/maps/contrib/110333269677809833894/photos\"\u003e工藤誠\u003c/a\u003e"               ],               "photo_reference" : "CmRaAAAApwKYnPXk-lpF_x3ZtT2I50U47477ew2P9tGkAwL9nwNJIB_3pr4rH4BawM3TcyVCx-HkKG_jofMAynbeET2pxLM4IIBpI2jXicmLDJOK1jsJvX5pHFuaFoi6kPDE8n2OEhDNFnIhB8Qyxpwfq5i0P2ApGhQve698ctXgVk4HJsdPnXYemxd1Zw",               "width" : 4618            }         ],         "place_id" : "ChIJMQ87IalgGGARQStYI-xqJE8",         "plus_code" : {            "compound_code" : "GM8W+W3 川崎市, 日本、神奈川県",            "global_code" : "8Q7XGM8W+W3"         },         "price_level" : 2,         "rating" : 4,         "reference" : "ChIJMQ87IalgGGARQStYI-xqJE8",         "scope" : "GOOGLE",         "types" : [ "restaurant", "food", "point_of_interest", "establishment" ],         "user_ratings_total" : 832,         "vicinity" : "川崎市川崎区京町１丁目１８−７"      },      {         "geometry" : {            "location" : {               "lat" : 35.5203362,               "lng" : 139.6912171            },            "viewport" : {               "northeast" : {                  "lat" : 35.52176047989273,                  "lng" : 139.6925041298927               },               "southwest" : {                  "lat" : 35.51906082010728,                  "lng" : 139.6898044701072               }            }         },         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/restaurant-71.png",         "id" : "2ed3940b077e4e414a1c0eb8e36874bd05aef05b",         "name" : "ラーメン亭",         "opening_hours" : {            "open_now" : false         },         "photos" : [            {               "height" : 4032,               "html_attributions" : [                  "\u003ca href=\"https://maps.google.com/maps/contrib/114005382118187538055/photos\"\u003e白イチゴ\u003c/a\u003e"               ],               "photo_reference" : "CmRaAAAAlVnM3GN2-mO-li-5e3aEM8pey1fYtJ2scYVDJJMivpdZErIj9C4J3cuelc6OShjReteFpw-M23zvtyJFOi1CZPFQ3B_3m9Y1SryJQV4oWXByOkWqg_tuMVh7DquoPOEcEhCJC7tKQRTOn7oqmrpETf_9GhSNHWjVK_eBXrJxVK6seCRMV1pDOA",               "width" : 3024            }         ],         "place_id" : "ChIJfQJogKdgGGARjxsbouWAZgc",         "plus_code" : {            "compound_code" : "GMCR+4F 川崎市, 日本、神奈川県",            "global_code" : "8Q7XGMCR+4F"         },         "rating" : 3.8,         "reference" : "ChIJfQJogKdgGGARjxsbouWAZgc",         "scope" : "GOOGLE",         "types" : [ "restaurant", "food", "point_of_interest", "establishment" ],         "user_ratings_total" : 24,         "vicinity" : "川崎市川崎区池田２丁目２−６"      },      {         "geometry" : {            "location" : {               "lat" : 35.5109857,               "lng" : 139.6830381            },            "viewport" : {               "northeast" : {                  "lat" : 35.51233552989272,                  "lng" : 139.6843879298928               },               "southwest" : {                  "lat" : 35.50963587010728,                  "lng" : 139.6816882701073               }            }         },         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/restaurant-71.png",         "id" : "c53616b4185b0e77a20e08c204f89f7cc4038def",         "name" : "吉田食堂",         "opening_hours" : {            "open_now" : false         },         "photos" : [            {               "height" : 3000,               "html_attributions" : [                  "\u003ca href=\"https://maps.google.com/maps/contrib/116550988486337559107/photos\"\u003e片山智恵\u003c/a\u003e"               ],               "photo_reference" : "CmRaAAAATWizrg4O5Cl1oph_fhkyWz2OLTm4VRKe5oy8pNxI_N21BPUSkwSupVajoqEp0W2Wp4TBmK6lBN033VS-vG99AWy-Neq3Qz0w_ZjdSk0uRq2_2d_jXl5ZUQTyOWbUJxM8EhCwvOSadRV3PJARgzld7LnAGhRLMSYMxyhSFyFPgXzX7Viz-FSL9g",               "width" : 5333            }         ],         "place_id" : "ChIJkw74zgVeGGARrO8ZbA8P6qs",         "plus_code" : {            "compound_code" : "GM6M+96 横浜市, 日本、神奈川県",            "global_code" : "8Q7XGM6M+96"         },         "price_level" : 2,         "rating" : 4.1,         "reference" : "ChIJkw74zgVeGGARrO8ZbA8P6qs",         "scope" : "GOOGLE",         "types" : [ "restaurant", "food", "point_of_interest", "establishment" ],         "user_ratings_total" : 103,         "vicinity" : "横浜市鶴見区鶴見中央３丁目４−１４"      },      {         "geometry" : {            "location" : {               "lat" : 35.5073057,               "lng" : 139.6796256            },            "viewport" : {               "northeast" : {                  "lat" : 35.50865552989271,                  "lng" : 139.6809754298927               },               "southwest" : {                  "lat" : 35.50595587010727,                  "lng" : 139.6782757701073               }            }         },         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/restaurant-71.png",         "id" : "89e22a6c0a82403fb920e0bf8b9d57425703f497",         "name" : "辛麺屋 赤丸 鶴見本店",         "opening_hours" : {            "open_now" : false         },         "photos" : [            {               "height" : 3096,               "html_attributions" : [                  "\u003ca href=\"https://maps.google.com/maps/contrib/111008891671470238267/photos\"\u003eかずかず\u003c/a\u003e"               ],               "photo_reference" : "CmRaAAAAPCbsnyP-ZpSByj7TWzJLA03IlwcRE915t_nhAmHOAtN5liy47SQHwKZrtCAIpBNNpDJbjVRMV2K7Huzz-CdrVDxpmXajqU3lWNeAbaNv_hJ0tlVWFLNiDEpZDcvBNcQ_EhCYGnfU5MU5HmCLA4Bk21RKGhRFxGIU1i-cfg3Ha3g0tMjQgE-ywA",               "width" : 5504            }         ],         "place_id" : "ChIJaw4p7QheGGARthBEGcrcdLU",         "plus_code" : {            "compound_code" : "GM4H+WV 横浜市, 日本、神奈川県",            "global_code" : "8Q7XGM4H+WV"         },         "price_level" : 2,         "rating" : 3.8,         "reference" : "ChIJaw4p7QheGGARthBEGcrcdLU",         "scope" : "GOOGLE",         "types" : [ "restaurant", "food", "point_of_interest", "establishment" ],         "user_ratings_total" : 45,         "vicinity" : "横浜市鶴見区鶴見中央４丁目２５−８"      }   ],   "status" : "OK"}';
	$arrPlacesInfo = json_decode($strTestJson, true);
	for ($i = 0; $i < count($arrPlacesInfo['results']); $i++) {
//		if ((float)$arrPlacesInfo[$i]["rating"] >= $numBaseRank and (float)$arrPlacesInfo[$i]["user_ratings_total"] <= $numBaseRatingTotal) {
		array_push($arrPlacesRetInfo,$arrPlacesInfo['results'][$i]); 
		$intCnt++;
//		} //if
	} //for	
	$hashRet = array_merge($hashRet,$arrPlacesRetInfo); 
	$hashRet['status'] = "OK";
	$hashRet['msg'] = "検索結果${intCnt}件";
//	$hashRet = array_merge($hashRet,$arrPlacesRetInfo); 
	echo json_encode($hashRet);
	return false;		
} //if

$strBaseUrl = 'https://maps.googleapis.com/maps/api/place/nearbysearch/json';
//$strUrl = $strBaseUrl.'?location='."${strLat}.${strLng}".'&radius='.$strRadius.'&language=ja&keyword='.$strKeyword.'&key='.$strApiKey;
$strUrl = $strBaseUrl.'?location='."${strLat},${strLng}".'&radius='.$strRadius.'&language=ja';
if($strKeyword != ''){
	$strUrl.='&keyword='.urlencode($strKeyword);
//	$strUrl.='&keyword='.$strKeyword;	
} //if
$strUrl.='&key='.$strApiKey;
//$hashData= json_decode(@file_get_contents($strUrl), true);
$hashData=getApiDataCurl($strUrl);
if(empty($hashData)){
	$hashRet['msg'] = '【Places API】API Call時にエラーが発生しました。';
	echo json_encode($hashRet);
	return false;	
} //if

$strRet = getPlaceRet($hashData);
if($strRet == ''){
	//resultsをplacesList配列に結合
	$arrPlacesInfo = array_merge($arrPlacesInfo,$hashData["results"]);
	//next_page_tokenを取得
	if(array_key_exists("next_page_token",$hashData)){
		$strNextPageToken = $hashData["next_page_token"];			
	}else{
		$strNextPageToken = '';			
	} //if

}else{
	$hashRet['msg'] = $strRet;
	echo json_encode($hashRet);
	return false;
} //if

//next_page_tokenが取得された場合は次ページあり。
//next_page_tokenが取得できなくなるまで、
//次ページ情報の取得を繰り返す。
while ($strNextPageToken != null) {
	sleep(2); //（連続リクエストすると取得に失敗する）
	$strUrl = $strBaseUrl.'?key='.$strApiKey.'&pagetoken='.$strNextPageToken;
//	$hashData= json_decode(@file_get_contents($strUrl), true);	
	$hashData=getApiDataCurl($strUrl);
	if(empty($hashData)){
		$hashRet['msg'] = '【Places API】API Call時にエラーが発生しました。';
		echo json_encode($hashRet);
		return false;	
	} //if	
	$strRet = getPlaceRet($hashData);
	if($strRet == ''){
		//resultsをplacesList配列に結合
		$arrPlacesInfo = array_merge($arrPlacesInfo,$hashData["results"]);
		//next_page_tokenを取得
		if(array_key_exists("next_page_token",$hashData)){
			$strNextPageToken = $hashData["next_page_token"];			
		}else{
			$strNextPageToken = '';			
		} //if
	}else{
		$hashRet['msg'] = $strRet;
		echo json_encode($hashRet);
		return false;
	} //if	
	
} //while


//rating,user_ratings_totalが設定されていないものを
//一旦「-1」に変更する。
for ($i = 0; $i < count($arrPlacesInfo); $i++) {
	if (!array_key_exists("rating",$arrPlacesInfo[$i])) {
		$arrPlacesInfo[$i]["rating"] = -1;
	} //if
	if (!array_key_exists("user_ratings_total",$arrPlacesInfo[$i])) {
		$arrPlacesInfo[$i]["user_ratings_total"] = -1;
	} //if	
} //for

//ratingがnumBaseRank以上,user_ratings_totalがnumBaseRatingTotal以下のものだけ取得
$intCnt = 0;
for ($i = 0; $i < count($arrPlacesInfo); $i++) {
	if ((float)$arrPlacesInfo[$i]["rating"] >= $numBaseRank and (float)$arrPlacesInfo[$i]["user_ratings_total"] <= $numBaseRatingTotal) {
//		$arrPlacesRetInfo[$intCnt] = array_merge($arrPlacesRetInfo,$arrPlacesInfo[$i]); 
		array_push($arrPlacesRetInfo,$arrPlacesInfo[$i]); 
		$intCnt++;
	} //if
} //for

$intCnt = 0;
$strGMapBase='https://maps.google.co.jp/maps?';
foreach($arrPlacesRetInfo as $hashInfo){
//	$retLat = $hashInfo["geometry"]["location"]["lat"]; //対象施設の緯度
//	$retLng = $hashInfo["geometry"]["location"]["lng"]; //対象施設の経度
	//緯度、経度、施設名、住所をカンマ区切りで画面に出力
//	echo $retLat.",".$retLng.",".$hashInfo["name"].$hashInfo["vicinity"].':評価'.$hashInfo["rating"].':数'.$hashInfo["user_ratings_total"]."<br>";
//	echo "<a href=${strGMapBase} target='_blank'></a></br>";
	$intCnt++;
} //foreach 

if($intCnt==0){
	$hashRet['msg'] = "検索結果が0件でした。";
	echo json_encode($hashRet);
	return false;	
} //if

//viewに返す
$hashRet['status'] = "OK";
$hashRet['msg'] = "検索結果${intCnt}件";
$hashRet = array_merge($hashRet,$arrPlacesRetInfo); 
echo json_encode($hashRet);
return false;	



function getPlaceRet($hashData_i){
	if ($hashData_i["status"] == "OK") {
		return '';
	} else if ($hashData_i["status"] == "ZERO_RESULTS") {
		return "【Places API】検索結果が0件です。";
	} else if ($hashData_i["status"] == "ERROR") {
		return "【Places API】サーバ接続に失敗しました。";
	} else if ($hashData_i["status"] == "INVALID_REQUEST") {
		return "【Places API】リクエストが無効でした。";
	} else if ($hashData_i["status"] == "OVER_QUERY_LIMIT") {
		return "【Places API】リクエストの利用制限回数を超えました。";
	} else if ($hashData_i["status"] == "REQUEST_DENIED") {
		return "【Places API】サービスが使えない状態でした。";
	} else if ($hashData_i["status"] == "UNKNOWN_ERROR") {
		return "【Places API】原因不明のエラーが発生しました。";
	} //if	
} //function




function getApiDataCurl($url)
{
    $option = [
        CURLOPT_RETURNTRANSFER => true, //文字列として返す
        CURLOPT_TIMEOUT        => 10, // タイムアウト時間
    ];

    $ch = curl_init($url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); //証明書無視
    curl_setopt_array($ch, $option);

    $json    = curl_exec($ch);
    $info    = curl_getinfo($ch);
    $errorNo = curl_errno($ch);

    // OK以外はエラーなので空白配列を返す
    if ($errorNo !== CURLE_OK) {
        // 詳しくエラーハンドリングしたい場合はerrorNoで確認
        // タイムアウトの場合はCURLE_OPERATION_TIMEDOUT
        return [];
    }

    // 200以外のステータスコードは失敗とみなし空配列を返す
    if ($info['http_code'] !== 200) {
        return [];
    }

    // 文字列から変換
    $jsonArray = json_decode($json, true);

    return $jsonArray;
} //function

//ajaxか判定する。
function ajaxJudge(){
	if(isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
		return true;  
	} //if	
	return false;
} //function







?>