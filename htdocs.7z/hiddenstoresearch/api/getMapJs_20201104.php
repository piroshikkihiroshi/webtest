<?php

//inifile
$arrIni = parse_ini_file("../setting/setting.ini");

$strUrl = 'https://maps.googleapis.com/maps/api/js?language=ja&region=JP&'; # 公式サンプルの HTML が src= で読んでたurl
$strKey = $arrIni['key']; # 環境変数に入っている APIキーを取り出す
$strSrc = $strUrl . "&key=" . $strKey; # url に APIキーを連結する
$strResponse = getApiDataCurl($strSrc); # google マップのサイトにアクセスして src を持ってくる
header("'Content-Type': 'text/javascript; charset=UTF-8'");
echo($strResponse);

//$strUrlのResponseをStringで取得
//@param $strUrl
//@return $String
function getApiDataCurl($strUrl_i)
{
    $option = [
        CURLOPT_RETURNTRANSFER => true, //文字列として返す
        CURLOPT_TIMEOUT        => 10, // タイムアウト時間
    ];

    $ch = curl_init($strUrl_i);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); //証明書無視
    curl_setopt_array($ch, $option);

    $strstrResponse    = curl_exec($ch);
    $info    = curl_getinfo($ch);
    $errorNo = curl_errno($ch);

    // OK以外はエラーなので空白配列を返す
    if ($errorNo !== CURLE_OK) {
        // 詳しくエラーハンドリングしたい場合はerrorNoで確認
        // タイムアウトの場合はCURLE_OPERATION_TIMEDOUT
        return [];
    }//if

    // 200以外のステータスコードは失敗とみなし空配列を返す
    if ($info['http_code'] !== 200) {
        return [];
    } //if

    return $strstrResponse;
} //function