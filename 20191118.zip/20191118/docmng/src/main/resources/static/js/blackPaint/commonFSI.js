
/**
************通常関数************
*/

/**
* 初期表示：ユーザー名を表示する。
*/
function showUserName() {
	var COOKIE_USER = document.cookie.split(';');
	for(let i=0 ; i< COOKIE_USER.length  ; i++){
		var objUserKey = COOKIE_USER[i].split('=')
    	if( objUserKey[0] === " user_name"){
    		var objUserDom = document.getElementById("USER_NAME");
    		objUserDom.innerText =objUserDom.innerText + objUserKey[1];
    	}
	}
} //function

/**
* 初期表示：ユーザー名IDを表示する。
*/
function showUserId() {
	var COOKIE_USER = document.cookie.split(';');
	for(let i=0 ; i< COOKIE_USER.length  ; i++){
		var objUserKey = COOKIE_USER[i].split('=')
    	if( objUserKey[0] === " user_id"){
    		var objUserDom = document.getElementById("USER_ID");
    		objUserDom.innerText =objUserDom.innerText + objUserKey[1];
    	}
	}
} //function

/**
* 初期表示：ファイル名を表示する。
*/
function showFileName (){
	var fileName = glFileName.split(".")[0];
	var objFileDom = document.getElementById("FILE_NAME");
	objFileDom.innerText =objFileDom.innerText + fileName;
} //function


/**
*  DocumentIngoのデータを取得(zip 全文テキストを除く)しjsonで返却する
* @return boolean
*/
function getDocumentInfo(documentId) {
    $.ajax({
        type: 'GET',
        url: '/rest/doc/rec?documentId='+documentId,
        processData: false, // Ajaxがdataを整形しない指定
        contentType: false, // contentTypeもfalseに指定(Fileをアップロード時は必要)
        async: false, //非同期false
        success: function (retData) {
            glDocumentInfoLists = JSON.parse(retData);
            for (let i = 0; i < glDocumentInfoLists.length; i++) { //nullがあったら空文字にする
                //nullは空文字にしておく
                for (const key in glDocumentInfoLists[i]) {
                    if (glDocumentInfoLists[i][key] === null) {
                        glDocumentInfoLists[i][key] = '';
                    } //if
                } //for
            } //for
            console.log("success");
            return false;
        }, //function
        error: function (e) {
            console.log("fail");
            return false;
        } //function
    }); //ajax
} //function


