package jp.co.nec.docmng.blackPaint.logic.HtmlToPdf;



import java.nio.file.Path;
import java.nio.file.Paths;

import io.woo.htmltopdf.HtmlToPdf;
import io.woo.htmltopdf.HtmlToPdfObject;



public class HtmlToPdfModel {

	/**

	 * strHtml_iからPDFを作成する

	 * @param strHtml_i

	 * @param strPath_i 相対パスを絶対パスに変更する必要があるのでimgが格納されているDirを指定

	 * @param strPdfOutPath_i pdf出力先のファイル名を含めたフルパス

	 * @return String

	 */

	public String convertHtmlToPdf(String strHtml_i,String strPath_i,String strPdfOutPath_i){



		String strRetHtml=strHtml_i;
		Path objPath = Paths.get(strPath_i);
		String strDirFile =  objPath.toUri().toString();;
		strRetHtml = strRetHtml.replace("src=\"", "src=\""+ strDirFile);
		strRetHtml = strRetHtml.replace("href='", "href='"+ strDirFile);
		// HTMLをPDFファイルに変更する
		HtmlToPdf.create().object(HtmlToPdfObject.forHtml(strRetHtml)).convert(strPdfOutPath_i);

		//※※※※※※動かなかったらこちらを使う/※※※※※※
//		// load the file to be rendered
//
//		HTMLDocument html = new HTMLDocument(strHtml_i);
//		// render to PDF & XPS
//		HtmlRenderer renderer = new HtmlRenderer();
////		renderer.render(new PdfDevice(new PdfRenderingOptions(), dir + "output.pdf"), html);
//		renderer.render(new PdfDevice(new PdfRenderingOptions(), strPdfOutPath_i), html);


		return "";



	} //convertHtmlToPdf



	public String convertListHtmlToPdf(String strHtml_i,String strPath_i,String strPdfOutPath_i){



		String strRetHtml=strHtml_i;

		Path objPath = Paths.get(strPath_i);

		String strDirFile =  objPath.toUri().toString();;

		strRetHtml = strRetHtml.replace("href='", "href='"+ strDirFile);

		// HTMLをPDFファイルに変更する

		HtmlToPdf.create().object(HtmlToPdfObject.forHtml(strRetHtml)).convert(strPdfOutPath_i);



		return strRetHtml;



	}

} //class

