package jp.co.nec.docmng.library.asposeToHtml.repository;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;


public class MaskHtmlMode {

	/**
	 * strpath_iで指定したファイルを改行付きですべて読み込む
	 * @param strpath_i
	 * @return 読み込んだ文字列
	 * @throws IOException
	 */
	public String readAll(final String strpath_i) throws IOException {
		return Files.lines(Paths.get(strpath_i), Charset.forName("UTF-8"))
				.collect(Collectors.joining(System.getProperty("line.separator")));

	} //readAll

	/**
	 * strHtml_i(htmlString)のBodyを正規表現で抜き出す(改行 必要以外の半角スペース削除)
	 * @param strHtml_i
	 * @return 抜き出したBody
	 */
	public String getBodyCompress(String strHtml_i) {
		String strRet = strHtml_i;

		//改行を削除
		strRet = strRet.replaceAll("\r\n", "");

		//2つ以上の半角スペースを一つにまとめる
		strRet = strRet.replaceAll("\\s+", " ");

		String strPattern = "\\<body\\>.+\\</body\\>";
		Pattern objPattern = Pattern.compile(strPattern);
		Matcher objMatch = objPattern.matcher(strRet);
		objMatch.find();
		strRet = objMatch.group();

		return strRet;
	} //getBody

	/**
	 * 全文検索エンジンに渡す用の文字列を取得する
	 * @param strBody_i HTML文字列からBody要素だけを抜き出したもの
	 * @return タグ無し連結文字列
	 */
	public String getIllegalText(String strBody_i) {
		String strRet = strBody_i;
		//tagを全て除去
		String strPattern = "<(\"[^\"]*\"|'[^']*'|[^'\">])*>";
		strRet = strRet.replaceAll(strPattern, "");
		//trim
		strRet = strRet.trim();

		//半角スペース記号置換
		//		strPattern="&#xa0;";
		//		strRet = strRet.replace(strPattern, " ");

		return strRet;
	} //getIllegalText

} //class
