package jp.co.nec.docmng.manege.util.map;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import jp.co.nec.docmng.manege.entity.PolicyInfoEntity;

@Mapper
public interface PolicyInfoMapManege {

    @Select("select * from admin.policy_info order by policy_number")
    public List<PolicyInfoEntity> findAll();

    @Insert("insert into admin.policy_info (policy_number,policy_name,policy_author,policy_reason,create_time) values (#{policyNumber},#{policyName},#{policyAuthor},#{policyReason},#{createTime})")
    public void insert(PolicyInfoEntity policyInfoEntity);

    @Update("update admin.policy_info set policy_number = coalesce(#{policyNumber}, policy_number), policy_name = coalesce(#{policyName}, policy_name), policy_reason = coalesce(#{policyReason}, policy_reason), update_time = coalesce(#{updateTime}, update_time) where policy_Id = #{policyId}")
    public void update(PolicyInfoEntity policyInfoEntity);

    @Delete("delete from admin.policy_info where policy_id = #{policyId}")
    public void deleteById(Integer id);

}
