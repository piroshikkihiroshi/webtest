package jp.co.nec.docmng.library.train;
/**
 * 黒塗り箇所管理用クラス
 */
public class Span {
	/**
	 * 文字列
	 */
	public String span;
	/**
	 * 開始位置
	 */
	public int start;
	/**
	 * 終了位置
	 */
	public int end;
}
