/**
 * 名称：DocInfoService.java
 * 機能名：文書情報連携
 * 概要：文書情報への連携用サービス
 */

package jp.co.nec.docmng.manage.service;

import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import jp.co.nec.docmng.manage.util.map.DocumentInfoMapManege;

/**
 * 文書情報連携
 */
@Service
public class DocumentInfoService {
	@Autowired
	private DocumentInfoMapManege documentMap;

	/**
	 * カテゴリーの更新処理
	 * @param targetCategory 取得条件となるドキュメントID
	 * @param categoryId カテゴリーIDの更新値
	 * @param updateTime 更新日時
	 */
	@Transactional
	public void updateDocFileInfo(int targetCategory, int categoryId, Date updateTime){
		documentMap.updateDocFileInfo(targetCategory, categoryId, updateTime);
	}
}
