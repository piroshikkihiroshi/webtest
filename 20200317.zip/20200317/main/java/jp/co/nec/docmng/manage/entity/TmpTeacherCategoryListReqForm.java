/**
 * 名称：TmpTeacherCategoryListReqForm.java
 * 機能名：管理系教師データ(分類)登録画面一時保存情報entity(Form)
 * 概要：管理系で使用する教師データ(分類)登録画面一時保存情報entity(Form)
 */

package jp.co.nec.docmng.manage.entity;

import java.util.List;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * 管理系教師データ(分類)登録画面一時保存情報entity(Form)
 */
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class TmpTeacherCategoryListReqForm {
    @NotBlank(message = "必須項目です。")
    private String savePath;
    @NotBlank(message = "必須項目です。")
    private String userName;
    @NotBlank(message = "必須項目です。")
    private List<TmpTeacherCategoryList> tmpTeacherCategoryList;

    /**
     * savePath getter
     * @return savePath
     */
    public String getSavePath() {
        return savePath;
    }
    /**
     * savePath setter
     * @param savePath
     */
    public void setSavePath(String savePath) {
        this.savePath = savePath;
    }

    /**
     * userName getter
     * @return userName
     */
    public String getUserName() {
        return userName;
    }
    /**
     * userName setter
     * @param userName
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * tmpTeacherCategoryList getter
     * @return tmpTeacherCategoryList
     */
    public List<TmpTeacherCategoryList> getTmpTeacherCategoryList() {
        return tmpTeacherCategoryList;
    }
    /**
     * tmpTeacherCategoryList setter
     * @param tmpTeacherCategoryList
     */
    public void setTmpTeacherCategoryList(List<TmpTeacherCategoryList> tmpTeacherCategoryList) {
        this.tmpTeacherCategoryList = tmpTeacherCategoryList;
    }

}
