/**
 * 名称：DocumentInfoEnt.java
 * 機能名：文書情報entity
 * 概要：文書情報entity
 */

package jp.co.nec.docmng.manage.entity;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

/**
 * 文書情報entity
 */
@Data
public class DocumentInfoEntity {

	/**
	 * 文書ID
	 */
	private int documentId;

	/**
	 * 全文検索用text
	 */
	private String documentContents;

	/**
	 * HTML群(zip圧縮)
	 */
	private byte[] htmlZipData;

	/**
	 * サーバID
	 */
	private int serverId;

	/**
	 * 文書名
	 */
	private String documentName;

	/**
	 * 拡張子
	 */
	private String extension;

	/**
	 * 文書サイズ
	 */
	private BigDecimal documentSize;

	/**
	 * 親ディレクトリID
	 */
	private int parentId;

	/**
	 * パス
	 */
	private String filePath;

	/**
	 * 黒塗り箇所
	 */
	private String marker;

	/**
	 * 分類軸ID
	 */
	private int categoryId;

	/**
	 * PROCENTERフラグ
	 */
	private Boolean procenterFlg;

	/**
	 * 保存期間
	 */
	private Date retentionPeriod;

	/**
	 * 文書作成者
	 */
	private String author;

	/**
	 * 文章更新者
	 */
	private String updater;

	/**
	 * 文書承認者
	 */
	private String authorizer;

	/**
	 * 文書更新日時
	 */
	private Date fileUpdateTime;

	/**
	 * 黒塗り状態
	 */
	private int maskStatus;

	/**
	 * 作成日時
	 */
	private Date createTime;

	/**
	 * 更新日時
	 */
	private Date updateTime;

	/**
	 * ノードID
	 */
	private int nodeId;

	/**
	 * PROCENTER親ディレクトリID
	 */
	private int procenterParentId;

}
