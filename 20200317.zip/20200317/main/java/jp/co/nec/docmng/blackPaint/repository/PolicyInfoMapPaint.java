/**
 * 名称：PolicyInfoMapPaint.java
 * 機能名：黒塗り処理ポリシー情報連携
 * 概要：黒塗り処理にて使用するポリシー情報への連携用レポジトリ
 */

package jp.co.nec.docmng.blackPaint.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import jp.co.nec.docmng.blackPaint.entity.PolicyInfoEntBlackPaint;

/**
 * 黒塗り処理ポリシー情報連携
 */
@Mapper
public interface PolicyInfoMapPaint {

	/**
	 * 全件取得
	 * @return 検索結果
	 */
	@Select("select * from admin.policy_info order by policy_number")
	List<PolicyInfoEntBlackPaint> findAll();

} //PolicyInfoMapper
