/**
 * 名称：TmpInfoGet.java
 * 機能名：一時保存テーブル確認
 * 概要：一時保存テーブルの状態をリクエスト（json）から確認する
 */

package jp.co.nec.docmng.blackPaint.util.api;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.blackPaint.entity.TmpMaskDocumentEntBlackPaint;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocumentServicePaint;

/**
 * 一時保存テーブル確認
 */
@RestController
public class TmpInfoGet {

	@Autowired
	TmpMaskDocumentServicePaint tmpMaskDocumentService;

	static Logger objLog = LoggerFactory.getLogger(TmpInfoGet.class);

	/**
	 * 一時保存テーブルの状態をリクエスト（json）から確認する
	 * @param strHashJson リクエスト（json）
	 * @param UserId :ユーザID
	 * @param model 未使用
	 * @return String true 保存されている false 保存されていない
	 */
	@ResponseBody
	@PostMapping("/blackpaint/rest/tmpinfo")
	@ResponseStatus(HttpStatus.OK)
	public String getTmpInfo(
			@RequestBody String strHashJson,
			@CookieValue(value = "user_id", required = false) String UserId,
			Model model) {
		boolean blRet = false;
		int intDocumentId = 0;
		String strRet = "";

		//POSTされたjsonをパースする
		final ObjectMapper objMapper = new ObjectMapper();
		List<Map<String, String>> objTmpList = null;
		final TypeReference<List<Map<String, String>>> objType = new TypeReference<List<Map<String, String>>>() {
		};
		try {
			objTmpList = objMapper.readValue(strHashJson, objType);
		} catch (final JsonParseException e) {
			objLog.error("err message", e);
			return "500"; // Internal Server Error;
		} catch (final JsonMappingException e) {
			objLog.error("err message", e);
			return "500"; // Internal Server Error;
		} catch (final IOException e) {
			objLog.error("err message", e);
			return "500"; // Internal Server Error;
		} //try

		final HashMap<String, String> objMap = (HashMap<String, String>) objTmpList.get(0);

		for (final String strKey : objMap.keySet()) {
			switch (strKey) {
			case "documentId":
				intDocumentId = Integer.parseInt(objMap.get(strKey));
				break;
			default:
				break;
			} //switch
		} //for

		List<TmpMaskDocumentEntBlackPaint> listZip = null;
		try {
			listZip = tmpMaskDocumentService.listTmpDoc(intDocumentId, UserId);
			if (listZip.size() == 0) {
				blRet = false;
			} else {
				blRet = true;
			} //if

			strRet = objMapper.writeValueAsString(blRet);
		} catch (final JsonProcessingException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		}
		return strRet;
	} //getPlicyAll

} //PolicyGet
