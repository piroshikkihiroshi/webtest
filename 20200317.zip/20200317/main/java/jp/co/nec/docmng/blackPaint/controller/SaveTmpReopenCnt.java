/**
 * 名称：SaveTmpReopenCnt.java
 * 機能名：一時保存再開Control
 * 概要：一時保存再開機能のControlを行う。
 */

package jp.co.nec.docmng.blackPaint.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.zeroturnaround.zip.ZipUtil;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.blackPaint.entity.TmpMaskDocMarkerEntBlackPaint;
import jp.co.nec.docmng.blackPaint.entity.TmpMaskDocumentEntBlackPaint;
import jp.co.nec.docmng.blackPaint.logic.dirFile.DirCnt;
import jp.co.nec.docmng.blackPaint.service.DocInfoServicePaint;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocMarkerServicePaint;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocumentServicePaint;

/**
 * 一時保存再開機能のControlを行う。
 */
@RestController
public class SaveTmpReopenCnt {

	/**
	 * context サーブレットのRealPathを取得する
	 */
	@Autowired
	ServletContext context;

	@Autowired
	TmpMaskDocumentServicePaint tmpMaskDocumentService;
	@Autowired
	TmpMaskDocMarkerServicePaint tmpMaskDocTmpMarkerService;
	@Autowired
	DocInfoServicePaint docInfoService;

	/**
	 * objLog log出力に使用する
	 */
	static Logger objLog = LoggerFactory.getLogger(SaveTmpReopenCnt.class);

	/**
	 * 一時保存再開メソッド
	 * 一時保存再開を押下したときの処理制御をする。
	 * @param documentId ドキュメントID
	 * @param UserId ユーザID
	 * @param strTmpDir ファイル出力先フォルダパス
	 * @param response HttpServletResponse
	 * @param model 引渡しパラメータ用モデル
	 * @return policy等の情報
	 */
	@ResponseBody
	@PostMapping("/blackpaint/SaveTmpReopen")
	@ResponseStatus(HttpStatus.OK)
	public synchronized String SaveTmpReopenRest(
			@RequestBody String documentId,
			@CookieValue(value = "user_id") String UserId,
			@CookieValue(value = "strTmpDirName", required = false) String strTmpDir,
			HttpServletResponse response, Model model) {

		if (strTmpDir.equals("")) {
			strTmpDir = "tmp" + UUID.randomUUID().toString() + "/";
			final Cookie cookie = new Cookie("strTmpDirName", strTmpDir);
			cookie.setMaxAge(60 * 3600);
			cookie.setPath("/");
			response.addCookie(cookie);
		} //if

		if (UserId == null)
			UserId = "";

		objLog.info("UserId:" + UserId);

		//モデル初期化
		//		FileCnt objFileCnt = new FileCnt();
		final DirCnt objDirCls = new DirCnt();

		//メンバ変数初期化
		final String strTmpUuid = UUID.randomUUID().toString();
		final int intDocumentId = Integer.parseInt(documentId); //documentId

		String strBasePath = ""; //黒塗り作成時の作業フォルダ
		String strFileOutDir = ""; //出力フォルダ
		String strRealPath = context.getRealPath("/");
		if(strRealPath==null) strRealPath="";

		//一時保存したzipをDBから取得
		List<TmpMaskDocumentEntBlackPaint> listZip = null;
		byte[] arrHtmlZip = null;
		List<TmpMaskDocMarkerEntBlackPaint> listInfo = null;

		try {
			listZip = tmpMaskDocumentService.getTmpHtmlZip(intDocumentId, UserId);
			arrHtmlZip = listZip.get(0).getHtmlZipData();
			//policy等取得
			listInfo = tmpMaskDocTmpMarkerService.selectTmpMaskDocMarker(intDocumentId, UserId);

		} catch (final Exception e) {
			objLog.error("err message", e);
			return "500"; // Internal Server Error
		} //try

		//file出力
		//出力フォルダ作成
		strBasePath = strRealPath + strTmpDir;
		strFileOutDir = strRealPath + "tmp" + strTmpUuid + "/";
		final String strZipPath = strFileOutDir + "mask.zip";
		final Path objZipPath = Paths.get(strZipPath);
		try {
			objDirCls.makeDirWithCheck(strFileOutDir);
			//zipファイル出力
			Files.write(objZipPath, arrHtmlZip);

			//セッションで削除できないためそのままunzip
			ZipUtil.unpack(new File(strZipPath), new File(strBasePath));

			//作業ディレクトリかたづけ
			objDirCls.delDirectory(strFileOutDir);
			objLog.info("作業directoryかたずけ完了：" + strFileOutDir);

		} catch (final IOException e1) {
			objLog.error("err message", e1);
			e1.printStackTrace();
		} //try
		catch (final Exception e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} //try

		String strRet = "";
		//jsonにしてpolicy等の情報を返す
		final ObjectMapper objMapper = new ObjectMapper();
		try {
			strRet = objMapper.writeValueAsString(listInfo);
		} catch (final JsonProcessingException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} //if

		return strRet;

	} //getView1

	/**
	 * エラー画面遷移(一時保存再開処理)
	 * @param e 発生したエラー
	 * @param response HTTPレスポンス
	 * @param model 引渡しパラメータ用モデル
	 * @return 遷移先アドレス
	 */
	@ExceptionHandler(Exception.class)
	public String handleException(Exception e, HttpServletResponse response, Model model) {

		response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		objLog.error("Error occurred.", e);
		final StringWriter objSw = new StringWriter();
		final PrintWriter objPw = new PrintWriter(objSw);
		e.printStackTrace(objPw);
		objPw.flush();
		final String strError = objSw.toString();
		try {
			objSw.close();
			objPw.close();
		} catch (final IOException e1) {
			e1.printStackTrace();
		} //try

		model.addAttribute("errorMessage", e.getMessage() + "\r\n" + "StackTrace" + "\r\n" + strError);

		return "blackPaint/Fail";
	} //method


} //MaskHtmlCnt
