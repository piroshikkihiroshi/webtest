/**
 * 名称：DocumentMapPaint.java
 * 機能名：黒塗り処理文書情報連携
 * 概要：黒塗り処理にて使用する文書情報への連携用レポジトリ
 */

package jp.co.nec.docmng.blackPaint.repository;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import jp.co.nec.docmng.blackPaint.entity.DocumentInfoEntPaint;

/**
 * 黒塗り処理文書情報連携
 */
@Mapper
public interface DocumentMapPaint {

	/**
	 * プライマリキー指定による取得（バイナリデータ含む）
	 * @param document_id 取得条件となるドキュメントID
	 * @return 取得したデータのリスト
	 */
	@Select("SELECT * FROM common.document_info WHERE document_id = #{document_id}") List<DocumentInfoEntPaint> selectDocInfo(int document_id);

	/**
	 * プライマリキー指定による取得（バイナリデータ含まない）
	 * @param document_id 取得条件となるドキュメントID
	 * @return 取得したデータのリスト
	 */
	@Select("SELECT document_id, document_contents, server_id, document_name, extension, document_size, parent_id, file_path, marker, category_id, procenter_flg, procenter_parent_id, node_id, retention_period, author, updater, authorizer, file_update_time, mask_status, create_time, update_time, procenter_file_id FROM common.document_info WHERE document_id = #{document_id}") List<DocumentInfoEntPaint> selectDocFileInfo(int document_id);

	/**
	 * ProcenterFileId指定による取得（バイナリデータ含まない）
	 * @param procenter_file_id 取得条件となるファイルID
	 * @return 取得したデータのリスト
	 */
	@Select("SELECT document_id, document_contents, server_id, document_name, extension, document_size, parent_id, file_path, marker, category_id, procenter_flg, procenter_parent_id, node_id, retention_period, author, updater, authorizer, file_update_time, mask_status, create_time, update_time, procenter_file_id FROM common.document_info WHERE procenter_file_id = #{procenter_file_id}") List<DocumentInfoEntPaint> selectDocToProcenterFileId(int procenter_file_id);


	/**
	 * カテゴリー、保存期間の更新処理
	 * @param document_id 取得条件となるドキュメントID
	 * @param category_id カテゴリーIDの更新値
	 * @param retention_period 保存期間の更新値
	 * @param update_time 更新日時
	 */
	@Update("UPDATE common.document_info SET category_id=#{category_id} , retention_period=#{retention_period} , update_time=#{update_time} WHERE document_id = #{document_id}") void updateDocFileInfo(int document_id, int category_id, Date retention_period, Date update_time);

} //PolicyInfoMapper
