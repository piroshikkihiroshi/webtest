/**
 * 名称：DirCnt.java
 * 機能名：ディレクトリ管理
 * 概要：ディレクトリ管理のためのクラス
 */

package jp.co.nec.docmng.blackPaint.logic.dirFile;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ディレクトリ管理
 */
public class DirCnt {

	static Logger objLog = LoggerFactory.getLogger(DirCnt.class);

	/**
	 * ディレクトリを作成する。(存在していた場合削除して再作成する)
	 * @param strDirPath_i 作成ディレクトリパス
	 * @return 成否ステータス（0以外は失敗）
	 */
	synchronized public int makeDirWithCheck(String strDirPath_i) {

		//strDirPath_iの長さが10未満なら処理しない(フェールセーフ)
		if (strDirPath_i.length() <= 10) {
			objLog.info("フォルダの削除を処理しない");
			return -2;
		} //if

		objLog.info("対象フォルダ："+strDirPath_i);

		File objTgtDir = new File(strDirPath_i);
		if (objTgtDir.exists()) {
			objLog.info("フォルダがすでに存在する為、一度削除します");
			try {
				FileUtils.deleteDirectory(objTgtDir);
				objLog.info("フォルダの削除に成功しました");
			} catch (IOException e) {
				objLog.error("フォルダの削除に失敗しました",e);
				return -1;
			}
		}
		objLog.info("フォルダの作成を実施します");
		if (objTgtDir.mkdir()) {
			objLog.info("フォルダの作成に成功しました");
		} else {
			objLog.info("フォルダの作成に失敗しました");
			return -1;
		}
		return 0;
	} //

	/**
	 * ディレクトリを削除する。
	 * @param strDirPath_i 削除ディレクトリパス
	 * @return 成否ステータス（0以外は失敗）
	 */
	synchronized public int delDirectory(String strDirPath_i) {
		//strDirPath_iの長さが10未満なら処理しない(フェールセーフ)
		if (strDirPath_i.length()<=10) {
			return -2;
		} //if

		objLog.info("対象フォルダ："+strDirPath_i);

		File objTgtDir = new File(strDirPath_i);
		if (objTgtDir.exists()) {
			objLog.info("フォルダがすでに存在する為、削除します");
			try {
				FileUtils.deleteDirectory(objTgtDir);
				objLog.info("フォルダの削除に成功しました");
			} catch (Exception e) {
				objLog.error("フォルダの削除に失敗しました",e);
				return -1;
			}
		}
		return 0;
	} //delDirectory





} //DirCnt
