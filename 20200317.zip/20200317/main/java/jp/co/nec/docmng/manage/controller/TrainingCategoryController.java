/**
 * 名称：TrainingCategoryControllerファイル
 * 機能名：教師データ登録（分類）コントローラー
 * 概要：教師データ登録（分類）の制御を実施する
 */
package jp.co.nec.docmng.manage.controller;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ibm.icu.text.CharsetDetector;
import com.ibm.icu.text.CharsetMatch;

import jp.co.nec.docmng.library.asposeToHtml.service.FileToHtml;
import jp.co.nec.docmng.manage.entity.CategoryInfo;
import jp.co.nec.docmng.manage.entity.CategoryInfoReflectForm;
import jp.co.nec.docmng.manage.entity.CategoryInfoReflectForm.AddValues;
import jp.co.nec.docmng.manage.entity.CategoryInfoReflectForm.ChangedValues;
import jp.co.nec.docmng.manage.entity.TmpTeacherCategoryList;
import jp.co.nec.docmng.manage.entity.TmpTeacherCategoryListReqForm;
import jp.co.nec.docmng.manage.service.CategoryInfoService;
import jp.co.nec.docmng.manage.service.DocumentInfoInternalService;
import jp.co.nec.docmng.manage.service.DocumentInfoService;
import jp.co.nec.docmng.manage.service.TmpTeacherCategoryService;

/**
 * 教師データ（分類）のリクエストを制御する
 */
@Controller
@RequestMapping("/manage/training_category")
public class TrainingCategoryController {

    /** ロガー */
    private static Logger objLog = LoggerFactory.getLogger(TrainingCategoryController.class);

    @Autowired
    CategoryInfoService categoryInfoService;

    @Autowired
    TmpTeacherCategoryService tmpTeacherCategoryService;
    @Autowired
    DocumentInfoService documentInfoService;
    @Autowired
    DocumentInfoInternalService documentInfoInternalService;

    /** その他カテゴリのcategoryId番号 */
    static Integer OTHER_ID = 0;

    /** 成功応答値 */
    static final String SUCCESS = "success";
    /** 失敗応答値 */
    static final String ERROR = "error";

    /** 作成されるHTMLの出力先 */
    static String STR_HTML_DIR_PATH = "src/main/resources/category";

	/** ファイル種類・該当なし */
	private static final int FILETYPE_OTHER = 0;
	/** ファイル種類・テキストファイル */
	private static final int FILETYPE_TEXT = 1;
	/** ファイル種類・ワードファイル */
	private static final int FILETYPE_WORD = 2;
	/** ファイル種類・エクセル */
	private static final int FILETYPE_EXCEL = 3;
	/** ファイル種類・PowerPoint */
	private static final int FILETYPE_PPT = 4;
	/** ファイル種類・PDF */
	private static final int FILETYPE_PDF = 5;

    /**
     * 管理者権限
     */
    private static final String USER_ROLE_TYPE = "Administrators";

    /**
     * <p>教師データ登録（分類）初期表示処理</p>
     * 処理内容：教師データ登録（分類）を表示用データを取得し表示する。
     * @param model 引渡しパラメータ用モデル
	 * @param request HTTPリクエスト
     * @return 教師データ登録（分類）画面URL
     */
    @GetMapping
    public String getTrainingCategory(Model model, HttpServletRequest request) {
    	
        // クッキー情報を取得する
        System.out.println("");
        System.out.println(request.getHeader("Cookie"));
        int userAuth = 0;

        // 管理者権限の文字列が検出されなかった場合
        if(request.getHeader("Cookie") == null){
            userAuth = 1;

            objLog.info("getSearchServerInfo request end (failed)");
            model.addAttribute("userAuth", userAuth);
            return "manage/trainingCategory";
        }

        // ログインしているユーザーの権限を確認する
        String userRoleString = "\"userRole\":\"";
        int openUserRolePoint = request.getHeader("Cookie").indexOf(userRoleString);
        int openUserRoleEndPoint = request.getHeader("Cookie").indexOf(USER_ROLE_TYPE,openUserRolePoint) + USER_ROLE_TYPE.length();
        System.out.println(openUserRolePoint);
        System.out.println(openUserRoleEndPoint);

        // 管理者権限の文字列が検出されなかった場合
        if(openUserRoleEndPoint == 13){
            userAuth = 1;

            objLog.info("getSearchServerInfo request end (failed)");
            model.addAttribute("userAuth", userAuth);
            return "manage/trainingCategory";
        }

        String openUserRole = request.getHeader("Cookie").substring(openUserRolePoint+userRoleString.length(),openUserRoleEndPoint);
        System.out.println(openUserRole);

        objLog.info("getTrainingCategory request start");

        // 分類一覧取得
        List<CategoryInfo> categoryInfos = categoryInfoService.findAll();

        // 教師データ分類一覧取得
        List<TmpTeacherCategoryList> teacherCategoryLists = tmpTeacherCategoryService.findAll();

        // 表示用に分類名を付与する
        for (int i = 0; i < teacherCategoryLists.size(); i++) {
            teacherCategoryLists.get(i).setCategoryName(" ");
            for (int j = 0; j < categoryInfos.size() ; j++) {
                if (categoryInfos.get(j).getCategoryId().equals(teacherCategoryLists.get(i).getCategoryId())) {
                    teacherCategoryLists.get(i).setCategoryName(categoryInfos.get(j).getCategoryName());
                    break;
                }
            }
        }

        // 保存先の取得とテキストへの設定
        ResourceBundle rb = ResourceBundle.getBundle("config/manage");
        model.addAttribute("saveRegistrationList", rb.getString("SavaFilePath.TrainingCategory"));

        // レスポンス情報セット
        model.addAttribute("categoryInfo", categoryInfos);
        model.addAttribute("teacherCategoryList", teacherCategoryLists);
        objLog.trace("categoryInfos:{}", categoryInfos);
        objLog.trace("teacherCategoryLists:{}", teacherCategoryLists);
        objLog.info("getTrainingCategory request end (success)");
        return "manage/trainingCategory";
    }

    /**
     * <p>分類一覧更新メソッド</p>
     * 処理内容：
     * <ol>
     *   <li>画面上で削除した分類一覧と紐づくDBの項目を削除する。</li>
     *   <li>画面上で編集した分類一覧と紐づくDBの項目を更新する。</li>
     *   <li>画面上で追加した分類一覧と紐づくDBの項目を追加する。</li>
     * </ol>
     * @param form 追加・編集・削除した分類データ
     * @return ResponseEntity&lt;String&gt; 更新結果
     * @throws Exception 更新に失敗した場合
     */
    @PostMapping("/category_reflect")
    @ResponseBody
    public ResponseEntity<String> categoryReflect(@RequestBody CategoryInfoReflectForm form) throws Exception {

        objLog.info("categoryReflect request start");
        // 存在チェック
        if (Objects.isNull(form)) {
            objLog.trace("form:{}", form);
            objLog.info("request data not found");
            objLog.info("categoryReflect request end (error)");
            return null;
        }
        objLog.info("form : {} ", form);

        CategoryInfo categoryInfo = new CategoryInfo();
        System.out.println("設定反映ボタン");
        List<AddValues> addValues = form.getAddValues();
        List<ChangedValues> changeValues = form.getChangedValues();
        List<Integer> deleteRow = form.getDeleteRow();
        Timestamp sysdate = Timestamp.valueOf(LocalDateTime.now());

        try {
            // 追加データがある場合
            if (!Objects.isNull(addValues)) {
                for (AddValues value : addValues) {
                    // 追加データセット
                    categoryInfo.setCategoryAuthor(value.getCategoryAuthor());
                    categoryInfo.setCategoryName(value.getCategoryName());
                    categoryInfo.setCategoryType(0);
                    categoryInfo.setCreateTime(sysdate);
                    categoryInfo.setUpdateTime(sysdate);
                    // 追加
                    categoryInfoService.insert(categoryInfo);
                }
            }

            // 編集データがある場合
            if (!Objects.isNull(changeValues)) {
                for (ChangedValues value : changeValues) {
                    // 更新データセット
                    categoryInfo.setCategoryId(value.getCategoryId());
                    categoryInfo.setCategoryName(value.getCategoryName());
                    categoryInfo.setUpdateTime(sysdate);
                    // 更新
                    categoryInfoService.update(categoryInfo);
                }
            }

            // 削除データがある場合
            if (!Objects.isNull(deleteRow)) {
                for (Integer value : deleteRow) {
                    // 文書情報の外部キーとして削除項目が存在するときにその他を設定する
                	documentInfoService.updateDocFileInfo(value, OTHER_ID, sysdate);

                    // 文書情報（内部処理用）の外部キーとして削除項目が存在するときにその他を設定する
                	documentInfoInternalService.updateDocFileInfo(value, OTHER_ID, sysdate);

                    // 教師データ(分類)登録画面一時保存情報の外部キーとして削除項目が存在するときにその他を設定する
                    TmpTeacherCategoryList updateTmpTeacherCategory = new TmpTeacherCategoryList();
                    updateTmpTeacherCategory.setCategoryId(OTHER_ID);
                    updateTmpTeacherCategory.setUpdateTime(sysdate);
                    tmpTeacherCategoryService.updateCategoryId(value, updateTmpTeacherCategory);

                    // 削除
                    categoryInfoService.delete(value);
                }
            }
        } catch (Exception e) {
            objLog.error("addValues:{}\r\nchangeValues:{}\r\ndeleteRow:{}", addValues, changeValues,deleteRow);
            objLog.error("error message", e);
            objLog.info("categoryReflect request end (error)");
            e.printStackTrace();
            return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
        }
        objLog.info("categoryReflect request end (success)");
        return new ResponseEntity<String>(HttpStatus.OK);
    }

    /**
     * <p>教師データ一覧更新メソッド</p>
     * 処理内容：
     * <ol>
     *   <li>画面上で削除した登録データ一覧と紐づくDBの項目を削除する。</li>
     *   <li>画面上で編集した分類一覧と紐づくDBの項目を更新する。</li>
     *   <li>画面上で追加した分類一覧と紐づくDBの項目を追加する。</li>
     * </ol>
     * @param form 追加・編集・削除した分類データ
     * @return ResponseEntity&lt;String&gt; 更新結果
     * @throws Exception 更新に失敗した場合
     */
    @PostMapping(value = "/teacher_category_reflect", produces="text/plain; charset=UTF-8")
    @ResponseBody
    public ResponseEntity<String> teacherCategoryReflect (@RequestBody TmpTeacherCategoryListReqForm form) throws Exception {

        objLog.info("teacherCategoryReflect request start");
        // 存在チェック
        if (Objects.isNull(form)) {
            objLog.trace("form:{}", form);
            objLog.info("request data not found");
            objLog.info("TeacherCategoryReflect request end (error)");
            return null;
        }
        objLog.info("form : {} ", form);

        List<TmpTeacherCategoryList> tmpTeacherCategoryList = form.getTmpTeacherCategoryList();
        String savePath = form.getSavePath();
        File saveDirectory = new File(savePath);
        if (!saveDirectory.exists()) {
            String err = "保存先のフォルダ" + savePath + "は存在しません。";
            objLog.info("{} correct answer directoryPath path directory not found ", savePath);
            objLog.info("teacherCategoryReflect request end (error)");
            return new ResponseEntity<String>(err, HttpStatus.BAD_REQUEST);
        }
        saveDirectory = null;

        List<String> csvDataList = new ArrayList<>();

        // CSVヘッダー
        csvDataList.add("index,text,marker");

        // ディレクトリの存在確認エラー用のフラグ、エラー文言、区切り文字
    	boolean retErr1 = false;
        String retErrString1 = "以下に記載したパスが存在しません。";
        String wk1 = "";

        // ディレクトリ配下のファイル存在確認エラー用のフラグ、エラー文言、区切り文字
    	boolean retErr2 = false;
        String retErrString2 = "以下のパスに対象ファイルが存在しません。";
        String wk2 = "";

        // index決定用変数(indexは1からスタート)
        int index = 1;

        for (int i = 0 ; i < tmpTeacherCategoryList.size() ; i++) {
            TmpTeacherCategoryList list = tmpTeacherCategoryList.get(i);
            String dirPath = list.getFilePath();
            File dir = new File(dirPath);
            if (!dir.exists()) {
            	// 指定ディレクトリが存在しない場合
                objLog.info("{} folder not found ", dirPath);
            	retErrString1 += wk1 + (i + 1) + "行目";
                wk1 = "、";
                retErr1 = true;
            }
            System.out.println (STR_HTML_DIR_PATH);

            // 存在しないディレクトリがあったらエラーとなるのでファイル処理はしない
            if (!retErr1) {

                // 各ディレクトリ配下のファイルを参照する
                File[] fileList = dir.listFiles();
            	boolean chk = false;	// ディレクトリ配下で対象ファイルがったらtrueとする

            	// そもそもディレクトリにファイルがない場合
            	if (fileList.length == 0) {
                	// 指定ディレクトリ配下にファイルが存在しない場合
                    objLog.info("{} file not found ", dirPath);
                	retErrString2 += wk2 + (i + 1) + "行目";
                    wk2 = "、";
                    retErr2 = true;
            	}

                for (int j = 0; j < fileList.length; j++) {
                	File objFile = fileList[j];

        			// ファイルの場合のみ処理を行う
        			if(objFile.isFile()) {

        				// 対象ファイルか判定する
        				int fileType = getFileType(objFile.getName());

        				// 対象ファイルではない場合は実施しない
        				if (fileType != FILETYPE_OTHER) {
        					// 対象ファイルの場合
        		            try {
        		            	// 既にディレクトリ配下にファイルが存在しなかった場合は実施しない（時間短縮のため）
        		            	if (!retErr2) {
            		                String csvData = createCsvData(objFile, fileType);
            		                csvDataList.add(index + "," + csvData + "," + list.getCategoryId());
        		            	}
        		                index++;
        		                chk = true;
        		            } catch (Exception e) {
        		                e.printStackTrace();
        		                String err = "CSVファイル作成中に失敗しました。";
        		                objLog.info("csv file creating error ");
        		                objLog.trace("csvDataList:{}", csvDataList);
        		                objLog.info("teacherCategoryReflect request end (error)");
        		                return new ResponseEntity<String>(err, HttpStatus.BAD_REQUEST);
        		            }
        				}
        			}

                    if ((j == fileList.length - 1) && !chk) {
                    	// 指定ディレクトリ配下に対象ファイルが存在しない場合
                        objLog.info("{} file not found ", dirPath);
                    	retErrString2 += wk2 + (i + 1) + "行目";
                        wk2 = "、";
                        retErr2 = true;
                    }
                    objFile = null;
                }
                fileList = null;
            }
            dir = null;
        }

        System.out.println(csvDataList);

        // 指定ディレクトリが存在しない場合
    	if (retErr1) {
            objLog.error("error message", retErrString1);
            return new ResponseEntity<String>(retErrString1, HttpStatus.NOT_ACCEPTABLE);
    	}

        // 指定ディレクトリ配下にファイルが存在しない場合
    	if (retErr2) {
            objLog.error("error message", retErrString2);
            return new ResponseEntity<String>(retErrString2, HttpStatus.NOT_ACCEPTABLE);
    	}

        // CSVファイル作成
        try {
            // CSVファイル名取得
            ResourceBundle rb = ResourceBundle.getBundle("config/manage");
            String fileName = rb.getString("SavaFileName.TrainingCategory");

            // CSVファイル作成
            if (!Files.exists(Paths.get(savePath, fileName))) {
                Files.createFile(Paths.get(savePath, fileName));
            }
            // CSVファイル書込
            Files.write(Paths.get(savePath, fileName), csvDataList,
                Charset.forName(StandardCharsets.UTF_8.toString()),
                StandardOpenOption.TRUNCATE_EXISTING);

            // DB反映処理（全削除）
            tmpTeacherCategoryService.deleteAll();

            for (TmpTeacherCategoryList addList : tmpTeacherCategoryList) {
                // DB反映処理（登録処理）
                tmpTeacherCategoryService.insert(addList);
            }
        } catch (Exception e) {
            objLog.info("teacherCategoryReflect request end (error)");
            e.printStackTrace();
            return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
        }
        objLog.info("teacherCategoryReflect request end (success)");
        return new ResponseEntity<String>(HttpStatus.OK);
    }
    /**
     * <p>教師データ（分類）のCSVに登録する本文部分生成</p>
     * 処理内容：リクエストされた教師データファイルから本文を取り出す。
     * @param file 教師データファイル
	 * @param fileType ファイルの種別 1：テキスト 2：ワード 3：エクセル 4：PowerPoint 5：PDF (0：該当しない の場合は当処理に入らない)
     * @return CSVに登録する本文
     * @throws Exception 教師データから本文取り出しに失敗した場合
     */
    private String createCsvData(File file, int fileType) throws Exception {
        objLog.trace("file:{}", file);

        String strDirPath = file.getAbsolutePath().replace(file.getName(), "");
        String strOrgFileName = file.getName();
        String strHtmlDirPath = STR_HTML_DIR_PATH;

        String csvString = "";
        if (fileType == FILETYPE_TEXT) {
        	csvString = textReadFile(file);
        } else {
            try {
            	// ライブラリを使って全文検索テキストを抜出す
                FileToHtml fileToHtml = new FileToHtml();
            	csvString = fileToHtml.fileToHtml(strDirPath, strOrgFileName, strHtmlDirPath)[0];
            	fileToHtml = null;

            	// 作業用に作成したHTML群を削除する
            	File dir = new File(strHtmlDirPath);
            	if (!deleteFolder(dir)) {
            		// 削除失敗時は一度だけリトライ
                	dir = null;
                	dir = new File(strHtmlDirPath);
            		deleteFolder(dir);
            	}
            	dir = null;
            }catch (Exception e) {
                objLog.error("strDirPath:{}\r\nstrDirPath:{}\r\nstrDirPath:{}", strDirPath, strOrgFileName, strHtmlDirPath);
                objLog.error("error message", e);
                e.printStackTrace();
                throw e;
            }
        }

        // テキスト中の「"」ダブルコーテーションの考慮
        csvString = csvString.replaceAll("\"", "\"\"");
        csvString = "\"" + csvString + "\"";

        return csvString;
    }

    /**
     * <p>テキストファイルから本文を抜き出す</p>
     * 処理内容：テキスト形式のファイルから本文をString形式で取り出し返す。
     * @param file 教師データ（分類）ファイル
     * @return 本文
     * @throws Exception 想定外エラー
     */
    private String textReadFile(File file) throws Exception {
        objLog.trace("file:{}", file);
		String ret = "";

		// 文字コード判定
		String cs = checkCharset(file);

		// Shift_JISのままだと環境依存文字が文字化けするので変換する
		if ("Shift_JIS".equals(cs)) {
			cs = "windows-31j";
		}

		// ファイルを読込む
		try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), cs))) {
			String data = "";
			while ((data = br.readLine()) != null) {
				// １行ずつ読込み、改行を追加する
				ret += data + "\r\n";
			}
			ret = ret.substring(0, ret.length() - 2);
		} catch (Exception e) {
            objLog.error("strFilePath:{}", file.getPath());
            objLog.error("error message", e);
            e.printStackTrace();
            throw e;
		}

		return ret;
    }

	/**
	 * 文字コードを判定する
	 * @param file 判定を行うファイルのファイルオブジェクト
	 * @return CharsetMatch 文字コードを表す文字列
	 * @throws IOException 入出力例外
	 */
    private String checkCharset(File file) throws Exception {

		BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file));

		// 文字コード判別用クラス
		CharsetDetector cd = new CharsetDetector();

		// 入力ストリーム設定
		cd.setText(bis);

		// 文字コード取得
		CharsetMatch cm = cd.detect();

		// 信頼度判定
		if (cm.getConfidence() > 60) {
			return cm.getName();
		}

		// 信頼度が低い場合は自分で判定してみる
		byte[] byte1 = Files.readAllBytes(file.toPath());
		byte[] byte2 = new String(byte1, cm.getName()).getBytes(cm.getName());
		if (Arrays.equals(byte1, byte2)) {
			return cm.getName();
		}

		// UTF-8か判定
		byte2 = new String(byte1, "UTF-8").getBytes("UTF-8");
		if (Arrays.equals(byte1, byte2)) {
			return "UTF-8";
		}

		// ここまでくると判断しきれないのでShift_JISで返す
		return "Shift_JIS";
	}

	/**
	 * 拡張子からファイルの種類を決定する
	 * @param fileName チェック対象のファイル名
	 * @return boolean 0：該当しない 1：テキスト 2：ワード 3：エクセル 4：PowerPoint 5：PDF
	 */
    private int getFileType(String fileName) {

		int ret = FILETYPE_OTHER;

		// 引数チェック
		if (isNullBlank(fileName)) {
			return ret;
		}

		// 拡張子からファイルの種類を決定する
		if (fileName.endsWith(".txt")) {
			// テキストファイル
			ret = FILETYPE_TEXT;
		} else if (fileName.endsWith(".doc") || fileName.endsWith(".docm") || fileName.endsWith(".docx")) {
			// ワードファイル
			ret = FILETYPE_WORD;
		} else if (fileName.endsWith(".xls") || fileName.endsWith(".xlsx") || fileName.endsWith(".xlsm")) {
			// エクセルファイル
			ret = FILETYPE_EXCEL;
		} else if (fileName.endsWith(".ppt") || fileName.endsWith(".pptx")) {
			// PowerPoint
			ret = FILETYPE_PPT;
		} else if (fileName.endsWith(".pdf")) {
			// PDF
			ret = FILETYPE_PDF;
		}

		return ret;
	}

	/**
	 * フォルダ配下を削除する
	 * @param dir 処理起点となるフォルダのファイルオブジェクト
	 * @return boolean 削除結果
	 */
    private boolean deleteFolder(File dir) {
		
		boolean ret = true;

		// フォルダ存在確認
		if (dir.exists()) {

			// listFilesメソッドを使用して一覧を取得する
			File[] list = dir.listFiles();

			for (File objFile : list) {

				// フォルダの場合
				if(objFile.isDirectory()) {

					// フォルダ削除処理を再起呼出しする
					ret = ret && deleteFolder(objFile);

					// 処理起点となるフォルダを削除する
					ret = ret && objFile.delete();
				}

				// ファイルの場合
				if(objFile.isFile()) {

					// ファイルを削除する
					ret = ret && objFile.delete();
				}
				
			}

		}
		return ret;
	}

	/**
	 * 文字列のブランク確認
	 * @param str 文字列
	 * @return boolean true:nullまたはブランク false:設定あり
	 */
    private boolean isNullBlank(String str) {
		boolean ret = false;
		if (str == null || 0 == str.trim().length()) {
			ret = true;
		}
		return ret;
	}
}
