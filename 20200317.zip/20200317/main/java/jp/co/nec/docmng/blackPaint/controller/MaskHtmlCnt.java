/**
 * 名称：MaskHtmlCnt.java
 * 機能名：黒塗り文書作成Control
 * 概要：塗り文書作成のControlを行う。
 */

package jp.co.nec.docmng.blackPaint.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.blackPaint.entity.DocumentInfoEntPaint;
import jp.co.nec.docmng.blackPaint.entity.MaskDocumentEntBlackPaint;
import jp.co.nec.docmng.blackPaint.entity.PolicyInfoEntBlackPaint;
import jp.co.nec.docmng.blackPaint.logic.dirFile.DirCnt;
import jp.co.nec.docmng.blackPaint.logic.dirFile.FileCnt;
import jp.co.nec.docmng.blackPaint.logic.edit.ExcelEdit;
import jp.co.nec.docmng.blackPaint.logic.edit.PdfEdit;
import jp.co.nec.docmng.blackPaint.logic.edit.PowerPointEdit;
import jp.co.nec.docmng.blackPaint.logic.edit.RefEdit;
import jp.co.nec.docmng.blackPaint.logic.edit.TextEdit;
import jp.co.nec.docmng.blackPaint.logic.edit.WordEdit;
import jp.co.nec.docmng.blackPaint.service.DocInfoServicePaint;
import jp.co.nec.docmng.blackPaint.service.MaskDocumentServicePaint;
import jp.co.nec.docmng.blackPaint.service.PolicyInfoServicePaint;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocMarkerServicePaint;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocumentServicePaint;

/**
 * 黒塗り文書作成Control
 */
@Controller
public class MaskHtmlCnt {

	static Logger objLog = LoggerFactory.getLogger(MaskHtmlCnt.class);

	@Autowired
	ServletContext context;
	@Autowired
	DocInfoServicePaint docInfoService;

	@Autowired
	TmpMaskDocMarkerServicePaint tmpMaskDocTmpMarkerService;

	@Autowired
	TmpMaskDocumentServicePaint tmpMaskDocumentService;

	@Autowired
	PolicyInfoServicePaint policyInfoService;

	@Autowired
	MaskDocumentServicePaint maskDocumentServicePaint;

	@Autowired
	private ResourceLoader resourceLoader;

	String strTmpDir = ""; //作業用フォルダ

	HashMap<String, String> hashMask;

	/**
	 * 黒塗り文書作成画面初期表示メソッド<br>
	 * 画面初期表示の処理をする。
	 * @param documentId 文書を一意に特定するID
	 * @param status 空文字: 初期処理 1: 再開 2: 黒塗りリスト確定
	 * @param blackPaintListJson 空文字: 初期処理、再開 値あり：備考のjson
	 * @param documentIdRef 参照文書のドキュメントID
	 * @param strPolicyList 選択した黒塗りポリシーID
	 * @param UserId ユーザID
	 * @param response HTTPレスポンス
	 * @param model 引渡しパラメータ用モデル
	 * @return 遷移先アドレス
	 */
	@GetMapping("/MaskHtmlCnt")
	public synchronized String getblackText(
			@RequestParam("documentId") int documentId,
			@RequestParam(name = "status", defaultValue = "") String status,
			@RequestParam(name = "blackPaintListJson", defaultValue = "") String blackPaintListJson,
			@RequestParam(value = "refDocumentId", required = false) Integer documentIdRef,
			@RequestParam(value = "strPolicyList", required = false) String strPolicyList,
			@CookieValue(value = "user_id", required = false) String UserId,
			HttpServletResponse response,
			Model model) {

		if (!blackPaintListJson.equals("")) {
			objLog.info("json：" + blackPaintListJson);
		} //if

		String aiData = ""; //aiが返すデータ

		String policySelect = "";
		if (strPolicyList != null) {
			policySelect = strPolicyList;
		}

		final FileCnt objFileCnt = new FileCnt();
		final DirCnt objDirCls = new DirCnt();

		final TextEdit objTextCls = new TextEdit();
		final WordEdit objWordCls = new WordEdit();
		final PowerPointEdit objPptCls = new PowerPointEdit();
		final ExcelEdit objExcelCls = new ExcelEdit();
		final RefEdit objRefCls = new RefEdit();
		final PdfEdit objPdfCls = new PdfEdit();

		String strContext = "";
		String strExtension = "";
		List<MaskDocumentEntBlackPaint> listMaskDoc = null;
		try {
			strContext = context.getContextPath().substring(1, context.getContextPath().length());
			objLog.info("contextパス:" + strContext);
		} catch (final Exception e) {
			objLog.info("contextパスは設定されていません");
		} //try

		final String strBasePath = context.getRealPath("/") + strContext;
		final String strTmpUuid = UUID.randomUUID().toString();
		String strTmpDirName = "";
		if (strContext.equals("")) {
			strTmpDirName = "tmp" + strTmpUuid + "/";
		} else {
			strTmpDirName = strContext + "/tmp" + strTmpUuid + "/";
		} //if
		strTmpDir = context.getRealPath("/") + strTmpDirName; //作業用フォルダ
		objLog.info("作業directory:" + strTmpDir);

		final Cookie cookie = new Cookie("strTmpDirName", strTmpDirName);
		cookie.setMaxAge(60 * 3600);
		cookie.setPath("/");
		response.addCookie(cookie);

		objLog.info("作業フォルダ：" + strTmpDirName);

		//contextのディレクトリがない場合だけ作成
		File objTgtDir = new File(strBasePath);
		if (!objTgtDir.exists()) {
			objDirCls.makeDirWithCheck(strBasePath);
		} //if
		objTgtDir = null;

		//DocumentIDでdocument_infoから情報を取得
		List<DocumentInfoEntPaint> listDoc = null;
		listDoc = docInfoService.selectDocInfo(documentId);
		strExtension = listDoc.get(0).getExtension();

		final String strOrgFilePath = listDoc.get(0).getDocumentName();
		objLog.info("対象パス：" + strOrgFilePath);

		String strOrgPath = listDoc.get(0).getFilePath();

		//一度RealPathへファイルをコピーする
		String strFileName = new File(strOrgFilePath).getName();
		String strFileWithoutExtension = objFileCnt.getNameWithoutExtension(strFileName);

		String strHtmlName = documentId + ".html"; //作成html名

		String strEditMarker = "";

		final List<PolicyInfoEntBlackPaint> policyInfoEntities = policyInfoService.findAll();
		// 図・表およびその他ポリシーを削除（リストの後ろから削除）
		for (int i = policyInfoEntities.size() - 1; i >= 0; i--) {
			final PolicyInfoEntBlackPaint pe = policyInfoEntities.get(i);
			Integer intPolicyType = pe.getPolicyType();
			if (intPolicyType == null)
				intPolicyType = 0;

			if (intPolicyType != 0) {
				policyInfoEntities.remove(i);
			}
		}
		if (policySelect == "") {
			for (int i = 0; i < policyInfoEntities.size() - 1; i++) {
				final PolicyInfoEntBlackPaint pe = policyInfoEntities.get(i);
				policySelect += pe.getPolicyId() + ",";
			}
			final PolicyInfoEntBlackPaint pe = policyInfoEntities.get(policyInfoEntities.size() - 1);
			policySelect += pe.getPolicyId() + "";
		}

		//全文検索モックデータ コロン区切りでペアは+区切り intpos,そこからつづく,intpos,そこからつづく
		int intPageCnt = 0;

		String refHtmlName = "";
		String refFileName = "";
		int intRefPageCnt = 0;

		boolean isLink = false;
		Integer intMaskStatus = 0;
		intMaskStatus = listDoc.get(0).getMaskStatus();
		final Integer intNodeId = listDoc.get(0).getNodeId();
		Integer intProcenterFileId = listDoc.get(0).getProcenterFileId();
		final Boolean isProFlag = listDoc.get(0).getProcenterFlg();
		final Date dateDocFileUpdate = listDoc.get(0).getFileUpdateTime();
		if (status.equals("") && (intMaskStatus == 1 || intMaskStatus == 2) && documentIdRef == null) { //※※※紐付けの場合 また初期表示のみ※※※
			objLog.info("紐付け処理対象判別");
			Date dateMaskDocUpdate = null;
			boolean blNodeFileFlag = false; //true:NodeId ProcenterFileIdセット済み　false：NodeId ProcenterFileIdセット無し
			boolean blModify = false; //true:原文書更新　false：原文書更新なし
			if ((intNodeId == 0) || (intProcenterFileId == 0)) {
				blNodeFileFlag = false;
			} else {
				blNodeFileFlag = true;
			} //if
			if (intProcenterFileId != null) {
				listMaskDoc = maskDocumentServicePaint.getMaskDoc(intProcenterFileId);
				if ((listMaskDoc != null) && (!(listMaskDoc.size() == 0))) {
					dateMaskDocUpdate = listMaskDoc.get(0).getUpdateTime();
				} //if

			} //if

			//「document_info」の「file_update_time」>「mask_document」の「update_time」なら文書更新とみなす
			if ((dateDocFileUpdate != null) && (dateMaskDocUpdate != null)) {
				if (dateDocFileUpdate.after(dateMaskDocUpdate)) {
					blModify = true;
				} //if
			} //if

			if (!blNodeFileFlag) {
				objLog.info("document_infoの NodeId またはprocenterFileIdがnullなのでPROCENTER保存データを黒塗りを行います。");
			} else if (blModify) {
				objLog.info("原文書が更新されているので、PROCENTER保存データを黒塗りします。");
			} else if ((intNodeId != null) && (intProcenterFileId != null) && (isProFlag != null)) {
				if (isProFlag) {
					objLog.info("PROCENTER DATAが存在するので紐付け処理を開始します。");
					try {
						//                        hashMask = objLinkCls.linkEditMain(listDoc,listMaskDoc, strTmpDir,resourceLoader);
						//20200227 document_infoから逆引きで拡張子を取得
						List<DocumentInfoEntPaint> listOrgDoc = null;
						listOrgDoc = docInfoService.selectDocInfo(listMaskDoc.get(0).getDocumentId());

						strExtension = listOrgDoc.get(0).getExtension();
						isLink = true;
						//20200310 モデルに入れ込むデータを上書きする
						documentId=listMaskDoc.get(0).getDocumentId();
						strOrgPath=listOrgDoc.get(0).getFilePath();

						//file名は黒塗り対象そのまま表示
						strFileWithoutExtension = objFileCnt.getNameWithoutExtension(new File(strOrgPath).getName());
						strHtmlName = documentId + ".html"; //作成html名

					} catch (final Exception e) {
						objLog.error("紐付けレコード取得処理でエラーが発生しました。document_info mask_documentのレコードを確認しててください", e);
						final MaskHtmlCnt maskHtmlCnt = new MaskHtmlCnt();
						maskHtmlCnt.handleException(e, response, model);
					} //if

				} else {
					objLog.info("PROCENTER DATAが存在しないので紐付けは行いません。");
				} //if
			} else {
				objLog.info("musk_statusは黒塗り済みですが、以下の値のいずれかが不正な為紐付けは行いません。");
				objLog.info("node_id：" + intNodeId);
				objLog.info("procenter_file_id：" + intProcenterFileId);
				objLog.info("procenter_flg：" + isProFlag);
			} //if

		}else if((!blackPaintListJson.equals(""))){ //Cancel、確定などで画面遷移してきた際、JsonからProcenterFileIdを取得する。
			final ObjectMapper objMapper = new ObjectMapper();
			JsonNode root=null;
			try {
				root = objMapper.readTree(blackPaintListJson);
				intProcenterFileId=root.get("glIntProcenterFileId").get(0).asInt();
			} catch (IOException e) {
				objLog.error("JSONパース失敗",e);
				throw new RuntimeException(e);
			} //try

		} //if

		if (documentIdRef != null) { //※※※参照文書※※※
			objLog.info("ref処理開始");
			status = "3";
			hashMask = objRefCls.refEditMain(listDoc, strTmpDir, resourceLoader, documentIdRef, UserId, status,
					tmpMaskDocTmpMarkerService, tmpMaskDocumentService, docInfoService);
			intPageCnt = Integer.parseInt(hashMask.get("strPageCnt"));
			refHtmlName = hashMask.get("strRefHtmlName");
			refFileName = hashMask.get("strRefFileName");
			intRefPageCnt = Integer.parseInt(hashMask.get("strRefPageCnt"));

		} else if (strExtension.equals("txt")) {//※※※txt※※※
			if (isLink) {
				status = "4";
				objLog.info("元文書が存在するので、元文書を表示します。");
			} //if
			objLog.info("txt処理開始");
			hashMask = objTextCls.textEditMain(listDoc, listMaskDoc, strTmpDir, resourceLoader, status, policySelect);
			intPageCnt = Integer.parseInt(hashMask.get("strPageCnt"));
			strEditMarker = hashMask.get("strEditMarker");
			aiData = hashMask.get("aiData");

		} else if (strExtension.contains("doc")) { //※※※word※※※
			if (isLink) {
				status = "4";
				objLog.info("元文書が存在するので、元文書を表示します。");
			} //if
			objLog.info("word処理開始");
			hashMask = objWordCls.wordEditMain(listDoc, listMaskDoc, strTmpDir, resourceLoader, status, policySelect);
			intPageCnt = Integer.parseInt(hashMask.get("strPageCnt"));
			strEditMarker = hashMask.get("strEditMarker");
			aiData = hashMask.get("aiData");
		} else if ((strExtension.equals("xls") || strExtension.equals("xlsx") || strExtension.equals("xlsm"))) { //※※※Excel※※※
			if (isLink) {
				status = "4";
				objLog.info("元文書が存在するので、元文書を表示します。");
			} //if
			objLog.info("excel処理開始");
			hashMask = objExcelCls.excelEditMain(listDoc, listMaskDoc, strTmpDir, resourceLoader, status, policySelect);
			intPageCnt = Integer.parseInt(hashMask.get("strPageCnt"));
			strEditMarker = hashMask.get("strEditMarker");
			aiData = hashMask.get("aiData");
		} else if ((strExtension.equals("ppt") || strExtension.equals("pptx") || strExtension.equals("pptm"))) { //※※※powerpoint※※※
			if (isLink) {
				status = "4";
				objLog.info("元文書が存在するので、元文書を表示します。");
			} //if
			objLog.info("ppt処理開始");
			hashMask = objPptCls.pptEditMain(listDoc, listMaskDoc, strTmpDir, resourceLoader, status, policySelect);
			intPageCnt = Integer.parseInt(hashMask.get("strPageCnt"));
			strEditMarker = hashMask.get("strEditMarker");
			aiData = hashMask.get("aiData");
		} else if (strExtension.equals("pdf")) {
			if (isLink) {
				status = "4";
				objLog.info("元文書が存在するので、元文書を表示します。");
			} //if
				//※※※pdf※※※
			objLog.info("pdf処理開始");
			hashMask = objPdfCls.pdfEditMain(listDoc, listMaskDoc, strTmpDir, resourceLoader, status, policySelect);
			intPageCnt = Integer.parseInt(hashMask.get("strPageCnt"));
			strEditMarker = hashMask.get("strEditMarker");
			aiData = hashMask.get("aiData");
		} //if

		String strMaskOutPath = "";
		String strRedOutPath = "";
		strMaskOutPath = strTmpDirName + "mask_" + strHtmlName;
		strRedOutPath = strTmpDirName + "red_" + strHtmlName;

		//viewへ値を渡す
		// 呼び出し先Jspに渡すデータセット(html出力パスを相対で指定)
		model.addAttribute("strMaskOutPath", strMaskOutPath);
		model.addAttribute("strRedOutPath", strRedOutPath);
		model.addAttribute("strTmpDirName", strTmpDirName); //tmpdirの情報も送る
		model.addAttribute("strPagePx", hashMask.get("strHeight")); //1ページの量
		model.addAttribute("intPageCnt", String.valueOf(intPageCnt)); //ページ数
		model.addAttribute("strFileName", strFileName); //オリジナルfile名 保存時に使用
		model.addAttribute("strFilePath", strOrgPath); //オリジナルfileパス リスト表示時に使用

		//AIデータがどのように来るかわからないのでポリシーなどはクライアントで処理
		if (aiData.equals("")) {
			model.addAttribute("strEditMarker", "");
		} else {
			model.addAttribute("strEditMarker", strEditMarker); //aiでマークしたid等を格納
		} //if

		model.addAttribute("documentId", documentId);//documentId
		model.addAttribute("strFileWithoutExtension", strFileWithoutExtension);//strFileWithoutExtension
		model.addAttribute("reOpenFlg", status);
		model.addAttribute("blackPaintListJson", blackPaintListJson);

		if (!(refHtmlName.equals(""))) {
			// model.addAttribute("refOutPath", "/" + strTmpDirName + refHtmlName);
			model.addAttribute("refOutPath", strTmpDirName + refHtmlName);
		} else {
			model.addAttribute("refOutPath", "");
		}

		model.addAttribute("refFileName", refFileName); // 参照文書ファイル名
		model.addAttribute("intRefPageCnt", String.valueOf(intRefPageCnt)); //ページ数
		try { //たまに遷移が速すぎるため1秒まつ
			Thread.sleep(1000);
		} catch (final InterruptedException e) {
			objLog.error(e.getMessage());
		} //try

		//20200204 add 黒塗りポリシー選択
		model.addAttribute("policySelect", policySelect); // ポリシー選択
		//20200310 ProcenterFileId
		model.addAttribute("intProcenterFileId", intProcenterFileId); // ポリシー選択

		return "blackPaint/MaskHtmlVeiw";
	} //getView1

	/**
	 * エラー画面遷移(黒塗り処理)
	 * @param e 発生したエラー
	 * @param response HTTPレスポンス
	 * @param model 引渡しパラメータ用モデル
	 * @return 遷移先アドレス
	 */
	@ExceptionHandler(Exception.class)
	public String handleException(
			Exception e,
			HttpServletResponse response,
			Model model) {

		//モデル初期化
		final DirCnt objDirCls = new DirCnt();
		final String strTmpDir_i = strTmpDir;

		//作業ディレクトリかたずけ
		if (strTmpDir_i.equals("")) {
			objLog.info("作業ディレクトリの取得が失敗しました");
		} else {
			try {
				//作業ディレクトリ,ファイルかたづけ
				objDirCls.delDirectory(context.getRealPath("/") + strTmpDir_i);
				objLog.info("作業ディレクトリ削除完了");
			} catch (final Exception e1) {
				objLog.info("作業ディレクトリ削除失敗");
			} //try

		} //if

		response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		objLog.error("Error occurred.", e);
		final StringWriter objSw = new StringWriter();
		final PrintWriter objPw = new PrintWriter(objSw);
		e.printStackTrace(objPw);
		objPw.flush();
		final String strError = objSw.toString();
		model.addAttribute("errorMessage", e.getMessage() + "\r\n" + "StackTrace" + "\r\n" + strError);
		objPw.close();
		return "blackPaint/Fail";
	} //method

	/**
	 * 黒塗りリスト確定、黒塗りリストキャンセルメソッド<br>
	 * 「getblackTextTest」経由後「MaskHtmlVeiw」を表示する
	 * @param documentId 文書を一意に特定するID
	 * @param status 空文字: 初期処理 1: 再開 2: 黒塗りリスト確定
	 * @param blackPaintListJson 空文字: 初期処理、再開 値あり：備考のjson
	 * @param documentIdRef 参照文書のドキュメントID
	 * @param strPolicyList 選択した黒塗りポリシーID
	 * @param UserId ユーザID
	 * @param response HTTPレスポンス
	 * @param model 引渡しパラメータ用モデル
	 * @return 遷移先アドレス
	 */
	@PostMapping("/MaskHtmlCnt")
	public String postblackText(
			@RequestParam("documentId") int documentId,
			@RequestParam(name = "status", defaultValue = "") String status,
			@RequestParam(name = "blackPaintListJson", defaultValue = "") String blackPaintListJson,
			@RequestParam(value = "refDocumentId", required = false) Integer documentIdRef,
			@RequestParam(value = "strPolicyList", required = false) String strPolicyList,
			@CookieValue(value = "user_id", required = false) String UserId,
			HttpServletResponse response,
			Model model) {

		getblackText(documentId, status, blackPaintListJson, documentIdRef, strPolicyList, UserId, response, model);
		return "blackPaint/MaskHtmlVeiw";

	} //method

} //MaskHtmlCnt
