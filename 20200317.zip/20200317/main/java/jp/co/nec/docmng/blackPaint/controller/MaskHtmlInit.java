/**
 * 名称：MaskHtmllnit.java
 * 機能名：
 * 概要：
 */

package jp.co.nec.docmng.blackPaint.controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 *
 */
@Controller
public class MaskHtmlInit {

	/**
	 * 黒塗り文書作成画面初期処理メソッド
	 * @param response HTTPレスポンス
	 * @param model 引渡しパラメータ用モデル
	 * @return 遷移先アドレス
	 */
	@GetMapping("blackPaint/MaskHtmlInit")
	public String MaskHtmlInitMain(HttpServletResponse response, Model model) {

		final String DOCUMENT_ID = "568";

		model.addAttribute("DOCUMENT_ID", DOCUMENT_ID);

		return "blackPaint/MaskHtmlInit";
	} //getView1

} //MaskHtmlCnt
