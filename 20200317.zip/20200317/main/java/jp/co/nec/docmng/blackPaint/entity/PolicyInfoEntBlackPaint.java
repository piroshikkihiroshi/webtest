/**
 * 名称：PolicyInfoEntBlackPaint.java
 * 機能名：黒塗り処理黒塗りポリシー設定情報entity
 * 概要：黒塗り処理で使用する黒塗りポリシー設定情報entity
 */

package jp.co.nec.docmng.blackPaint.entity;

import java.sql.Timestamp;

import lombok.Data;

/**
 * 黒塗り処理黒塗りポリシー設定情報entity
 */
@Data
public class PolicyInfoEntBlackPaint {

	/**
	 * ポリシーID
	 */
	private Integer policyId;

	/**
	 * 表示順位
	 */
	private Integer policyNumber;

	/**
	 * 黒塗りポリシー名
	 */
	private String policyName;

	/**
	 * 黒塗りポリシー作成者
	 */
	private String policyAuthor;

	/**
	 * 黒塗り対処理由
	 */
	private String policyReason;

	/**
	 * 作成日時
	 */
	private Timestamp createTime;

	/**
	 * 更新日時
	 */
	private Timestamp updateTime;

	/**
	 * ポリシー種別
	 */
	private Integer policyType;

}
