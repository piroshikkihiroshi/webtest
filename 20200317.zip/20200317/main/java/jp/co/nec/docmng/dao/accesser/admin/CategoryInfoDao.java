package jp.co.nec.docmng.dao.accesser.admin;

import java.io.Reader;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import jp.co.nec.docmng.dao.entity.admin.CategoryInfo;
import jp.co.nec.docmng.dao.entity.admin.CategoryInfoExample;
import jp.co.nec.docmng.dao.mapper.admin.CategoryInfoMapper;

/**
 * CategoryInfoDao
 * 分類軸情報テーブルの全件を取得する。
 */
public class CategoryInfoDao {

	/**
	 * 分類軸情報テーブルの情報を表示する。
	 * @return List&lt;CategoryInfot&gt; categoryInfoList 分類軸情報テーブルの情報リストを取得する。
	 */
	public List<CategoryInfo> getCategoryAll() {

		List<CategoryInfo> categoryInfoList = null;

		try (Reader readerConfig = Resources.getResourceAsReader("mybatis-config.xml");) {

			// 読み込んだ設定ファイルからSqlSessionFactoryを生成する
			SqlSessionFactory sqlFactory = new SqlSessionFactoryBuilder().build(readerConfig);

			// SQLセッションを取得する
			try (SqlSession sqlSession = sqlFactory.openSession()) {

				// 分類軸情報テーブルのMapperを取得する
				CategoryInfoMapper categoryInfoMapper = sqlSession.getMapper(CategoryInfoMapper.class);

				// 分類軸情報テーブルの条件検索用クラスを生成する
				CategoryInfoExample categoryInfoExample = new CategoryInfoExample();

				categoryInfoExample.setOrderByClause("category_id");

				// 上記の条件でテーブルを検索する
				categoryInfoList = categoryInfoMapper.selectByExample(categoryInfoExample);
			}
		} catch (Exception e) {
			// テーブル情報を取得できない場合
			e.printStackTrace();
		}
		return categoryInfoList;
	}

}
