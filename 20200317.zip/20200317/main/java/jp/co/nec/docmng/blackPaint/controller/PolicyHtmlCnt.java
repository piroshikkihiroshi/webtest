/**
 * 名称：PolicyHtmlCnt.java
 * 機能名：黒塗りポリシー選択画面画面コントローラー
 * 概要：黒塗りポリシー選択画面の制御を実施する
 */
package jp.co.nec.docmng.blackPaint.controller;

import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jp.co.nec.docmng.blackPaint.entity.PolicyInfoEntBlackPaint;
import jp.co.nec.docmng.blackPaint.entity.PolicyKeywordInfoBlackPaint;
import jp.co.nec.docmng.blackPaint.service.PolicyInfoServicePaint;
import jp.co.nec.docmng.blackPaint.service.PolicyKeywordInfoServicePaint;

/**
 * 黒塗りポリシー一覧表示Control
 */
@Controller
@RequestMapping("/PolicyHtmlCnt")
public class PolicyHtmlCnt {

	private static Logger objLog = LoggerFactory.getLogger(PolicyHtmlCnt.class);

	private static final int DISPLAY_LIMIT_PIECE = 3;

	@Autowired
	PolicyInfoServicePaint policyInfoService;
	@Autowired
	PolicyKeywordInfoServicePaint policyKeywordInfoService;

	/**
	 * 黒塗りポリシー選択画面初期表示メソッド<br>
	 * 黒塗りポリシー初期表示に必要なデータを取得し表示する。<br>
	 * @param policySelect 選択された黒塗りポリシーID
	 * @param model モデル
	 * @return 遷移先アドレス
	 */
	@GetMapping
	public String getPolicyInfo(
			@RequestParam("policySelect") String policySelect,
			Model model) {

		objLog.info("getPolicyInfo request start");
		// 全件取得
		final List<PolicyInfoEntBlackPaint> policyInfoEntities = policyInfoService.findAll();
		final List<PolicyKeywordInfoBlackPaint> policyKeywordInfos = policyKeywordInfoService.findAll();

		// 50文字を超える対象黒塗りポリシー該当キーワードの51文字目以降を省略する
		int keywordCnt = 0;
		int tmpPolicyId = -1;
		for (int i = 0; i < policyKeywordInfos.size(); i++) {
			// 前要素のポリシーIDと今回のポリシーIDを比較し同じ時カウンターを+1
			if (tmpPolicyId == policyKeywordInfos.get(i).getPolicyId()) {
				keywordCnt++;
				// 前回のポリシーIDと変化があった時初期化
			} else {
				// カウンター初期化
				keywordCnt = 0;
			}
			// ビュー側で表示切替が難しいためコントローラで同一ポリシーのキーワード4個目以降を非表示とするフラグを設定
			if (DISPLAY_LIMIT_PIECE <= keywordCnt) {
				policyKeywordInfos.get(i).setViewFlag(false);
			}
			// ポリシーID保持
			tmpPolicyId = policyKeywordInfos.get(i).getPolicyId();
		}

		// 図・表およびその他ポリシーを削除（リストの後ろから削除）
		for (int i = policyInfoEntities.size() - 1; i >= 0; i--) {
			final PolicyInfoEntBlackPaint pe = policyInfoEntities.get(i);

			if (!Objects.equals(pe.getPolicyType(), 0)) {
				policyInfoEntities.remove(i);
			}
		}

		// レスポンス情報セット
		model.addAttribute("policyInfo", policyInfoEntities);
		model.addAttribute("policyKeywordInfos", policyKeywordInfos);
		model.addAttribute("policySelect", policySelect);
		objLog.trace("policyInfoEntities:{}", policyInfoEntities);
		objLog.trace("policyInfoEntities:{}", policyInfoEntities);
		objLog.info("getPolicyInfo request end (success)");
		return "blackPaint/SelectPolicyHtmlVeiw";
	}

}
