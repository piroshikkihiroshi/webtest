/**
 * 名称：SearchServerInfoMapManage.java
 * 機能名：管理系検索対象サーバ設定情報連携
 * 概要：管理系にて使用する検索対象サーバ設定情報への連携用レポジトリ
 */

package jp.co.nec.docmng.manage.util.map;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import jp.co.nec.docmng.manage.entity.SearchServerInfoEntity;

/**
 * 管理系検索対象サーバ設定情報連携
 */
@Mapper
public interface SearchServerInfoMapManage {

	/**
	 * 全件取得
	 * @return 検索結果
	 */
    @Select("select * from admin.search_server_info order by server_id")
    public List<SearchServerInfoEntity> findAll();

	/**
	 * データ登録
	 * @param searchServerInfo 登録情報
	 */
    @Insert("insert into admin.search_server_info (server_name,display_name,login_user_name,login_password,directory_path,create_time,update_time) values (#{serverName},#{displayName},#{loginUserName},#{loginPassword},#{directoryPath},#{createTime},#{updateTime})")
    public void insert(SearchServerInfoEntity searchServerInfo);

	/**
	 * データ更新_サーバID指定
	 * @param searchServerInfo 更新情報
	 */
    @Update("update admin.search_server_info set server_name = coalesce(#{serverName}, server_name), display_name = coalesce(#{displayName}, display_name), login_user_name = coalesce(#{loginUserName}, login_user_name), login_password = coalesce(#{loginPassword}, login_password), directory_path = coalesce(#{directoryPath}, directory_path), update_time = coalesce(#{updateTime}, update_time) where server_id = #{serverId}")
    public void update(SearchServerInfoEntity searchServerInfo);

	/**
	 * データ削除_サーバID指定
	 * @param id サーバID
	 */
    @Delete("delete from admin.search_server_info where server_id = #{serverId}")
    public void deleteById(Integer id);

}
