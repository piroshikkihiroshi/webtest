/**
 * 名称：DocumentInfoEntPaint.java
 * 機能名：黒塗り処理文書情報entity
 * 概要：黒塗り処理で使用する文書情報entity
 */

package jp.co.nec.docmng.blackPaint.entity;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 黒塗り処理文書情報entity
 */
public class DocumentInfoEntPaint {

	/**
	 * documentId getter
	 * @return documentId
	 */
	public int getDocumentId() {
		return documentId;
	}

	/**
	 * documentId setter
	 * @param documentId
	 */
	public void setDocumentId(Integer documentId) {
		this.documentId = documentId;
	}

	/**
	 * documentContents getter
	 * @return documentContents
	 */
	public String getDocumentContents() {
		return documentContents;
	}

	/**
	 * documentContents setter
	 * @param documentContents
	 */
	public void setDocumentContents(String documentContents) {
		this.documentContents = documentContents;
	}

	/**
	 * htmlZipData getter
	 * @return htmlZipData
	 */
	public byte[] getHtmlZipData() {
		return htmlZipData;
	}

	/**
	 * htmlZipData setter
	 * @param htmlZipData
	 */
	public void setHtmlZipData(byte[] htmlZipData) {
		this.htmlZipData = htmlZipData;
	}

	/**
	 * serverId getter
	 * @return serverId
	 */
	public int getServerId() {
		return serverId;
	}

	/**
	 * serverId setter
	 * @param serverId
	 */
	public void setServerId(Integer serverId) {
		this.serverId = serverId;
	}

	/**
	 * documentName getter
	 * @return documentName
	 */
	public String getDocumentName() {
		return documentName;
	}

	/**
	 * documentName setter
	 * @param documentName
	 */
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	/**
	 * extension getter
	 * @return extension
	 */
	public String getExtension() {
		return extension;
	}

	/**
	 * extension setter
	 * @param extension
	 */
	public void setExtension(String extension) {
		this.extension = extension == null ? null : extension.trim();
	}

	/**
	 * documentSize getter
	 * @return documentSize
	 */
	public BigDecimal getDocumentSize() {
		return documentSize;
	}

	/**
	 * documentSize setter
	 * @param documentSize
	 */
	public void setDocumentSize(BigDecimal documentSize) {
		this.documentSize = documentSize;
	}

	/**
	 * parentId getter
	 * @return parentId
	 */
	public int getParentId() {
		return parentId;
	}

	/**
	 * parentId setter
	 * @param parentId
	 */
	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}

	/**
	 * filePath getter
	 * @return filePath
	 */
	public String getFilePath() {
		return filePath;
	}

	/**
	 * filePath setter
	 * @param filePath
	 */
	public void setFilePath(String filePath) {
		this.filePath = filePath == null ? null : filePath.trim();
	}

	/**
	 * marker getter
	 * @return marker
	 */
	public String getMarker() {
		return marker;
	}

	/**
	 * marker setter
	 * @param marker
	 */
	public void setMarker(String marker) {
		this.marker = marker == null ? null : marker.trim();
	}

	/**
	 * categoryId getter
	 * @return categoryId
	 */
	public int getCategoryId() {
		return categoryId;
	}

	/**
	 * categoryId setter
	 * @param categoryId
	 */
	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}

	/**
	 * procenterFlg getter
	 * @return procenterFlg
	 */
	public Boolean getProcenterFlg() {
		return procenterFlg;
	}

	/**
	 * procenterFlg setter
	 * @param procenterFlg
	 */
	public void setProcenterFlg(Boolean procenterFlg) {
		this.procenterFlg = procenterFlg;
	}

	/**
	 * retentionPeriod getter
	 * @return retentionPeriod
	 */
	public Date getRetentionPeriod() {
		return retentionPeriod;
	}

	/**
	 * retentionPeriod setter
	 * @param retentionPeriod
	 */
	public void setRetentionPeriod(Date retentionPeriod) {
		this.retentionPeriod = retentionPeriod;
	}

	/**
	 * author getter
	 * @return author
	 */
	public String getAuthor() {
		return author;
	}

	/**
	 * author setter
	 * @param author
	 */
	public void setAuthor(String author) {
		this.author = author;
	}

	/**
	 * updater getter
	 * @return updater
	 */
	public String getUpdater() {
		return updater;
	}

	/**
	 * updater setter
	 * @param updater
	 */
	public void setUpdater(String updater) {
		this.updater = updater;
	}

	/**
	 * authorizer getter
	 * @return authorizer
	 */
	public String getAuthorizer() {
		return authorizer;
	}

	/**
	 * authorizer setter
	 * @param authorizer
	 */
	public void setAuthorizer(String authorizer) {
		this.authorizer = authorizer;
	}

	/**
	 * fileUpdateTime getter
	 * @return fileUpdateTime
	 */
	public Date getFileUpdateTime() {
		return fileUpdateTime;
	}

	/**
	 * fileUpdateTime setter
	 * @param fileUpdateTime
	 */
	public void setFileUpdateTime(Date fileUpdateTime) {
		this.fileUpdateTime = fileUpdateTime;
	}

	/**
	 * maskStatus getter
	 * @return maskStatus
	 */
	public int getMaskStatus() {
		return maskStatus;
	}

	/**
	 * maskStatus setter
	 * @param maskStatus
	 */
	public void setMaskStatus(Integer maskStatus) {
		this.maskStatus = maskStatus;
	}

	/**
	 * createTime getter
	 * @return createTime
	 */
	public Date getCreateTime() {
		return createTime;
	}

	/**
	 * createTime setter
	 * @param createTime
	 */
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	/**
	 * updateTime getter
	 * @return updateTime
	 */
	public Date getUpdateTime() {
		return updateTime;
	}

	/**
	 * updateTime setter
	 * @param updateTime
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	/**
	 * node_id getter
	 * @return node_id
	 */
	public int getNodeId() {
		return nodeId;
	}

	/**
	 * node_id setter
	 * @param node_id
	 */
	public void setNodeId(int node_id) {
		this.nodeId = node_id;
	}

	/**
	 * procenter_file_id getter
	 * @return procenter_file_id
	 */
	public int getProcenterFileId() {
		return procenterFileId;
	}

	/**
	 * setProcenterFileId setter
	 * @param procenter_file_id
	 */
	public void setProcenterFileId(int procenter_file_id) {
		this.procenterFileId = procenter_file_id;
	}

	/**
	 * procenter_parent_id getter
	 * @return procenter_parent_id
	 */
	public int getProcenterParentId() {
		return procenterParentId;
	}

	/**
	 * procenter_parent_id setter
	 * @param procenter_parent_id
	 */
	public void setProcenterParentId(int procenter_parent_id) {
		this.procenterParentId = procenter_parent_id;
	}

	/**
	 * 文書ID
	 */
	private int documentId;

	/**
	 * 全文検索用text
	 */
	private String documentContents;

	/**
	 * HTML群(zip圧縮)
	 */
	private byte[] htmlZipData;

	/**
	 * サーバID
	 */
	private int serverId;

	/**
	 * 文書名
	 */
	private String documentName;

	/**
	 * 拡張子
	 */
	private String extension;

	/**
	 * 文書サイズ
	 */
	private BigDecimal documentSize;

	/**
	 * 親ディレクトリID
	 */
	private int parentId;

	/**
	 * パス
	 */
	private String filePath;

	/**
	 * 黒塗り箇所
	 */
	private String marker;

	/**
	 * 分類軸ID
	 */
	private int categoryId;

	/**
	 * PROCENTERフラグ
	 */
	private Boolean procenterFlg;

	/**
	 * 保存期間
	 */
	private Date retentionPeriod;

	/**
	 * 文書作成者
	 */
	private String author;

	/**
	 * 文章更新者
	 */
	private String updater;

	/**
	 * 文書承認者
	 */
	private String authorizer;

	/**
	 * 文書更新日時
	 */
	private Date fileUpdateTime;

	/**
	 * 黒塗り状態
	 */
	private int maskStatus;

	/**
	 * 作成日時
	 */
	private Date createTime;

	/**
	 * 更新日時
	 */
	private Date updateTime;

	/**
	 * ノードID
	 */
	private int nodeId;

	/**
	 * ファイルID
	 */
	private int procenterFileId;

	/**
	 * PROCENTER親ディレクトリID
	 */
	private int procenterParentId;

}
