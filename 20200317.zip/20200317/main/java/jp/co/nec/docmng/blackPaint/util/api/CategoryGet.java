/**
 * 名称：CategoryGet.java
 * 機能名：分類テーブル一覧json取得
 * 概要：分類テーブル一覧をjsonで取得する
 */

package jp.co.nec.docmng.blackPaint.util.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.blackPaint.entity.CategoryEntPaint;
import jp.co.nec.docmng.blackPaint.service.CategoryServicePaint;

/**
 * 分類テーブル一覧json取得
 */
@RestController
public class CategoryGet {

	@Autowired
	CategoryServicePaint objCategoryService;

	/**
	 * 分類テーブル一覧をjsonで取得する
	 * @return String 分類テーブル全件
	 */
	@GetMapping("/rest/category/all")
	public String getPolicyAll() {
		String strRet = "";
		final List<CategoryEntPaint> listPolicy = objCategoryService.findAll();

		final ObjectMapper objMapper = new ObjectMapper();
		try {
			strRet = objMapper.writeValueAsString(listPolicy);
		} catch (final JsonProcessingException e) {
			e.printStackTrace();
		}
		return strRet;
	} //getPlicyAll

} //PolicyGet
