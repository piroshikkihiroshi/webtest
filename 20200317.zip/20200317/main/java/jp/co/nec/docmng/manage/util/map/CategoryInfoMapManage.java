/**
 * 名称：CategoryMapPaint.java
 * 機能名：管理系カテゴリー情報連携
 * 概要：管理系にて使用するカテゴリー情報への連携用レポジトリ
 */

package jp.co.nec.docmng.manage.util.map;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import jp.co.nec.docmng.manage.entity.CategoryInfo;

/**
 * 管理系カテゴリー情報連携
 */
@Mapper
public interface CategoryInfoMapManage {

	/**
	 * 全件取得(カテゴリー種別が0のレコード)
	 * @return 検索結果
	 */
    @Select("select * from admin.category_info where category_type = 0 order by category_id")
    public List<CategoryInfo> findAll();

	/**
	 * データ登録
	 * @param record 登録情報
	 */
    @Insert("insert into admin.category_info (category_name, category_author, create_time, update_time, category_type) values (#{categoryName}, #{categoryAuthor},  #{createTime}, #{updateTime}, #{categoryType})")
    public void insertCategoryList(CategoryInfo record);

	/**
	 * カテゴリー名更新
	 * @param categoryInfo 更新情報
	 */
    @Update("update admin.category_info set category_name = #{categoryName}, update_time = #{updateTime} where category_id = #{categoryId}")
    public void updateCategoryList(CategoryInfo categoryInfo);

	/**
	 * データ削除_カテゴリー指定
	 * @param deleteRow カテゴリーID
	 */
    @Delete("delete from admin.category_info where category_id = #{categoryId}")
    public void deleteCategoryList(Integer deleteRow);

}
