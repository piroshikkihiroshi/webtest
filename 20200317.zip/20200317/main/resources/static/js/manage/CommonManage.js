/**
 * @fileOverview 管理機能共通スクリプト
 * @author NEC
 * @version 1.0.0
 * @desc 機能名：管理機能
 * @desc 画面名：管理画面共通
 */


/**
 * 管理画面表示前処理
 * @param {Object} windowFlag 呼び出し元画面を表すフラグ（0：検索対象サーバ設定 1：黒塗りポリシー設定 2：教師データ(分類)登録 3：教師データ(黒塗り箇所抽出)登録）
 */
function beforeManageOpen(windowFlag){
    try {
    	// 特に何もしない
    } catch (error) {
        console.log(error);
    }
}


/**
 * 管理画面閉じた後処理
 * @param {Object} windowFlag 呼び出し元画面を表すフラグ（0：検索対象サーバ設定 1：黒塗りポリシー設定 2：教師データ(分類)登録 3：教師データ(黒塗り箇所抽出)登録）
 */
function afterManageClose(windowFlag) {
    try {
        if ((window.opener) && (Object.keys(window.opener).length)) {
            if (window.opener.SearchMain && typeof window.opener.SearchMain.deleteMngWindowFlag === 'function') {
                window.opener.SearchMain.deleteMngWindowFlag(windowFlag);
            }
        }
    } catch (error) {
        console.log(error);
    }
}
