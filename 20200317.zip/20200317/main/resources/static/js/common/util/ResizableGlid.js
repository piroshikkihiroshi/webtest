"use strict"

class ResizableGrid {
    constructor(dom, lineAndColumns) {
        this.alignHeightCounter = 0;
        this.dom = dom;
        this.dom.style.position = "relative",
            this.lineAndColumns = lineAndColumns;
        console.log(this.lineAndColumns)
        this.height = this.dom.clientHeight;
        this.domPos = this.dom.getBoundingClientRect()
        this.gridColumns = [];
        this.onMouseMoveCallBack = param => this._onMouseMoveCallBack(param);
        this.onMouseUpCallback = param => this._onMouseUpCallback(param);
        this.lineAndColumns[0].slice(0, this.lineAndColumns[0].length).map((item, i) => {
            console.log("item");
            console.log(item);
            if (item.className.match(/free/)) {
                var mode = "free"
            } else if (item.className.match(/fix/)) {
                var mode = "fix"
            } else {
                var mode = "resize"
            }
            let pos = item.getBoundingClientRect()

            if (i < this.lineAndColumns[0].length - 1) {
                var isLast = false;
            } else {
                var isLast = true;
            }
            //////////////////////////////////////////
            let gridItem = new GridItem({
                id: i,
                chargedDom: item,
                x: pos.right - this.domPos.left > 0 ? pos.right - this.domPos.left : 0,
                height: this.height,
                parent: this,
                callback: this.onMouseMoveCallBack,
                onMouseUpCallback: this.onMouseUpCallback,
                mode: mode,
                isLast: isLast
            })
            console.log("pos");
            console.log(pos);
            console.log(this.domPos);
            console.log(this.domPos.left);

            //////////////////////////////////////////
            if (mode === "resize") {
                this.dom.appendChild((
                    gridItem.UIDom
                ))
            }
            this.gridColumns.push(gridItem)
        })
        console.log(this.gridColumns)
        this._setSizeForEachGrid();
        window.addEventListener("resize", this.resizeHandler.bind(this))
    }
    /////////////////////////////////////////
    _onMouseUpCallback(param) {
        this._setGridColumnsPos()
    }
    _setGridColumnsPos() {
        let total = 0
        this.gridColumns.map(item => {
            item.x = item.width + total;
            total += item.width;
        })
    }
    resizeHandler(event) {
        this._resizeGrid()
    }
    _resizeGrid() {
        let width = this.dom.clientWidth - 35; // 変わったあとの横幅
        let originalTotalWidth = 0;//サイズが変わる前のトータル
        let totalWidthFix = 0;//サイズが変わる方のトータル
        let totalWidthFlex = 0;//サイズが変わる方のトータル
        this.gridColumns.map(item => {
            originalTotalWidth += item.width;
            if (item.mode === "fix") {
                totalWidthFix += item.width;
            } else {
                totalWidthFlex += item.width;
            }
        })
        this.gridColumns.map(item => {
            if (item.mode !== "fix") {
                let a = item.width / ((originalTotalWidth - totalWidthFix) / (width - totalWidthFix))
                item.width = a
            } else {
            }
        })
        // this._setSizeForEachGrid()
        this.lineAndColumns.map((line, lineNum) => {
            line.map((item, i) => {
                item.className = item.className.replace(/w[0-9]*/, "");//幅を決めているCSSクラスを削除
                if (lineNum !== 0) {
                    item.style.width = this.gridColumns[i].width + "px";
                } else {
                    /// ヘッダー行はすでにセットされているのでここではセットしない
                    // item.style.width = this.gridColumns[i].width + "px";
                }
            })
        })
        this._setGridColumnsPos()
        // console.log("line", width, totalWidthFix)

    }


    /////////////////////////////////////////
    // ドラッグ処理
    /////////////////////////////////////////
    _onMouseMoveCallBack(param) {
        this._setSizeForEachGrid(param)
    }
    _setSizeForEachGrid(param) {
        if (window.alignHeight) {
            console.log(window.alignHeight)
            this.alignHeightCounter++
            setTimeout(() => {
                if (--this.alignHeightCounter === 0) {
                    console.log("window.alignHeight.resize call")
                    window.alignHeight.resize()
                }
            }, 100);
        }

        // console.log(param)
        let columnWidth = []
        let totalLength = 0;
        // 各カラムの幅を計算
        this.gridColumns.map((item, i) => {
            columnWidth[i] = Number(item.x) - totalLength;
            totalLength = totalLength + columnWidth[i];
        })
        // // ドラッグ中カラムか、その右隣りのセルの幅が50未満だったら弾いて処理終了
        if (param) {
            if (columnWidth[param.id] < 50 || columnWidth[param.id + 1] < 50) return
        }

        // それぞれのセルの幅を設定
        this.lineAndColumns.map((line, lineNum) => {
            line[0].parentNode.style.overflow = "hidden"
            line.map((item, i) => {
                item.className = item.className.replace(/w[0-9]*/, "");//幅を決めているCSSクラスを削除
                if (lineNum !== 0) {
                    if (line.length - 1 === i) {
                        item.style.width = columnWidth[i] - 20 + "px";//最後の行
                    } else {
                        item.style.width = columnWidth[i] + "px";
                    }
                } else {
                    // [注意]一行目だけ gridColumnsを参照する
                    this.gridColumns[i].width = columnWidth[i]
                }
            })
        })
    }
}




class GridItem {
    constructor(param) {
        // 変数初期化
        this.id = param.id
        this.parent = param.parent;
        this.chargedDom = param.chargedDom;
        this.width = this.chargedDom.clientWidth;
        this.mode = param.mode;
        this.isLast = param.isLast;
        this.callback = param.callback;
        this.onMouseUpCallback = param.onMouseUpCallback;
        this.UIDom = document.createElement("div");
        this.UIDom.style.width = "8px";
        this.UIDom.style.height = Number(param.height) + "px";
        this.UIDom.style.position = "absolute";
        this.UIDom.style.top = 0;
        this.UIDom.style.left = Number(param.x) + "px";
        this.x = Number(param.x);
        this.UIDom.style.cursor = "ew-resize";
        this.UIDom.style.background = "#f00";
        this.UIDom.style.opacity = 0;
        // インタラクション
        this.onMouseDown = event => this._onMouseDown(event);
        this.onMouseMove = event => this._onMouseMove(event);
        this.onMouseUp = event => this._onMouseUp(event);
        this.UIDom.addEventListener("mousedown", this.onMouseDown)
        this.isDragging = false;
    }
    /**
     * @param {number} value
     */
    set x(value) {
        // console.log(this.width, this._width,this.id)
        this.UIDom.style.left = (value - (Number(this.UIDom.style.width.replace("px", "")) / 2) + "px")
    }
    get x() {
        return Number(this.UIDom.style.left.replace("px", "")) + Number(Number(this.UIDom.style.width.replace("px", "")) / 2)
    }
    /**
     * @param {any} height
     */
    set height(height) {
        this.UIDom.style.height = Number(height) + "px"
    }
    get width() {
        let ret = this._width
        return ret
    }
    set width(width) {
        // console.log(width, this.chargedDom)
        this._width = width;
        if (this.isLast) {
            this.chargedDom.style.width = (this._width) + "px"
        } else {
            this.chargedDom.style.width = (this._width) + "px"
        }
    }

    ////////////////////////////////////////////////////////////
    // 以下マウスインタラクション関連
    ////////////////////////////////////////////////////////////
    _onMouseDown(event) {
        this.idDragging = true;
        this.parent.dom.addEventListener("mousemove", this.onMouseMove)
        this.parent.dom.addEventListener("mouseout", this.onMouseMove)
        window.addEventListener("mouseup", this.onMouseUp)
    }
    _onMouseMove(event) {
        this.x = event.x - 2;
        this.callback({
            x: this.x,
            id: this.id,
        })
    }
    _onMouseUp(event) {
        this.parent.dom.removeEventListener("mousemove", this.onMouseMove)
        this.parent.dom.removeEventListener("mouseout", this.onMouseMove)
        this.onMouseUpCallback()
        window.removeEventListener("mouseup", this.onMouseUp)
    }
}