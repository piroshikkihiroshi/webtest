/** 
 * @fileOverview UITestManagerHOZON
 * @author NEC
 * @version 1.0.0
  * @description ボタンのトグルを行う
 */
/**
 * @class UITestManagerHOZON
 * @param param.targetButtons
 * @description ボタンのトグルを行う
 */
'use strict'
class UITestManagerHOZON {
    constructor(param) {
        var pagerButton1 = param.pager.button1;
        var pagerButton2 = param.pager.button2;
        var pagerInput = param.pager.input;
        this.initPager(pagerButton1, pagerButton2, pagerInput);
    }
    initPager(pagerButton1, pagerButton2, pagerInput) {
        pagerButton1.addEventListener("change", event => {
            if (event.target.checked) {
                pagerInput.disabled = true;
            }
        })
        pagerButton2.addEventListener("change", event => {
            if (event.target.checked) {
                pagerInput.disabled = false;
            }
        })
    }
}