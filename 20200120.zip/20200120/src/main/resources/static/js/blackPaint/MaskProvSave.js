//定数等
const TODAY = getNowYMD();
const MASK_HEAD = "mask_";
const RED_HEAD = 'red_';
const RED_FILE_NAME = "(査閲用)";
const MSK_FILE_NAME = "(公開用)";
const LST_FILE_NAME = "(黒塗諸元)";
const DROP_DOWN_ON_CLS = "dropdown_on";
const CATE_LIST_CLS ="cate_list"

var glIntPageAct = 1;
var glArrPaths = []; //maskpdfPath
var glArrRedPaths = []; //maskpdfPath

var glStrJson='';
var isPost = false;

/**
 * 本日日付を取得する
 * @return yyyy/mm/dd hh:mm形式の本日日付
 *  */
function getNowYMD() {
    var objDate = new Date();
    var strYear = objDate.getFullYear();
    var strMonth = ("00" + (objDate.getMonth() + 1)).slice(-2);
    var strDate = ("00" + objDate.getDate()).slice(-2);
    var strHour = ("00" + objDate.getHours()).slice(-2);
    var strMinutes = ("00" + objDate.getMinutes()).slice(-2);

    var result = strYear + "/" + strMonth + "/" + strDate +' ' + strHour + ':' + strMinutes;
    return result;
} //getNowYMD

/**
 * 来年日付を取得する
 * @return yyyy/mm/dd形式の本日日付
 *  */
function getNextYear() {
    var objDate = new Date();
    objDate.setYear(objDate.getFullYear()+1)
    var strYear = objDate.getFullYear();
    var strMonth = ("00" + (objDate.getMonth() + 1)).slice(-2);
    var strDate = ("00" + objDate.getDate()).slice(-2);
    var result = strYear + "/" + strMonth + "/" + strDate;
    return result;
} //getNowYMD



/**
 * 保存ファイル名を作成し、親フレームに埋め込む
 */
function makeSaveName() {
    var arrNames = glFileName.split(".");
    $("#redFileName")[0].innerText = arrNames[0]+RED_FILE_NAME + ".pdf";
    $("#mskFileName")[0].innerText = arrNames[0]+MSK_FILE_NAME + ".pdf";
    $("#lstFileName")[0].innerText = arrNames[0]+LST_FILE_NAME + ".pdf";
} //makeSaveName


/**
 * 次のページへページネーションする
 */
function pageNext() {
    if ( glIntPageAct < PAGE_MAX ) {
        //iframeの入れ替え
        var intActPage = glIntPageAct; //ページは自由入力なのでgl変数に保持している
        intActPage++;
        var strSrc = glArrPaths[intActPage-1];
        document.getElementById("pdf_src").src = strSrc;

        //親フレームの表示変更
        document.getElementById('pager_page_id').value = intActPage;
        glIntPageAct = intActPage;
    } //if
} //functon

/**
 * 前のページへページネーションする
 */
function pageBack() {
    if ( Number(glIntPageAct)>1 ) {
        //iframeの入れ替え
        var intActPage = glIntPageAct; //ページは自由入力なのでgl変数に保持している
        intActPage--;
        var strSrc = glArrPaths[intActPage-1];
        document.getElementById("pdf_src").src = strSrc;

        //親フレームの表示変更
        document.getElementById('pager_page_id').value = intActPage;
        glIntPageAct = intActPage;
    } //if

} //functon

/**
 * 指定したページへページネーションする
 */
function pageSelect(intTgtPage_i) {
    var strSrc = glArrPaths[intTgtPage_i-1];
    document.getElementById("pdf_src").src = strSrc;

    glIntPageAct = intTgtPage_i;
} //functon


/**
 * テキストボックスに入力したページへページネーションする
 */
function enterPager() {
	if ( event.keyCode !== 13 ) { // Enterキー除外
	    return false;
	}
	var intPage = Number(document.getElementById('pager_page_id').value);
	if((intPage!==undefined) && (intPage !==0) && (intPage<=PAGE_MAX) && (intPage >= 0) ){
    	pageSelect(intPage);
    	glIntPageAct= intPage;

	} //if
} //function

/**
* 分類一覧を取得する
* @return boolean
*/
function getCategoryAll(){
    $.ajax({
        type: 'GET',
        url: 'rest/category/all',
        processData: false, // Ajaxがdataを整形しない指定
        contentType: false, // contentTypeもfalseに指定(Fileをアップロード時は必要)
        async:false, //非同期false
        success: function (retData) {
            glCategoryLists=JSON.parse(retData);
            console.log("success");
            return false;
        }, //function
        error: function (e) {
            console.log("fail");
            return false;
        } //function
    }); //ajax

} //function


/**
* 分類プルダウンの初期設定する
*/
function setInitCategory() {

    //categoryList用HTML
    var strCateHtml = '';
    var intCategoryId= glDocumentInfoLists[0]["categoryId"];
    for (let i = 0; i < glCategoryLists.length; i++) {
        if (i===intCategoryId) {
            strCateHtml+='<li class=" '+CATE_LIST_CLS+ ' '+DROP_DOWN_ON_CLS+'" value="'+ glCategoryLists[i].category_id + '">'+ glCategoryLists[i].category_name + '</li>';
        }else{
            strCateHtml+='<li class=" '+CATE_LIST_CLS+ '" value="'+ glCategoryLists[i].category_id + '">'+ glCategoryLists[i].category_name + '</li>';
        } //if
    } //for
    $("#catedrop")[0].innerHTML = strCateHtml;
    var objInitCate= document.getElementById("cateselect");
    for (let i = 0; i < glCategoryLists.length; i++) {
        var intCurrentId = glCategoryLists[i].category_id;
        if (intCategoryId===intCurrentId) {
            objInitCate.innerText = glCategoryLists[i].category_name;
            break;
        } //if
    } //for
} //function

/**
 **********イベント イベント操作関係 **********
*/

/**
 * マウスダウンイベント
*/
function cateSelect(e) {

    //list内処理
    var listClass=$("."+CATE_LIST_CLS);
    var objCate= document.getElementById("cateselect");
    objCate.innerText = e.target.innerText;

    //全消し
    listClass.removeClass(DROP_DOWN_ON_CLS);
    //addClass
    e.target.classList.add(DROP_DOWN_ON_CLS);

} //function


/**
 * マウスダウンイベント
*/
function mouseDownAct(e) {

    //分類軸設定イベント
    if (e.target.className.indexOf(CATE_LIST_CLS) >= 0) {
        cateSelect(e);
        return ;
    } //if

} //function


/**
 * PROCENTER/C、mask_documentテーブルに指定ページの黒塗りPDF、黒塗り候補PDF、黒塗りリストを保存する
*/
function saveDoc() {

	if ($("#PAGE_SETTING2").prop("checked")) {
		var strPages = $('#page_input')[0].value;
		if( ( strPages == '') ) {
			alert("ページ数が指定されていません。");
	        return;
		}else if( ( strPages.match( /[^\d\-\,]+/ )) ){
			alert("「数字(半角)」と「-」と「,」しか使用できません。");
	        return;
		}

		var arrComma = strPages.split(',');
		for (let i = 0; i < arrComma.length; i++) {
			 if (arrComma[i].indexOf('-') >= 0) {
				 var arrHyphen=arrComma[i].split('-');
				 if(Number(arrHyphen[0]) < 0 || PAGE_MAX < Number(arrHyphen[0])){
					 alert("「指定したページ」にページ範囲外を指定しています");
				     return;
				 }else if(Number(arrHyphen[1]) < 0 || PAGE_MAX < Number(arrHyphen[1])){
					 alert("「指定したページ」にページ範囲外を指定しています");
				     return;
				 }
			 }else if(Number(arrComma[i]) < 0 || PAGE_MAX < Number(arrComma[i])){
				 alert("「指定したページ」にページ範囲外を指定しています");
			     return;
			 }

		 }
	}

    var blRet=confirm("保存処理を行いますか?");
    if (!blRet) {
        return;
    } //

    var arrPrint = []; //印刷範囲のインデックス true：印刷 false 印刷無し
    //印刷範囲を取得する
    if ($("#PAGE_SETTING1").prop("checked")) { //全てのページ
        for (let i = 1; i < PAGE_MAX+1; i++) {
            arrPrint[i] = true;
        } //for

    }else{ //指定したページ
        for (let i = 1; i < PAGE_MAX+1; i++) { //一度全部false
            arrPrint[i] = false;
        } //for
        var strPages = $('#page_input')[0].value;
        //カンマでスプリットして特定ページを取得する
        var arrComma = strPages.split(',');
        for (let i = 0; i < arrComma.length; i++) {
            if (arrComma[i].indexOf('-') >= 0) { //ハイフンがあったら連続で格納
                var arrHyphen=arrComma[i].split('-');
                for (let j = Number(arrHyphen[0]); j <= Number(arrHyphen[arrHyphen.length-1]); j++) {
                    arrPrint[j] = true;
                } //for
            }else{
            	arrPrint[Number(arrComma[i])] = true;
            } //if
        } //for
    } //if

    //glJsonを解体しておく
    var glblackPaintList = JSON.parse(glStrJson);
    keywords=glblackPaintList.keywords; //黒塗り単語の配列
    pages=glblackPaintList.pages;  //登場箇所の配列
    policyNames=glblackPaintList.policyNames; //ポリシー名の配列
    Reasons=glblackPaintList.Reasons; //黒塗り対処理由の配列
    Remarks=glblackPaintList.Remarks; //黒塗りリストで記述した備考
    glArrBfIds=glblackPaintList.glArrAfIds;
    glArrAfIds=glblackPaintList.glArrAfIds;
    glArrPolicys=glblackPaintList.glArrPolicys;

    //categoryを引き当てる
    var cateId = 0;
    var strSelectCate=document.getElementById('cateselect').innerText;

    for (let i = 0; i < glCategoryLists.length; i++) {
        if (strSelectCate===glCategoryLists[i].category_name) {
            cateId=glCategoryLists[i].category_id;
            break;
        } //if
    } //for

    //更新日付
    var updateTime = document.getElementById('modifyDate').innerText;
    //保存期間
    var retentionPeriod = document.getElementsByClassName('FLAT_PICKER')[0].value;



    //連想配列→jsonでpost
    let HashJson = {
        'tmpDir': [glStrTmpDir],
        'strFileName':[glFileName],
        'updateTime':[updateTime],
        'retentionPeriod':[retentionPeriod],
        'cateId':[cateId],
        'documentId':[gldocumentId],
        'arrPrint': arrPrint,
        'arrMaskPaths':glArrPaths,
        'arrRedPaths':glArrRedPaths,
        //以下は黒塗りリスト作成用(ページ番号分からないと作れないのでここで作成)
        'keywords':keywords,
        'pages':pages,
        'policyNames':policyNames,
        'Reasons':Reasons,
        'Remarks':Remarks,
        'glArrBfIds':glArrBfIds,
        'glArrAfIds':glArrAfIds,
        'glArrPolicys':glArrPolicys

    };

    //保存controllerへポスト
    var strJson = '[' + JSON.stringify(HashJson) + ']';

    var objForm = document.createElement('form');
    var objReq = document.createElement('input');
    var objReq2 = document.createElement('input');

    objForm.method = 'POST';
    objForm.action = "SaveDocCnt";

    objReq.type = 'hidden'; //入力フォームが表示されないように
    objReq.name = 'strJson';
    objReq.value = strJson;

	objReq2.type = 'hidden'; //入力フォームが表示されないように
    objReq2.name = 'strFilePath';
    objReq2.value = glFilePath;

    objForm.appendChild(objReq);
    objForm.appendChild(objReq2);
    document.body.appendChild(objForm);
    //POST送信フラグを「true」に設定
    isPost = true;
    objForm.submit();

} //function


/**
 * 黒塗り文書作成画面を表示する
 */
function cancelSave(){

    var blRet = confirm("「黒塗り文書保存画面」で編集した内容を破棄して、「黒塗り文書作成画面」に遷移してもよろしいでしょうか。");

    if (blRet) {

        var strJson = glStrJson;
        var objForm = document.createElement('form');
        var objReq = document.createElement('input');
        var objReq2 = document.createElement('input');
        var objReq3 = document.createElement('input');


        objReq.type = 'hidden'; //入力フォームが表示されないように
        objReq.name = 'documentId';
        objReq.value = gldocumentId;

        objReq2.type = 'hidden'; //入力フォームが表示されないように
        objReq2.name = 'status';
        objReq2.value = "2"; //備考を読み込むため確定フラグ

        objReq3.type = 'hidden'; // 入力フォームが表示されないように
        objReq3.name = 'blackPaintListJson';
        objReq3.value = strJson; // 備考を含んだjson


        objForm.appendChild(objReq);
        objForm.appendChild(objReq2);
        objForm.appendChild(objReq3);

        objForm.method = 'POST';
        objForm.action = "MaskHtmlCnt";

        document.body.appendChild(objForm);
        //POST送信フラグを「true」に設定
        isPost = true;
        objForm.submit();

    } //if



} //function

"use strict"
class ToolTip{
    constructor(items){
        this.items = Array.from(items)
        console.log(this.items)
        this.items.map(item => {
            new ToolTipItem(item)
        })
    }
}
class ToolTipItem{
    constructor(dom){
        // 初期化
        this.rootDom = dom;
        this.dom = document.createElement("div")
        let rect = this.rootDom.getBoundingClientRect();
        // dom生成
        this.dom.innerText = this.rootDom.innerText;
        this.dom.style.position = "absolute";
        this.dom.style.background = "#ffc";
        this.dom.style.padding = "5px 15px";
        this.dom.style.borderRadius = "3px";
        this.dom.style.boxShadow = "0 8px 8px  rgba(0,0,0,0.2)";
        this.dom.style.transitionDuration = "0.2s";
        this.dom.style.top = (rect.top + window.pageYOffset +20 ) + "px";
        this.dom.style.left = (rect.left + window.pageXOffset + 80) + "px";
//        this.dom.style.left = (rect.left + window.pageXOffset + 20) + "px";
        this.dom.style.opacity = 0;
        //
        this.rootHovering = false;
        this.domHovering = false;
        this.showing = false;
        this.rootDom.addEventListener("mouseover", this.show.bind(this),true)
        this.dom.addEventListener("mouseout", this.hide.bind(this))
        this.dom.addEventListener("click", event => event.stopImmediatePropagation(),true)
        document.body.addEventListener("click", this.hide.bind(this))
    }
    show(){
        this.showing = true;
        document.body.appendChild(this.dom)
        setTimeout(() => {
            this.dom.style.opacity = 1;
        }, 100);
    }
    hide(){
        this.dom.style.opacity = 0;
        setTimeout(() => {
            try{
                document.body.removeChild(this.dom)
            }catch(error){

            }
        }, 100);
    }
    domHover() {
        this.show()
        this.domHovering = true;
        console.log(this)
    }
    domMouseOut() {
        this.domHovering = false;
        this.hide()
        console.log(this)
    }
    rootHover() {
        this.show()
        this.rootHovering = true;
        console.log(this)
    }
    rootMouseOut() {
        this.rootHovering = false;
        this.hide()
        console.log(this)
    }
}


