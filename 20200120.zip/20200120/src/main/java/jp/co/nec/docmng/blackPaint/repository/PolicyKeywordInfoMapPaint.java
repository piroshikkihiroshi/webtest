package jp.co.nec.docmng.blackPaint.repository;


import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

import jp.co.nec.docmng.blackPaint.entity.PolicyKeywordInfoBlackPaint;


@Mapper
public interface PolicyKeywordInfoMapPaint {

	@Insert("INSERT INTO admin.policy_keyword_info( policy_id, policy_keyword, create_time, update_time) VALUES ( #{policy_id}, #{policy_keyword}, #{create_time}, #{update_time})")
    public void insertPolicyKeyword(PolicyKeywordInfoBlackPaint objEnt);





} //interface
