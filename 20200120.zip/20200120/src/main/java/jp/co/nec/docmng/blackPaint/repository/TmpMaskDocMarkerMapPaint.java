package jp.co.nec.docmng.blackPaint.repository;


import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import jp.co.nec.docmng.blackPaint.entity.TmpMaskDocMarkerEntBlackPaint;


@Mapper
public interface TmpMaskDocMarkerMapPaint {

    //table tmp_mask_document_marker

    @Insert("INSERT INTO common.tmp_mask_document_marker(document_id, user_id, marker_start_cd, marker_end_cd, marker_policy, marker_remarks, create_time) VALUES ( #{document_id}, #{user_id}, #{marker_start_cd}, #{marker_end_cd}, #{marker_policy}, #{marker_remarks}, #{create_time})")
    public void insertTmpMaskDocMarker(TmpMaskDocMarkerEntBlackPaint objEnt);

    @Select("SELECT marker_id, document_id, user_id, marker_start_cd, marker_end_cd, marker_policy, marker_remarks, create_time, update_time FROM common.tmp_mask_document_marker WHERE document_id = #{document_id} and user_id = #{user_id} ORDER BY marker_id")
    public List<TmpMaskDocMarkerEntBlackPaint> selectTmpMaskDocMarker(Integer document_id,String user_id);

    @Delete("DELETE FROM common.tmp_mask_document_marker WHERE document_id = #{document_id} and user_id = #{user_id}")
    public void deleteTmpMarkerDoc(Integer document_id,String user_id);

    @Update("UPDATE common.tmp_mask_document_marker SET marker_policy = #{marker_policy} WHERE document_id = #{document_id}")
    public void updateTmpMarkerDoc(TmpMaskDocMarkerEntBlackPaint objEnt2);

    @Select("SELECT marker_id, document_id, user_id, marker_start_cd, marker_end_cd, marker_policy, marker_remarks, create_time, update_time FROM common.tmp_mask_document_marker WHERE marker_policy = #{marker_policy} ORDER BY marker_id")
    public List<TmpMaskDocMarkerEntBlackPaint> findMakerPolicyId(Integer marker_policy);




} //interface
