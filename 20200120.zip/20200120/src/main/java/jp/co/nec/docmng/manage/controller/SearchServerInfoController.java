/**
 * 名称：SearchServerInfoControllerファイル
 * 機能名：検索対象サーバ設定画面コントローラー
 * 概要：検索対象サーバ設定画面の制御を実施する
 */
package jp.co.nec.docmng.manage.controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.thymeleaf.util.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.manage.entity.SearchServerInfoEntity;
import jp.co.nec.docmng.manage.entity.SearchServerInfoForm;
import jp.co.nec.docmng.manage.entity.SearchServerInfoSaveFrom;
import jp.co.nec.docmng.manage.entity.SearchServerInfoSaveFrom.AddValues;
import jp.co.nec.docmng.manage.entity.SearchServerInfoSaveFrom.ChangedValues;
import jp.co.nec.docmng.manage.service.SearchServerInfoService;


/**
 * 検索対象サーバ設定画面のリクエストを制御する
 */
@Controller
@RequestMapping("/manage/search_server")
public class SearchServerInfoController {

    /** ロガー */
    private static Logger objLog = LoggerFactory.getLogger(SearchServerInfoController.class);

    /**
     * 実行batファイルパス
     */
    private static final String BAT_FILE_PATH = "src/main/resources/netuse.bat";

    /**
     * Mountファイルパス
     */
    private static final String MOUNT_FILE_PATH = "/mnt/share";

    /**
     * OS名
     */
    public static final String OS_NAME = System.getProperty("os.name").toLowerCase();

    //TODO 設定反映ステータスと認証ステータスを同じ文字列で渡してしまっているが変えたほうが良い？
    /**
     * 設定反映ステータス：成功
     */
    private static final String SUCCESS = "success";

    /**
     * 設定反映ステータス：失敗
     */
    private static final String FAILURE = "failure";

    /**
     * 管理者権限
     */
    private static final String USER_ROLE_TYPE = "Administrators";

    /**
     * 設定反映ステータス格納用変数
     */
    private String saveStatus = null;

    @Autowired
    private SearchServerInfoService searchServerInfoService;

    /**
     * <p>検索対象サーバ設定画面初期表示メソッド</p>
     * 処理内容：<br>
     * <ol>
     *   <li>検索対象サーバ設定画面に必要なデータを取得し表示する。</li>
     * </ol>
     * @param form 検索対象追加用フォーム
     * @param model モデル
     * @return 検索対象サーバ設定画面のURL
     */
    @GetMapping
    public String getSearchServerInfo(@ModelAttribute("searchServerInfoForm") SearchServerInfoForm form, Model model,HttpServletRequest request) {
        //クッキー情報を取得する
        System.out.println("");
        System.out.println(request.getHeader("Cookie"));
        int userAuth = 0;

        //管理者権限の文字列が検出されなかった場合
        if(request.getHeader("Cookie") == null){
            userAuth = 1;

            objLog.info("getPolicyInfo request end (failed)");
            model.addAttribute("userAuth", userAuth);
            return "manage/search_server";
        }

        //ログインしているユーザーの権限を確認する
        String userRoleString = "\"userRole\":\"";
        int openUserRolePoint = request.getHeader("Cookie").indexOf(userRoleString);
        int openUserRoleEndPoint = request.getHeader("Cookie").indexOf(USER_ROLE_TYPE,openUserRolePoint) + USER_ROLE_TYPE.length();
        System.out.println(openUserRolePoint);
        System.out.println(openUserRoleEndPoint);

        //管理者権限の文字列が検出されなかった場合
        if(openUserRoleEndPoint == 13){
            userAuth = 1;

            objLog.info("getPolicyInfo request end (failed)");
            model.addAttribute("userAuth", userAuth);
            return "manage/searchServer";
        }

        String openUserRole = request.getHeader("Cookie").substring(openUserRolePoint+userRoleString.length(),openUserRoleEndPoint);
        System.out.println(openUserRole);

        objLog.info("getSearchServerInfo request start");

        // 全件取得する
        List<SearchServerInfoEntity> searchServerInfoList = searchServerInfoService.findAll();
        model.addAttribute("serchServerInfo", searchServerInfoList);

        //TODO 設定反映失敗時のアラート、エラー番号を出力する予定
        if (StringUtils.equals(saveStatus, SUCCESS)) {
            model.addAttribute("saveStatus", SUCCESS);
        } else if (StringUtils.equals(saveStatus, FAILURE)) {
            model.addAttribute("saveStatus", FAILURE);
        }
        saveStatus = null;

        objLog.trace("saveStatus:{}", saveStatus);
        objLog.info("getSearchServerInfo request end (success)");

        return "manage/searchServer";

    }

    /**
     * <p>検索対象サーバ設定画面 設定反映メソッド</p>
     * 処理内容：<br>
     * <ol>
     *   <li>画面上で削除した項目と紐づくDBの項目を削除する。</li>
     *   <li>画面上で編集した項目と紐づくDBの項目を更新する。</li>
     *   <li>画面上で追加した項目と紐づくDBの項目を追加する。</li>
     * </ol>
     * @param editValue 画面上で編集したサーバ情報
     * @param deleteRows 画面上で削除した項目のサーバID
     * @param addValue 画面上で追加したサーバ情報
     * @return リロード
     */
    @RequestMapping("/save")
    @ResponseBody
    public ResponseEntity<String> save (
            @RequestBody SearchServerInfoSaveFrom form) throws Exception {

        objLog.info("manage search server save request start");

        if (Objects.isNull(form)) {
            objLog.trace("form:{}", form);
            objLog.info("request data not found");
            objLog.info("teacherCategoryReflect request end (error)");
            return new ResponseEntity<String>("request data not found",HttpStatus.BAD_REQUEST);
        }
        objLog.info("form : {} ", form);

        List<AddValues> addValues = form.getAddValues();
        List<ChangedValues> changeValues = form.getChangedValues();
        List<Integer> deleteRow = form.getDeleteRow();
        System.out.println("設定反映ボタン");

        try {

            // システム日付を取得する
            Timestamp sysdate = Timestamp.valueOf(LocalDateTime.now());

            // 追加データがある場合
            if (!Objects.isNull(addValues)) {
                for (AddValues value : addValues) {
                    SearchServerInfoEntity addServerInfo = new SearchServerInfoEntity();
                    addServerInfo.setDisplayName(value.getDisplayName());
                    addServerInfo.setServerName(value.getServerName());
                    addServerInfo.setDirectoryPath(value.getDirectoryPath());
                    addServerInfo.setLoginUserName(value.getLoginUserName());
                    addServerInfo.setLoginPassword(value.getLoginPassword());
                    addServerInfo.setCreateTime(sysdate);
                    addServerInfo.setUpdateTime(sysdate);
                    // DBに反映
                    searchServerInfoService.insert(addServerInfo);
                }
            }

            // 編集項目
            if (!Objects.isNull(changeValues)) {
                for (ChangedValues value : changeValues) {
                    SearchServerInfoEntity changeServerInfo = new SearchServerInfoEntity();
                    changeServerInfo.setServerId(value.getServerId());
                    changeServerInfo.setDisplayName(value.getDisplayName());
                    changeServerInfo.setServerName(value.getServerName());
                    changeServerInfo.setDirectoryPath(value.getDirectoryPath());
                    changeServerInfo.setLoginUserName(value.getLoginUserName());
                    changeServerInfo.setLoginPassword(value.getLoginPassword());
                    changeServerInfo.setCreateTime(sysdate);
                    changeServerInfo.setUpdateTime(sysdate);
                    // DBに反映
                    searchServerInfoService.update(changeServerInfo);
                }
            }
            // 削除項目
            if (!Objects.isNull(deleteRow)) {
                for (Integer value : deleteRow) {
                    searchServerInfoService.deleteById(value);
                }
            }

            saveStatus = SUCCESS;

        } catch (Exception e) {
            e.printStackTrace();
            objLog.error("addValues:{}\r\nchangeValues:{}\r\ndeleteRow:{}", addValues, changeValues,deleteRow);
            objLog.error("error message", e);
            objLog.info("manage search server save request end (error)");
            e.printStackTrace();
            saveStatus = FAILURE;
            return new ResponseEntity<String>(saveStatus,HttpStatus.BAD_REQUEST);
        }
        objLog.info("manage search server save request end (success)");
        return new ResponseEntity<String>(saveStatus, HttpStatus.OK);
    }

    /**
     * <p>検索対象サーバ設定画面 認証メソッド</p>
     * 処理内容：引数で指定されたディレクトリへのアクセス権限の確認をする。<br>
     * @param form 認証するユーザ名・パスワード・保存先情報
     * @return 認証結果
     * @throws Exception
     */
    @RequestMapping("/auth")
    @ResponseBody
    public String auth(@RequestBody SearchServerInfoForm form) throws Exception {

        objLog.info("manage search server auth request start");
        // 存在チェック
        if (Objects.isNull(form)) {
            objLog.trace("form:{}", form);
            objLog.info("request data not found");
            objLog.info("manage search server auth request end (error)");
            return "failure";
        }
        objLog.info("form : {} ", form);

        String userName = form.getLoginUserName();
        String password = form.getLoginPassword();
        String directoryPath = form.getDirectoryPath();
        String serverName = form.getServerName();

        objLog.info("userName:[{}]  password:[{}]  directoryPath:[{}]", userName, password, directoryPath);

        String authStr = null;
        System.out.println(directoryPath);
        objLog.trace("server: [{}]", OS_NAME);

        // OS依存しそうなので記載する
        if (OS_NAME.startsWith("windows")) {

		String cmds;

        // ユーザー名がない場合
        if (StringUtils.isEmpty(userName)) {
			// windowsにてコマンド実行する内容
        	cmds = "net use \\\\" + serverName + directoryPath;
            // ユーザー名はあるがパスワードがない場合
        } else if (StringUtils.isEmpty(password)) {

			// windowsにてコマンド実行する内容
        	cmds = "net use \\\\" + serverName + directoryPath + " /user:" + userName;
            // ユーザー名とパスワード両方ある場合
        } else {
			// windowsにてコマンド実行する内容
        	cmds = "net use \\\\" + serverName + directoryPath + " " + password + " /user:" + userName;
        }
        objLog.info("Exe Command : [{}]", cmds);

        // コマンドを実行する
        Process runtimeProcess = Runtime.getRuntime().exec(cmds);
        int exitValue = runtimeProcess.waitFor();
        objLog.info("procces value : [{}]", exitValue);

        // 認証成功時
        if (exitValue == 0) {
            authStr = "success";
            // 認証失敗時
        } else {
            authStr = "failure";
        }

        String cm;

        // windowsにてコマンド実行する内容
        cm = "net use \\\\" + serverName + directoryPath + " /delete";

        // コマンドを実行する
        Process p = Runtime.getRuntime().exec(cm);
        p.waitFor();


        // batファイルを削除する
        File file = new File(BAT_FILE_PATH);
        file.delete();

        } else {

            // Windowsサーバでない場合
            directoryPath = directoryPath.replace("\\", "/");
            System.out.println(directoryPath);

			String cmdsUmount = "sudo /bin/umount -l " + MOUNT_FILE_PATH;
			objLog.info(cmdsUmount);

			// コマンドを実行する
			Process p = Runtime.getRuntime().exec(cmdsUmount);
			p.waitFor();
			ProcessBuilder pb = null;

			// ユーザの指定にドメインが含まれるなら分割する
            String[] spUserName = userName.split("\\\\");
            String mountCommand = "sudo /bin/mount -t cifs -o " ;

            if(spUserName.length == 2){
                String cmds[] = {mountCommand + "sec=ntlm,username=" + spUserName[1] + ",password=" + password + ",domain=" + spUserName[0] + " //" + serverName + directoryPath + " " + MOUNT_FILE_PATH};

                objLog.info("Exe Command : [{}]", Arrays.toString(cmds));

                // コマンド実行
                pb = new ProcessBuilder("sudo","/bin/mount", "-t", "cifs", "-o", "sec=ntlm,username=" + spUserName[1] + ",password=" + password + ",domain=" + spUserName[0], "//" + serverName + directoryPath, MOUNT_FILE_PATH);

            } else {
                String cmds[] = {mountCommand + "username=" + userName + ",password=" + password + " //" + serverName + directoryPath + " " + MOUNT_FILE_PATH};

                objLog.info("Exe Command : [{}]", Arrays.toString(cmds));

                // コマンド実行
                pb = new ProcessBuilder("sudo","/bin/mount", "-t", "cifs", "-o", "username=" + userName + ",password=" + password, "//" + serverName + directoryPath, MOUNT_FILE_PATH);
            }

            pb.redirectErrorStream(true);
            Process runtimeProcess = pb.start();

            InputStream is = runtimeProcess.getInputStream();

            //　コマンド実行後の確認
            BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"));

            String line;

            while ((line = br.readLine()) != null) {
                // コマンド実行のログ出力
                System.out.println(line);
                objLog.info("Exe log : [{}]", line);
            }

            // プロセス値を取得する
            int exitValue = runtimeProcess.waitFor();
            objLog.info("procces value : [{}]", exitValue);

            // 認証成功時
            if (exitValue == 0) {
                authStr = "success";
                // 認証失敗時
            } else {
                authStr = "failure";
            }
			String cmdsUmountCheck = "sudo /bin/umount -l " + MOUNT_FILE_PATH;
			objLog.info(cmdsUmountCheck);

			// コマンドを実行する
			Process pc = Runtime.getRuntime().exec(cmdsUmountCheck);
			pc.waitFor();

        }

        ObjectMapper mapper = new ObjectMapper();
        String ret = mapper.writeValueAsString(authStr);

        objLog.trace("ret : {}", ret);
        objLog.info("manage search server auth request end (success)");
        return ret;
    }
}