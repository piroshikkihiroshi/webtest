/**
 * 名称：MakeListCnt.java
 * 機能名：黒塗りリスト表示Control
 * 概要：黒塗りリスト表示Controlを行う。
 */
package jp.co.nec.docmng.blackPaint.controller;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jp.co.nec.docmng.blackPaint.entity.DocumentInfoEntPaint;
import jp.co.nec.docmng.blackPaint.logic.dirFile.DirCnt;
import jp.co.nec.docmng.blackPaint.service.DocInfoService;


@Controller
public class MaskListCnt {

	static Logger objLog = LoggerFactory.getLogger(MaskHtmlCnt.class);

	@Autowired
	ServletContext context;
	@Autowired
	DocInfoService docInfoService;

	/**
	 * 黒塗りリスト表示メソッド
	 * 黒塗りリスト表示を押下したときの処理制御をする。
	 * @param  blackPaintList_i 以下の値を入れ込んだjsonString
	 * keywords 黒塗り単語の配列
	 * pages 登場箇所の配列
	 * policyNames ポリシー名の配列
	 * Reasons 黒塗り対処理由の配列
	 * Remark s黒塗り対処理由の配列
	 * @param tmpDir_i 作業directory
	 * @param strFileName_i ファイル名
	 * @param documentId_i dokyumenntoid
	 * @param intPageCnt_i pageカウント
	 * @param strFilePath_i ファイルのフルパス
	 * @param model
	 */
	@PostMapping("/MaskListCnt")
	public synchronized String getblackPaintInfo(
			@RequestParam("blackPaintList") String blackPaintList_i,
			@RequestParam("tmpDir") String tmpDir_i,
			@RequestParam("strFileName") String strFileName_i,
			@RequestParam("documentId") String documentId_i,
			@RequestParam("intPageCnt") int intPageCnt_i,
			@RequestParam("strFilePath") String strFilePath_i,Model model) {
		if (!blackPaintList_i.equals("")) {
			objLog.info("json："+blackPaintList_i);
		} //if

		objLog.info("作業フォルダ：" + tmpDir_i);

		//DocumentIDでdocument_infoから情報を取得
		List<DocumentInfoEntPaint> listDoc=null;
		listDoc =docInfoService.selectDocInfo(Integer.parseInt(documentId_i));
		strFilePath_i = listDoc.get(0).getFilePath();

		model.addAttribute("blackPaintList", blackPaintList_i); //黒塗りリスト表示画面用JSON

		model.addAttribute("strTmpDirName", tmpDir_i);
		model.addAttribute("strFileName",strFileName_i);
		model.addAttribute("documentId", documentId_i);
		model.addAttribute("intPageCnt", intPageCnt_i);
		model.addAttribute("strFilePath", strFilePath_i);

		return "blackPaint/MaskListView";
	} //getView1

	/**
	 * エラー画面遷移(黒塗り処理)
	 */
	@ExceptionHandler(Exception.class)
	public String handleException(
			Exception e,
			HttpServletRequest request,
			HttpServletResponse response,
			Model model
			){

		//GCを明示的によんでメモリ解放
		//System.gc();


		//モデル初期化
		DirCnt objDirCls = new DirCnt();
		Cookie cookie[] = request.getCookies();
		String strTmpDir_i = "";
		if (cookie != null){
			for (int i = 0 ; i < cookie.length ; i++){
				if (cookie[i].getName().equals("strTmpDirName")){
					strTmpDir_i = cookie[i].getValue();
				} //if
			} //for
		} //if

		//作業ディレクトリかたずけ
		if(strTmpDir_i.equals(""))  {
			objLog.info("作業ディレクトリの取得が失敗しました");
		}else {
			try {
				//作業ディレクトリ,ファイルかたづけ
				objDirCls.delDirectory(context.getRealPath("/") + strTmpDir_i);
				objLog.info("作業ディレクトリ削除完了");
			} catch (Exception e1) {
				objLog.info("作業ディレクトリ削除失敗");
			} //try

		} //if


		response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		objLog.error("Error occurred.", e);
		StringWriter objSw = new StringWriter();
		PrintWriter objPw = new PrintWriter(objSw);
		e.printStackTrace(objPw);
		objPw.flush();
		String strError = objSw.toString();
		try {
			objSw.close();
			objPw.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		} //try

		model.addAttribute("errorMessage", e.getMessage() + "\r\n" + "StackTrace" + "\r\n" + strError) ;

		return "blackPaint/Fail";
	} //method

} //MaskHtmlCnt