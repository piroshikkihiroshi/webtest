package jp.co.nec.docmng.blackPaint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.blackPaint.entity.MaskDocMarkerEntBlackPaint;
import jp.co.nec.docmng.blackPaint.repository.MaskDocMarkerMapPaint;

@Service
public class MaskDocMarkerService {
    @Autowired
    private MaskDocMarkerMapPaint maskDocMarkerMapPaint;

    //table mask_document_marker

    @Transactional
    public void insertMaskDocument(MaskDocMarkerEntBlackPaint objEnt2) {
        maskDocMarkerMapPaint.insertMaskDocMarker(objEnt2);
    } //insertMaskDocument


    @Transactional
    public List<MaskDocMarkerEntBlackPaint> selectMaskDocMarker(Integer documentId) {
        return maskDocMarkerMapPaint.selectMaskDocMarker(documentId);

    } //insertMaskDocument

    @Transactional
    public void deleteMarkerDoc(Integer document_id) {
        maskDocMarkerMapPaint.deleteMarkerDoc(document_id);
    } //deleteMarkerDoc

    @Transactional
    public void updateMarkerDoc(MaskDocMarkerEntBlackPaint objEnt2) {
        maskDocMarkerMapPaint.updateMarkerDoc(objEnt2);
    } //updateMarkerDoc

    @Transactional
    public List<MaskDocMarkerEntBlackPaint> findMakerPolicyId(Integer policyId) {
        return maskDocMarkerMapPaint.findMakerPolicyId(policyId);
    } //findMakerPolicyId


} //PolicyInfoServiceApi
