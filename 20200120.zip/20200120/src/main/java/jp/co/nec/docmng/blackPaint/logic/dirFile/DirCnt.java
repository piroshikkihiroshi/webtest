package jp.co.nec.docmng.blackPaint.logic.dirFile;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DirCnt {

	static Logger objLog = LoggerFactory.getLogger(DirCnt.class);

	/**
	 * ディレクトリを作成する。(存在していた場合削除して再作成する)
	 * @param String strDirPath_i 作成ディレクトリパス
	 * @param String strCopyDir_i コピー先ディレクトリパス
	 * @return int 成否ステータス
	 */
	synchronized public int makeDirWithCheck(String strDirPath_i) {

		//strDirPath_iの長さが10未満なら処理しない(フェールセーフ)
		if (strDirPath_i.length()<=10) {
			return -2;
		} //if

		objLog.info("対象フォルダ："+strDirPath_i);

		File objTgtDir = new File(strDirPath_i);
		if (objTgtDir.exists()) {
			objLog.info("フォルダがすでに存在する為、一度削除します");
			try {
				FileUtils.deleteDirectory(objTgtDir);
				objLog.info("フォルダの削除に成功しました");
			} catch (IOException e) {
				objLog.error("フォルダの削除に失敗しました",e);
				e.printStackTrace();
				return -1;
			}
		}
		if (objTgtDir.mkdir()) {
			objLog.info("フォルダの作成に成功しました");
		} else {
			objLog.info("フォルダの作成に失敗しました");
			return -1;
		}
		return 0;
	} //

	/**
	 * ディレクトリを削除する。
	 * @param String strDirPath_i 削除ディレクトリパス
	 * @return int 成否ステータス
	 */
	synchronized public int delDirectory(String strDirPath_i) {
		//strDirPath_iの長さが10未満なら処理しない(フェールセーフ)
		if (strDirPath_i.length()<=10) {
			return -2;
		} //if

		objLog.info("対象フォルダ："+strDirPath_i);

		File objTgtDir = new File(strDirPath_i);
		if (objTgtDir.exists()) {
			objLog.info("フォルダがすでに存在する為、削除します");
			try {
				FileUtils.deleteDirectory(objTgtDir);
				objLog.info("フォルダの削除に成功しました");
			} catch (Exception e) {
				objLog.error("フォルダの削除に失敗しました",e);
				e.printStackTrace();
				return -1;
			}
		}
		return 0;
	} //delDirectory

	/**
	 * zip解凍を行う
	 * @param inputFile 解凍するzipファイル
	 * @param outputDir 解凍先フォルダ
	 * @throws Exception
	 */
	public void decompressZip(String inputFile, String outputDir) throws Exception {
		// zipファイルの読込
		// try-with-resource構文でファイルcloseしている

		objLog.info("inファイル："+inputFile);
		objLog.info("outファイル："+outputDir);

		try (FileInputStream fis = new FileInputStream(inputFile);
				ZipInputStream archive = new ZipInputStream(fis)) {
			// エントリーを1つずつファイル・フォルダに復元
			ZipEntry entry = null;
			while ((entry = archive.getNextEntry()) != null) {
				// ファイルを作成
				File file = new File(outputDir + "/" + entry.getName());

				// フォルダ・エントリの場合はフォルダを作成して次へ
				if (entry.isDirectory()) {
					file.mkdirs();
					continue;
				}

				// ファイル出力する場合、
				// フォルダが存在しない場合は事前にフォルダ作成
				if (!file.getParentFile().exists()) {
					file.getParentFile().mkdirs();
				}

				// ファイル出力
				try (FileOutputStream fos = new FileOutputStream(file);
						BufferedOutputStream bos = new BufferedOutputStream(fos)) {
					// エントリーの中身を出力
					int size = 0;
					byte[] buf = new byte[1024];
					while ((size = archive.read(buf)) > 0) {
						bos.write(buf, 0, size);
					} //while
				} //try
			} //while
		} //try
	} //decompressZip

	/**
	 * ディレクトリをfromからtoにコピーします<br>
	 * サブディレクトリの中身も全てコピーします<br>
	 * コピー先が存在する場合例外を出します．<br>
	 * @param from コピー元ディレクトリ名
	 * @param to コピー先ディレクトリ名
	 */
//	public void copyDir(String from, String to)
//	{
//		//コピー元
//		final Path fromPath = Paths.get(from);
//		//コピー先
//		final Path toPath = Paths.get(to);
//
//		//FileVisitorの定義
//		FileVisitor<Path> visitor = new SimpleFileVisitor<Path>() {
//			@Override
//			public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
//				//ディレクトリをコピーする
//				Files.copy(dir, toPath.resolve(fromPath.relativize(dir)), StandardCopyOption.COPY_ATTRIBUTES);
//				return FileVisitResult.CONTINUE;
//			}
//
//			@Override
//			public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
//				//ファイルをコピーする
//				Files.copy(file, toPath.resolve(fromPath.relativize(file)), StandardCopyOption.COPY_ATTRIBUTES);
//				return FileVisitResult.CONTINUE;
//			}
//		};
//
//		//ファイルツリーを辿ってFileVisitorの動作をさせる
//		try {
//			Files.walkFileTree(fromPath, visitor);
//		} catch (IOException e) {
//			e.printStackTrace();
//		} //try
//	} //method


} //DirCnt
