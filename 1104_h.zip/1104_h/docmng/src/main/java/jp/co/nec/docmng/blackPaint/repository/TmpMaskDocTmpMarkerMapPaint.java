package jp.co.nec.docmng.blackPaint.repository;


import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import jp.co.nec.docmng.blackPaint.entity.TmpMaskDocMarkerEntBlackPaint;


@Mapper
public interface TmpMaskDocTmpMarkerMapPaint {

	@Insert("INSERT INTO common.tmp_mask_document_marker(document_id, user_id, marker_start_cd, marker_end_cd, marker_policy, marker_remarks, create_time) VALUES ( #{document_id}, #{user_id}, #{marker_start_cd}, #{marker_end_cd}, #{marker_policy}, #{marker_remarks}, #{create_time})")
    public void insertTmpMaskDocMarker(TmpMaskDocMarkerEntBlackPaint objEnt);

	@Select("SELECT marker_id, document_id, user_id, marker_start_cd, marker_end_cd, marker_policy, marker_remarks, create_time, update_time FROM common.tmp_mask_document_marker WHERE document_id = #{document_id} and user_id = #{user_id} ORDER BY marker_id")
    public List<TmpMaskDocMarkerEntBlackPaint> selectTmpMaskDocMarker(Integer document_id,String user_id);



} //interface
