package jp.co.nec.docmng.manege.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.thymeleaf.util.StringUtils;

import jp.co.nec.docmng.manege.entity.PolicyInfoEntity;
import jp.co.nec.docmng.manege.entity.PolicyKeywordInfo;
import jp.co.nec.docmng.manege.service.PolicyInfoService;
import jp.co.nec.docmng.manege.service.PolicyKeywordInfoService;
@Controller
@RequestMapping("/manege/policy")
public class PolicyInfoController {
    /**
     * 該当キーワードの表示上限文字数
     */
    private static final int DISPLAY_LIMIT_NUM = 50;

    @Autowired
    PolicyInfoService policyInfoService;
    @Autowired
    PolicyKeywordInfoService policyKeywordInfoService;

    /**
     * <p>黒塗りポリシー設定画面GET処理</p>
     * 処理内容：<br>
     * <ol>
     *   <li>黒塗りポリシー設定画面をGETする</li>
     * </ol>
     * @param form 検索対象追加用フォーム
     * @param model モデル
     * @return 検索対象サーバ設定画面のURL
     */
    @GetMapping
    public String getPolicyInfo(Model model) {

        // 全件取得
        List<PolicyInfoEntity> policyInfoEntities = policyInfoService.findAll();
        List<PolicyKeywordInfo> policyKeywordInfos = policyKeywordInfoService.findAll();

        // 50文字を超える対象黒塗りポリシー該当キーワードの51文字目以降を省略する
        for (int i = 0; i < policyKeywordInfos.size(); i++) {
            // 該当キーワードを取得する
            String keyword = policyKeywordInfos.get(i).getPolicyKeyword();

            // 該当キーワードが50文字を超える場合
            if (DISPLAY_LIMIT_NUM < keyword.length()) {
                // 51文字目以降を切り取る
                String cutStr = StringUtils.substring(keyword, 0, DISPLAY_LIMIT_NUM);
                // エンティティにセットしなおす
                policyKeywordInfos.get(i).setPolicyKeyword(cutStr + "...");
            }
        }

        model.addAttribute("policyInfo", policyInfoEntities);
        model.addAttribute("policyKeywordInfos", policyKeywordInfos);
        return "manege/policy";
    }


}
