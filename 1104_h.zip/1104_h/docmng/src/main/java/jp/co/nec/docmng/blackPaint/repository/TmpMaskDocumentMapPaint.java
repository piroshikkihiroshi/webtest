package jp.co.nec.docmng.blackPaint.repository;


import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import jp.co.nec.docmng.blackPaint.entity.TmpMaskDocumentEntBlackPaint;


@Mapper
public interface TmpMaskDocumentMapPaint {

	@Insert("INSERT INTO common.tmp_mask_document(document_id, user_id, html_zip_data, create_time, update_time) VALUES (#{document_id}, #{user_id}, #{html_zip_data}, #{create_time}, #{update_time})")
    public void insertTmpMaskDocument(TmpMaskDocumentEntBlackPaint TmpMaskDocumentEnt);

	@Select("SELECT html_zip_data FROM common.tmp_mask_document WHERE document_id = #{document_id} and user_id = #{user_id}")
    public List<TmpMaskDocumentEntBlackPaint> getTmpHtmlZip(Integer document_id,String user_id);

	@Select("SELECT document_id FROM common.tmp_mask_document WHERE document_id = #{document_id} and user_id = #{user_id}")
    public List<TmpMaskDocumentEntBlackPaint> isTmpDoc(Integer document_id,String user_id);


} //interface
