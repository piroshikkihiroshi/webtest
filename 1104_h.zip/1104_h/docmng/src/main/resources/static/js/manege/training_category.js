$(function () {

    /**
     * 画面が変更または閉じれる時に動作
     * ダイアログを表示する
     * messageboxで表示を行いたいが、検知の限界が存在する為「beforeunload」を使用する
     * 参考サイト：https://teratail.com/questions/51831
    **/
    $(window).on("beforeunload", function (e) {
        // POST送信フラグが「true」の場合、ダイアログを表示しない
        if (isPost) {
            return;
        } else {
            return true;
        }
    });

    /**
     * ×ボタン押下後に動作
     * 選択した行を削除する
     **/
    $('.DeleteRowTrainingPolicy').on('click', function (e) {
        //選択した行にIDを付与
        e.target.parentElement.parentElement.setAttribute('id', 'selected');
        //選択した行の削除
        $("#selected").remove();
    });

    /**
     * ×ボタン押下後に動作
     * 動的に生成された選択した行を削除する
     **/
    $(document).on('click', '.NewDeleteRowTrainingPolicy', function (e) {
        //選択した行にIDを付与
        e.target.parentElement.parentElement.setAttribute('id', 'selected');
        //選択した行の削除
        $("#selected").remove();

    });

    //読み込み時に「⇐」ぼたんを非表示
    $('.scrollBody').ready(function (e) {
        document.getElementById("Outbutton").style.display = "none";
    });// fuction

    /**
     * 表をクリック時に動作
     * クリックを行った時に選択した行の色が変更される
    **/
    $('#autoNo').mousedown(function (e) {
        //表の項目以外をクリック時には色を付けない
        if (e.target.id != "autoNo") {
            //一項目のみclick可能とする
            if (e.target.parentElement.id == 'selected') {
                document.getElementById('selected').removeAttribute("id");
            } else {
                if (document.getElementById('selected') == null) {
                    e.target.parentElement.setAttribute('id', 'selected');
                }// if
                document.getElementById('selected').removeAttribute("id");
                e.target.parentElement.setAttribute('id', 'selected');
            }// if
        } else if (e.target.id == "autoNo") {
            return false;
        }// if

    });// function


    // Ajax通信テスト ボタンクリック
    $("#outputFileButton").click(function () {
        var strAddFilePassText = $('#addDirectoryPass').val();

        //未入力チェック
        if (strAddFilePassText == "") {
            alert('『フォルダパス』が未入力です。');
            return false;
        }// if

        // コントローラに渡すjsonオブジェクトを作成する
        var jsonObj = new Object();
        jsonObj.directoryPass = strAddFilePassText;

        $.ajax({
            url: "http://localhost:8080/manege/training_category",
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify(jsonObj),
            dataType: "json"
            // ajax通信成功時の処理
        }).done(function (data, textStatus, jqXHR) {
            let successOrFailure = "";
            var successCount = 0;
            if (data.length !== 0) {
                for (let i = 0; i < data.length; i++) {
                    for (let index = 0; index < document.getElementById("teacherCategoryFile").children.length; index++) {
                        var listFile = document.getElementById("teacherCategoryFile").children[index].children[2].outerText;
                        if (listFile === data[i]) {
                            successCount++;
                        }
                    }
                    if (document.getElementById("teacherCategoryFile").children.length !== successCount) {
                        //×ボタン
                        var strAddDeleteButton = '<button type="button" class="NewDeleteRowTrainingPolicy">×</button>'

                        //最上位行のプルダウンメニュー内容を取得
                        var strPullDownMenuList = document.getElementsByClassName("categoryInfo")[0].outerHTML;

                        // 追加されていないファイルパスを追加する
                        var tr = $("<tr></tr>");
                        var strDeleteButton = $("<td style='text-align: center;'></td>");
                        var strCategoryList = $("<td style='text-align: center;'></td>");
                        var strFilePass = $("<td></td>");

                        //表に取得した値を挿入する
                        $("#teacherCategoryFile").append(tr);
                        tr.append(strDeleteButton).append(strCategoryList).append(strFilePass);
                        strDeleteButton.html(strAddDeleteButton);
                        strCategoryList.html(strPullDownMenuList);
                        strFilePass.html(data[i]);
                }
            }
                alert('ファイルパスを出力が完了いたしました。');
            } else if (data.length === 0) {
                alert('入力したディレクトリが存在しないか、配下にファイルが存在しませんでした。');
            }
            console.log(jqXHR.status);
            // ajax通信失敗時の処理
        }).fail(function (jqXHR, textStatus, errorThrown) {
            console.log(jqXHR.status);
            // 成功でも失敗でも通信終了時に必要な処理があれば
        }).always(function () {
        });

        console.log(jsonObj);

    });

});// function

/**
 * ⇒ボタン押下時に動作
 * 分類一覧表を表示し、「⇐」ボタンを表示する
**/
function FadeIn() {
    //分類一覧表の表示
    $('#categoryTable').fadeIn(375);

    //分類一覧表のボタン表示
    $('#categoryDecisionTable').fadeIn(375);

    //「⇐」ボタンを表示、「⇒」ボタンを非表示
    document.getElementById("Outbutton").style.display = "block";
    document.getElementById("InButton").style.display = "none";
}// function

/**
 * ⇐ボタン押下時に動作
 * 分類一覧表を非表示し、「⇒」ボタンを表示する
**/
function FadeOut() {
    //分類一覧表の表示
    $('#categoryTable').fadeOut(375);

    //分類一覧表のボタン表示
    $('#categoryDecisionTable').fadeOut(375);

    //「⇒」ボタンを表示、「⇐」ボタンを非表示
    document.getElementById("Outbutton").style.display = "none";
    document.getElementById("InButton").style.display = "block";
}// function


//グローバル変数
var addValues = {};
var addListCount = 0;

/**
 * 追加ボタン押下時に動作
 * 一覧表の最下部に追加する
**/
function AddList() {

    //現在の最大行取得
    var objAutoRowNo = document.getElementById("autoNo").rows.length - 1;
    strAutoRowNo = '' + objAutoRowNo;

    //非編集状態かつ編集中ではない場合
    if (document.getElementsByClassName('EditMode').length == 0 && document.getElementsByClassName("EditTable").length == 0) {

        //最終行が新規作成テキストボックスか確認を行う
        if (document.getElementById("autoNo").children[objAutoRowNo].classList[0] !== "addListTable") {
            //編集行を、最終行に変更を行う
            if (document.getElementById('selected') !== null) {
                document.getElementById('selected').removeAttribute("id");
            }// if

            //新規作成する欄を作成
            var tr = $("<tr id='selected' class='addListTable " + addListCount + "'></tr>");
            var strCategoryName = $("<td></td>");

            //表に取得した値を挿入する
            $('#autoNo').append(tr);
            tr.append(strCategoryName);
            strCategoryName.html("<input type='text' id='newCategoryName' class='textbox' value=" + "" + " ></imput>");

        } else if (document.getElementById("autoNo").children[objAutoRowNo].classList[0] === "addListTable") {

            //入力されているテキストボックス内容を取得
            var strNewCategoryNameText = document.getElementById("newCategoryName").value;

            //入力チェック
            if (strNewCategoryNameText == "") {
                alert("分類軸名を入力後再度ボタンを押下してください");
                return false;
            }// if

            //入力された値がすでに一覧に存在するかチェック
            for (let index = 0; index < objAutoRowNo; index++) {
                var strListContent = document.getElementById("autoNo").children[index].children[0].textContent;
                if (strListContent === strNewCategoryNameText) {
                    alert("既に一覧に登録されているため、追加できません");
                    return false;
                }// if
            }// for

            //連想配列の作成
            addValues[addListCount] = { ["category_name"]: strNewCategoryNameText, ["category_author"]: "" };//現在ログインしているユーザー名を取得する
            addListCount++;

            //テキストボックス化を解除する
            document.getElementById("newCategoryName").outerHTML = "<td>" + strNewCategoryNameText + "</td>";

            //非アクティブ化状態に移行するため、クラスの削除
            document.getElementsByClassName("addListTable")[0].classList.remove("addListTable");

            return;
        }// if
        //編集状態かつ編集中の場合
    } else if (document.getElementsByClassName('EditMode').length > 0 && document.getElementsByClassName("EditTable").length > 0) {
        alert("現在編集中のため追加は行えません");
        return false;
    }// if
}// function

//グローバル変数
var changedValues = {};

/**
   * 編集ボタン押下時に動作
   * 選択した項目内容を変更する
  **/
function Edit() {
    //現在新規作成中の場合アラートを表示する
    if (document.getElementsByClassName('addListTable').length == 0) {
        //非編集状態かつ編集中ではない場合
        if (document.getElementsByClassName('EditMode').length == 0 && document.getElementsByClassName("EditTable").length == 0) {
            if (document.getElementById('selected').length != 0) {
                //編集がアクティブ状態のため、クラス付与
                $('#autoNo').eq(0).addClass('EditMode');
                $('#selected').eq(0).addClass('EditTable');

                //分類軸ID取得
                var strChangeRow = $("#selected>td[style='display: none;']").text();

                //新規追加行チェック
                if (strChangeRow === "") {
                    //選択行の分類軸名を取得
                    var strCategoryNameText = $('#selected').eq(0).children()[0].valueOf().textContent;
                    //選択行の分類軸名をTextBox化
                    $('#selected').eq(0).children()[0].outerHTML = "<input type='text' id='changeCategoryName' class='textbox' value=" + strCategoryNameText + " ></imput>";
                } else {
                    //選択行の分類軸名を取得
                    var strCategoryNameText = $('#selected').eq(0).children()[1].valueOf().textContent;
                    //選択行の分類軸名をTextBox化
                    $('#selected').eq(0).children()[1].outerHTML = "<input type='text' id='changeCategoryName' class='textbox' value=" + strCategoryNameText + " ></imput>";
                }// if
            }// if
            //編集状態かつ編集中の場合
        } else if (document.getElementsByClassName('EditMode').length > 0 && document.getElementsByClassName("EditTable").length > 0) {

            //分類軸ID取得
            var strChangeRow = $(".EditTable>td[style='display: none;']").text();
            //DBで表示されているリストの場合、classからリスト番号を取得
            var strAddChangeRow = document.getElementsByClassName("EditTable")[0].classList[0];
            //表示されている値の登録
            var strTextBoxCategoryName = document.getElementById("changeCategoryName").value;
            //現在の最大行取得
            var objAutoRowNo = document.getElementById("autoNo").rows.length - 1;

            //入力された値がすでに一覧に存在するかチェック
            for (let index = 0; index < objAutoRowNo; index++) {
                var strListContent = document.getElementById("autoNo").children[index].children[0].textContent;
                if (strListContent === strTextBoxCategoryName) {
                    alert("既に一覧に登録されているため、編集が確定できません");
                    return false;
                }// if
            }// for

            // 連想配列作成・追加
            if (addValues[strAddChangeRow]) {
                addValues[strAddChangeRow]["category_name"] = strTextBoxCategoryName;
                if (changedValues[strChangeRow]) {
                    changedValues[strChangeRow]["category_name"] = strTextBoxCategoryName;
                }// if
            } else {
                if (!changedValues[strChangeRow]) {
                    changedValues[strChangeRow] = { ["category_name"]: strTextBoxCategoryName };
                } else {
                    changedValues[strChangeRow]["category_name"] = strTextBoxCategoryName;
                }// if
            }// if
            //テキストボックス化を解除する
            document.getElementById("changeCategoryName").outerHTML = "<td>" + strTextBoxCategoryName + "</td>";

            //非アクティブ化状態に移行するため、クラスの削除
            document.getElementById('autoNo').classList.remove("EditMode");
            document.getElementsByClassName("EditTable")[0].classList.remove("EditTable");

            return;
        }// if
    } else if (document.getElementsByClassName('addListTable').length > 0) {
        alert("現在新規作成中のため編集は行えません");
        return false;
    }// if
}// function

/**
 * 削除ボタン押下時に動作
 * 選択した行を削除する
**/
//グローバル変数
//DBデータの削除した項番
var deleteDBNo = [];

//行の削除を行う
function DeleteRow() {
    //行を選択していない場合、アラートを表示
    if (document.getElementById('selected') !== null) {
        //選択している行が編集中の場合、アラートを表示
        if (document.getElementById("selected").className !== "EditTable") {
            //分類軸ID取得
            var strDeleteRow = $("#selected>td[style='display: none;']").text();

            //新規作成で表示されているリストの場合、classからリスト番号を取得
            var strAddChangeRow = document.getElementById("selected").classList[0];

            //グローバル変数に分類軸IDの値を取得する
            deleteDBNo.push(strDeleteRow);

            //連想配列の削除を行う
            if (changedValues[strDeleteRow]) {
                delete changedValues[strDeleteRow];
                if (addValues[strAddChangeRow]) {
                    delete addValues[strAddChangeRow];
                }// if
            } else if (addValues[strAddChangeRow]) {
                delete addValues[strAddChangeRow];
            }// if

            //選択した行の削除
            $("#selected").remove();

        } else {
            alert("選択した行は現在編集中のため削除できません。");
        }//if
    } else {
        alert("行を選択後、ボタンを押下してください");
    }// if
}// function

/**
 * キャンセルボタン押下時に動作
 * ダイアログを表示する
**/
function Cancel() {
    blCan = confirm("変更内容を破棄してもよろしいでしょうか。");
    if (blCan) {
        window.close();
    } else {
        return;
    }// if
}// function

/**
 * クリアボタン押下時に動作
 * ダイアログを表示する
**/
function Clear() {
    blCan = confirm("分類一覧設定と登録データ一覧の変更内容を破棄してもよろしいでしょうか。");
    if (blCan) {
        location.reload();
    } else {
        return;
    }// if
}// function