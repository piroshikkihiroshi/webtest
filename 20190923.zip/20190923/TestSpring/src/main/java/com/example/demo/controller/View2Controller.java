package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.model.entity.View2entity;
import com.example.demo.model.service.View2service;

@Controller
public class View2Controller {

	@Autowired
	private View2service objView2Service;

	@GetMapping("/view2")
	public String getView1() {
		return "view2";
	} //getView1

	@PostMapping("/view2")
	public String postDbRequest(@RequestParam("userid") String strUserId_i, Model model) {
		// １件検索
		View2entity objView2ent = objView2Service.findOne(strUserId_i);
		// 検索結果をModelに登録
		model.addAttribute("user_id", objView2ent.getUser_id());
		//	model.addAttribute("user_password", objView2ent.getPassword()); //passwordは送らない
		model.addAttribute("user_name", objView2ent.getUser_name());
		// helloResponseDB.htmlに画面遷移
		return "view2Response";
	} //postDbRequest

} //class
