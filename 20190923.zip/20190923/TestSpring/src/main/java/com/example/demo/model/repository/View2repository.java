package com.example.demo.model.repository;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

//ポイント１：@Repository
@Repository
public class View2repository {

	// ポイント２：JdbcTemplate
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public Map<String, Object> findOne(String user_id_i) {
		// SELECT文
		String query = "SELECT "
				+ " user_id,"
				+ " password,"
				+ " user_name "
				+ "FROM user_info "
				+ "WHERE user_id=?";
		// 検索実行
		Map<String, Object> employee = jdbcTemplate.queryForMap(query, user_id_i);
		return employee;
	}

} //class
