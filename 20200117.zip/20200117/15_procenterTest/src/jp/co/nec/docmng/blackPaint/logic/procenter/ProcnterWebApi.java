package jp.co.nec.docmng.blackPaint.logic.procenter;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;

import org.apache.log4j.Logger;

import jp.co.nec.docmng.blackPaint.entity.procenter.PrcenterConvert;
import jp.co.nec.docmng.blackPaint.entity.procenter.ProcenterEnt;



public class ProcnterWebApi {

	static Logger objLog = Logger.getLogger(ProcnterWebApi.class);
	private static final String EOL = "\r\n";


	/**
	 * strUrl_iをgetでCallする
	 * @param String strUrl_i   webapiurl
	 * @return void
	 * @throws Exception
	 */
	public void getUrlCall(String strUrl_i) throws Exception{

		HttpURLConnection  urlConn = null;
		InputStream in = null;
		BufferedReader reader = null;

		//接続するURLを指定する
		URL url = new URL(strUrl_i);

		//コネクションを取得する
		urlConn = (HttpURLConnection) url.openConnection();
		urlConn.setRequestMethod("GET");
		urlConn.connect();

		int status = urlConn.getResponseCode();

		objLog.info("HTTPステータス:" + status);

		if (status == HttpURLConnection.HTTP_OK) {

			in = urlConn.getInputStream();

			reader = new BufferedReader(new InputStreamReader(in));

			StringBuilder output = new StringBuilder();
			String line;

			while ((line = reader.readLine()) != null) {
				output.append(line);
			}
			objLog.info(output.toString());
		} //if

		if (reader != null) {
			reader.close();
		} //if
		if (urlConn != null) {
			urlConn.disconnect();
		} //if

	} //method

	/**
	 * PROCENTER/CのWEBAPIを呼び出す(form-urlencoded)
	 * @param String strUrl_i   webapiurl
	 * @param String strJson_i strUrl_iにわたすjsonString
	 * @return ProcenterEnt jacksonでコンバートしたbeen
	 * @throws Exception
	 */
	public ProcenterEnt getProCenterUrencode(String strUrl_i,String strJson_i) throws Exception{

		String strRet = "";
		String method = "POST";
		String strEncJson  = "";
		int intRet=0;
		//connection open
		HttpURLConnection objCon = (HttpURLConnection) new URL(strUrl_i).openConnection();

		//header
		objCon.setDoOutput(true);
		objCon.setRequestMethod(method);
		objCon.setUseCaches(false);
		objCon.setRequestProperty("User-Agent","PROCENTER_C_WEBAPI_CLIENT_XXX");
		objCon.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

		//body
		OutputStream objOS = null;
		try {
			objOS = objCon.getOutputStream();
			objOS.write(strJson_i.getBytes(StandardCharsets.UTF_8));
		} finally {
			if (objOS!=null) objOS.close();
		} //try

		objOS.flush();
		InputStream obIin = null;
		try {
			//結果取得
			intRet = objCon.getResponseCode();
			obIin = objCon.getInputStream();
			byte[] getBodys= obIin.readAllBytes();
			strRet = new String(getBodys);
		} catch (Exception e) {
			objLog.error(e);
		} finally {
			//keep-aliveなので切断なし
//			objCon.disconnect();
		} //try


		//json convert
		PrcenterConvert prcenterConvert = new PrcenterConvert();
		ProcenterEnt procenterEnt = prcenterConvert.fromJsonString(strRet);

		return procenterEnt;
	}


//
//	/**
//	 * PROCENTER/CのWEBAPIを呼び出す(form-urlencoded)
//	 * @param String strUrl_i   webapiurl
//	 * @param String strJson_i strUrl_iにわたすjsonString
//	 * @return ProcenterEnt jacksonでコンバートしたbeen
//	 * @throws Exception
//	 */
//	public ProcenterEnt getProCenterUrencode(String strUrl_i,String strJson_i) throws Exception{
//
//		//header
//		HttpHeaders objHeaders = new HttpHeaders();
//		objHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
//
//		objLog.info("json:"+strJson_i);
//
//		//body
//		MultiValueMap<String, String> hashQuery= new LinkedMultiValueMap<String, String>();
//		String strEncoding = "UTF-8";
//		String strEncJson = "";
////		strEncJson=URLEncoder.encode(strJson_i, strEncoding);
//		hashQuery.add("query=", strEncJson);
//
//		//Request
//		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(hashQuery, objHeaders);
//
//		RestTemplate restTemplate = new RestTemplate(new SimpleClientHttpRequestFactory());
//
//		//Response
//		ResponseEntity<String> entResponse = restTemplate.postForEntity( strUrl_i, request , String.class );
//
//		//json convert
//		PrcenterConvert prcenterConvert = new PrcenterConvert();
//		ProcenterEnt procenterEnt = prcenterConvert.fromJsonString(entResponse.getBody());
//
//		return procenterEnt;
//
//	} //method

	/**
	 * PROCENTER/CのWEBAPIを呼び出す(multipart)
	 * ※ファイルアップロードときはこちらを呼び出す
	 * @param String strUrl_i   webapiurl
	 * @param String strJson_i strUrl_iにわたすjsonString
	 * @return ProcenterEnt jacksonでコンバートしたbeen
	 * @throws Exception
	 */

		public int getProCenterMultipart(List<String> listFilePath, String strUrl_i) throws Exception {

			String method = "POST";
			String strBoundary = "---------------------------7dd24e3050716";
			String strEncJson  = "";
			//connection open
			HttpURLConnection objCon = (HttpURLConnection) new URL(strUrl_i).openConnection();

			//header
			objCon.setDoOutput(true);
			objCon.setRequestMethod(method);
			objCon.setUseCaches(false);
			objCon.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + strBoundary);
			OutputStream objOS = objCon.getOutputStream();

			for (int i = 0; i <= listFilePath.size(); i++) {
				if(i==0) { //jsonの作成
					//セッションと結合
					String strJson = "";
					strJson+="\"files\": [";
					for (int j = 0; j < listFilePath.size(); j++) {
						strJson+="\"file_"+(j+1)+"\",";
					} //for
					strJson = strJson.substring(0,strJson.length()-1);
					strJson +="]";

					//※※※※※※session infoと結合

					strEncJson=URLEncoder.encode(strJson, "UTF-8");

					objOS.write(("--" + strBoundary + EOL +
							"Content-Disposition: form-data; name=\"query\"; " +
//							strEncJson + EOL).getBytes(StandardCharsets.UTF_8)) ;
							strEncJson + EOL +
							"Content-Type: application/octet-stream" + EOL + EOL)
									.getBytes(StandardCharsets.UTF_8));
//					byte[] arrBuffer = new byte[128];
//					int intSize = -1;
//					while (-1 != (intSize = objFile.read(arrBuffer))) {
//						objOS.write(arrBuffer, 0, intSize);
//					}
				}else { //実ファイル送付
					String filename = listFilePath.get(i - 1);
					FileInputStream objFile = new FileInputStream(filename);
					objOS.write(("--" + strBoundary + EOL +
							"Content-Disposition: form-data; name=\"file_"+(i)+"\"; " +
							"filename=\"" + filename + "\"" + EOL +
							"Content-Type: application/octet-stream" + EOL + EOL)
									.getBytes(StandardCharsets.UTF_8));
					byte[] arrBuffer = new byte[128];
					int intSize = -1;
					while (-1 != (intSize = objFile.read(arrBuffer))) {
						objOS.write(arrBuffer, 0, intSize);
					}
					objFile.close();

				} //if


			} //for
			objOS.write((EOL + "--" + strBoundary + "--" + EOL).getBytes(StandardCharsets.UTF_8));
			objOS.flush();

			int intRet = 0;

			try {
				intRet = objCon.getResponseCode();
			} catch (Exception e) {
				System.err.println(e);
			} finally {
				//keep-aliveなので切断なし
//				objCon.disconnect();
			} //try

			return intRet;

		} //method


} //PolicyGet
