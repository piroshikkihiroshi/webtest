package com.example.app.login;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@Controller
public class LoginController {

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String index(Model model) {
        model.addAttribute("message", "Hello Springboot");
        return "index";
    }


    @RequestMapping(value = "/9_splingTest/aaa", method = RequestMethod.GET)
    public String aaa(Model model) {
        model.addAttribute("message", "Hello Springboot");
        return "index";
    }

//    public ModelAndView  login(ModelAndView modelAndView) {
//
////        ModelAndView modelAndView = new ModelAndView();
//        modelAndView.addObject("test","test");
////        modelAndView.addObject(new User("紀伊", "太郎"));
//        modelAndView.setViewName("/login.html");
//        return modelAndView;
//
//    }



}
