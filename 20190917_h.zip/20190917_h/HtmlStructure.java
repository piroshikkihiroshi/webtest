package htmlMaskTest;

/**
 * HTMLのchar毎の情報を格納するクラス
 * HashMap<Integer, HtmlStructure> の形で格納し、keyは置換対象外文字やtagを含んだポジション
 * (<div>タグ等を含む)を格納する
 */
public class HtmlStructure {
	public String strTgt = ""; //対象文字
	public int intStatus = 0; //strTgtのステータス 0：置換対象外(半角文字等) 1：対象 2：tag
	public int intNotTagPos = 0; //置換対象外文字やtagを抜いたときのポジション


} //class
