/**
 * 名称：SearchServerInfoForm.java
 * 機能名：
 * 概要：
 */

package jp.co.nec.docmng.manage.entity;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * 
 */
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class SearchServerInfoForm {

	/**
	 * displayName getter
	 * @return displayName
	 */
    public String getDisplayName() {
		return displayName;
	}
    /**
     * displayName setter
     * @param displayName
     */
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	/**
	 * serverName getter
	 * @return serverName
	 */
	public String getServerName() {
		return serverName;
	}
    /**
     * serverName setter
     * @param serverName
     */
	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

	/**
	 * directoryPath getter
	 * @return directoryPath
	 */
	public String getDirectoryPath() {
		return directoryPath;
	}
    /**
     * directoryPath setter
     * @param directoryPath
     */
	public void setDirectoryPath(String directoryPath) {
		this.directoryPath = directoryPath;
	}

	/**
	 * loginUserName getter
	 * @return loginUserName
	 */
	public String getLoginUserName() {
		return loginUserName;
	}
    /**
     * loginUserName setter
     * @param loginUserName
     */
	public void setLoginUserName(String loginUserName) {
		this.loginUserName = loginUserName;
	}

	/**
	 * loginPassword getter
	 * @return loginPassword
	 */
	public String getLoginPassword() {
		return loginPassword;
	}
    /**
     * loginPassword setter
     * @param loginPassword
     */
	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}
	
	@NotBlank(message = "必須項目です。")
    private String displayName;
    @NotBlank(message = "必須項目です。")
    private String serverName;
    @NotBlank(message = "必須項目です。")
    private String directoryPath;
    @NotBlank(message = "必須項目です。")
    private String loginUserName;
    @NotBlank(message = "必須項目です。")
    private String loginPassword;

}
