/**
 * 名称：PolicyKeywordInfoService.java
 * 機能名：管理系ポリシーキーワード情報連携
 * 概要：管理系にて使用するポリシーキーワード情報への連携用サービス
 */

package jp.co.nec.docmng.manage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.manage.entity.PolicyKeywordInfo;
import jp.co.nec.docmng.manage.util.map.PolicyKeywordInfoMapManage;

/**
 * 管理系ポリシーキーワード情報連携
 */
@Service
public class PolicyKeywordInfoService {

    @Autowired
    private PolicyKeywordInfoMapManage policyKeywordMapper;

	/**
	 * 全件取得
	 * @return 検索結果
	 */
    @Transactional
    public List<PolicyKeywordInfo> findAll(){
        List<PolicyKeywordInfo> entityList = policyKeywordMapper.findAll();
        return entityList;
    }

	/**
	 * データ削除_ポリシー指定
	 * @param policyId ポリシーID
	 */
    public void deleteKeyWord(Integer policyId) {
        policyKeywordMapper.deleteKeyWord(policyId);
    }

}
