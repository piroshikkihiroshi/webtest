/**
 * 名称：PolicyKeywordInfoMapPaint.java
 * 機能名：黒塗り処理黒塗りポリシーキーワード情報連携
 * 概要：黒塗り処理にて使用する黒塗りポリシーキーワード情報への連携用レポジトリ
 */

package jp.co.nec.docmng.blackPaint.repository;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import jp.co.nec.docmng.blackPaint.entity.PolicyKeywordInfoBlackPaint;
import jp.co.nec.docmng.manage.entity.PolicyKeywordInfo;

/**
 * 黒塗り処理黒塗りポリシーキーワード情報連携
 */
@Mapper
public interface PolicyKeywordInfoMapPaint {

	/**
	 * 全件取得
	 * @return 検索結果
	 */
    @Select("select * from admin.policy_keyword_info order by policy_id asc, update_time desc")
    public List<PolicyKeywordInfoBlackPaint> findAll();
	
	/**
	 * データ登録処理
	 * @param objEnt 登録内容を格納したentity
	 */
	@Insert("INSERT INTO admin.policy_keyword_info( policy_id, policy_keyword, create_time, update_time) VALUES ( #{policyId}, #{policyKeyword}, #{createTime}, #{updateTime})")
    public void insertPolicyKeyword(PolicyKeywordInfoBlackPaint objEnt);

} //interface
