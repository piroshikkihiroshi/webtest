/**
 * 名称：SearchServerInfoEntity.java
 * 機能名：管理系検索対象サーバ設定情報entity
 * 概要：管理系で使用する検索対象サーバ設定情報entity
 */

package jp.co.nec.docmng.manage.entity;

import java.sql.Timestamp;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

/**
 * 管理系検索対象サーバ設定情報entity
 */
@Data
public class SearchServerInfoEntity {

	/**
	 * サーバID
	 */
	private Integer serverId;

	/**
	 * サーバ名
	 */
    private String serverName;

	/**
	 * 表示名
	 */
    private String displayName;

	/**
	 * ログインユーザ名
	 */
    private String loginUserName;

	/**
	 * ログインパスワード
	 */
    private String loginPassword;

	/**
	 * ディレクトリパス
	 */
    private String directoryPath;

	/**
	 * 作成日時
	 */
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss.SSS", timezone = "Asia/Tokyo")
    private Timestamp createTime;

	/**
	 * 更新日時
	 */
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss.SSS", timezone = "Asia/Tokyo")
    private Timestamp updateTime;

}
