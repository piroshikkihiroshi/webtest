package jp.co.nec.docmng.manage.controller;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.common.DBConnection;
import jp.co.nec.docmng.manage.entity.PolicyInfoEntity;
import jp.co.nec.docmng.manage.entity.TmpTeacherPolicyList;
import jp.co.nec.docmng.manage.entity.TmpTeacherPolicyListReqForm;

@SuppressWarnings("javadoc")
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class TrainingPolicyControllerTest {

    DBConnection dbConnection = new DBConnection();

    private MockMvc mockMvc;

    /**
     * 黒塗りポリシー一覧が空の場合のエラーメッセージ
     */
    static final String POLICYINFO_EMPTYERR = "ポリシー情報が存在しません。";

    @Autowired
    TrainingPolicyController target;

    @Before
    public void setup() {
        mockMvc = MockMvcBuilders.standaloneSetup(target).build();
    }

    // 必要なテーブルを空にする（使いまわすためメソッド化）
    private void DBEmpty () {
        // 削除のSQL文
        String deletePolicyInfo = "delete from admin.policy_info";
        String deleteTmpTeacherPolicyList = "delete from admin.tmp_teacher_policy_list";
        // SQL実行
        // 外部キーのあるテーブルから削除
        dbConnection.SQLExe(deleteTmpTeacherPolicyList);
        dbConnection.SQLExe(deletePolicyInfo);
    }
    // テストに必要なデータ（SQL）
    String insertPolicyInfo = "insert into admin.policy_info " +
            " (policy_id, policy_number, policy_name, policy_author, policy_reason, create_time, update_time)" +
            "	VALUES" +
//            "	(1, 1, 'name1', 'author1', 'reason1', '2019/11/11 12:00:00', '2019/11/11 12:00:00')," +
            "	(0, 0, 'その他', 'author1', 'reason1', '2019/11/11 12:00:00', '2019/11/11 12:00:00')," +
            "	(1, 1, 'name1', 'author1', 'reason1', '2019/11/11 12:00:00', '2019/11/11 12:00:00')," +
            "	(2, 5, 'name2', 'author2', 'reason2', '2019/11/11 12:00:00', '2019/11/11 12:00:00')," +
            "	(3, 4, 'name3', 'author3', 'reason3', '2019/11/11 12:00:00', '2019/11/11 12:00:00')," +
            "	(4, 2, 'name4', 'author4', 'reason4', '2019/11/11 12:00:00', '2019/11/11 12:00:00')," +
            "	(5, 3, 'name5', 'author5', 'reason5', '2019/11/11 12:00:00', '2019/11/11 12:00:00');";

    String insertTmpTeacherPolicyInfo = "INSERT INTO admin.tmp_teacher_policy_list(" +
            "	user_id, sort_id, policy_id, directory_path, create_time, update_time)" +
            "	VALUES" +
//            "	('user1', 1, 1, '\\\\yoks3106\\NES_文書管理システム\\99_tmp\\岩淵\\test\\category\\test1\\', '2019/11/06 12:00:00', '2019/11/06 12:00:00');"
            "	('user1', 1, 1, '\\\\yoks3106\\NES_文書管理システム\\99_tmp\\岩淵\\test\\category\\test1\\', '2019/11/06 12:00:00', '2019/11/06 12:00:00'),"+
            "	('user1', 3, 2, '\\\\yoks3106\\NES_文書管理システム\\99_tmp\\岩淵\\test\\category\\test2\\', '2019/11/06 12:00:00', '2019/11/06 12:00:00')," +
            "	('user1', 2, 3, '\\\\yoks3106\\NES_文書管理システム\\99_tmp\\岩淵\\test\\category\\test3\\', '2019/11/06 12:00:00', '2019/11/06 12:00:00')," +
            "	('user1', 4, 4, '\\\\yoks3106\\NES_文書管理システム\\99_tmp\\岩淵\\test\\category\\test4\\', '2019/11/06 12:00:00', '2019/11/06 12:00:00');";

    /**
     * 教師データ登録（黒塗り箇所摘出）一覧表示
     * 黒塗りポリシー一覧が空の場合
     * @throws Exception
     */
    @Test
    public void test_getTrainingPolicy001() throws Exception {
        // DBとの接続を確立
        dbConnection.DBConnect();
        // 事前に必要なテーブルを空にする
        DBEmpty();
        // テスト実施前に必要なテーブルをinsert

        MvcResult result = mockMvc.perform(get("/manage/training_policy"))
        .andExpect(status().isOk())
        .andExpect(view().name("manage/training_policy"))
        .andExpect(model().attribute("err", POLICYINFO_EMPTYERR))//TODO
        .andReturn();

        @SuppressWarnings("unchecked")
        List<PolicyInfoEntity> resultPolicyInfo = (List<PolicyInfoEntity>) result.getModelAndView().getModel().get("policyInfo");
        // 応答値のポリシーIDが1の列を取得出来ている事を確認
        // DBとの接続をclose
        dbConnection.DBClose();
        System.out.println("test_getTrainingPolicy001 正常終了");
    }

    /**
     * 教師データ登録（黒塗り箇所摘出）一覧表示（正常系）
     * @throws Exception
     */
    @Test
    public void test_getTrainingPolicy002() throws Exception {
        // DBとの接続を確立
        dbConnection.DBConnect();
        // 事前に必要なテーブルを空にする
        DBEmpty();
        // テスト実施前に必要なテーブルをinsert
        dbConnection.SQLExe(insertPolicyInfo);
        dbConnection.SQLExe(insertTmpTeacherPolicyInfo);

        MvcResult result = mockMvc.perform(get("/manage/training_policy"))
        .andExpect(status().isOk())
        .andExpect(view().name("manage/training_policy"))
        .andReturn();

        @SuppressWarnings("unchecked")
        List<PolicyInfoEntity> resultPolicyInfo = (List<PolicyInfoEntity>) result.getModelAndView().getModel().get("policyInfo");
        System.out.println(resultPolicyInfo);
        int policyId = resultPolicyInfo.get(0).getPolicyId();
        System.out.println(policyId);
        // 応答値のポリシーIDが1の列を取得出来ている事を確認
        // DBとの接続をclose
        dbConnection.DBClose();
        assertEquals(policyId, 1);
        System.out.println("test_getTrainingPolicy002 正常終了");

    }

    /**
     * teacherCategoryReflect001
     * 保存先のフォルダが存在しない場合
     * @throws Exception
     */
    @Test
    public void test_teacherCategoryReflect() throws Exception{
        // DBとの接続を確立
        dbConnection.DBConnect();
        // 事前に必要なテーブルを空にする
        DBEmpty();
        // テスト実施前に必要なテーブルをinsert
        dbConnection.SQLExe(insertPolicyInfo);
        dbConnection.SQLExe(insertTmpTeacherPolicyInfo);
        // リクエストデータ作成
        TmpTeacherPolicyListReqForm requestForm = new TmpTeacherPolicyListReqForm();
        List<TmpTeacherPolicyList> tmpTeacherPolicyList = new ArrayList<TmpTeacherPolicyList>();
        TmpTeacherPolicyList tmpTeacherPolicy = new TmpTeacherPolicyList();
        String userId[] = {"user00001"};
        int sortId[] = {0};
        int policyId[]= {1};
        String directoryPath[] = {"\\\\yoks3106\\NES_文書管理システム\\99_tmp\\岩淵\\test\\test1"};
        for (int i = 0 ; i < userId.length ; i++ ) {
            tmpTeacherPolicy.setUserId(userId[i]);
            tmpTeacherPolicy.setSortId(sortId[i]);
            tmpTeacherPolicy.setPolicyId(policyId[i]);
            tmpTeacherPolicy.setDirectoryPath(directoryPath[i]);
            tmpTeacherPolicyList.add(tmpTeacherPolicy);
        }
        // リクエストデータ登録
        requestForm.setTmpTeacherPolicyList(tmpTeacherPolicyList);
        requestForm.setSavePath("\\errtest\\");
        ObjectMapper mapper = new ObjectMapper();
        String requestJson = mapper.writeValueAsString(requestForm);

        // POSTテスト
        mockMvc.perform(post("/manage/training_policy/teacher_policy_reflect")
//                .param("saveValue", requestJson))
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(requestJson))
        .andExpect(status().is4xxClientError()) // 400　エラー応答が返ってくる事
        .andReturn();

        // DBとの接続を確立
        System.out.println("test_teacherCategoryReflect001 正常終了");
        // テストに利用したDBを空にして終了
        DBEmpty();
        // DBとの接続をclose
        dbConnection.DBClose();
    }

    /**
     * teacherCategoryReflect001
     * 正解データ格納先が存在しない場合
     * @throws Exception
     */
    @Test
    public void test_teacherCategoryReflect002() throws Exception{
        // DBとの接続を確立
        dbConnection.DBConnect();
        // 事前に必要なテーブルを空にする
        DBEmpty();
        // テスト実施前に必要なテーブルをinsert
        dbConnection.SQLExe(insertPolicyInfo);
        dbConnection.SQLExe(insertTmpTeacherPolicyInfo);
        // リクエストデータ作成
        TmpTeacherPolicyListReqForm requestForm = new TmpTeacherPolicyListReqForm();
        List<TmpTeacherPolicyList> tmpTeacherPolicyList = new ArrayList<TmpTeacherPolicyList>();
        TmpTeacherPolicyList tmpTeacherPolicy = new TmpTeacherPolicyList();
        String userId[] = {"user00001"};
        int sortId[] = {0};
        int policyId[]= {1};
        String directoryPath[] = {"\\errtest\\"};//存在しないフォルダ
        for (int i = 0 ; i < userId.length ; i++ ) {
            tmpTeacherPolicy.setUserId(userId[i]);
            tmpTeacherPolicy.setSortId(sortId[i]);
            tmpTeacherPolicy.setPolicyId(policyId[i]);
            tmpTeacherPolicy.setDirectoryPath(directoryPath[i]);
            tmpTeacherPolicyList.add(tmpTeacherPolicy);
        }
        // リクエストデータ登録
        requestForm.setTmpTeacherPolicyList(tmpTeacherPolicyList);
        requestForm.setSavePath("\\\\yoks3106\\NES_文書管理システム\\99_tmp\\岩淵\\test\\tmp");
        ObjectMapper mapper = new ObjectMapper();
        String requestJson = mapper.writeValueAsString(requestForm);

        // POSTテスト
        mockMvc.perform(post("/manage/training_policy/teacher_policy_reflect")
//                .param("saveValue", requestJson))
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(requestJson))
        .andExpect(status().is4xxClientError()) // 400　エラー応答が返ってくる事
        .andReturn();

        // DBとの接続を確立
        System.out.println("test_teacherCategoryReflect002 正常終了");
        // テストに利用したDBを空にして終了
        DBEmpty();
        // DBとの接続をclose
        dbConnection.DBClose();
    }
    /**
     * teacherCategoryReflect（正常系）
     * @throws Exception
     */
    @Test
    public void test_teacherCategoryReflectXXX() throws Exception{
        // DBとの接続を確立
        dbConnection.DBConnect();
        // 事前に必要なテーブルを空にする
        DBEmpty();
        // テスト実施前に必要なテーブルをinsert
        dbConnection.SQLExe(insertPolicyInfo);
        dbConnection.SQLExe(insertTmpTeacherPolicyInfo);
        // リクエストデータ作成
        TmpTeacherPolicyListReqForm requestForm = new TmpTeacherPolicyListReqForm();
        List<TmpTeacherPolicyList> tmpTeacherPolicyList = new ArrayList<TmpTeacherPolicyList>();
        TmpTeacherPolicyList tmpTeacherPolicy = new TmpTeacherPolicyList();
        String userId[] = {"user00001"};
        int sortId[] = {0};
        int policyId[]= {1};
        String directoryPath[] = {"\\\\yoks3106\\NES_文書管理システム\\99_tmp\\岩淵\\test\\test1"};
        for (int i = 0 ; i < userId.length ; i++ ) {
            tmpTeacherPolicy.setUserId(userId[i]);
            tmpTeacherPolicy.setSortId(sortId[i]);
            tmpTeacherPolicy.setPolicyId(policyId[i]);
            tmpTeacherPolicy.setDirectoryPath(directoryPath[i]);
            tmpTeacherPolicyList.add(tmpTeacherPolicy);
        }
        // リクエストデータ登録
        requestForm.setTmpTeacherPolicyList(tmpTeacherPolicyList);
        requestForm.setSavePath("\\\\yoks3106\\NES_文書管理システム\\99_tmp\\岩淵\\test\\tmp");
        ObjectMapper mapper = new ObjectMapper();
        String requestJson = mapper.writeValueAsString(requestForm);

        // POSTテスト
        mockMvc.perform(post("/manage/training_policy/teacher_policy_reflect")
//                .param("saveValue", requestJson))
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(requestJson))
        .andExpect(status().isOk()) // 200　正常応答が返ってくる事
        .andReturn();

        // DBとの接続を確立
        dbConnection.DBConnect();
        String selectrequestData = "select * from admin.tmp_teacher_policy_list order by sort_id";
        // DB登録結果を取得する
        ResultSet resultSet = dbConnection.SelectSQLExe(selectrequestData);
        for (int i = 0 ; resultSet.next() ; i++) {
            // リクエスト情報と登録結果を比較
            assertEquals(userId[i], resultSet.getString("user_id"));
            assertEquals(sortId[i], resultSet.getInt("sort_id"));
            assertEquals(policyId[i], resultSet.getInt("policy_id"));
            assertEquals(directoryPath[i], resultSet.getString("directory_path"));
        }
        System.out.println("test_teacherCategoryReflect 正常終了");
        // テストに利用したDBを空にして終了
        DBEmpty();
        // DBとの接続をclose
        dbConnection.DBClose();
    }

}
