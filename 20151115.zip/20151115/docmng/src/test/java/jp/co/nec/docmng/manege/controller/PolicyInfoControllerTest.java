package jp.co.nec.docmng.manege.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class PolicyInfoControllerTest {

	private MockMvc mockMvc;

	@Autowired
	PolicyInfoController target;

	@Before
	public void setup() {
		mockMvc = MockMvcBuilders.standaloneSetup(target).build();
	}

	@Test
	public void test_getPolicyInfo() throws Exception{
		mockMvc.perform(get("/manege/policy"))
        .andExpect(status().isOk())
        .andExpect(view().name("manege/policy"))
        .andExpect(model().attribute("policyInfo", ""))//TODO
        .andExpect(model().attribute("policyKeywordInfos", ""));	//TODO
	}

	@Test
	public void test_save() throws Exception{
		mockMvc.perform(post("/manege/policy")
				.param("save", "")
				.param("changedValue","")//TODO
				.param("deleteRow","")//TODO
				.param("addValue",""))//TODO
        .andExpect(status().isOk())
        .andExpect(view().name("redirect:policy"));
	}

}
