package jp.co.nec.docmng.manege.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class TrainingPolicyControllerTest {

	private MockMvc mockMvc;

	@Autowired
	TrainingPolicyController target;

	@Before
	public void setup() {
		mockMvc = MockMvcBuilders.standaloneSetup(target).build();
	}

	@Test
	public void test_getTrainingPolicy() throws Exception {
		mockMvc.perform(get("/manege/training_policy"))
        .andExpect(status().isOk())
        .andExpect(view().name("manege/training_policy"))
        .andExpect(model().attribute("policyInfo", ""))//TODO
        .andExpect(model().attribute("teacherPolicyList", ""))//TODO
        .andExpect(model().attribute("userName", "user3（管理者）"));	//TODO

	}

	@Test
	public void test_save() throws Exception{
		mockMvc.perform(post("/manege/training_policy")
				.param("saveValue", ""))//TODO
        .andExpect(status().isOk())
        .andExpect(view().name("manege/training_policy"))
        .andExpect(model().attribute("policyInfo", ""))//TODO
        .andExpect(model().attribute("teacherPolicyList", ""));//TODO
	}

}
