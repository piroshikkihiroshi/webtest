package jp.co.nec.docmng.manege.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.manege.entity.SearchServerInfoForm;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class SearchServerInfoControllerTest {

	private MockMvc mockMvc;

	@Autowired
	SearchServerInfoController target;

	@Before
	public void setup() {
		mockMvc = MockMvcBuilders.standaloneSetup(target).build();
	}

	@Test
	public void test_getSearchServerInfo() throws Exception{
		mockMvc.perform(get("/manege/search_server")
				.param("searchServerInfoForm", ""))//TODO
        .andExpect(status().isOk())
        .andExpect(view().name("manege/search_server"))
        .andExpect(model().attribute("serchServerInfo", ""))//TODO
        .andExpect(model().attribute("saveStatus", ""));	//TODO
	}

	@Test
	public void test_save() throws Exception{
		mockMvc.perform(post("/manege/search_server")
				.param("save", "")
				.param("editValue","")//TODO
				.param("deleteRow","")//TODO
				.param("addValue",""))//TODO
        .andExpect(status().isOk())
        .andExpect(view().name("redirect:search_server"));
	}

	@Test
	public void test_auth() throws Exception {

		//TODO
		SearchServerInfoForm form = new SearchServerInfoForm();
		form.setDirectoryPath("\\aaa");
		form.setLoginUserName("test");
		form.setLoginPassword("test");

		String body = (new ObjectMapper()).valueToTree(form).toString();

		mockMvc.perform(post("/manege/search_server")
				.contentType(MediaType.APPLICATION_JSON)
				.content(body))
//				.flashAttr("form", form))
//				.content(form.toString()))
//				.contentType(MediaType.APPLICATION_FORM_URLENCODED_VALUE)
//				.requestAttr("form", form))
//				.with(SecurityMockMvcRequestPostProcessors.csrf())
        .andExpect(status().isOk())
        .andExpect(view().name("redirect:policy"));
	}
}
