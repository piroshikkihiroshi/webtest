$(function () {
    /**
     * 画面が変更または閉じれる時に動作
     * ダイアログを表示する
     * messageboxで表示を行いたいが、検知の限界が存在する為「beforeunload」を使用する
     * 参考サイト：https://teratail.com/questions/51831
    **/
    $(window).on("beforeunload", function (e) {
        // POST送信フラグが「true」の場合、ダイアログを表示しない
        if (isPost) {
            return;
        } else {
            return true;
        }
    });

    /**
     * 行をクリック後に動作
     * 何がクリックされたかによってイベントを振り分ける
     **/
    document.getElementById("main_scroll_R").addEventListener("click", function (event) {
        var li = event.target;
        console.log(li);
        // ×ボタン押下時動作
        if (li.classList.contains("DeleteRowTrainingPolicy") || li.classList.contains("NewDeleteRowTrainingPolicy")) {
            deleteRow(li);
        }// if

    }, false);// function
});// function

/**
 * 選択された行を削除する。
 */
function deleteRow(li) {
    //選択した行にIDを付与
    li.parentElement.setAttribute("id", "selected");
    //選択した行の削除
    $("#selected").remove();
    // リスト件数を-1する
    teacherPolicyListSize--;
    selectCategoryEvent();
}

/**
 * 出力ボタン押下時に動作
 * 一覧表に行の新規追加を行う
**/
function AddListData() {
    //現在の行数を取得
    var objAutoRowNo = document.getElementById("main_scroll_R").children.length + 1;
    strAutoRowNo = '' + objAutoRowNo;

    var successCount = 0;
    //テキストボックス内の文字列取得
    var strAddFilePassListText = document.getElementById("addFilePassList").value;

    //最上位行のプルダウンメニュー内容を取得
    var strPullDownMenuList = document.getElementsByClassName("menu")[0].innerHTML;

    //最上位行のstyleを取得
    var strFilePassStyle = document.getElementById("main_scroll_R").children[0].children[2].style.cssText;

    if (strAddFilePassListText !== "") {
        for (let index = 0; index < document.getElementById("main_scroll_R").children.length; index++) {
            var listFile = document.getElementById("main_scroll_R").children[index].children[2].outerText;
            if (listFile !== strAddFilePassListText) {
                successCount++;
            }
        }
        if (document.getElementById("main_scroll_R").children.length === successCount) {
            //新規作成する欄を作成
            var ul = $('<ul class="tr"></ul>');
            var strDeleteButton = $('<li class="w40 bt_batsu NewDeleteRowTrainingPolicy"></li>');
            var strNonViewPlicyId = $('<li style="display: none">0</li>');
            var strPolicyPullDown = $('<li class="w100 menu dropdown_arrow_right" style="position: relative;">その他</li>');
            var strFilePassList = $('<li class="wAutoA B text_align_left" style="' + strFilePassStyle + '"></li>');
            //表に取得した値を挿入する
            $(".scrollBody").append(ul);
            ul.append(strDeleteButton).append(strNonViewPlicyId).append(strPolicyPullDown).append(strFilePassList);
            strDeleteButton.html('');
//            strPolicyPullDown.html(strPullDownMenuList);
            strFilePassList.html(strAddFilePassListText);
            //一覧追加用テキストボックスを空にする
            document.getElementById("addFilePassList").value = "";
            // 追加行にハイアラキーメニューを表示させるため再処理
            Array.from(document.querySelectorAll("#main_scroll_R ul li.menu")).map(item => hierarchyMenuProc(item));
            // リスト件数を＋１
            teacherPolicyListSize++;
            selectCategoryEvent();
        } else {
            alert("入力したディレクトリパスは既に設定済みです");
        }
    } else {
        alert("ディレクトリパスを入力後、再度ボタンを押下してください");
    }
}// function
/**
 * キャンセルボタン押下時に動作
 * ダイアログを表示する
**/
function Cancel() {
    blCan = confirm("変更内容を破棄してもよろしいでしょうか。");
    if (blCan) {
        window.close();
        sessionStorage.clear();
    } else {
        return;
    }// if
}// function
/**
 * 登録ボタン押下時に動作
 * コントローラーへDB更新データをPOSTする
 */
function postItem() {
    var savePath = $('#saveRegistrationList')[0].value;
    var policyList = $("#main_scroll_R")[0].children;
    //TODO: とりあえずユーザ名を取得しておく
    var userId = $("#USER_ID")[0].textContent;

    console.log(savePath);
    // 保存先パスの入力チェック
    if (!savePath) {
        alert("保存先パスが入力されていません");
        return;
    }
    //データ送信用
    var postData = {}
    // 送信データ列部
    var teacherPolicyList = [];
    for (let i = 0; i < policyList.length; i++) {
        // ポリシーID
        var policyData = {};
        var policyId = policyList[i].children[1].outerText;
        var path = policyList[i].children[3].textContent;
        // ユーザ名
        policyData['userId'] = userId;
        // ソードID
        policyData['sortId'] = i;
        // ポリシーID
        policyData['policyId'] = policyId;
        // 格納先パス
        policyData['directoryPath'] = path;
        teacherPolicyList[i] = policyData;
    }
    //送信データ生成
    var jsonObj = new Object();

    jsonObj.tmpTeacherPolicyList = teacherPolicyList;
    jsonObj.savePath = savePath;

    console.log(jsonObj);

    $.ajax({
        url: "/manege/training_policy/teacher_policy_reflect",
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify(jsonObj),
        // ajax通信成功時の処理
    }).done(function (data) {
        let successOrFailure = "";
        console.log(data);
        alert("登録データ一覧の更新に成功しました");
        // ajax通信失敗時の処理
        // 画面を更新する
        location.reload();
    }).fail(function (xhr, textStatus, errorThrown) {
        alert(xhr.responseText + "\r\n登録データ一覧の更新処理に失敗しました");
        // 成功でも失敗でも通信終了時に必要な処理があれば
    }).always(function () {
    });
}