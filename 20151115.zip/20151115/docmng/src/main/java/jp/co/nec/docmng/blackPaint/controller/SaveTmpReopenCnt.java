/**
 * 名称：SaveTmpReopenCnt.java
 * 機能名：一時保存再開Control
 * 概要：一時保存再開機能のControlを行う。
 */

package jp.co.nec.docmng.blackPaint.controller;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.zeroturnaround.zip.ZipUtil;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.blackPaint.entity.TmpMaskDocMarkerEntBlackPaint;
import jp.co.nec.docmng.blackPaint.entity.TmpMaskDocumentEntBlackPaint;
import jp.co.nec.docmng.blackPaint.logic.dirFile.DirCnt;
import jp.co.nec.docmng.blackPaint.logic.dirFile.FileCnt;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocTmpMarkerService;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocumentService;

/**
 * 一時保存再開機能のControlを行う。
 */
@RestController
public class SaveTmpReopenCnt {

	/**
	 * context サーブレットのRealPathを取得する
	 * objLog log出力に使用する
	 * PAGE_CLASS ページを判定するHTMLClass。ページをSplitするのに使用する
	 * ARR_HEAD ファイル名、フォルダ名を判定するために使用する
	 */
	@Autowired
	ServletContext context;
	@Autowired
	TmpMaskDocumentService tmpMaskDocumentService;
	@Autowired
	TmpMaskDocTmpMarkerService tmpMaskDocTmpMarkerService;


	static Logger objLog = LoggerFactory.getLogger(SaveTmpReopenCnt.class);

	static String PAGE_CLASS = "awdiv awpage"; //splitするページのHTMLClass
	static String[] ARR_HEAD = {"mask_","red_"}; //ファイル名、フォルダ名のヘッダー配列

	/**
	 * 一時保存再開メソッド
	 * 一時保存再開を押下したときの処理制御をする。
	 * @param strHashJson 以下の値を入れ込んだjsonString
	 * documentId ドキュメントID
	 */
	@ResponseBody
	@PostMapping("/blackpaint/SaveTmpReopen")
	@ResponseStatus(HttpStatus.OK)
	public String SaveTmpDocCntRest(
			@RequestBody String strHashJson,
			@CookieValue(value="user_id", required=false) String UserId,
			Model model) {

		//モデル初期化
		FileCnt objFileCnt = new FileCnt();
		DirCnt  objDirCls = new DirCnt();

		//メンバ変数初期化
		String strTmpDir=""; //黒塗り編集画面で処理したHTMLが格納されたTMPディレクトリ名。
		String strFileName=""; //オリジナルwordファイル名。
		int intDocumentId=-1; //documentId

		String strBasePath =""; //黒塗り作成時の作業フォルダ
		String strFileOutDir=""; //出力フォルダ
		String strRealPath = context.getRealPath("/");
		String strTmpTimeStamp=""; //tempファイルタイムスタンプ
		strTmpTimeStamp=String.valueOf(System.currentTimeMillis());

		//POSTされたjsonをパースする
		ObjectMapper objMapper = new ObjectMapper();
		List<Map<String, String>> objTmpList = null;
		TypeReference<List<Map<String, String>>> objType = new TypeReference<List<Map<String, String>>>() {};
		try {
			objTmpList = objMapper.readValue(strHashJson, objType);
		} catch (JsonParseException e) {
			objLog.error( "err message", e );
			e.printStackTrace();
		} catch (JsonMappingException e) {
			objLog.error( "err message", e );
			e.printStackTrace();
		} catch (IOException e) {
			objLog.error( "err message", e );
			e.printStackTrace();
		} //try

		HashMap<String, String> objMap = (HashMap<String, String>) objTmpList.get(0);

		for (String strKey : objMap.keySet()) {
			switch (strKey) {
			case "tmpDir":
				strTmpDir = objMap.get(strKey);
				break;
			case "strFileName":
				strFileName = objMap.get(strKey);
				break;
			case "documentId":
				intDocumentId = Integer.parseInt(objMap.get(strKey)) ;
				break;
			default:
				break;
			} //switch

		} //for

		//一時保存したzipをDBから取得
//		byte[] arrHtmlZip = tmpMaskDocumentService.getHtmlZip(intDocumentId, UserId);
		List<TmpMaskDocumentEntBlackPaint> listZip=null;
		byte[] arrHtmlZip=null;
		List<TmpMaskDocMarkerEntBlackPaint> listInfo = null;

		try {
			listZip = tmpMaskDocumentService.getTmpHtmlZip(intDocumentId, UserId);
			arrHtmlZip = listZip.get(0).getHtmlZipData();
			//policy等取得
			listInfo = tmpMaskDocTmpMarkerService.selectTmpMaskDocMarker(intDocumentId, UserId);

		} catch (Exception e) {
			objLog.error( "err message", e );
			e.printStackTrace();
		} //try

		//file出力
		//出力フォルダ作成
		strBasePath=strRealPath + strTmpDir ;
		strFileOutDir=strRealPath+"tmp"+strTmpTimeStamp+"/";
		String strZipPath = strFileOutDir + "mask.zip";
		String strUnZipPath = strRealPath+"zip"+strTmpTimeStamp+"/";
		Path objZipPath = Paths.get(strZipPath);
		try {
			objDirCls.makeDirWithCheck(strFileOutDir);
			//zipファイル出力
			Files.write(objZipPath, arrHtmlZip);
			//unzipする
//			ZipUtil.unpack(new File(strZipPath), new File(strUnZipPath));
			//現在のhtmlと入れ替える
//			objDirCls.DelDirctory(strBasePath); //一旦削除
//			FileUtils.moveDirectory(new File(strUnZipPath), new File(strBasePath));

			//セッションで削除できないためそのままunzip
			ZipUtil.unpack(new File(strZipPath), new File(strBasePath));


			//作業ディレクトリかたづけ
			objDirCls.DelDirctory(strFileOutDir);


		} catch (IOException e1) {
			objLog.error( "err message", e1 );
			e1.printStackTrace();
		} //try
		catch (Exception e) {
			objLog.error( "err message", e );
			e.printStackTrace();
		} //try

		String strRet = "";
		//jsonにしてpolicy等の情報を返す
        try {
        	strRet=objMapper.writeValueAsString(listInfo);
		} catch (JsonProcessingException e) {
			objLog.error( "err message", e );
			e.printStackTrace();
		} //if

	return strRet;

} //getView1




} //MaskHtmlCnt
