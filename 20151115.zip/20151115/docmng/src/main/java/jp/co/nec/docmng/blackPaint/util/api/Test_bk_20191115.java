package jp.co.nec.docmng.blackPaint.util.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import jp.co.nec.docmng.blackPaint.repository.PolicyInfoMapPaint;



@RestController
public class Test_bk_20191115 {

	@Autowired
	PolicyInfoMapPaint objPolicyInfoService;


	@GetMapping("/rest/protestaaaa")
	public String getProCenterInfo(){
//		String strRet = "";
//		RestTemplate restTemplate = new RestTemplate();
//		Map<String, String> vars = new HashMap<String, String>();
//		vars.put("user", "masason");
//		vars.put("count", "10");
////		String response = restTemplate.getForObject("http://twitter.com/statuses/user_timeline/{user}.json?count={count}", String.class, vars);
//		String response = restTemplate.getForObject("http://localhost/hiddenstoresearch/api/station.json", String.class, vars);
//
//		return response;

		String url = "http://localhost/hiddenstoresearch/api/station.json";
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

		MultiValueMap<String, String> map= new LinkedMultiValueMap<String, String>();
		map.add("query", "[test]");

		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(map, headers);

		RestTemplate restTemplate = new RestTemplate(new SimpleClientHttpRequestFactory());
		ResponseEntity<String> response = restTemplate.postForEntity( url, request , String.class );

		return response.getBody();

	} //getPlicyAll

} //PolicyGet
