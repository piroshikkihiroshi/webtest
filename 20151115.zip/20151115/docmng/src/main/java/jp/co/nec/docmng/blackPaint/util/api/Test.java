package jp.co.nec.docmng.blackPaint.util.api;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import jp.co.nec.docmng.blackPaint.repository.PolicyInfoMapPaint;



@RestController
public class Test {

	@Autowired
	PolicyInfoMapPaint objPolicyInfoService;


	@GetMapping("/rest/protest")
	public String getTest(){
		String strRet = "";
		String strUrl = "http://localhost/test/phpinfo.php?XDEBUG_SESSION_START=xdebug";
		String strJson = "test";
		Test objMe = new Test();
		strRet = objMe.getProCenterInfo(strUrl, strJson);

		return strRet;

	} //method

	public String getProCenterInfo(String strUrl_i,String strJson_i){
		HttpHeaders objHeaders = new HttpHeaders();
		objHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

		MultiValueMap<String, String> hashQuery= new LinkedMultiValueMap<String, String>();
		String strEncoding = "UTF-8";
		String strEncJson = "";
		try {
			strEncJson=URLEncoder.encode(strJson_i, strEncoding);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} //try

		hashQuery.add("query", strEncJson);

		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(hashQuery, objHeaders);

		RestTemplate restTemplate = new RestTemplate(new SimpleClientHttpRequestFactory());
		ResponseEntity<String> entResponse = restTemplate.postForEntity( strUrl_i, request , String.class );

		return entResponse.getBody();

	} //method



} //PolicyGet
