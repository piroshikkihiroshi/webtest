package jp.co.nec.docmng.blackPaint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.blackPaint.entity.DocumentInfoEntPaint;
import jp.co.nec.docmng.blackPaint.repository.DocumentMapPaint;

@Service
public class DocInfoService {
	@Autowired
	private DocumentMapPaint documentMapPaint;

	//table document_info

	@Transactional
	public List<DocumentInfoEntPaint> selectDocInfo(int document_id) {
		return documentMapPaint.selectDocInfo(document_id);

	} //insertMaskDocument



} //PolicyInfoServiceApi
