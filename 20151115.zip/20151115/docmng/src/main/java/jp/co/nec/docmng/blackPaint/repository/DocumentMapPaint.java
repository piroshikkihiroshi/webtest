package jp.co.nec.docmng.blackPaint.repository;


import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import jp.co.nec.docmng.blackPaint.entity.CategoryEntPaint;
import jp.co.nec.docmng.blackPaint.entity.DocumentInfoEntPaint;
import jp.co.nec.docmng.blackPaint.entity.MaskDocMarkerEntBlackPaint;


@Mapper
public interface DocumentMapPaint {

    @Select("SELECT * FROM common.document_info WHERE document_id = #{document_id}")
    public List<DocumentInfoEntPaint> selectDocInfo(int document_id);
    
	/*
	 * @Select("SELECT  FROM common.document_info WHERE document_id = #{document_id}"
	 * ) public List<DocumentInfoEntPaint> selectDocFileInfo(Integer document_id);
	 */

} //PolicyInfoMapper
