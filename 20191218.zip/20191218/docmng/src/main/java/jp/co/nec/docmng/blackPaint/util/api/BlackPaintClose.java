package jp.co.nec.docmng.blackPaint.util.api;

import javax.servlet.ServletContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nec.docmng.blackPaint.logic.dirFile.DirCnt;



@RestController
public class BlackPaintClose {

	@Autowired
	ServletContext context;

	static Logger objLog = LoggerFactory.getLogger(BlackPaintClose.class);
	/**
	 * 終了処理(作業directory片付け)
	 */
	@GetMapping("/rest/tmpdir/del")
	public String closeTmpDir(HttpServletRequest request) {
		String strRet = "";

		//モデル初期化
		DirCnt objDirCls = new DirCnt();
		Cookie cookie[] = request.getCookies();
		String strTmpDir_i = "";
		if (cookie != null){
			for (int i = 0 ; i < cookie.length ; i++){
				if (cookie[i].getName().equals("strTmpDirName")){
					strTmpDir_i = cookie[i].getValue();
				} //if
			} //for
		} //if

		//作業ディレクトリかたずけ
		if(strTmpDir_i.equals(""))  {
			objLog.info("作業ディレクトリの取得が失敗しました");
			strRet="fail";
		}else {
			try {
				//作業ディレクトリ,ファイルかたづけ
				objDirCls.DelDirctory(context.getRealPath("/") + strTmpDir_i);
				objLog.info("作業ディレクトリ削除完了");
				strRet="success";
			} catch (Exception e1) {
				objLog.info("作業ディレクトリ削除失敗");
				strRet="fail";
			} //try

		} //if

		return strRet;
	} //method

} //PolicyGet
