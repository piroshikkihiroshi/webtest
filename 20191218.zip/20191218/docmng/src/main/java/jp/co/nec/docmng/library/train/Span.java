package jp.co.nec.docmng.library.train;

public class Span {
	public String span;
	public int start;
	public int end;
}
