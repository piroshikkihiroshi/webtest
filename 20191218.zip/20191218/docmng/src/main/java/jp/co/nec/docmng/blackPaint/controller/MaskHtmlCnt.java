/**
 * 名称：MaskHtmlCnt.java
 * 機能名：黒塗り文書作成Control
 * 概要：塗り文書作成のControlを行う。
 */

package jp.co.nec.docmng.blackPaint.controller;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.zeroturnaround.zip.ZipUtil;

import jp.co.nec.docmng.blackPaint.entity.DocumentInfoEntPaint;
import jp.co.nec.docmng.blackPaint.logic.Aspose.AsposeWordModel;
import jp.co.nec.docmng.blackPaint.logic.dirFile.DirCnt;
import jp.co.nec.docmng.blackPaint.logic.dirFile.FileCnt;
import jp.co.nec.docmng.blackPaint.logic.maskHtml.HtmlStructure;
import jp.co.nec.docmng.blackPaint.logic.maskHtml.MaskHtmlModel;
import jp.co.nec.docmng.blackPaint.service.DocInfoService;
import jp.co.nec.docmng.library.blackprintextract.entity.BlackPrintPlace;
import jp.co.nec.docmng.library.blackprintextract.service.BlackPrintExtract;

@Controller
public class MaskHtmlCnt {

	static Logger objLog = LoggerFactory.getLogger(MaskHtmlCnt.class);

	@Autowired
	ServletContext context;
	@Autowired DocInfoService docInfoService;

    @Autowired
    private ResourceLoader resourceLoader;

    String strTmpDir = ""; //作業用フォルダ

	/**
	 * 黒塗り文書作成画面初期表示メソッド
	 * 画面初期表示の処理をする。
	 * @param documentId 文書を一意に特定するID
	 * @param status 空文字: 初期処理 1: 再開 2: 黒塗りリスト確定
	 * @param blackPaintListJson 空文字: 初期処理、再開 値あり：備考のjson
	 * @CookieValue user_id ユーザID
	 */
	@GetMapping("/MaskHtmlCnt")
	public synchronized String getblackTextTest(
			@RequestParam("documentId") int documentId,
			@RequestParam(name="status", defaultValue = "") String status, //空文字: 初期処理 1: 再開 2: 黒塗りリスト確定
			@RequestParam(name="blackPaintListJson", defaultValue = "") String blackPaintListJson, //空文字: 初期処理、再開 値あり：備考のjson
			@CookieValue(value="user_id", required=false) String UserId,
			HttpServletResponse response,
			Model model) {

		String aiData = ""; //aiが返すデータ

		String strHeight = "785"; //word A4の時 他は未考慮
//	    int insPageLen = 1000; //txtのページの長さ
	    int insPageLen = 1900; //txtのページの長さ

		FileCnt objFileCnt = new FileCnt();
		AsposeWordModel objAspCls = new AsposeWordModel();
		MaskHtmlModel  objMaskCls = new MaskHtmlModel();
		DirCnt objDirCls = new DirCnt();

		String strContext="";
		try {
			strContext = context.getContextPath().substring(1,context.getContextPath().length());
			objLog.info("contextパス:" + strContext);
		} catch (Exception e) {
			objLog.info("contextパスは設定されていません");
		} //try


        String strBasePath = context.getRealPath("/") + strContext;
//        String strTmpTimeStamp = String.valueOf(System.currentTimeMillis()) ;
        String strTmpUuid = UUID.randomUUID().toString() ;
        String strTmpDirName="";
        if (strContext.equals("")) {
        	strTmpDirName="tmp" + strTmpUuid + "/";
		}else {
			strTmpDirName=strContext+"/tmp" + strTmpUuid + "/";
		} //if
        strTmpDir = context.getRealPath("/") +  strTmpDirName; //作業用フォルダ
        objLog.info("作業directory:"+strTmpDir);

		Cookie cookie = new Cookie("strTmpDirName", strTmpDirName);
	    cookie.setMaxAge(60*3600);
	    cookie.setPath("/");
		response.addCookie(cookie);

		objLog.info("作業フォルダ：" + strTmpDirName);

		//contextのディレクトリ作成
		try {
			objDirCls.makeDirWithCheck(strBasePath);
		} catch (Exception e) {
			objLog.info("作業フォルダの作成に失敗しました。" + strBasePath);
		} //try


		//DocumentIDでdocument_infoから情報を取得
		List<DocumentInfoEntPaint> listDoc=null;
		listDoc =docInfoService.selectDocInfo(documentId);

		String strOrgFilePath = listDoc.get(0).getDocumentName();
		objLog.info("対象パス：" + strOrgFilePath);

		String strOrgPath = listDoc.get(0).getFilePath();

		//一度RealPathへファイルをコピーする
		String strFileName = strOrgFilePath.substring(strOrgFilePath.lastIndexOf("\\") + 1,strOrgFilePath.length());
		String strFileWithoutExtension = objFileCnt.getNameWithoutExtension(strFileName);

        String strHtmlName = strFileWithoutExtension + ".html"; //作成html名
        String strHtmlPath = strTmpDir + strFileWithoutExtension + ".html"; //作成htmlパス

        String strStyle = ""; //CSSを作成する
        strStyle+="<style>";
        strStyle+=".tagRed{";
        strStyle+="    color: rgb(233, 84, 84);";
//        strStyle+="    background-color: #ffff7b;";
        strStyle+="}";
        strStyle+=".tagRng{";
        strStyle+="    color: rgb(233, 87, 51);";
        strStyle+="    background-color: rgba(159, 192, 230, 0.884);";
        strStyle+="}";
        strStyle+=".tagMsk{";
        strStyle+="    color: black;";
        if (listDoc.get(0).getExtension().equals("txt")) {
            strStyle+="    word-break: break-all;";
//            strStyle+="    padding: 3px;";
//            strStyle+="    font-family: Courier, Monaco, monospace;";
            strStyle+="    line-height: 1.2;";
            strStyle+="    width: 97%;";
            strStyle+="    text-align: justify;";

        }else {
            strStyle+="    font-size: 10.5pt;";
        } //id

        strStyle+="}";
        strStyle+=".awpage {";
        strStyle+="    position: relative;";
        strStyle+="    border: none;";
        strStyle+="    margin: 0px;";
        strStyle+="}";
        strStyle+=".redimg{";
        strStyle+="    -webkit-filter: sepia(100%)  hue-rotate(300deg); ";
        strStyle+="    -moz-filter: sepia(100%)  hue-rotate(300deg);";
        strStyle+="    -o-filter: sepia(100%)  hue-rotate(300deg);";
        strStyle+="    -ms-filter: sepia(100%)  hue-rotate(300deg);";
        strStyle+="    filter: sepia(100%)  hue-rotate(300deg);";
        strStyle+="}";
        strStyle+="</style>";

		FileWriter objFile=null;
		PrintWriter objPw=null;
		String[] arrMask=null;
		String[] arrRed=null;

		//全文検索モックデータ コロン区切りでペアは+区切り intpos,そこからつづく,intpos,そこからつづく
		String strTestData = aiData;
		String strAllHtml = "";
		String strOrgBody = "";
		String strNotTagBody = "";
		String strRepBody = "";
		String strMaskHtml= "";
		String strRedHtml = "";
		int intPageCnt = 0;

		//とりあえずcontrollerで処理分け のちにロジックに移行
		if (listDoc.get(0).getExtension().equals("txt")) {
			objLog.info("txt処理開始");
			try {
				//出力フォルダ作成
				objDirCls.makeDirWithCheck(strTmpDir);
				objDirCls.makeDirWithCheck(strTmpDir + strFileWithoutExtension);
				//動的templateを作成
				String strOutHtml = "";
				strOutHtml+="<body>";
				strOutHtml+=listDoc.get(0).getDocumentContents();
				strOutHtml+="</body>";

				//全文検索エンジンに渡す用の文字列を取得する
				strNotTagBody=listDoc.get(0).getDocumentContents();

	//			※※※※※※※検索エンジンに送付※※※※※※※

				//AIdata
				BlackPrintExtract objAiCls  = new BlackPrintExtract();
				//aiDatalist
				List<BlackPrintPlace> listAi = null;
				try {
//					listAi = objAiCls.extractBlackPrintPlace(2001);
					listAi = objAiCls.extractBlackPrintPlace(documentId);
					BlackPrintPlace tmpPrintPlace = null;
					aiData = "";
					for (int i = 0; i < listAi.size(); i++) {
						tmpPrintPlace = listAi.get(i);
						aiData+=tmpPrintPlace.start + ":" + tmpPrintPlace.end + ":" + tmpPrintPlace.policyID + "+";
					} //for
					aiData = aiData.substring(0,aiData.length()-1);
				} catch (Exception e2) {
					aiData="";
					objLog.info("AIデータ取得処理でエラーが発生したため、取得したHTMLをそのまま表示");
					objLog.error( "err message", e2 );
					e2.printStackTrace();
				} //try

				if(aiData==null) aiData="";

				//debug
//				aiData="43:46:1+48:49:1+51:54:1+346:349:1+359:360:1+432:435:1+437:440:1+443:444:1+498:501:1+503:504:1+630:633:1+750:753:1+854:859:1+861:862:1+864:869:1+882:883:1+886:887:1+895:896:1+905:907:1+929:934:1+994:996:1+1079:1084:1+1166:1170:1+1198:1201:1";
//				aiData="10:11:1+39:48:1+53:66:1+81:85:1+98:102:1+104:109:1+184:187:1+327:328:1";
//				aiData="1:4:1+23:24:1";
//				aiData="1:6:1+12:13:1+37:38:1+65:66:1+68:71:1+73:74:1+80:82:1+107:108:1+145:147:1+178:179:1+181:183:1+234:235:1+252:252:1+259:260:1+279:284:1+286:292:1+297:309:1+319:322:1+324:325:1+343:344:1+359:360:1+380:381:1+395:483:1+484:485:1+487:490:1+504:505:1+545:546:1+591:593:1+603:680:1+684:687:1+690:696:1+698:702:1+710:711:1+721:727:1+746:752:1+754:755:1+774:809:1+813:813:1+838:839:1+847:850:1+855:858:1+861:862:1+886:887:1+889:892:1+894:895:1+898:900:1+902:906:1+922:925:1+980:981:1+990:1087:1+1099:1100:1+1106:1107:1+1109:1112:1+1117:1120:1+1123:1125:1+1160:1163:1+1192:1193:1+1211:1212:1+1227:1230:1+1278:1279:1+1281:1286:1+1291:1294:1+1297:1299:1+1309:1310:1+1343:1344:1+1346:1347:1+1359:1359:1+1371:1372:1+1374:1386:1+1388:1391:1+1393:1393:1+1413:1414:1";

				objLog.info("aiData="+aiData);

				if(!aiData.equals("")) {
					//全文検索から戻ってきた値をhashへ成型
					HashMap<Integer, String> hashRepPos = objMaskCls.makePosHash(aiData);
					objMaskCls.makePosHash(aiData);

					//bodyの構造体hashを取得
					HashMap<Integer, HtmlStructure> hashBodyStructure = objMaskCls.getBodyStructure(strOutHtml);
					//全文検索エンジンに返した結果を置換してbodyを入れ替えた文字列を取得(黒塗り)
					arrMask=objMaskCls.bodyReplace(hashRepPos, hashBodyStructure,1);
					strRepBody = arrMask[0];

					//htmlのbodyの中身を入れ替え、置換HTMLを作成する
					strMaskHtml = objMaskCls.makeBody(strOutHtml,strRepBody);

					//20191212 結果から再度構造体を作成し、ページネーションを作成
					HashMap<Integer, HtmlStructure> hashBodyPageStructure = objMaskCls.getBodyStructure(strMaskHtml);
					String strTmpTxt ="";
					strTmpTxt = objMaskCls.bodyMakePaginate(hashBodyPageStructure,insPageLen);

					//スタイルシートPath埋め込み
					strMaskHtml = objMaskCls.insertStyleTxt(strTmpTxt,strStyle);


					//全文検索エンジンに返した結果を置換してbodyを入れ替えた文字列を取得(赤文字)
					arrRed=objMaskCls.bodyReplace(hashRepPos, hashBodyStructure,2);
					strRepBody=arrRed[0];

					//htmlのbodyの中身を入れ替え、置換HTMLを作成する
					strRedHtml = objMaskCls.makeBody(strOutHtml,strRepBody);

					//20191212 結果から再度構造体を作成し、ページネーションを作成
					hashBodyPageStructure=null;
					hashBodyPageStructure = objMaskCls.getBodyStructure(strRedHtml);
					strTmpTxt ="";
					strTmpTxt = objMaskCls.bodyMakePaginate(hashBodyPageStructure,insPageLen);

					//スタイルシートPath埋め込み
					strRedHtml = objMaskCls.insertStyleTxt(strTmpTxt,strStyle);

				}else { //aidataなし
					objLog.info("aiDataが無いため、サーバでの黒塗り処理は行いません。");
					strMaskHtml = strOutHtml;
					//20191212 結果から再度構造体を作成し、ページネーションを作成
					HashMap<Integer, HtmlStructure> hashBodyPageStructure = objMaskCls.getBodyStructure(strMaskHtml);
					String strTmpTxt ="";
					strTmpTxt = objMaskCls.bodyMakePaginate(hashBodyPageStructure,insPageLen);

					//スタイルシートPath埋め込み
					strMaskHtml = objMaskCls.insertStyleTxt(strTmpTxt,strStyle);

					//赤文字
					strRedHtml = strOutHtml;
					//20191212 結果から再度構造体を作成し、ページネーションを作成
					hashBodyPageStructure=null;
					hashBodyPageStructure = objMaskCls.getBodyStructure(strRedHtml);
					strTmpTxt ="";
					strTmpTxt = objMaskCls.bodyMakePaginate(hashBodyPageStructure,insPageLen);

					//スタイルシートPath埋め込み
					strRedHtml = objMaskCls.insertStyleTxt(strTmpTxt,strStyle);


				} //if
					synchronized (this) {

						//css,黒塗り画像ファイル配備 ※deploy時にエラーになるためresourceLoaderで取得
						String strCssPath = "/static/css/blackPaint/mask.css";
						String strImgPath = "/static/css/images/m";
						//deploy後に動かないので修正
						objLog.info("ファイル、イメージ配備開始");
						Resource resource =null;
						resource = resourceLoader.getResource("classpath:" + strCssPath);
						objLog.info(strCssPath +"存在判定："+ resource.exists());
						InputStream objIs = resource.getInputStream();
						byte[] arrByte = null;
						arrByte = IOUtils.toByteArray(objIs);
						FileOutputStream objOutSr = null;
						objOutSr=new FileOutputStream(strTmpDir + "/" + strFileWithoutExtension+ "/mask.css");
						objOutSr.write(arrByte);//出力（dataのbyte列をファイルに書き込む）
						objOutSr.close();//閉じる(fosを使ったファイル操作を終えた時に実行)

						resource = resourceLoader.getResource("classpath:" + strImgPath);
						objLog.info(strCssPath +"存在判定："+ resource.exists());
						objIs = resource.getInputStream();
						arrByte = IOUtils.toByteArray(objIs);

						objOutSr=new FileOutputStream(strTmpDir + "/" + strFileWithoutExtension+ "/m");

						objOutSr.write(arrByte);//出力（dataのbyte列をファイルに書き込む）
						objOutSr.close();//閉じる(fosを使ったファイル操作を終えた時に実行)

						objLog.info("ファイル、イメージ配備完了");
					} //synchronized

					String strMaskOutPath = strTmpDir + "mask_" + strHtmlName;
					String strRedOutPath = strTmpDir + "red_" + strHtmlName;

					//htmlを出力する(黒塗り)
					objPw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(
					        new FileOutputStream(strMaskOutPath, true),"utf-8")));
					objPw.println(strMaskHtml);
					objPw.close();
					objLog.info("maskHTML完了");

					//htmlを出力する(赤文字)
					objPw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(
					        new FileOutputStream(strRedOutPath, true),"utf-8")));
					objPw.println(strRedHtml);
					objPw.close();
					objLog.info("赤文字HTML完了");
					//ページカウント取得
//					intPageCnt = 1; //暫定
					intPageCnt = objAspCls.aspPageGet(strMaskHtml);
//					intPageCnt = objAspCls.aspPageGet(strMaskHtml) - 1;


			} catch (IOException e) {
				objLog.error( "err message", e );
				e.printStackTrace();
			} //try


		} else { //※※※※※※※※※※※word※※※※※※※※※※
			objLog.info("word処理開始");
			byte[] arrHtmlZip=null;
			arrHtmlZip = listDoc.get(0).getHtmlZipData();
			//file出力
			//出力フォルダ作成
			String strFileOutDir=strBasePath+"/tmp"+strTmpUuid+"/";
			String strZipPath = strFileOutDir + "mask.zip";

			Path objZipPath = Paths.get(strZipPath);
			try {

				objDirCls.makeDirWithCheck(strFileOutDir);
				//zipファイル出力
				Files.write(objZipPath, arrHtmlZip);
				//unzipする
				ZipUtil.unpack(new File(strZipPath), new File(strFileOutDir));

				//作業ファイルかたづけ
				File fileZip = new File(strZipPath);
				fileZip.delete();

				objLog.info("HTML群取得完了");

			} catch (IOException e1) {
				objLog.error( "err message", e1 );
				e1.printStackTrace();
			} //try
			catch (Exception e) {
				objLog.error( "err message", e );
				e.printStackTrace();
			} //try

	        try {
	        	//tmpDir作成
	            //対象HTMLを取得する
	            strAllHtml = objMaskCls.readAll(strHtmlPath);

		        //圧縮されたBodyを取得
//				strOrgBody = objMaskCls.getBodyCompress(strAllHtml);

				//全文検索エンジンに渡す用の文字列を取得する
//				strNotTagBody=listDoc.get(0).getDocumentContents();

//				※※※※※※※検索エンジンに送ったと想定※※※※※※※

				//AIdata スタブ
				BlackPrintExtract objAiCls  = new BlackPrintExtract();
				//aiDatalist
				List<BlackPrintPlace> listAi = null;
				try {
//					listAi = objAiCls.extractBlackPrintPlace(2001);
					listAi = objAiCls.extractBlackPrintPlace(documentId);
					BlackPrintPlace tmpPrintPlace = null;
					aiData = "";
					for (int i = 0; i < listAi.size(); i++) {
						tmpPrintPlace = listAi.get(i);
						aiData+=tmpPrintPlace.start + ":" + tmpPrintPlace.end + ":" + tmpPrintPlace.policyID + "+";
					} //for
					aiData = aiData.substring(0,aiData.length()-1);
				} catch (Exception e2) {
					aiData="";
					objLog.info("AIデータ取得処理でエラーが発生したため、取得したHTMLをそのまま表示");
					objLog.error( "err message", e2 );
					e2.printStackTrace();
				} //try

				if(aiData==null) {
					aiData="";
				} //if

				//debug
//				aiData="206:230:1";
//				aiData="1:5:1";

				objLog.info("aiData="+aiData);

				if(!aiData.equals("")) {

					//全文検索から戻ってきた値をhashへ成型
					HashMap<Integer, String> hashRepPos = objMaskCls.makePosHash(aiData);
					objMaskCls.makePosHash(aiData);

					objLog.info("makePosHash完了");

					//bodyの構造体hashを取得
//					HashMap<Integer, HtmlStructure> hashBodyStructure = objMaskCls.getBodyStructure(strOrgBody);
					HashMap<Integer, HtmlStructure> hashBodyStructure = objMaskCls.getBodyStructure(strAllHtml);

					//全文検索エンジンに返した結果を置換してbodyを入れ替えた文字列を取得(黒塗り)
					arrMask=objMaskCls.bodyReplace(hashRepPos, hashBodyStructure,1);
					strRepBody = arrMask[0];


					//htmlのbodyの中身を入れ替え、置換HTMLを作成する
//					strMaskHtml = objMaskCls.makeBody(strAllHtml,strRepBody);
					strMaskHtml = strRepBody;

					//スタイルシートPath埋め込み
					strMaskHtml = objMaskCls.insertStyle(strMaskHtml,strStyle);

					//全文検索エンジンに返した結果を置換してbodyを入れ替えた文字列を取得(赤文字)
					arrRed=objMaskCls.bodyReplace(hashRepPos, hashBodyStructure,2);
					strRepBody=arrRed[0];
					//htmlのbodyの中身を入れ替え、置換HTMLを作成する
//					strRedHtml = objMaskCls.makeBody(strAllHtml,strRepBody);
					strRedHtml = strRepBody;

					//スタイルシートPath埋め込み
					strRedHtml = objMaskCls.insertStyle(strRedHtml,strStyle);
				}else { //aidataなし
					objLog.info("aiDataが無いため、サーバでの黒塗り処理は行いません。");
					strMaskHtml=strAllHtml;
					strRedHtml=strAllHtml;
					//スタイルシートPath埋め込み
					strMaskHtml = objMaskCls.insertStyle(strMaskHtml,strStyle);
					//スタイルシートPath埋め込み
					strRedHtml = objMaskCls.insertStyle(strRedHtml,strStyle);
				} //if

				synchronized (this) {
					//css,黒塗り画像ファイル配備 ※deploy時にエラーになるためresourceLoaderで取得
					String strCssPath = "/static/css/blackPaint/mask.css";
					String strImgPath = "/static/css/images/m";
					//deploy後に動かないので修正
					objLog.info("ファイル、イメージ配備開始");
					Resource resource =null;
					resource = resourceLoader.getResource("classpath:" + strCssPath);
					objLog.info(strCssPath +"存在判定："+ resource.exists());

					InputStream objIs = resource.getInputStream();
					byte[] arrByte = null;
	//				arrByte=objIs.readAllBytes();
					arrByte = IOUtils.toByteArray(objIs);
					FileOutputStream objOutSr = null;
					objOutSr=new FileOutputStream(strTmpDir + "/" + strFileWithoutExtension+ "/mask.css");
					objOutSr.write(arrByte);//出力（dataのbyte列をファイルに書き込む）
					objOutSr.close();//閉じる(fosを使ったファイル操作を終えた時に実行)

					resource = resourceLoader.getResource("classpath:" + strImgPath);
					objLog.info(strCssPath +"存在判定："+ resource.exists());
					objIs = resource.getInputStream();
					arrByte = IOUtils.toByteArray(objIs);

					objOutSr=new FileOutputStream(strTmpDir + "/" + strFileWithoutExtension+ "/m");

					objOutSr.write(arrByte);//出力（dataのbyte列をファイルに書き込む）
					objOutSr.close();//閉じる(fosを使ったファイル操作を終えた時に実行)


	//				FileUtils.copyFile(resource.getFile(), objTgtImgFile);
					objLog.info("ファイル、イメージ配備完了");

					String strMaskOutPath = strTmpDir + "mask_" + strHtmlName;
					String strRedOutPath = strTmpDir + "red_" + strHtmlName;

					objLog.info("html出力開始");
					//htmlを出力する(黒塗り)
					objPw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(
					        new FileOutputStream(strMaskOutPath, true),"utf-8")));
					objPw.println(strMaskHtml);
					objPw.close();
					objLog.info("maskHTML完了");

					//htmlを出力する(赤文字)
					objPw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(
					        new FileOutputStream(strRedOutPath, true),"utf-8")));
					objPw.println(strRedHtml);
					objPw.close();
					objLog.info("赤文字HTML完了");
				} //synchronized

				synchronized (this) {
					//ページカウント取得
					intPageCnt = objAspCls.aspPageGet(strMaskHtml);
				} //synchronized

	        } catch (Exception e) {
				objLog.error("err message", e);
	            e.printStackTrace();
	        } //try

		} //if


		@SuppressWarnings("deprecation")
		String strMaskOutPath = strTmpDirName + "mask_" + URLEncoder.encode(strHtmlName);
		@SuppressWarnings("deprecation")
		String strRedOutPath = strTmpDirName + "red_" + URLEncoder.encode(strHtmlName);

		//viewへ値を渡す
		// 呼び出し先Jspに渡すデータセット(html出力パスを相対で指定)
		model.addAttribute("strMaskOutPath", strMaskOutPath);
		model.addAttribute("strRedOutPath",  strRedOutPath);
//		model.addAttribute("strMaskOutPath", strTmpDirName + "mask_" + strHtmlName );
//		model.addAttribute("strRedOutPath",  strTmpDirName + "red_" + strHtmlName);
		model.addAttribute("strTmpDirName", strTmpDirName); //tmpdirの情報も送る
		model.addAttribute("strPagePx", strHeight); //1ページの量
		model.addAttribute("intPageCnt", String.valueOf(intPageCnt)); //ページ数
		model.addAttribute("strFileName",strFileName); //オリジナルfile名 保存時に使用
		model.addAttribute("strFilePath",strOrgPath); //オリジナルfileパス リスト表示時に使用

		//AIデータがどのように来るかわからないのでポリシーなどはクライアントで処理
		if(aiData.equals("")) {
			model.addAttribute("strEditMarker", "");
		}else {
			model.addAttribute("strEditMarker", arrRed[1]); //aiでマークしたid等を格納
		} //if

		model.addAttribute("documentId", documentId);//documentId
		model.addAttribute("strFileWithoutExtension", strFileWithoutExtension);//strFileWithoutExtension
		model.addAttribute("reOpenFlg",status);
		model.addAttribute("blackPaintListJson",blackPaintListJson);
		try { //たまに遷移が速すぎるため1秒まつ
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			objLog.error(e.getMessage());
		} //try

		return "blackPaint/MaskHtmlVeiw";
	} //getView1

	/**
	 * エラー画面遷移(黒塗り処理)
	 */
	@ExceptionHandler(Exception.class)
	public String handleException(
			Exception e,
			HttpServletRequest request,
			HttpServletResponse response,
			Model model
			){


		//モデル初期化
		DirCnt objDirCls = new DirCnt();
		String strTmpDir_i = strTmpDir;

		//作業ディレクトリかたずけ
		if(strTmpDir_i.equals(""))  {
			objLog.info("作業ディレクトリの取得が失敗しました");
		}else {
			try {
				//作業ディレクトリ,ファイルかたづけ
				objDirCls.DelDirctory(context.getRealPath("/") + strTmpDir_i);
				objLog.info("作業ディレクトリ削除完了");
			} catch (Exception e1) {
				objLog.info("作業ディレクトリ削除失敗");
			} //try

		} //if

		response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		objLog.error("Error occurred.", e);
		StringWriter objSw = new StringWriter();
		PrintWriter objPw = new PrintWriter(objSw);
		e.printStackTrace(objPw);
		objPw.flush();
		String strError = objSw.toString();
		model.addAttribute("errorMessage", e.getMessage() + "\r\n" + "StackTrace" + "\r\n" + strError) ;

		return "blackPaint/Fail";
	} //method


	/**
	 * 黒塗りリスト確定メソッド
	 * 「getblackTextTest」経由後「MaskHtmlVeiw」を表示する
	 * @param documentId 文書を一意に特定するID
	 * @param status 空文字: 初期処理 1: 再開 2: 黒塗りリスト確定
	 * @param blackPaintListJson 空文字: 初期処理、再開 値あり：備考のjson
	 * @CookieValue user_id ユーザID
	 */
	@PostMapping("/MaskHtmlCnt")
	public String postblackTextTest(
			@RequestParam("documentId") int documentId,
			@RequestParam(name="status", defaultValue = "") String status, //空文字: 初期処理 1: 再開 2: 黒塗りリスト確定
			@RequestParam(name="blackPaintListJson", defaultValue = "") String blackPaintListJson, //空文字: 初期処理、再開 値あり：備考のjson
			@CookieValue(value="user_id", required=false) String UserId,
			HttpServletResponse response,
			Model model) {

		getblackTextTest(documentId, status, blackPaintListJson, UserId, response, model);
		return "blackPaint/MaskHtmlVeiw";

	} //method


} //MaskHtmlCnt
