//グローバル変数
var isPost = false;

/**
 * ボタン無効状態の定数
 * @memberOf SearchServer
 * @constant {Number} DISABLE_TRUE
*/
DISABLE_TRUE = 0;
/**
 * ボタン有効状態の定数
 * @memberOf SearchServer
 * @constant {Number} DISABLE_FALSE
*/
DISABLE_FALSE = 1;

/**
 * 登録ボタンの有効(1)／無効(0)状態を保持する変数
 * @memberOf SearchServer
 * @type {Number} regBtnCheck
 */
var regBtnCheck = DISABLE_TRUE;

/**
 * 編集前の登録データ一覧を保持する変数
 * @memberOf SearchServer
 * @type {Object} beforeRegDataList
 */
var beforeRegDataList = [];

// 現在のURL
var hostUrl = location.protocol + '//' + location.host + location.pathname;

//アラートメッセージ
var alreadyDirectoryPassMessage = "入力したディレクトリパスは既に設定済みです。";
var selectedNotClickLoadMessage = "ディレクトリパスを入力後、再度ボタンを押下してください。"
var savePassAddNullMessage = "保存先パスが入力されていません。";
var addReflectSettingCheckMessage = "変更した内容を反映しますか。";
var addReflectSettingMessage = "変更が反映されました。";
var addReflectSettingFailureMessage = "設定反映に失敗しました。";
var cancelSelectedMessage = "変更内容を破棄してもよろしいでしょうか。";
var notUserRoleOrLoginOutMessage = "ログインを行っていない、または管理者ではありません。";


$(function () {

    // 画面ロード時にボタンの表示状態更新
    btnAllCheck();

    /**
     * 画面が変更または閉じれる時に動作
     * ダイアログを表示する
     * messageboxで表示を行いたいが、検知の限界が存在する為「beforeunload」を使用する
     * 参考サイト：https://teratail.com/questions/51831
    **/
    $(window).on("beforeunload", function (e) {
        // POST送信フラグが「true」の場合、ダイアログを表示しない
        if (isPost) {
            return;
        } else {
            return true;
        }
    });

    //Cookieを確認し、管理者権限またはログインしているかチェックを行う
    $(window).ready(function (e) {
        // ドメイン情報取得
        DomainCookie.initDomainCookie('[[${DomainInfo}]]');

        var userRole = DomainCookie.getUserRole();

        // ログインしてない場合
        if (userRole === null) {
            alert(notUserRoleOrLoginOutMessage);
            window.close();
        }

        //管理者権限か確認を行う
        if (userRole === "Administrators") {
            showUserName();
            showUserId();
            userRoleFlag = true;
        }

        //管理者権限、またはログインしていなかった場合画面を閉じる
        if (userRoleFlag !== true) {
            alert(notUserRoleOrLoginOutMessage);
            window.close();
        }
    })

    /**
     * 行をクリック後に動作
     * 何がクリックされたかによってイベントを振り分ける
     **/
    document.getElementById("main_scroll_R").addEventListener("click", function (event) {
        var li = event.target;
        console.log(li);
        // ×ボタン押下時動作
        if (li.classList.contains("DeleteRowTrainingPolicy") || li.classList.contains("NewDeleteRowTrainingPolicy")) {
            deleteRow(li);
        }// if

    }, false);// function

    /**
     * 登録データ一覧表読み完了後動作関数
     * 登録データ一覧の読み込みが完了後、一覧表の数が0だった場合ボタンをdisabledに変更を行う。
     * @memberOf  policy
     */
    $("#main_scroll_R").ready(function (e) {
        console.log("main_scroll_R");
        var policyList = $("#main_scroll_R")[0].children;

        // 1行目コピー用の空行となっているため開始番号は1
        for (var cnt = 1; cnt < policyList.length; cnt++) {
            var teacherpolicy = {};
            teacherpolicy["policyId"] = policyList[cnt].children[1].textContent;
            teacherpolicy["filePath"] = policyList[cnt].children[3].textContent;
            // 開始番号が1のため-1
            beforeRegDataList[cnt - 1] = teacherpolicy;
        }
        console.log(beforeRegDataList);
    });
});// function

/**
 * 選択された行を削除する。
 */
function deleteRow(li) {
    //選択した行にIDを付与
    li.parentElement.setAttribute("id", "selected");
    //選択した行の削除
    $("#selected").remove();
    // 削除した結果登録データが初期状態と変化しているかチェックする
    checkRegDataListCange();
}

/**
 * 出力ボタン押下時に動作
 * 一覧表に行の新規追加を行う
**/
function addListData() {
    //現在の行数を取得
    var objAutoRowNo = document.getElementById("main_scroll_R").children.length + 1;
    strAutoRowNo = '' + objAutoRowNo;

    var successCount = 0;
    //テキストボックス内の文字列取得
    var strAddFilePassListText = document.getElementById("addFilePassList").value;

    //最上位行のプルダウンメニュー内容を取得
    var strPullDownMenuList = document.getElementsByClassName("menu")[0].innerHTML;

    //最上位行のstyleを取得
    var strFilePassStyle = document.getElementById("main_scroll_R").children[0].children[2].style.cssText;

    if (strAddFilePassListText !== "") {
        for (let index = 0; index < document.getElementById("main_scroll_R").children.length; index++) {
            var listFile = document.getElementById("main_scroll_R").children[index].children[2].outerText;
            if (listFile !== strAddFilePassListText) {
                successCount++;
            }
        }
        if (document.getElementById("main_scroll_R").children.length === successCount) {
            //新規作成する欄を作成
            var ul = $('<ul class="tr"></ul>');
            var strDeleteButton = $('<li class="w40 bt_batsu NewDeleteRowTrainingPolicy"></li>');
            var strNonViewPlicyId = $('<li style="display: none">0</li>');
            var strPolicyPullDown = $('<li class="w100 menu dropdown_arrow_right" style="position: relative;">その他</li>');
            var strFilePassList = $('<li class="wAutoA B text_align_left" style="' + strFilePassStyle + '"></li>');
            //表に取得した値を挿入する
            $(".scrollBody").append(ul);
            ul.append(strDeleteButton).append(strNonViewPlicyId).append(strPolicyPullDown).append(strFilePassList);
            strDeleteButton.html('');
            strFilePassList.html(strAddFilePassListText);
            //一覧追加用テキストボックスを空にする
            document.getElementById("addFilePassList").value = "";
            // 追加した結果登録データが初期状態と変化があるか確認する
            checkRegDataListCange();
            // 追加行にハイアラキーメニューを表示させるため再処理
            Array.from(document.querySelectorAll("#main_scroll_R ul li.menu")).map(item => hierarchyMenuProc(item));
        } else {
            alert(alreadyDirectoryPassMessage);
        }
    } else {
        alert(selectedNotClickLoadMessage);
    }
}// function
/**
 * キャンセルボタン押下時に動作
 * ダイアログを表示する
**/
function cancel() {
    blCan = confirm(cancelSelectedMessage);
    if (blCan) {
        window.close();
        sessionStorage.clear();
    } else {
        return;
    }// if
}// function
/**
 * 登録ボタン押下時に動作
 * コントローラーへDB更新データをPOSTする
 */
function postItem() {
    blCanPost = confirm(addReflectSettingCheckMessage);
    if (blCanPost) {

        var savePath = $('#saveRegistrationList')[0].value;
        var policyList = $("#main_scroll_R")[0].children;
        var userId = $("#USER_ID")[0].textContent;

        console.log(savePath);
        // 保存先パスの入力チェック
        if (!savePath) {
            alert(savePassAddNullMessage);
            return;
        }
        //データ送信用
        var postData = {}
        // 送信データ列部
        var teacherPolicyList = [];
        // 1行目はコピー用の空行になっているため1から開始
        for (let i = 1; i < policyList.length; i++) {
            // ポリシーID
            var policyData = {};
            var policyId = policyList[i].children[1].outerText;
            var path = policyList[i].children[3].textContent;
            // ユーザ名
            policyData['userId'] = userId;
            // ソードID
            policyData['sortId'] = i;
            // ポリシーID
            policyData['policyId'] = policyId;
            // 格納先パス
            policyData['directoryPath'] = path;
            // iが1から開始しているため、-1
            teacherPolicyList[i - 1] = policyData;
        }
        //送信データ生成
        var jsonObj = new Object();

        jsonObj.tmpTeacherPolicyList = teacherPolicyList;
        jsonObj.savePath = savePath;

        console.log(jsonObj);

        $.ajax({
            url: hostUrl + "/teacher_policy_reflect",
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify(jsonObj),
            // ajax通信成功時の処理
        }).done(function (data) {
            isPost = true;
            let successOrFailure = "";
            console.log(data);
            alert(addReflectSettingMessage);
            // ajax通信失敗時の処理
            // 画面を更新する
            location.reload();
        }).fail(function (xhr, textStatus, errorThrown) {
            //alert(xhr.responseText + "\r\n登録データ一覧の更新処理に失敗しました");
            alert(addReflectSettingFailureMessage);
            // 成功でも失敗でも通信終了時に必要な処理があれば
        }).always(function () {
        });
    } else {
        return;
    }
}

/**
 * 全てのボタンの「活性」・「非活性」を判定する
 */
function btnAllCheck() {
    isReg();
}

/**
* 登録ボタンの「活性」「非活性」を判定する
*/
function isReg() {
    if (regBtnCheck == 0) {
        $("#regBtn").prop("disabled", true);
    } else {
        $("#regBtn").prop("disabled", false);
    }//if
}// function

/**
 * 初期表示したときの登録データ一覧と変化があるか確認する
 */
function checkRegDataListCange() {
    var policyList = $("#main_scroll_R")[0].children;
    //登録ボタンを無効にする
    regBtnCheck = DISABLE_TRUE;
    //初期状態の登録データ一覧と行数が同じか比較する（コピー行があるため、policyyListは-1）
    if (beforeRegDataList.length === policyList.length - 1) {
        console.log("行数が同じ");
        //初期状態の登録データ一覧と分類及びファイルパスを比較する
        for (cnt = 0; cnt < beforeRegDataList.length; cnt++) {
            console.log("policyid  " + beforeRegDataList[cnt]["policyId"] + " == " + policyList[cnt + 1].children[1].textContent)
            // 初期状態から変化があった場合
            if (beforeRegDataList[cnt]["policyId"] != policyList[cnt + 1].children[1].textContent
                || beforeRegDataList[cnt]["filePath"] != policyList[cnt + 1].children[3].textContent) {
                //登録ボタンを有効にする
                regBtnCheck = DISABLE_FALSE;
                break;
            } //if
        }
    } else {
        //登録ボタンを有効にする
        regBtnCheck = DISABLE_FALSE;
    }// if
    // ボタンの状態を更新
    btnAllCheck();
}// function