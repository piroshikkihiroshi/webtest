package com.example.officeHtml;

import java.io.File;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import org.zeroturnaround.zip.ZipUtil;

import com.aspose.cells.CellArea;
import com.aspose.cells.HtmlSaveOptions;
import com.aspose.cells.ImageOrPrintOptions;
import com.aspose.cells.PrintingPageType;
import com.aspose.cells.SheetRender;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.WorksheetCollection;


public class TestExcel_bk_20200126 {
	public static void main(String[] args) {
		try {
			connectionTest();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * コネクションの取得
	 *
	 * @throws Exception
	 *             実行時例外
	 */
	public static void connectionTest() throws Exception {
		Connection conn = null;

		try {


			//DB設定読み込み
			ResourceBundle objRb=null;
			objRb=ResourceBundle.getBundle("config/setting");
			String strUrl=objRb.getString("url");;
			String strUsername=objRb.getString("username");;
			String strPassword=objRb.getString("password");;
			String strDriverClassName=objRb.getString("driverClassName");;

			// クラスのロード
			Class.forName(strDriverClassName);

			// コネクションの取得
			conn = DriverManager.getConnection(strUrl, strUsername, strPassword);
			// insertのテスト
			insertTest(conn);

			System.out.println("success");
		} catch (Exception e) {
			System.out.println("fail");
			throw e;
		} finally {
			if (conn != null) {
				conn.close();
			}
		}
	}

	/**
	 * データ取得テスト
	 *
	 * @param conn
	 *            コネクション
	 * @throws Exception
	 */
	public static void insertTest(Connection conn) throws Exception {
		Statement stmt = null;
		ResultSet objRs = null;
		try {

			// ステートメントの作成
			stmt = conn.createStatement();

			// srcDoc : 変換するPowerPointファイルのパス
			String srcDoc = "C:/Users/Public/Documents/test/test.xlsx";

			// dstDoc : 変換語のHTMLファイルのパス
//			String dstDoc = "C:/Users/Public/Documents/test/test01/test.html";
			String dstTmpDoc = "C:/Users/Public/Documents/test/test01/tmp_test.xlsx";
			String dstTmpPdf = "C:/Users/Public/Documents/test/test01/tmp_.pdf";
			String dstDoc = "C:/Users/Public/Documents/test/test01/";

			//excel→tmp excel

			Workbook workbook = new Workbook(srcDoc);
			WorksheetCollection worksheets = workbook.getWorksheets();
			Worksheet worksheet = worksheets.get(0);
		    ImageOrPrintOptions printoption = new ImageOrPrintOptions();
		    printoption.setPrintingPage(PrintingPageType.DEFAULT);
		    SheetRender sr = new SheetRender(worksheet, printoption);
		    int pageCount = sr.getPageCount();
		    System.out.println("pageCount:"+pageCount);
		    CellArea[] area = worksheet.getPrintingPageBreaks(printoption);

		    List<String> listArea = new ArrayList<String>();
		    for (int i = 0; i < area.length; i++) {

				String strArea=area[i].toString();
				strArea=strArea.substring(strArea.lastIndexOf("(")+1,strArea.lastIndexOf(")"));
				listArea.add(strArea);


		    }

		    for (int i = 0; i < listArea.size(); i++) {

				HtmlSaveOptions htmlSaveOptions = new HtmlSaveOptions();
				workbook = new Workbook(srcDoc);
				worksheets = workbook.getWorksheets();
				worksheet = worksheets.get(0);
				worksheet.getPageSetup().setPrintArea(listArea.get(i));
				htmlSaveOptions.setExportActiveWorksheetOnly(true);
				htmlSaveOptions.setExportPrintAreaOnly(true);

				workbook.save(dstDoc+"test_"+i+".html",htmlSaveOptions);


			}

			workbook.dispose();




			// dstDoc : 変換語のHTMLファイルのパス
			String strFileOutDir = "C:\\Users\\Public\\Documents\\test\\test01";

			// zipに固める
			String strZipOut = "C:/Users/Public/Documents/mask01.zip";
			ZipUtil.pack(new File(strFileOutDir), new File(strZipOut));

			// zipをbyte配列にする
			byte[] byteZip = null;
			File objZipFile = null;
			objZipFile = new File(strZipOut);
			byteZip = Files.readAllBytes(objZipFile.toPath());

			//query exec
			String sql = "";
			int intDocumentId=4;
			PreparedStatement pstmt = null;
			//存在確認
			sql = "SELECT COUNT(document_id) cnt FROM common.document_info WHERE document_id=" + intDocumentId;
			objRs = stmt.executeQuery(sql);
			objRs.next();

			if(objRs.getInt("cnt")==1) { //delete →insert
				System.out.println("document_id"+intDocumentId+"が存在するのでDelete→Insert");
				sql = "DELETE FROM common.document_info WHERE document_id=" + intDocumentId;
				stmt.executeUpdate(sql);
			} //if

			sql = "INSERT INTO common.document_info(document_id, document_contents, html_zip_data, server_id , document_name, extension, document_size  , parent_id , file_path, marker , category_id , procenter_flg , procenter_parent_id , node_id , retention_period , author , updater , authorizer , file_update_time , mask_status , create_time , update_time) VALUES (  ? ,1,? , 1,? , ?  , 0 , 30 , ?, null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 , null , null);";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, 4);
			pstmt.setBytes(2, byteZip);
			pstmt.setString(3, "test.xlsx");
			pstmt.setString(4,"xlsx");
			pstmt.setString(5, srcDoc);
			pstmt.executeUpdate();

			System.out.println("InsertTest_OK");
		} catch (Exception e) {
			System.out.println("InsertTest_NG");
			System.err.println(e);
			throw e;
		} finally {
			if (stmt != null) {
				stmt.close();
				stmt = null;
			} //if
			if (objRs != null) {
				objRs.close();
				objRs = null;
			} //if
		} //try
	} //method
} //class
