package jp.co.nec.docmng.manage.controller;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.lang.reflect.Field;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.common.DBConnection;
import jp.co.nec.docmng.manage.entity.CategoryInfo;
import jp.co.nec.docmng.manage.entity.CategoryInfoForm;
import jp.co.nec.docmng.manage.entity.CategoryInfoReflectForm;
import jp.co.nec.docmng.manage.entity.CategoryInfoReflectForm.AddValues;
import jp.co.nec.docmng.manage.entity.CategoryInfoReflectForm.ChangedValues;
import jp.co.nec.docmng.manage.entity.TmpTeacherCategoryList;
import jp.co.nec.docmng.manage.entity.TmpTeacherCategoryListReqForm;

@SuppressWarnings("javadoc")
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class TrainingCategoryControllerTest {

    // DBアクセス用クラス
    DBConnection dbConnection = new DBConnection();

    private MockMvc mockMvc;

    @Autowired
    TrainingCategoryController target;

    @Before
    public void setup() {
        mockMvc = MockMvcBuilders.standaloneSetup(target).build();
    }

    //テスト用データ
    String insertCategoryInfo = "insert into admin.category_info" +
            "	(category_id, category_name, category_author, create_time, update_time)" +
            "	values" +
//            "	(0, 'その他', 'testauthor1', '2019/11/13 00:00:00', '2019/11/13 00:00:00')," +
            "	(998, 'test998', 'testauthor1', '2019/11/13 00:00:00', '2019/11/13 00:00:00')," +
            "	(999, 'test999', 'testauthor2', '2019/11/13 00:00:00', '2019/11/13 00:00:00');";

    //テスト用データ
    String insertCategoryInfoOther = "insert into admin.category_info" +
            "	(category_id, category_name, category_author, create_time, update_time)" +
            "	values" +
            "	(0, 'その他', 'testauthor1', '2019/11/13 00:00:00', '2019/11/13 00:00:00')," +
            "	(998, 'test998', 'testauthor1', '2019/11/13 00:00:00', '2019/11/13 00:00:00')," +
            "	(999, 'test999', 'testauthor2', '2019/11/13 00:00:00', '2019/11/13 00:00:00');";
    String insertTmpTeacherCategoryList = "insert into admin.tmp_teacher_category_list" +
            "	(user_id, sort_id, category_id, file_path, create_time, update_time)" +
            "	values" +
            "	('user999', 996, 998, '\\\\yoks3106\\NES_文書管理システム\\99_tmp\\岩淵\\test\\category\\test1\\test1.txt', '2019/11/13 00:00:00', '2019/11/13 00:00:00')," +
            "	('user999', 997, 998, '\\\\yoks3106\\NES_文書管理システム\\99_tmp\\岩淵\\test\\category\\test2\\test2.txt', '2019/11/13 00:00:00', '2019/11/13 00:00:00')," +
            "	('user999', 998, 999, '\\\\yoks3106\\NES_文書管理システム\\99_tmp\\岩淵\\test\\category\\test3\\test3.txt', '2019/11/13 00:00:00', '2019/11/13 00:00:00')," +
            "	('user999', 999, 999, '\\\\yoks3106\\NES_文書管理システム\\99_tmp\\岩淵\\test\\category\\test4\\test4.txt', '2019/11/13 00:00:00', '2019/11/13 00:00:00');";

    //テストデータ削除用SQL
    String deleteCategoryInfo = "delete from admin.category_info where category_id in (998, 999);";
    String deleteCategoryInfoOther = "delete from admin.category_info where category_id in (0, 998, 999);";
    String deleteTmpTeacherCategoryList = "delete from admin.tmp_teacher_category_list" +
            "	where (user_id, sort_id) in (('user999', 996), ('user999', 997), ('user999', 998), ('user999', 999));";

    /**
     * test_getTrainingCategory001（正常系）
     * 教師データ（分類）設定画面表示
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @Test
    public void test_getTrainingCategory001() throws Exception {
        // DBとの接続を確立
        dbConnection.DBConnect();

        dbConnection.SQLExe(insertCategoryInfo);
        dbConnection.SQLExe(insertTmpTeacherCategoryList);

        try {
            MvcResult result = mockMvc.perform(get("/manage/training_category"))
            .andExpect(status().isOk())
            .andExpect(view().name("manage/training_category"))
            .andReturn();
            List<TmpTeacherCategoryList> teacherCategoryLists =
                     (List<TmpTeacherCategoryList>) result.getModelAndView().getModel().get("teacherCategoryList");
            List<CategoryInfo> categoryInfos =
                    (List<CategoryInfo>) result.getModelAndView().getModel().get("categoryInfo");

            // テストデータ登録確認用
            // 分類
            List<Integer> insertCategoryId = new ArrayList<Integer>(Arrays.asList(999, 998));
            // 教師データ
            List<String> insertTmpTeacherUserId = new ArrayList<String>(Arrays.asList("user999"));
            List<Integer> insertTmpTeacherSortId = new ArrayList<Integer>(Arrays.asList(996, 997, 998, 999));

            List<Integer> dbCategoryId = new ArrayList<Integer>();

            List<String> dbTeacherUserId = new ArrayList<String>();
            List<Integer> dbTeacherSortId = new ArrayList<Integer>();
            // DB取得
            // category_info テーブル
            for (CategoryInfo ci : categoryInfos) {
                // 登録したデータが含まれているか確認
                dbCategoryId.add(ci.getCategoryId());
            }
            assertTrue(dbCategoryId.containsAll(insertCategoryId));
            // tmp_teacher_category_listテーブル
            for (TmpTeacherCategoryList ttcl : teacherCategoryLists) {
                dbTeacherUserId.add(ttcl.getUserId());
                dbTeacherSortId.add(ttcl.getSortId());
            }
            assertTrue(dbTeacherUserId.containsAll(insertTmpTeacherUserId));
            assertTrue(dbTeacherSortId.containsAll(insertTmpTeacherSortId));

        } catch (Exception e) {
            throw e;
        } finally {
            dbConnection.SQLExe(deleteTmpTeacherCategoryList);
            dbConnection.SQLExe(deleteCategoryInfo);
        }
        System.out.println("test_getTrainingCategory001 正常終了");
    }

    /**
     * test_outputFile001
     * ファイル一覧取得（正常）
     * @throws Exception 想定外エラー
     */
    @Test
    public void test_outputFile001() throws Exception {

        //さすがにテストコードでファイル作成したくないので存在するディレクトリを指定
        String directoryPath = "\\\\yoks3106\\NES_文書管理システム\\99_tmp\\岩淵\\test\\test5";
        CategoryInfoForm form = new CategoryInfoForm();

        form.setDirectoryPass(directoryPath);
        ObjectMapper mapper = new ObjectMapper();
        String requestJson = mapper.writeValueAsString(form);
        // POST
        MvcResult result = mockMvc.perform(post("/manage/training_category/read_file")
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestJson))
                .andExpect(status().isOk())
                .andReturn();
        // レスポンスをjson化
        String tmp = result.getResponse().getContentAsString();
        JsonNode jsonNode = mapper.readTree(tmp);
        // ファイルリストが取得出来ればOK
       assertTrue(jsonNode.size() > 0);
       System.out.println("test_outputFile002 正常終了");
    }

    /**
     * test_outputFile002
     * ファイル一覧取得（指定のディレクトリが存在しない）
     * @throws Exception 想定外エラー
     */
    @Test
    public void test_outputFile002() throws Exception {

        //存在しないディレクトリを指定
        String directoryPath = "\\\\yoks3106\\NES_文書管理システム\\99_tmp\\岩淵\\test\\test6";
        CategoryInfoForm form = new CategoryInfoForm();

        form.setDirectoryPass(directoryPath);
        ObjectMapper mapper = new ObjectMapper();
        String requestJson = mapper.writeValueAsString(form);
        // POST
        MvcResult result = mockMvc.perform(post("/manage/training_category/read_file")
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestJson))
                .andExpect(status().isOk())
                .andReturn();
        // レスポンスをjson化
        String tmp = result.getResponse().getContentAsString();
        JsonNode jsonNode = mapper.readTree(tmp);
        System.out.println(jsonNode.size());
        // リストが0件ならOK
       assertTrue(jsonNode.size() == 0);
       System.out.println("test_outputFile002 正常終了");
    }

    /**
     * test_categoryReflect001
     * 分類一覧更新メソッド（正常）
     * @throws Exception 想定外エラー
     */
    @Test
    public void test_categoryReflect001() throws Exception{
        // DBとの接続を確立
        dbConnection.DBConnect();

        dbConnection.SQLExe(insertCategoryInfoOther);
        dbConnection.SQLExe(insertTmpTeacherCategoryList);

        // 追加データ
        String addCategoryAuthor = "addCategoryAuthor";
        String addCategoryName = "addCategoryName";

        Integer changeCategoryId = 998;
        String changeCategoryName = "changeCategoryName";

        Integer deleteCategoryId = 999;
        try {
            // リクエストデータの作成
            CategoryInfoReflectForm requestForm = new CategoryInfoReflectForm();
            List<AddValues> addValues = new ArrayList<AddValues>();
            List<ChangedValues> changedValues = new ArrayList<ChangedValues>();
            List<Integer> deleteRow = new ArrayList<Integer>();

            AddValues addValue = new AddValues();
            ChangedValues changeValue = new ChangedValues();

            // 追加
            addValue.setCategoryAuthor(addCategoryAuthor);
            addValue.setCategoryName(addCategoryName);
            addValues.add(addValue);

            // 更新
            changeValue.setCategoryId(changeCategoryId);
            changeValue.setCategoryName(changeCategoryName);
            changedValues.add(changeValue);

            // 削除
            deleteRow.add(deleteCategoryId);

            requestForm.setAddValues(addValues);
            requestForm.setChangedValues(changedValues);
            requestForm.setDeleteRow(deleteRow);

            ObjectMapper mapper = new ObjectMapper();
            String requestJson = mapper.writeValueAsString(requestForm);

            //POST
            mockMvc.perform(post("/manage/training_category/category_reflect")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(requestJson))
                    .andExpect(status().isOk());

         // 追加確認
            String select = "select * from admin.category_info where category_name = '" + addCategoryName+ "'";
            ResultSet addRs = dbConnection.SelectSQLExe(select);
            // 行が取得出来ているなら登録OK
            assertTrue(addRs.next());
            addRs.close();

            // 変更確認
            String changeselect = "select * from admin.category_info where category_name = '" + changeCategoryName+ "'";
            ResultSet changeRs = dbConnection.SelectSQLExe(changeselect);
            // 行が取得出来ているなら登録OK
            assertTrue(changeRs.next());
            changeRs.close();

            // 削除確認
            String delselect = "select * from admin.category_info where category_id = '" + deleteCategoryId+ "'";
            ResultSet delRs = dbConnection.SelectSQLExe(delselect);
            // 削除しているため0件
            assertTrue(!delRs.next());
            delRs.close();

            System.out.println("test_getTrainingCategory001 正常終了");

            // DBからテストデータ削除
            dbConnection.SQLExe(deleteTmpTeacherCategoryList);
            // 追加行削除する
            String addColumnDelSql = "delete from admin.category_info where category_name = '" + addCategoryName + "'";
            dbConnection.SQLExe(addColumnDelSql);
            // 削除行を取り除いた他の行も削除
            String delColumnDelSql = "delete from admin.category_info where category_id = 998";
            dbConnection.SQLExe(delColumnDelSql);
        } catch (Exception e) {
            e.printStackTrace();
            dbConnection.SQLExe(deleteTmpTeacherCategoryList);
            dbConnection.SQLExe(deleteCategoryInfoOther);
            throw e;
        } finally {
        }
    }

    /**
     * test_teacherCategoryReflect001（正常）
     * 登録データ一覧更新メソッド
     * @throws Exception 想定外エラー
     */
    @Test
    public void test_teacherCategoryReflect001() throws Exception {
        // DBとの接続を確立
        dbConnection.DBConnect();

        dbConnection.SQLExe(insertCategoryInfo);
        dbConnection.SQLExe(insertTmpTeacherCategoryList);

        // テストデータ作成
        TmpTeacherCategoryListReqForm form = new TmpTeacherCategoryListReqForm();

        String savePath = "\\\\yoks3106\\NES_文書管理システム\\99_tmp\\岩淵\\test\\tmp";
        String userName = "addUserName";

        String addUserId = "addUserID";
        Integer addSortId = 999;
        Integer addCategoryId = 999;
        String addFilePath = "\\\\yoks3106\\NES_文書管理システム\\99_tmp\\岩淵\\test\\category\\test1\\test1.txt";

        Integer delCategoryId = 998;

        List<TmpTeacherCategoryList> tmpTeacherCategoryList = new ArrayList<TmpTeacherCategoryList>();
        TmpTeacherCategoryList tmpTeacherCategory = new TmpTeacherCategoryList();
        tmpTeacherCategory.setUserId(addUserId);
        tmpTeacherCategory.setSortId(addSortId);
        tmpTeacherCategory.setCategoryId(addCategoryId);
        tmpTeacherCategory.setFilePath(addFilePath);

        tmpTeacherCategoryList.add(tmpTeacherCategory);

        form.setTmpTeacherCategoryList(tmpTeacherCategoryList);
        form.setSavePath(savePath);
        form.setUserName(userName);


        System.out.println(form.getSavePath());
        System.out.println(form.getTmpTeacherCategoryList());

        try {
            ObjectMapper mapper = new ObjectMapper();
            String requestJson = mapper.writeValueAsString(form);

            System.out.println(requestJson);
            //POST
            mockMvc.perform(post("/manage/training_category/teacher_category_reflect")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(requestJson))
                    .andExpect(status().isOk());

            // 登録確認
            String changeselect = "select * from admin.tmp_teacher_category_list where user_id = '" + addUserId+ "'";
            ResultSet changeRs = dbConnection.SelectSQLExe(changeselect);
            // 行が取得出来ているなら登録OK
            assertTrue(changeRs.next());
            changeRs.close();

            // 削除確認
            String delselect = "select * from admin.tmp_teacher_category_list where category_id = '" + delCategoryId+ "'";
            ResultSet delRs = dbConnection.SelectSQLExe(delselect);
            // 削除しているため0件
            assertTrue(!delRs.next());
            delRs.close();

            System.out.println("test_teacherCategoryReflect001 正常終了");

            // DBからテストデータ削除
            // 削除行を取り除いた他の行も削除
            String delColumnDelSql = "delete from admin.tmp_teacher_category_list" +
                    " where user_id = 'addUserID' and sort_id = 999";
            dbConnection.SQLExe(delColumnDelSql);
            dbConnection.SQLExe(deleteCategoryInfo);
        } catch (Exception e) {
            e.printStackTrace();
            dbConnection.SQLExe(deleteTmpTeacherCategoryList);
            dbConnection.SQLExe(deleteCategoryInfo);
            throw e;
        } finally {

        }
    }

    /**
     * test_teacherCategoryReflect002（正常）
     * 登録データ一覧更新メソッド Wordファイル
     * @throws Exception 想定外エラー
     */
    @Test
    public void test_teacherCategoryReflect002() throws Exception {
        // DBとの接続を確立
        dbConnection.DBConnect();

        dbConnection.SQLExe(insertCategoryInfo);
        dbConnection.SQLExe(insertTmpTeacherCategoryList);

        // テストデータ作成
        TmpTeacherCategoryListReqForm form = new TmpTeacherCategoryListReqForm();

        String savePath = "\\\\yoks3106\\NES_文書管理システム\\99_tmp\\岩淵\\test\\tmp";
        String userName = "addUserName";

        String addUserId = "addUserID";
        Integer addSortId = 999;
        Integer addCategoryId = 999;
        String addFilePath = "\\\\yoks3106\\NES_文書管理システム\\99_tmp\\岩淵\\test\\category\\test1\\test5word.docx";

        Integer delCategoryId = 998;

        List<TmpTeacherCategoryList> tmpTeacherCategoryList = new ArrayList<TmpTeacherCategoryList>();
        TmpTeacherCategoryList tmpTeacherCategory = new TmpTeacherCategoryList();
        tmpTeacherCategory.setUserId(addUserId);
        tmpTeacherCategory.setSortId(addSortId);
        tmpTeacherCategory.setCategoryId(addCategoryId);
        tmpTeacherCategory.setFilePath(addFilePath);

        tmpTeacherCategoryList.add(tmpTeacherCategory);

        form.setTmpTeacherCategoryList(tmpTeacherCategoryList);
        form.setSavePath(savePath);
        form.setUserName(userName);


        System.out.println(form.getSavePath());
        System.out.println(form.getTmpTeacherCategoryList());

        try {
            ObjectMapper mapper = new ObjectMapper();
            String requestJson = mapper.writeValueAsString(form);

            System.out.println(requestJson);
            //POST
            mockMvc.perform(post("/manage/training_category/teacher_category_reflect")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(requestJson))
                    .andExpect(status().isOk());

            // 登録確認
            String changeselect = "select * from admin.tmp_teacher_category_list where user_id = '" + addUserId+ "'";
            ResultSet changeRs = dbConnection.SelectSQLExe(changeselect);
            // 行が取得出来ているなら登録OK
            assertTrue(changeRs.next());
            changeRs.close();

            // 削除確認
            String delselect = "select * from admin.tmp_teacher_category_list where category_id = '" + delCategoryId+ "'";
            ResultSet delRs = dbConnection.SelectSQLExe(delselect);
            // 削除しているため0件
            assertTrue(!delRs.next());
            delRs.close();

            System.out.println("test_teacherCategoryReflect002 正常終了");

            // DBからテストデータ削除
            // 削除行を取り除いた他の行も削除
            String delColumnDelSql = "delete from admin.tmp_teacher_category_list" +
                    " where user_id = 'addUserID' and sort_id = 999";
            dbConnection.SQLExe(delColumnDelSql);
            dbConnection.SQLExe(deleteCategoryInfo);

        } catch (Exception e) {
            e.printStackTrace();
            dbConnection.SQLExe(deleteTmpTeacherCategoryList);
            dbConnection.SQLExe(deleteCategoryInfo);
            throw e;
        } finally {
        }
    }

    /**
     * test_teacherCategoryReflect003
     * 登録データ一覧更新メソッド （保存先が見つからない）
     * @throws Exception 想定外エラー
     */
    @Test
    public void test_teacherCategoryReflect003() throws Exception {
        // DBとの接続を確立
        dbConnection.DBConnect();

        dbConnection.SQLExe(insertCategoryInfo);
        dbConnection.SQLExe(insertTmpTeacherCategoryList);

        // テストデータ作成
        TmpTeacherCategoryListReqForm form = new TmpTeacherCategoryListReqForm();

        String savePath = "\\\\err\\test";
        String userName = "addUserName";

        String addUserId = "addUserID";
        Integer addSortId = 999;
        Integer addCategoryId = 999;
        String addFilePath = "\\\\yoks3106\\NES_文書管理システム\\99_tmp\\岩淵\\test\\category\\test1\\test1.txt";

        List<TmpTeacherCategoryList> tmpTeacherCategoryList = new ArrayList<TmpTeacherCategoryList>();
        TmpTeacherCategoryList tmpTeacherCategory = new TmpTeacherCategoryList();
        tmpTeacherCategory.setUserId(addUserId);
        tmpTeacherCategory.setSortId(addSortId);
        tmpTeacherCategory.setCategoryId(addCategoryId);
        tmpTeacherCategory.setFilePath(addFilePath);

        tmpTeacherCategoryList.add(tmpTeacherCategory);

        form.setTmpTeacherCategoryList(tmpTeacherCategoryList);
        form.setSavePath(savePath);
        form.setUserName(userName);

        try {
            ObjectMapper mapper = new ObjectMapper();
            String requestJson = mapper.writeValueAsString(form);

            System.out.println(requestJson);
            //POST
            MvcResult result = mockMvc.perform(post("/manage/training_category/teacher_category_reflect")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(requestJson))
                    .andExpect(status().isBadRequest())
                    .andReturn();

            String resultData = result.getResponse().getContentAsString().replace("\"", "");

            String err = "保存先のフォルダ" + savePath + "は存在しません。";

            System.out.println(resultData + "  "  + err);
            assertEquals(resultData, err);

            System.out.println("test_teacherCategoryReflect003 正常終了");
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            // DBからテストデータ削除
            dbConnection.SQLExe(deleteTmpTeacherCategoryList);
            dbConnection.SQLExe(deleteCategoryInfo);
        }
    }
    /**
     * test_teacherCategoryReflect004
     * 登録データ一覧更新メソッド （ファイルが見つからない）
     * リストに反映後に削除された場合
     * @throws Exception 想定外エラー
     */
    @Test
    public void test_teacherCategoryReflect004() throws Exception {
        // DBとの接続を確立
        dbConnection.DBConnect();

        dbConnection.SQLExe(insertCategoryInfo);
        dbConnection.SQLExe(insertTmpTeacherCategoryList);

        // テストデータ作成
        TmpTeacherCategoryListReqForm form = new TmpTeacherCategoryListReqForm();

        String savePath = "\\\\yoks3106\\NES_文書管理システム\\99_tmp\\岩淵\\test\\tmp";
        String userName = "addUserName";

        String addUserId = "addUserID";
        Integer addSortId = 999;
        Integer addCategoryId = 999;
        String addFilePath = "\\\\err\\file.txt";

        List<TmpTeacherCategoryList> tmpTeacherCategoryList = new ArrayList<TmpTeacherCategoryList>();
        TmpTeacherCategoryList tmpTeacherCategory = new TmpTeacherCategoryList();
        tmpTeacherCategory.setUserId(addUserId);
        tmpTeacherCategory.setSortId(addSortId);
        tmpTeacherCategory.setCategoryId(addCategoryId);
        tmpTeacherCategory.setFilePath(addFilePath);

        tmpTeacherCategoryList.add(tmpTeacherCategory);

        form.setTmpTeacherCategoryList(tmpTeacherCategoryList);
        form.setSavePath(savePath);
        form.setUserName(userName);

        try {
            ObjectMapper mapper = new ObjectMapper();
            String requestJson = mapper.writeValueAsString(form);

            System.out.println(requestJson);
            //POST
            MvcResult result = mockMvc.perform(post("/manage/training_category/teacher_category_reflect")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(requestJson))
                    .andExpect(status().isBadRequest())
                    .andReturn();

            String resultData = result.getResponse().getContentAsString().replace("\"", "");

            String err = "指定のファイル" + addFilePath + "は存在しません。";
            assertEquals(resultData, err);

            System.out.println("test_teacherCategoryReflect004 正常終了");
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            // DBからテストデータ削除
            dbConnection.SQLExe(deleteTmpTeacherCategoryList);
            dbConnection.SQLExe(deleteCategoryInfo);
        }
    }

    /**
     * test_teacherCategoryReflect005
     * 登録データ一覧更新メソッド（カテゴリその他未登録）
     * @throws Exception 想定外エラー
     */
    @Test
    public void test_teacherCategoryReflect005() throws Exception {
        // DBとの接続を確立
        dbConnection.DBConnect();

        dbConnection.SQLExe(insertCategoryInfo);
        dbConnection.SQLExe(insertTmpTeacherCategoryList);

        String otherSelect = "select * from admin.category_info where category_id = 0";
        ResultSet otherRs = dbConnection.SelectSQLExe(otherSelect);
        // その他が登録されているならいったん削除
        if (otherRs.next()) {
            String delOther = "delete from admin.category_info where category_id = 0;";
            dbConnection.SQLExe(delOther);
        }
        otherRs.close();

        // テストデータ作成
        TmpTeacherCategoryListReqForm form = new TmpTeacherCategoryListReqForm();

        String savePath = "\\\\yoks3106\\NES_文書管理システム\\99_tmp\\岩淵\\test\\tmp";
        String userName = "addUserName";

        String addUserId = "addUserID";
        Integer addSortId = 999;
        Integer addCategoryId = 999;
        String addFilePath = "\\\\yoks3106\\NES_文書管理システム\\99_tmp\\岩淵\\test\\category\\test1\\test1.txt";

        List<TmpTeacherCategoryList> tmpTeacherCategoryList = new ArrayList<TmpTeacherCategoryList>();
        TmpTeacherCategoryList tmpTeacherCategory = new TmpTeacherCategoryList();
        tmpTeacherCategory.setUserId(addUserId);
        tmpTeacherCategory.setSortId(addSortId);
        tmpTeacherCategory.setCategoryId(addCategoryId);
        tmpTeacherCategory.setFilePath(addFilePath);

        tmpTeacherCategoryList.add(tmpTeacherCategory);

        form.setTmpTeacherCategoryList(tmpTeacherCategoryList);
        form.setSavePath(savePath);
        form.setUserName(userName);


        System.out.println(form.getSavePath());
        System.out.println(form.getTmpTeacherCategoryList());

        try {
            ObjectMapper mapper = new ObjectMapper();
            String requestJson = mapper.writeValueAsString(form);

            System.out.println(requestJson);
            //POST
            mockMvc.perform(post("/manage/training_category/teacher_category_reflect")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(requestJson))
                    .andExpect(status().isOk());

            String otherAddSelect = "select * from admin.category_info where category_id = 0";
            ResultSet otherAddRs = dbConnection.SelectSQLExe(otherAddSelect);
            // その他行が拾えればOK
            assertTrue(otherAddRs.next());
            otherRs.close();

            System.out.println("test_teacherCategoryReflect005 正常終了");
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            // DBからテストデータ削除
            // 削除行を取り除いた他の行も削除
            String delColumnDelSql = "delete from admin.tmp_teacher_category_list" +
                    " where user_id = 'addUserID' and sort_id = 999";
            dbConnection.SQLExe(delColumnDelSql);
            dbConnection.SQLExe(deleteCategoryInfo);
        }
    }
    /**
     * test_teacherCategoryReflect006
     * 登録データ一覧更新メソッド（CSVファイルの作成に失敗）
     * HTMLコンバート中にHTMLの保存先が見つからない
     * @throws Exception 想定外エラー
     */
    @Test
    public void test_teacherCategoryReflect006() throws Exception {

        // TrainingCategoryController の定数 STR_HTML_DIR_PATHを置き換える
        TrainingCategoryController tcc = new TrainingCategoryController();
        Field fieldProperty = null;
        fieldProperty = tcc.getClass().getDeclaredField("STR_HTML_DIR_PATH");
        fieldProperty.setAccessible(true);
        fieldProperty.set(fieldProperty, "\\\\err\\test");

        // DBとの接続を確立
        dbConnection.DBConnect();

        dbConnection.SQLExe(insertCategoryInfo);
        dbConnection.SQLExe(insertTmpTeacherCategoryList);

        String otherSelect = "select * from admin.category_info where category_id = 0";
        ResultSet otherRs = dbConnection.SelectSQLExe(otherSelect);
        // その他が登録されているならいったん削除
        if (otherRs.next()) {
            String delOther = "delete from admin.category_info where category_id = 0;";
            dbConnection.SQLExe(delOther);
        }
        otherRs.close();

        // テストデータ作成
        TmpTeacherCategoryListReqForm form = new TmpTeacherCategoryListReqForm();

        String savePath = "\\\\yoks3106\\NES_文書管理システム\\99_tmp\\岩淵\\test\\tmp";
        String userName = "addUserName";

        String addUserId = "addUserID";
        Integer addSortId = 999;
        Integer addCategoryId = 999;
        String addFilePath = "\\\\yoks3106\\NES_文書管理システム\\99_tmp\\岩淵\\test\\category\\test1\\test5word.docx";

        List<TmpTeacherCategoryList> tmpTeacherCategoryList = new ArrayList<TmpTeacherCategoryList>();
        TmpTeacherCategoryList tmpTeacherCategory = new TmpTeacherCategoryList();
        tmpTeacherCategory.setUserId(addUserId);
        tmpTeacherCategory.setSortId(addSortId);
        tmpTeacherCategory.setCategoryId(addCategoryId);
        tmpTeacherCategory.setFilePath(addFilePath);

        tmpTeacherCategoryList.add(tmpTeacherCategory);

        form.setTmpTeacherCategoryList(tmpTeacherCategoryList);
        form.setSavePath(savePath);
        form.setUserName(userName);

        try {
            ObjectMapper mapper = new ObjectMapper();
            String requestJson = mapper.writeValueAsString(form);

            System.out.println(requestJson);
            //POST
            MvcResult result = mockMvc.perform(post("/manage/training_category/teacher_category_reflect")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(requestJson))
                    .andExpect(status().isBadRequest())
                    .andReturn();

            String resultData = result.getResponse().getContentAsString().replace("\"", "");

            String err ="CSVファイル作成中に失敗しました。";
            assertEquals(resultData, err);

            System.out.println("test_teacherCategoryReflect006 正常終了");
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            // DBからテストデータ削除
            dbConnection.SQLExe(deleteTmpTeacherCategoryList);
            dbConnection.SQLExe(deleteCategoryInfo);
        }
    }

}
