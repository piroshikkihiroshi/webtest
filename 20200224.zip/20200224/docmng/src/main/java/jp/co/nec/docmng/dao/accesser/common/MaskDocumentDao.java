package jp.co.nec.docmng.dao.accesser.common;

import java.io.Reader;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import jp.co.nec.docmng.dao.entity.common.MaskDocument;
import jp.co.nec.docmng.dao.entity.common.MaskDocumentExample;
import jp.co.nec.docmng.dao.mapper.common.MaskDocumentMapper;

/**
 * MaskDocumentDao
 * 黒塗り文書保存テーブルの全件を取得する。
 */
public class MaskDocumentDao {
	
	/**
	 * 黒塗り文書保存テーブルの情報を表示する。
	 * @return List<MaskDocument> maskDocumentList 黒塗り文書保存テーブルの情報リストを取得する。
	 */
	public List<MaskDocument> getMaskDocumentAll() {
		
	List<MaskDocument> maskDocumentList = null;
	
	try (Reader readerConfig = Resources.getResourceAsReader("mybatis-config.xml");) {

		// 読み込んだ設定ファイルからSqlSessionFactoryを生成する
		SqlSessionFactory sqlFactory = new SqlSessionFactoryBuilder().build(readerConfig);

		// SQLセッションを取得する
		try (SqlSession sqlSession = sqlFactory.openSession()) {

			// 黒塗り文書保存テーブルのMapperを取得する
			MaskDocumentMapper maskDocumentMapper = sqlSession.getMapper(MaskDocumentMapper.class);

			// 黒塗り文書保存テーブルの条件検索用クラスを生成する
			MaskDocumentExample maskDocumentExample = new MaskDocumentExample();
			
			maskDocumentExample.setOrderByClause("mask_id");

			// 上記の条件でテーブルを検索する
			maskDocumentList = maskDocumentMapper.selectByExample(maskDocumentExample);
		}
	} catch (Exception e) {
		// テーブル情報を取得できない場合
		e.printStackTrace();
	}
	return maskDocumentList;
	}
}
