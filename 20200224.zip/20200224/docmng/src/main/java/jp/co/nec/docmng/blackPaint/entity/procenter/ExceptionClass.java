/**
 * 名称：ExceptionClass.java
 * 機能名：PROCENTER エラー
 * 機能:PROCENTERのエラー管理
 */

package jp.co.nec.docmng.blackPaint.entity.procenter;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * PROCENTER エラー
 */
public class ExceptionClass {

	/**
	 * エラー内容
	 */
	private String message;

	/**
	 * message getter
	 * @return message
	 */
	@JsonProperty("message")
	public String getMessage() {
		return message;
	}
	/**
	 * message setter
	 * @param value
	 */
	@JsonProperty("message")
	public void setMessage(String value) {
		this.message = value;
	}
}
