/**
 * @fileOverview ハイアラキーメニューを生成クラス
 * @author NEC
 * @version 1.0.0
 */
/**
 * @class HierarchyMenu
 * @description 指定されたdomと与えられた階層データに従って、
 * ハイアラキーメニューを生成します。
 */
'use strict'
class HierarchyMenu{
    /**
     *Creates an instance of HierarchyMenu.
     * @param {Object} params DOM
     * @memberof HierarchyMenu
     */
    constructor(params){
        var items = [];
        this.isShow = false;
        Array.from(params).map(param =>{
            var item = {};
            item.rootDom = this.createRootDom();
            item.rootDom.style.display = "none";
            item.rootDom.className = "rootDom";
            // item.toggleShow = event => console.log(event);
            param.targetDom.appendChild(item.rootDom);
            item.hierarchy = param.hierarchy;
            item.dom = this.createHierarchyDom(item,item.hierarchy, item.rootDom,true/* 初回 */);
            items.push(item);
            param.targetDom.addEventListener("click", event => {
                event.preventDefault();
                event.stopImmediatePropagation()
                if (!event.target.querySelector(".rootDom")) return;
                var rootDom = event.target.querySelector(".rootDom")
                console.log(event)
                if(rootDom.style.display === "none"){
                    rootDom.style.display = "block"
                }else{
                    rootDom.style.display = "none"
                }
            }, { passive: false })

        })
    }
    /**
     * メニューのピボットになるdomの生成
     * @returns {Object} メニューのピボットになるDOM
     * @memberof HierarchyMenu
     */
    createRootDom(){
        var dom = document.createElement("div");
        dom.style.width = 0;
        dom.style.height = 0;
        dom.style.lineHeight = 0;
        dom.style.posotion = "relative";
        return dom;
    }
    /**
     * キャンセル
     * @param {Object} cancelItem 処理をキャンセルするアイテム
     * @memberof HierarchyMenu
     */
    cancel(cancelItem) {
        // とりあえず消すだけ
        cancelItem.rootDom.style.display = "none";
    }
    /**
     * ハイアラキーメニューのdomの生成
     * @param {Object} rootItem
     * @param {Object} hierarchyObj
     * @param {Object} rootDom
     * @param {Boolean} firstTime
     * @memberof HierarchyMenu
     */
    createHierarchyDom(rootItem,hierarchyObj,rootDom,firstTime){
        var containerDom = document.createElement("div");
        firstTime ? containerDom.className = "hierarchy_columnContainer1st"
            : containerDom.className = "hierarchy_columnContainer";
        firstTime ? containerDom.className = "hierarchy_columnContainer1st"
            : containerDom.style.display = "none";
        rootDom.appendChild(containerDom)
        Array.from(hierarchyObj).map(item => {
            var dom = document.createElement("div");
            dom.innerText = item.title;
            dom.className = "hierarchy_item";
            containerDom.appendChild(dom)
            if (item.hierarchy === undefined) {
                this.clickRoot = rootItem;
                dom.addEventListener("click", item.callback.bind(this), { passive: false })
                dom.addEventListener("contextmenu", event => event.preventDefault() , { passive: false })
            }else{
                dom.className = dom.className + " rightArrow"
                var clickDom = event => {
                    event.preventDefault();
                    event.stopImmediatePropagation();
                    // 階層のコンテナの場合
                    if (event.target.querySelector(".hierarchy_columnContainer")) {
                        var rootDom = event.target.querySelector(".hierarchy_columnContainer")
                        if (rootDom.style.display === "none") {
                            rootDom.style.display = "block"
                        } else {
                            rootDom.style.display = "none"
                        }
                    }
                    // チェックボックスの処理
                    if (event.target.className.match("unChecked")) {
                        event.target.className = event.target.className.replace("unChecked","checked")
                    }else
                    if (event.target.className.match("checked")) {
                        event.target.className = event.target.className.replace("checked", "unChecked")
                    }
                }
                dom.addEventListener("click", clickDom , { passive: false })
                dom.addEventListener("contextmenu", clickDom , { passive: false })

                this.createHierarchyDom(rootItem,item.hierarchy, dom)

            }
            if (item.checkBox !== undefined){
                item.checkBox?
                dom.className = dom.className + " unChecked":
                dom.className = dom.className + " checked"
            }
        })
    }
}