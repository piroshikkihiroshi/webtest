"use strict"
/*
 * 
 * 受け取った列のリストのすべてのカラムの高さが等しくなるようにセットする。
 * リサイズなどで合わせ直すときは一旦すべてのドムの高さの指定を外して
 * フリーにしてから、最大値を取り直す。
 * フリーにしてすぐに測定するとセットされていた高さから変わっていないので、
 * タイマーを掛けてセット。
 * タイマーで呼び続けると負荷が高いので、
 * 呼び出しが処理されずに複数溜まっている場合はキャンセルして、
 * 最後に掛けられた呼び出しのみ実行する。
 * ResizableGridのグリッドを変更した場合も呼び出される。
 * 
 */
class AlignHeight {
    constructor(lines) {
        /////// ラインの高さをキャンセル
        Array.from(lines).map(line => line.style.height = "unset")
        this.lines = lines.map(line => {
            return Array.from(line.querySelectorAll("li"))
        })
        console.log(this.lines)
        this.alignHeight()
        this.count = 0;
        window.addEventListener("resize", this.resize.bind(this))

    }
    alignHeight() {
        console.log(this.lines)
        this.lines.map(line => {
            let max = Math.max(...(line.map(li => li.clientHeight)))
            console.log(max)
            line.map(li => {
                li.style.height = max + "px";
            })
        })
    }
    freeHeight() {
        this.lines.map(line => {
            line.map(li => {
                li.style.height = "unset";
            })
        })
    }
    resize() {
        console.log("resize", this)
        this.freeHeight()
        this.count++;
        setTimeout(() => {
            if (--this.count === 0) {
                (() => { this.alignHeight() })()
                console.log("resize timer", this)
            }
        }, 100);
    }
}