//定数等
const TAG_RED = "tagRed";
const TAG_MASK = "tagMsk";

const STATE_MASK = 1;
const STATE_RED = 2;
const MASK_MSG = "■";
const MASK_BF = "<span class='tagMsk' id='msk";
const MASK_BF_INIT= "<span class='tagMsk tagMskInit' id='msk";
const MASK_BF_END= "<span class='tagMsk tagMskEnd' id='msk";
const RED_BF = "<span class='tagRed' id='red";
const RED_BF_INIT= "<span class='tagRed tagRedInit' id='red";
const RED_BF_END= "<span class='tagRed tagRedEnd' id='red";
const MASK_END_CLS="tagMskEnd";
const RED_END_CLS="tagRedEnd";
const MASK_AF = "</span>";
const RED_AF = "</span>";
const MASK_INIT_CLS="tagMskInit";
const RED_INIT_CLS="tagRedInit";

const NODE_CROSS = 1;
const SPACE_MARK = '&nbsp;';
const REG_TAG_VAL_SPLIT = "(<\\/?[^>]+>)|([^<]+)";
const NOMAL_MENU = 1;
const MASK_MENU = 2;

const ID_OFFSET = 4;

var glActContext;
var glIdCnt = 0;

//暫定で100000 余裕があればAIのマスク連番(サーバサイド処理)と合わせる
var glMaskIdCnt = 100000;
var glRedIdCnt = 100000;


/**
* HTMLのchar毎の情報を格納するクラス
* HashMap<Integer, HtmlStructure> の形で格納し、keyは置換対象外文字やtagを含んだポジション
* (<div>タグ等を含む)を格納する
*/
class HtmlStructure {
    strTgt = ""; //対象文字
    intPage = 0; //Page
    intStatus = 0; //strTgtのステータス 0：置換対象外(半角文字等) 1：対象 2：tag
    intNotTagPos = 0; //置換対象外文字やtagを抜いたときのポジション		
} //class

/**
* strの文字列をbeforeStrをafterStrに全置換する
* @return 置換文字列
*/
function replaceAll(str, beforeStr, afterStr) {
    var reg = new RegExp(beforeStr, "g");
    return str.replace(reg, afterStr);
} //function

/**
* 全てのタグにIDを付与する(もともとIDある場合未考慮)
*/
function allIdPut(objTgtDom_i, strTagName_i) {
    objTgtDom_i.setAttribute("id", strTagName_i + glIdCnt);
    glIdCnt++;
    for (var index = glIdCnt; index < objTgtDom_i.childElementCount; index++) {
        var objActDom = objTgtDom_i.children[index];
        objActDom.setAttribute("id", strTagName_i + index);
        glIdCnt++;
    } // for	
    if (objTgtDom_i.childElementCount != 0) {
        for (var index = 0; index < objTgtDom_i.childElementCount; index++) {
            var objActDom = objTgtDom_i.children[index];
            allIdPut(objActDom, strTagName_i);
        } // for	
    }//if		
} //function

/**
* bodyの構造体hashを取得
* @param strOrgBody_i
* @return HtmlStructureのハッシュ
*/
function getBodyStructure(strOrgBody_i) {
    var strTgtVal = strOrgBody_i;

    var hashRetStructure = {};
    var listLastNotTagPos = []; //intNotTagPosを格納していく
    var strRegrep = REG_TAG_VAL_SPLIT; //タグとタグを除いた値をグループで取得する
    var objPattern = new RegExp(strRegrep, "g");
    var strCurrentKwd = ""; //現在ヒットしている単語
    var intCurrentPos = 0;
    var objRegRet;
    while ((objRegRet = objPattern.exec(strTgtVal)) != null) {
        strCurrentKwd = objRegRet[2];
        if (strCurrentKwd == undefined) { //タグの処理
            strCurrentKwd = objRegRet[1];
            searchAnalysis(hashRetStructure, listLastNotTagPos, strCurrentKwd, intCurrentPos, 2);
        } else if (strCurrentKwd == " " || strCurrentKwd == SPACE_MARK) { //半角スペース処理
            searchAnalysis(hashRetStructure, listLastNotTagPos, strCurrentKwd, intCurrentPos, 0);
            continue; //半角スペースはそのまま格納
        } else if (Boolean(strCurrentKwd.match(/\t|\v|\n|\r|\f/g))) { //特殊記号処理        
            searchAnalysis(hashRetStructure, listLastNotTagPos, strCurrentKwd, intCurrentPos, 0);
            continue; //特殊記号処理はそのまま格納            
        } else { //通常文字
            searchAnalysis(hashRetStructure, listLastNotTagPos, strCurrentKwd, intCurrentPos, 1);
        } //if
        intCurrentPos = Object.keys(hashRetStructure).length;

    }  //while

    return hashRetStructure;
} //function

/**
* 検索結果からbodyの構造体hashを作成する
* @param HashMap<Integer, HtmlStructure> hashRetStructure_i 参照渡しのハッシュ
* HtmlStructureはHTMLのchar毎の情報を格納するクラス
* HashMap<Integer, HtmlStructure> の形で格納し、keyは置換対象外文字やtagを含んだポジション(<div>タグ等を含む)を格納する
* @param strCurrentKwd_i 現在正規表現でヒットしている文字列
* @param intCurrentPos_i タグを含めた現在のposition
* @param intStatus_i 0：置換対象外(半角文字等) 1：対象 2：tag
*/
function searchAnalysis(hashRetStructure_i, listLastNotTagPos_i, strCurrentKwd_i, intCurrentPos_i, intStatus_i) {
    var intCntPos = Object.keys(hashRetStructure_i).length;
    var intNotTagPos = 0;
    objHtmlStructure = null;
    var arrTmp = strCurrentKwd_i.split("");
    var strTgt = "";

    if (listLastNotTagPos_i.length != 0) { //tag抜き文字の最終を取得する
        intNotTagPos = listLastNotTagPos_i[listLastNotTagPos_i.length - 1];
    } //if

    for (var i = 0; i < arrTmp.length; i++) {
        objHtmlStructure = new HtmlStructure();
        strTgt = arrTmp[i];
        objHtmlStructure.strTgt = strTgt;
        objHtmlStructure.intStatus = intStatus_i;
        if (intStatus_i == 1) { //通常文字はintNotTagPosをカウント
            intNotTagPos++;
            objHtmlStructure.intNotTagPos = intNotTagPos;
        } //if
        hashRetStructure_i[intCntPos + (i + 1)] = objHtmlStructure;
    } //for

    if (intStatus_i == 1) { //通常時はtag抜き文字の最終を格納
        listLastNotTagPos_i.push(intNotTagPos);
    } //if
} //function

/**
 * 全文検索エンジンに返した結果を置換してbodyを入れ替え、または赤文字変換した文字列を取得
 * @param hashBodyStructure_i HTMLのchar毎の情報を格納するクラスを格納したhash key：HTMLのindex : val HTMLのchar(index)毎の情報を格納するクラス
 * @param intMaskStatus_i 置換ステータス :マスク 2:赤文字
 * @return 置換したBody文字列
 */
function bodyCharChange(hashBodyStructure_i, intMaskStatus_i) {
    var strRepBody = "";
    var intStatus = 0;
    var blFlag = true;
    var intIndCnt=Object.keys(hashBodyStructure_i).length;
    for (var i = 1; i < Object.keys(hashBodyStructure_i).length + 1; i++) {
        var objHtmlStructure = hashBodyStructure_i[i];
        intStatus = objHtmlStructure.intStatus;
        intNotTagPos = objHtmlStructure.intNotTagPos;
        if (intStatus == 1) { //通常文字の場合
            if (intMaskStatus_i == 1 && blFlag) { //初期だけ特別クラス
                strRepBody += MASK_BF_INIT + glMaskIdCnt + "'>" + MASK_MSG + MASK_AF; //マスク
                blFlag=false;
                glMaskIdCnt++;
            } else if (blFlag) { //初期だけ特別クラス
                strRepBody += RED_BF_INIT + glRedIdCnt + "'>" + objHtmlStructure.strTgt + RED_AF; //赤塗り
                blFlag=false;
                glRedIdCnt++;
            } else if (intMaskStatus_i == 1 && i==intIndCnt) { //最後も特別クラス
                strRepBody += MASK_BF_END + glMaskIdCnt + "'>" + MASK_MSG + MASK_AF; //マスク
                blFlag=false;
                glMaskIdCnt++;
            } else if (i==intIndCnt) { //最後も特別クラス
                strRepBody += RED_BF_END + glRedIdCnt + "'>" + objHtmlStructure.strTgt + RED_AF; //赤塗り
                blFlag=false;
                glRedIdCnt++;
            }else if (intMaskStatus_i == 1) {
                strRepBody += MASK_BF + glMaskIdCnt + "'>" + MASK_MSG + MASK_AF; //マスク
                glMaskIdCnt++;
            } else {
                strRepBody += RED_BF + glRedIdCnt + "'>" + objHtmlStructure.strTgt + RED_AF; //赤塗り
                glRedIdCnt++;
            } //if

        } else { //その他の場合そのまま出力する
            strRepBody += objHtmlStructure.strTgt;
        } //if
    } //for
    return strRepBody;
} //function


/**
* 引数の文字列をtagとそれ以外に分割する
*/
function splitTagArr(strTgtVal_i, arrTag_i, arrNotTag_i) {
    var strTgtVal = strTgtVal_i;
    var strRegrep = REG_TAG_VAL_SPLIT; //タグとタグを除いた値をグループで取得する
    var objPattern = new RegExp(strRegrep, "g");
    var strCurrentKwd = ""; //現在ヒットしている単語
    var objRegRet;
    while ((objRegRet = objPattern.exec(strTgtVal)) != null) {
        strCurrentKwd = objRegRet[2];
        if (strCurrentKwd == undefined) { //タグ
            strCurrentKwd = objRegRet[1];
            arrTag_i.push(strCurrentKwd);
            arrNotTag_i.push(""); //indexを合わせるために空文字を挿入
        } else { //通常文字
            arrTag_i.push("");//indexを合わせるために空文字を挿入
            arrNotTag_i.push(strCurrentKwd);
        } //if
    }  //while
} //function

/**
* 引数の文字列の最終がタグか判定する
* @return tag:true tag以外 false
*/
function isLastTag(strTgtVal_i) {
    var strTgtVal = strTgtVal_i;
    var strRegrep = REG_TAG_VAL_SPLIT; //タグとタグを除いた値をグループで取得する
    var objPattern = new RegExp(strRegrep, "g");
    var strCurrentKwd = ""; //現在ヒットしている単語
    var objRegRet;
    var blRet = false;
    while ((objRegRet = objPattern.exec(strTgtVal)) != null) {
        strCurrentKwd = objRegRet[2];
        if (strCurrentKwd == undefined) { //タグ
            blRet = true;
        } else { //通常文字
            blRet = false;
        } //if
    }  //while
    return blRet;
} //function


/**
* 選択指定している範囲のマスク、マスク候補を変更する
*/
function tgtMaskChk(objEnt_i) {

    //選択されていなかったらreturn
    if (glObjRedFlame.getSelection().toString() == "") {
        return;
    } //if

    var objSelection = glObjRedFlame.getSelection(); // 選択範囲のオブジェクト取得
    var objTgtRange = objSelection.getRangeAt(0); //rangeを取得
    var objInitDom;
    var objEndDom;
    var strInnerBody = glObjRedFlame.body.innerHTML;
    var strTgtVal = "";
    /**
    * memo Dom横断の場合のobjTgtRange.startOffset,objTgtRange.endOffsetの挙動
    *「objTgtRange.startContainer.wholeText」から何文字OffsetしたかがobjTgtRange.startOffset
    *「objTgtRange.endContainer.wholeText」から何文字OffsetしたかがobjTgtRange.endOffset
    *また、wholeTextはDOMのinnerTextと一致するのでそこから捜索する
    */
    //partDom作成	
    var objInitNode = objSelection.anchorNode; //Selectionのアンカーとは、選択の開始点
    var objInitDom = objInitNode.parentNode;
    var strInitInner = objInitDom.innerHTML.toString();
    var strInitOuter = objInitDom.outerHTML.toString();
    var strInitPart = strInitInner.substr(objTgtRange.startOffset, strInitInner.length);
    strInitPart = strInitOuter.substr(strInitOuter.lastIndexOf(strInitPart), strInitOuter.length); //閉じタグプラス			
    var intInitOutPos = strInnerBody.indexOf(strInitOuter);
    var intInitPartPos = intInitOutPos + strInitOuter.lastIndexOf(strInitPart);


    var objEndNode = objSelection.focusNode; //Selectionのフォーカスとは、選択の終了点
    var objEndDom = objEndNode.parentNode;
    var strEndInner = objEndDom.innerHTML.toString();
    var strEndOuter = objEndDom.outerHTML.toString();

    var strEndPart = strEndInner.substr(0, objTgtRange.endOffset);
    var strEndBfTag = strEndOuter.substr(0, strEndOuter.indexOf('>') + 1);
    strEndPart = strEndBfTag + strEndPart;
    var intEndOutPos = strInnerBody.indexOf(strEndOuter);
    var intEndPartPos = intEndOutPos + strEndOuter.indexOf(strEndPart) + strEndPart.length;

    strTgtVal = strInnerBody.substring(intInitPartPos, intEndPartPos);
    var strBfBody = strInnerBody.substr(0, intInitPartPos);
    var strAfBody = strInnerBody.substring(intEndPartPos, strInnerBody.length);

    //マスク候補処理
    var hashBodyStructure = {};
    hashBodyStructure = getBodyStructure(strTgtVal);
    var strRepVal = bodyCharChange(hashBodyStructure, STATE_RED);

    //bodyを入れ替える
    var strChangeBody = strBfBody + strRepVal + strAfBody;
    glObjRedBody.innerHTML = strChangeBody;

    //マスク処理
    var strMaskInnerBody = glObjMaskFlame.body.innerHTML;
    var strMakkTgtVal=strMaskInnerBody.substring(intInitPartPos, intEndPartPos);
    var hashBodyMaskStructure = getBodyStructure(strMakkTgtVal);
    var strMaskRepVal = bodyCharChange(hashBodyMaskStructure, STATE_MASK);

    //bodyを入れ替える
    var strMaskBfBody = strMaskInnerBody.substr(0, intInitPartPos);
    var strMaskAfBody = strMaskInnerBody.substring(intEndPartPos, strMaskInnerBody.length);
    var strMaskChangeBody = strMaskBfBody + strMaskRepVal + strMaskAfBody;
    glObjMaskBody.innerHTML = strMaskChangeBody;

    contextNone();

} //function


function tgtMaskRelease(strTgtEvent_i) {
    //選択されていなかったらreturn
    if (glObjRedFlame.getSelection().toString() == "") {
        return;
    } //if

    var objSelection = glObjRedFlame.getSelection(); // 選択範囲のオブジェクト取得
    //partDom作成	
    var objInitNode = objSelection.anchorNode; //Selectionのアンカーとは、選択の開始点
    var objInitDom = objInitNode.parentElement;
    var objNextDom = objInitDom;
    var objTgtDom = objInitDom;
    var objStartDom;
    var objExitDom;
    var strActClass = "";
    var blEnd=false;
    //対象タグが連続で含まれているStartを探す
    while (true) {
        // try {
        //     strActClass = objNextDom.getAttribute("class");            
        // } catch (error) {
        //     blEnd=true
        // }//try

        // if ( (strActClass==RED_INIT_CLS) || blEnd ) {
        //     objStartDom=objTgtDom;
        //     break;
        // } //if
        objTgtDom = objNextDom;
        objNextDom = objNextDom.closest('.' + RED_INIT_CLS);
        if (objNextDom!=null) {
            objStartDom=objNextDom;
        } //if
        objNextDom = objTgtDom.parentElement;

    } //while

    //対象タグが連続で含まれているEndを探す
    objNextDom = objInitDom;
    objTgtDom = objInitDom;    
    blEnd=false;
    while (true) {
        try {
            strActClass = objNextDom.getAttribute("class");            
        } catch (error) {
            blEnd=true
        }//try

        if ( (strActClass!=TAG_RED) || blEnd ) {
            objExitDom=objTgtDom;
            break;
        } //if
        objTgtDom = objNextDom;
        objNextDom = objNextDom.nextElementSibling;
    } //while


    var objParentDom =objStartDom.parentElement;
    var strParentInner = objParentDom.innerHTML.toString();
    var strStartOuter = objStartDom.outerHTML.toString();
    var strEndOuter = objExitDom.outerHTML.toString();
    var strTgtHtml = strParentInner.substring(strParentInner.indexOf(strStartOuter),strParentInner.lastIndexOf(strEndOuter) + strEndOuter.length);
    //bodyからの距離を出す
    var intBodyStart = glObjRedFlame.body.innerHTML.indexOf(strTgtHtml);
    var intBodyEndExtend = strTgtHtml.length;   
    //replaceでclassを削除
    var strModHtml = replaceAll(strTgtHtml,'</span><span class="'+TAG_RED+'">','');
    strModHtml = replaceAll(strModHtml,' class="'+TAG_RED+'"','');    
    //body入れ替え
    var strBodyRep = glObjRedBody.innerHTML.replace(strTgtHtml,strModHtml);
    glObjRedBody.innerHTML = strBodyRep;

    var strMaskTgtHtml = glObjMaskBody.innerHTML.substr(intBodyStart,intBodyEndExtend);
    var strMaskBodyRep = glObjMaskBody.innerHTML.replace(strMaskTgtHtml,strModHtml);

    glObjMaskBody.innerHTML=strMaskBodyRep;

    contextNone();
} //function


// function tgtMaskRelease(strTgtEvent_i) {
//     //選択されていなかったらreturn
//     if (glObjRedFlame.getSelection().toString() == "") {
//         return;
//     } //if

//     var objSelection = glObjRedFlame.getSelection(); // 選択範囲のオブジェクト取得
//     //partDom作成	
//     var objInitNode = objSelection.anchorNode; //Selectionのアンカーとは、選択の開始点
//     var objInitDom = objInitNode.parentNode;
//     var objNextDom = objInitDom;
//     var objTgtDom = objInitDom;
//     var objStartDom;
//     var objExitDom;
//     var strActClass = "";
//     var blEnd=false;
//     //対象タグが連続で含まれているStartを探す
//     while (true) {
//         try {
//             strActClass = objNextDom.getAttribute("class");            
//         } catch (error) {
//             blEnd=true
//         }//try

//         if ( (strActClass!=TAG_RED) || blEnd ) {
//             objStartDom=objTgtDom;
//             break;
//         } //if
//         objTgtDom = objNextDom;
//         objNextDom = objNextDom.previousElementSibling;
//     } //while

//     //対象タグが連続で含まれているEndを探す
//     objNextDom = objInitDom;
//     objTgtDom = objInitDom;    
//     blEnd=false;
//     while (true) {
//         try {
//             strActClass = objNextDom.getAttribute("class");            
//         } catch (error) {
//             blEnd=true
//         }//try

//         if ( (strActClass!=TAG_RED) || blEnd ) {
//             objExitDom=objTgtDom;
//             break;
//         } //if
//         objTgtDom = objNextDom;
//         objNextDom = objNextDom.nextElementSibling;
//     } //while


//     var objParentDom =objStartDom.parentElement;
//     var strParentInner = objParentDom.innerHTML.toString();
//     var strStartOuter = objStartDom.outerHTML.toString();
//     var strEndOuter = objExitDom.outerHTML.toString();
//     var strTgtHtml = strParentInner.substring(strParentInner.indexOf(strStartOuter),strParentInner.lastIndexOf(strEndOuter) + strEndOuter.length);
//     //bodyからの距離を出す
//     var intBodyStart = glObjRedFlame.body.innerHTML.indexOf(strTgtHtml);
//     var intBodyEndExtend = strTgtHtml.length;   
//     //replaceでclassを削除
//     var strModHtml = replaceAll(strTgtHtml,'</span><span class="'+TAG_RED+'">','');
//     strModHtml = replaceAll(strModHtml,' class="'+TAG_RED+'"','');    
//     //body入れ替え
//     var strBodyRep = glObjRedBody.innerHTML.replace(strTgtHtml,strModHtml);
//     glObjRedBody.innerHTML = strBodyRep;

//     var strMaskTgtHtml = glObjMaskBody.innerHTML.substr(intBodyStart,intBodyEndExtend);
//     var strMaskBodyRep = glObjMaskBody.innerHTML.replace(strMaskTgtHtml,strModHtml);

//     glObjMaskBody.innerHTML=strMaskBodyRep;

//     contextNone();
// } //function


/**
 * 独自コンテキストメニューを閉じる
*/
function contextNone(e) {
    document.getElementById('contextmenu').style.display = "none";
    document.getElementById('contextmenu_red').style.display = "none";    
} //fanction

function contextOpen(e,intStatus_i) {
    if (intStatus_i==NOMAL_MENU) {
        document.getElementById('contextmenu').style.left = e.pageX - scrollX + document.getElementById('red').offsetLeft + 35 + "px";
        document.getElementById('contextmenu').style.top = e.pageY - scrollY + document.getElementById('red').offsetTop + 43 + "px";
        document.getElementById('contextmenu').style.display = "block";        
    }else if(intStatus_i==MASK_MENU){
        document.getElementById('contextmenu_red').style.left = e.pageX - scrollX + document.getElementById('red').offsetLeft + 35 + "px";
        document.getElementById('contextmenu_red').style.top = e.pageY - scrollY + document.getElementById('red').offsetTop + 43 + "px";
        document.getElementById('contextmenu_red').style.display = "block";                
    } //if

} //fanction

/**
 * コンテキストメニュー操作
*/
function contextFunc(e) {
    glActContext=e; //context保持
    var objSelection = glObjRedFlame.getSelection(); // 選択範囲のオブジェクト取得
    var strClsChk=e.target.getAttribute("class");
    if(strClsChk==null) strClsChk="";
    if (strClsChk.indexOf(TAG_RED)>=0) { //対象クラスがTAG_REDならMASK_MENUを開く
        getRedRange(e);
        contextOpen(e,MASK_MENU);                
    }else if (objSelection != "") { //選択されていたらNOMAL_MENUを開く
        contextOpen(e,NOMAL_MENU);
    } //if

} //function


function getRedRange(e) {
    var objTgt = e.target;
    var strTgtOuter=objTgt.outerHTML.toString();
    //glObjRedBody.outerHTMLを平らにする


    //RED_INIT_CLSのID取得
    var objreg = new RegExp(RED_INIT_CLS + ".+" + objTgt.id);
    arrBfMatch = objreg.exec(glObjRedBody.outerHTML.toString());
    objreg = new RegExp('>.*');
    var strBfId = replaceAll(arrBfMatch[0].substr(arrBfMatch[0].indexOf('id')+ID_OFFSET).replace(objreg,""),'"','');

    //RED_END_CLSのID取得
    objreg = new RegExp(objTgt.id + ".+" + RED_END_CLS);
    arrAfMatch = objreg.exec(glObjRedBody.outerHTML.toString());
    objreg = new RegExp('>.*');
    var strTmpAf= glObjRedBody.outerHTML.toString().substr(glObjRedBody.outerHTML.toString().indexOf(arrAfMatch[0]),glObjRedBody.outerHTML.toString().length).replace(arrAfMatch[0],'')
    var strAfId = strTmpAf.substr(strTmpAf.indexOf("id")+ID_OFFSET,glRedIdCnt.toString().length + "red".length);

    var intBfPos = glObjRedBody.innerHTML.indexOf(glObjRedFlame.getElementById(strBfId).outerHTML);
    var intAfPos = glObjRedBody.innerHTML.indexOf(glObjRedFlame.getElementById(strAfId).outerHTML);
    var intAfTmpPos = glObjRedFlame.getElementById(strAfId).outerHTML.length;
    
    objRange = glObjRedFlame.createRange();
    objRange.setStart(glObjRedFlame.getElementById(strBfId),0);
    objRange.setEnd(glObjRedFlame.getElementById(strAfId),glObjRedFlame.getElementById(strAfId).innerText.length);
    var objTgtSelection = glObjRedFlame.getSelection();
    glObjRedBody.focus();
    objTgtSelection.removeAllRanges();
    objTgtSelection.addRange(objRange);


} //function
