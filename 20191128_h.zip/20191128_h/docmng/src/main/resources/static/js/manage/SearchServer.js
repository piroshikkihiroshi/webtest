//グローバル変数
deleterCount = 0;
objDeleteAllCount = 0;
editCheck = 0;
addBtnCheck = 0;
editCancelCheck = 0;
reflectCheck = 0;
deleteCheck = 0;
addkeyValue = 0;
reflectflag = 0;
addListCount = 0;

var isPost = false;
var changedValues = {};
var addValues = {};
var deleteDBNo = [];


//アラートメッセージ
var displayNameNullMessage = "『表示名』が未入力です。";
var serverNameNullMessage = "『対象サーバ』が未入力です。";
var directoryPathNullMessage = "『フォルダパス』が未入力です。";
var deleteEditListMessage = "選択した行は現在編集中のため削除できません。";
var selectedNotClickDeleteMessage = "行の選択を行った後「削除ボタン」を押下してください。"
var selectedNotClickEditMessage = "行の選択を行った後「編集ボタン」を押下してください。";
var authenticationSettingMessage = "認証に成功しました。";
var authenticationSettingFailureMessage = "認証に失敗しました。";
var addReflectSettingCheckMessage="変更した内容を反映しますか。";
var addReflectSettingMessage = "変更が反映されました";
var addReflectSettingFailureMessage = "設定反映に失敗しました。";
var cancelSelectedMessage = "変更内容を破棄してもよろしいでしょうか。";


$(function () {


  //画面が変更または閉じられる時に動作する
  $(window).on("beforeunload", function (e) {
    // POST送信フラグが「true」の場合、ダイアログを表示しないようにする
    if (isPost) {
      return;
    } else {
      return true;
    }
  });


  //一覧表の表示が完了した時、DBに登録されているデータが0だった場合、ボタンをdisabledに変更する
  $('.scrollBody').ready(function (e) {

    //「編集キャンセルボタン」をdisableに変更する
    editCancelCheck = 0;
    isEditCancel();

    //「反映ボタン」をdisableに変更する
    reflectCheck = 0;
    isReflect();

    //表示項番の設定をする
    DisplayNo();

    if (document.getElementById('main_scroll').childElementCount == 0) {
      //「編集ボタン」をdisableに変更する
      editCheck = 0;
      isEdit();

      //「削除ボタン」をdisableに変更する
      deleteCheck = 0;
      isDelete();
    }

  });

  //表をクリック時に動作し、クリックを行った時に選択した行の色が変更する
  $('.scrollBody').mousedown(function (e) {
    //表の項目以外をクリック時には色を付けないようにする
    if (e.target.id != "main_scroll") {
      if (e.target.className != "tr l") {
        if (e.target.nodeName == "A") {
          if (e.target.parentElement.parentElement.id == 'selected') {
            document.getElementById('selected').removeAttribute("id");
            return true;
          } else {
            if (document.getElementById('selected') == null) {
              e.target.parentElement.parentElement.setAttribute('id', 'selected');
            }
            document.getElementById('selected').removeAttribute("id");
            e.target.parentElement.parentElement.setAttribute('id', 'selected');
            return true;
          }
        }
        //一項目のみclick可能とする
        if (e.target.parentElement.id == 'selected') {
          document.getElementById('selected').removeAttribute("id");
        } else {
          if (document.getElementById('selected') == null) {
            e.target.parentElement.setAttribute('id', 'selected');
          }
          document.getElementById('selected').removeAttribute("id");
          e.target.parentElement.setAttribute('id', 'selected');
        }
      } else {
        return false;
      }
    } else if (e.target.id == "main_scroll") {
      return false;
    }

  });

  //テキストボックスの内容を変更した場合、「認証ボタン」をdisableに変更する
  $('#displayName').change(function (e) {
    reflectCheck = 0;
    isReflect();
  });
  $('#serverName').change(function (e) {
    reflectCheck = 0;
    isReflect();
  });
  $('#directoryPath').change(function (e) {
    reflectCheck = 0;
    isReflect();
  });
  $('#loginUserName').change(function (e) {
    reflectCheck = 0;
    isReflect();
  });
  $('#loginPassword').change(function (e) {
    reflectCheck = 0;
    isReflect();
  });
});

//表示項番を更新する
function DisplayNo() {
  for (let i = 1; i < document.getElementById('main_scroll').childElementCount + 1; i++) {
    document.getElementById('main_scroll').children[i - 1].children[1].innerText = "" + i;
  }
}

//反映ボタンクリック時に動作し、一覧に追加または、一覧内容の変更をする
function check() {
  var objDisplayName = document.getElementById('displayName');
  var objServerName = document.getElementById('serverName');
  var objDirectoryPath = document.getElementById('directoryPath');
  var objLoginUserName = document.getElementById('loginUserName');
  var objLoginPassword = document.getElementById('loginPassword');
  var objAutoRowNo = document.getElementById("main_scroll").childElementCount + 1;
  strAutoRowNo = '' + objAutoRowNo;

  //未入力チェックをする
  if (objDisplayName.value == "") {
    alert(displayNameNullMessage);
    return false;
  } else if (objServerName.value == "") {
    alert(serverNameNullMessage);
    return false;
  } else if (objDirectoryPath.value == "") {
    alert(directoryPathNullMessage);
    return false;
  }

  //編集状態がアクティブ化しているか判断をする
  if (document.getElementsByClassName('EditMode').length == 0) {
    //連想配列の作成する
    addValues[addListCount] = {
      ["displayName"]: objDisplayName.value,
      ["serverName"]: objServerName.value,
      ["directoryPath"]: objDirectoryPath.value,
      ["loginUserName"]: objLoginUserName.value,
      ["loginPassword"]: objLoginPassword.value
    };

    // 登録されているkey, valueを順に取得する
    var ul = $('<ul class="' + addListCount + ' tr l"></ul>');
    var strDisplay = $('<li class="w40"></li>');
    var strServer = $('<li class="w120"></li>');
    var strjServerName = $('<li class="w120"></li>');
    var strUserName = $('<li class="w140"></li>');
    var objFilePass = $('<li class="wAutoA B text_align_left"></li>');
    addListCount++;

    //表に取得した値を挿入する
    $(".scrollBody").append(ul);
    ul.append(strDisplay).append(strServer).append(strjServerName).append(strUserName).append(objFilePass);
    strDisplay.html(objAutoRowNo);
    strServer.html(objDisplayName.value);
    strjServerName.html(objServerName.value);
    strUserName.html(objLoginUserName.value);
    objFilePass.html(objDirectoryPath.value);

    //テキストボックス内の文字列削除する
    objDisplayName.value = "";
    objServerName.value = "";
    objDirectoryPath.value = "";
    objLoginUserName.value = "";
    objLoginPassword.value = "";

    //「反映ボタン」をdisableに変更する
    reflectCheck = 0;
    isReflect();

    //「編集ボタン」をenableに変更する
    editCheck = 1;
    isEdit();

    //「削除ボタン」をenableに変更する
    deleteCheck = 1;
    isDelete();

    fillDomWidth();
    console.log(addValues);

    //編集状態アクティブ化の場合かき処理を実施する
  } else if (document.getElementsByClassName('EditMode').length > 0) {
    //項番の値取得する
    var strChangeRow = $(".EditTable>li[style='display: none;']").text();

    //DB、または新規追加行か判別する
    if (document.getElementsByClassName("EditTable")[0].children[0].getAttribute("data-clm") == "server_id") {
      for (let index = 2; index < 6; index++) {
        if (index == 2) {
          document.getElementsByClassName("EditTable")[0].children[index].valueOf().textContent = objDisplayName.value;
        } else if (index == 3) {
          document.getElementsByClassName("EditTable")[0].children[index].valueOf().textContent = objServerName.value;
        } else if (index == 4) {
          document.getElementsByClassName("EditTable")[0].children[index].valueOf().textContent = objLoginUserName.value;
        } else if (index == 5) {
          document.getElementsByClassName("EditTable")[0].children[index].valueOf().textContent = objDirectoryPath.value;
        }
      }

      // 連想配列作成・追加する
      if (!changedValues[strChangeRow]) {
        changedValues[strChangeRow] = {
          ["serverId"]: strChangeRow,
          ["displayName"]: objDisplayName.value,
          ["serverName"]: objServerName.value,
          ["loginUserName"]: objLoginUserName.value,
          ["loginPassword"]: objLoginPassword.value,
          ["directoryPath"]: objDirectoryPath.value
        };
      } else {
        changedValues[strChangeRow]["serverId"] = strChangeRow;
        changedValues[strChangeRow]['displayName'] = objDisplayName.value;
        changedValues[strChangeRow]['serverName'] = objServerName.value;
        changedValues[strChangeRow]['loginUserName'] = objLoginUserName.value;
        changedValues[strChangeRow]['loginPassword'] = objLoginPassword.value;
        changedValues[strChangeRow]['directoryPath'] = objDirectoryPath.value;
      }

      //テキストボックス内の文字列削除する
      objDisplayName.value = "";
      objServerName.value = "";
      objDirectoryPath.value = "";
      objLoginUserName.value = "";
      objLoginPassword.value = "";

      console.log(changedValues);
    } else {

      //新規作成で表示されているリストの場合、classからリスト番号を取得する
      var strAddChangeRow = document.getElementsByClassName("EditTable")[0].classList[0];

      for (let index = 1; index < 5; index++) {
        if (index == 1) {
          document.getElementsByClassName("EditTable")[0].children[index].valueOf().textContent = objDisplayName.value;
        } else if (index == 2) {
          document.getElementsByClassName("EditTable")[0].children[index].valueOf().textContent = objServerName.value;
        } else if (index == 3) {
          document.getElementsByClassName("EditTable")[0].children[index].valueOf().textContent = objLoginUserName.value;
        } else if (index == 4) {
          document.getElementsByClassName("EditTable")[0].children[index].valueOf().textContent = objDirectoryPath.value;
        }
      }

      //追加項目の変更する
      addValues[strAddChangeRow]['displayName'] = objDisplayName.value;
      addValues[strAddChangeRow]['serverName'] = objServerName.value;
      addValues[strAddChangeRow]['loginUserName'] = objLoginUserName.value;
      addValues[strAddChangeRow]['directoryPath'] = objDirectoryPath.value;
      addValues[strAddChangeRow]['loginPassword'] = objLoginPassword.value;

      //テキストボックス内の文字列削除する
      objDisplayName.value = "";
      objServerName.value = "";
      objDirectoryPath.value = "";
      objLoginUserName.value = "";
      objLoginPassword.value = "";

      //「編集ボタン」をenableに変更する
      editCheck = 1;
      isEdit();

      //「削除ボタン」をenableに変更する
      deleteCheck = 1;
      isDelete();

      console.log(addValues);
    }

    //非アクティブ化状態に移行するため、クラスの削除する
    document.getElementById('main_scroll').classList.remove("EditMode");
    document.getElementsByClassName("EditTable")[0].classList.remove("EditTable");

    //「編集ボタン」を活性化状態にする
    document.getElementById("editBtn").classList.toggle("on");

    //「設定反映ボタン」をenableに変更する
    addBtnCheck = 1;
    isAdd();

    //「編集キャンセルボタン」をdisableに変更する
    editCancelCheck = 0;
    isEditCancel();

    //「反映ボタン」をdisableに変更する
    reflectCheck = 0;
    isReflect();

  }

}// funcrion


//キャンセルボタン押下時に動作しダイアログを表示する
function Cancel() {
  blCan = confirm(cancelSelectedMessage);
  if (blCan) {
    window.close();
  } else {
    return;
  }
}

//編集キャンセルボタン押下時に動作し編集状態を解除し、テキストボックス内を空にする
function editCancel() {
  if (document.getElementsByClassName('EditMode').length > 0) {
    var objDisplayName = document.getElementById('displayName');
    var objServerName = document.getElementById('serverName');
    var objDirectoryPath = document.getElementById('directoryPath');
    var objLoginUserName = document.getElementById('loginUserName');
    var objLoginPassword = document.getElementById('loginPassword');

    //テキストボックス内の文字列削除する
    objDisplayName.value = "";
    objServerName.value = "";
    objDirectoryPath.value = "";
    objLoginUserName.value = "";
    objLoginPassword.value = "";

    //非アクティブ化状態に移行するため、クラスの削除する
    document.getElementById('main_scroll').classList.remove("EditMode");
    document.getElementsByClassName("EditTable")[0].classList.remove("EditTable");

    //「設定反映ボタン」をenableに変更する
    addBtnCheck = 1;
    isAdd();

    //「編集ボタン」を活性化状態に変更する
    document.getElementById("editBtn").classList.toggle("on");

    //「編集キャンセルボタン」をenableに変更する
    editCancelCheck = 0;
    isEditCancel();

    //認証ボタン成功後か確認する
    if (reflectflag == 1) {

      //「反映ボタン」をdisableに変更する
      reflectCheck = 0;
      isReflect();

      //認証状態解除
      reflectflag = 0;
    }

  }
}

//削除ボタン押下時に動作し、選択した行を削除する
function DeleteRow() {
  if (document.getElementById('selected') !== null) {

    if (!document.getElementById("selected").classList.contains("EditTable")) {

      //項番の値取得する
      var strDeleteRow = $("#selected>li[style='display: none;']").text();

      //新規作成で表示されているリストの場合、classからリスト番号を取得する
      var strAddChangeRow = document.getElementById("selected").classList[0];

      //グローバル変数に項番の値を設定する
      deleteDBNo.push(strDeleteRow);

      //連想配列の削除する
      if (changedValues[strDeleteRow]) {
        delete changedValues[strDeleteRow];
        if (addValues[strAddChangeRow]) {
          delete addValues[strAddChangeRow];
        }
      } else if (addValues[strAddChangeRow]) {
        delete addValues[strAddChangeRow];
      }

      //選択した行の削除する
      $("#selected").remove();

      //項番の付け直しをする
      var strAutoRowNo = document.getElementById("main_scroll").childElementCount;
      for (var i = 0; i < strAutoRowNo; i++) {
        //選択した行に非表示要素があるかの判断する
        let hiddenKey = $(".scrollBody ul").eq(i).children("li[style='display: none;']").text();
        if (hiddenKey != "") {
          $('.scrollBody ul').eq(i).children().eq(1).text("" + (i + 1));
        } else {
          $(".scrollBody ul").eq(i).children()[0].valueOf().textContent = ("" + (i + 1));
        }
      }
    } else {
      alert(deleteEditListMessage);
    }
  } else {
    alert(selectedNotClickDeleteMessage);
  }
}


//編集ボタン押下時に動作し、選択した項目内容を変更する
function Edit() {

  //テキストボックスの変数化する
  var objDisplayName = document.getElementById('displayName');
  var objServerName = document.getElementById('serverName');
  var objDirectoryPath = document.getElementById('directoryPath');
  var objLoginUserName = document.getElementById('loginUserName');

  if (document.getElementById('selected') != null || document.getElementsByClassName('EditMode').length != 0) {
    //編集状態アクティブ化か判断する
    if (document.getElementsByClassName('EditMode').length == 0) {
      //編集がアクティブ状態のため、クラス付与する
      $('#main_scroll').eq(0).addClass('EditMode');
      $('#selected').eq(0).addClass('EditTable');

      // 認証時チェック
      if (!objDisplayName.value) {

        //DB、または新規追加行か判別する
        if (document.getElementById("selected").children[0].getAttribute("data-clm") == "server_id") {
          for (let index = 2; index < 6; index++) {
            var strDisplayList = document.getElementById("selected").children[index].outerText;
            if (index == 2) {
              objDisplayName.value = strDisplayList;
            } else if (index == 3) {
              objServerName.value = strDisplayList;
            } else if (index == 4) {
              objLoginUserName.value = strDisplayList;
            } else if (index == 5) {
              objDirectoryPath.value = strDisplayList;
            }
          }

        } else {
          for (let index = 1; index < 5; index++) {
            var strDisplayList = document.getElementById("selected").children[index].outerText;
            if (index == 1) {
              objDisplayName.value = strDisplayList;
            } else if (index == 2) {
              objServerName.value = strDisplayList;
            } else if (index == 3) {
              objLoginUserName.value = strDisplayList;
            } else if (index == 4) {
              objDirectoryPath.value = strDisplayList;
            }
          }
        }
      }

      //「設定反映ボタン」をdisableに変更する
      addBtnCheck = 0;
      isAdd();

      //「編集ボタン」を活性化状態に変更する
      document.getElementById("editBtn").classList.toggle("on");

      //「編集キャンセルボタン」をenableに変更する
      editCancelCheck = 1;
      isEditCancel();

      //認証ボタン成功後か確認する
      if (reflectflag == 1) {

        //「反映ボタン」をdisableに変更する
        reflectCheck = 0;
        isReflect();

        //認証状態解除する
        reflectflag = 0;
      }
      return;

    } else if (document.getElementById('selected') == null || document.getElementsByClassName('EditMode').length != 0) {
      //非アクティブ化状態に移行するため、クラスの削除する
      document.getElementById('main_scroll').classList.remove("EditMode");
      document.getElementsByClassName("EditTable")[0].classList.remove("EditTable");

      //テキストボックス内の文字列削除
      objDisplayName.value = "";
      objServerName.value = "";
      objDirectoryPath.value = "";
      objLoginUserName.value = "";
      editCheck = 0;

      //「設定反映ボタン」をenableに変更する
      addBtnCheck = 1;
      isAdd();

      //「編集キャンセルボタン」をdisableに変更する
      editCancelCheck = 0;
      isEditCancel();

      //「編集ボタン」を活性化状態にする
      document.getElementById("editBtn").classList.toggle("on");

      //認証ボタン成功後か確認する
      if (reflectflag == 1) {

        //「反映ボタン」をdisableに変更する
        reflectCheck = 0;
        isReflect();

        //認証状態解除する
        reflectflag = 0;
      }
      return;
    }

  } else {
    alert(selectedNotClickEditMessage);

    //「設定反映ボタン」をenableに変更しない
    editCheck = 1;

    return false;
  }
}

//設定反映ボタン押下時に動作する
function postItem() {
  //変更を行うか確認を取る内容をアラート表示する
  blCanPost = confirm(addReflectSettingCheckMessage);
  if (blCanPost) {

  // POST用json
  var jsonObj = new Object();
  // 削除項目のIDをデータ受け渡し用タグに格納する
  jsonObj.deleteRow = deleteDBNo;
  // 編集項目の値をデータ受け渡し用タグに格納する
  var postChangeValues = [];
  for (var cv in changedValues) {
    postChangeValues.push(changedValues[cv]);
  }
  jsonObj.changedValues = postChangeValues;
  // 追加項目の値をデータ受け渡し用タグに格納する
  var postAddValues = [];
  // リクエストパラメータに合うように変更する
  for (var av in addValues) {
    console.log(addValues[av]);
    postAddValues.push(addValues[av]);
  }
  jsonObj.addValues = postAddValues;
  console.log(jsonObj);

  //POST処理を実施する
  $.ajax({
    url: "/manege/search_server/save",
    type: "POST",
    contentType: "application/json",
    data: JSON.stringify(jsonObj),
    // ajax通信成功時の処理を実施する
  }).done(function (data) {
    let successOrFailure = "";
    console.log(data);
    // 画面を更新する
    isPost = true;
    alert(addReflectSettingMessage);
    location.reload();
    // 更新フラグをONに変更する
    // ajax通信失敗時の処理を実施実施
  }).fail(function (xhr, textStatus, errorThrown) {
    //alert(xhr.responseText + "\r\n設定反映に失敗しました。");
    alert(addReflectSettingFailureMessage);
    // 成功でも失敗でも通信終了時に必要な処理があれば記載する
  }).always(function () {
  });
  } else {
    return;
  }
}

//設定反映ボタンの「活性」「非活性」を判定する
function isAdd() {
  if (addBtnCheck == 0) {
    $("#addBtn").prop("disabled", true);
    return true;
  }
  $("#addBtn").prop("disabled", false);
  return false;
}

//編集ボタンの「活性」「非活性」を判定する
function isEdit() {
  if (editCheck == 0) {
    $("#editBtn").prop("disabled", true);
    return true;
  }
  $("#editBtn").prop("disabled", false);
  return false;
}

//編集キャンセルボタンの「活性」「非活性」を判定する
function isEditCancel() {
  if (editCancelCheck == 0) {
    $("#editCancelBtn").prop("disabled", true);
    return true;
  }
  $("#editCancelBtn").prop("disabled", false);
  return false;
}

//反映ボタンの「活性」「非活性」を判定する
function isReflect() {
  if (reflectCheck == 0) {
    $("#reflectBtn").prop("disabled", true);
    return true;
  }
  $("#reflectBtn").prop("disabled", false);
  return false;
}

//削除ボタンの「活性」「非活性」を判定する
function isDelete() {
  if (deleteCheck == 0) {
    $("#deleteBtn").prop("disabled", true);
    return true;
  }
  $("#deleteBtn").prop("disabled", false);
  return false;
}

$(function () {
  // Ajax通信テスト ボタンクリックする
  $("#auth_btn").click(function () {
    var objDisplayName = $('#displayName').val();
    var objServerName = $('#serverName').val();
    var objDirectoryPath = $('#directoryPath').val();
    var objLoginUserName = $('#loginUserName').val();
    var objLoginPassword = $('#loginPassword').val();

    //未入力チェックを実施する
    if (objDisplayName == "") {
      alert(displayNameNullMessage);
      return false;
    } else if (objServerName == "") {
      alert(serverNameNullMessage);
      return false;
    } else if (objDirectoryPath == "") {
      alert(directoryPathNullMessage);
      return false;
    }

    // コントローラに渡すjsonオブジェクトを作成する
    var jsonObj = new Object();
    jsonObj.displayName = objDisplayName;
    jsonObj.serverName = objServerName;
    jsonObj.directoryPath = objDirectoryPath;
    jsonObj.loginUserName = objLoginUserName;
    jsonObj.loginPassword = objLoginPassword;

    $.ajax({
      url: "/manege/search_server/auth",
      type: "POST",
      contentType: "application/json",
      data: JSON.stringify(jsonObj),
      dataType: "json"
      // ajax通信成功時の処理を実施する
    }).done(function (data, textStatus, jqXHR) {
      let successOrFailure = "";
      if (data == "success") {
        alert(authenticationSettingMessage);
        //「反映ボタン」を有効にする
        reflectCheck = 1;
        isReflect();
        reflectflag = 1;
      } else if (data == "failure" || data == "1219" || data == "86") {
        if (reflectflag == 1) {
          //「反映ボタン」を無効にする
          reflectCheck = 0;
          isReflect();
          reflectflag = 0;
        }
        alert(authenticationSettingFailureMessage);
      }
      console.log(jqXHR.status);
      // ajax通信失敗時の処理を実施する
    }).fail(function (jqXHR, textStatus, errorThrown) {
      console.log(jqXHR.status);
      // 成功でも失敗でも通信終了時に必要な処理があれば追加記載をする
    }).always(function () {
    });

    console.log(jsonObj);

  });
});
