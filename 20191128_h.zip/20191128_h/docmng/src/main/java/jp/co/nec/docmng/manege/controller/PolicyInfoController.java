/**
 * 名称：PolicyInfoControllerファイル
 * 機能名：黒塗りポリシー設定画面コントローラー
 * 概要：黒塗りポリシー設定画面の制御を実施する
 */
package jp.co.nec.docmng.manege.controller;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.thymeleaf.util.StringUtils;

import jp.co.nec.docmng.manege.entity.PolicyInfoEntity;
import jp.co.nec.docmng.manege.entity.PolicyInfoReflectForm;
import jp.co.nec.docmng.manege.entity.PolicyInfoReflectForm.AddValues;
import jp.co.nec.docmng.manege.entity.PolicyInfoReflectForm.ChangedValues;
import jp.co.nec.docmng.manege.entity.PolicyKeywordInfo;
import jp.co.nec.docmng.manege.entity.TmpTeacherPolicyList;
import jp.co.nec.docmng.manege.service.PolicyInfoService;
import jp.co.nec.docmng.manege.service.PolicyKeywordInfoService;
import jp.co.nec.docmng.manege.service.TmpTeacherPolicyService;

/**
 * 黒塗りポリシー設定画面のリクエストを制御する
 */
@Controller
@RequestMapping("/manege/policy")
public class PolicyInfoController {

    /** ロガー */
    private static Logger objLog = LoggerFactory.getLogger(PolicyInfoController.class);

    /**
     * 該当キーワードの表示上限文字数
     */
    private static final int DISPLAY_LIMIT_NUM = 50;

    /**
     * 該当キーワードの表示上限個数
     */
    private static final int DISPLAY_LIMIT_PIECE = 4;

    /**
     * 非表示対象ポリシー名1
     */
    private static final String DISPLAY_NON_POLICY1 = "その他ポリシー";
    /**
     * 非表示対象ポリシー名2
     */
    private static final String DISPLAY_NON_POLICY2 = "図・表";

    //要らないかも？
    /**
     * 設定反映ステータス：成功
     */
    private static final String SUCCESS = "success";

    /**
     * 設定反映ステータス：失敗
     */
    private static final String FAILURE = "failure";
    /**
     * 設定反映ステータス格納用変数
     */
    private String saveStatus = null;

    /** OTHER_ID */
    private static final Integer OTHER_ID = 0;

    @Autowired
    PolicyInfoService policyInfoService;
    @Autowired
    PolicyKeywordInfoService policyKeywordInfoService;
    @Autowired
    TmpTeacherPolicyService tmpTeacherPolicyService;

    /**
     * <p>黒塗りポリシー設定画面初期表示メソッド</p>
     * 処理内容：黒塗りポリシー初期表示に必要なデータを取得し表示する。<br>
     * @param form 検索対象追加用フォーム
     * @param model モデル
     * @return 検索対象サーバ設定画面のURL
     */
    @GetMapping
    public String getPolicyInfo(Model model) {

        objLog.info("getPolicyInfo request start");
        // 全件取得
        List<PolicyInfoEntity> policyInfoEntities = policyInfoService.findAll();
        List<PolicyKeywordInfo> policyKeywordInfos = policyKeywordInfoService.findAll();

        // 50文字を超える対象黒塗りポリシー該当キーワードの51文字目以降を省略する
        int keywordCnt = 0;
        int tmpPolicyId = -1;
        for (int i = 0; i < policyKeywordInfos.size(); i++) {
            // 該当キーワードを取得する
            String keyword = policyKeywordInfos.get(i).getPolicyKeyword();
            // 該当キーワードが50文字を超える場合
            if (DISPLAY_LIMIT_NUM < keyword.length()) {
                // 51文字目以降を切り取る
                String cutStr = StringUtils.substring(keyword, 0, DISPLAY_LIMIT_NUM);
                // エンティティにセットしなおす
                policyKeywordInfos.get(i).setPolicyKeyword(cutStr + "...");
            }
            // 前要素のポリシーIDと今回のポリシーIDを比較し同じ時カウンターを+1
            if (tmpPolicyId == policyKeywordInfos.get(i).getPolicyId()) {
                keywordCnt++;
                // 前回のポリシーIDと変化があった時初期化
            } else {
                // カウンター初期化
                keywordCnt = 0;
            }
            // ビュー側で表示切替が難しいためコントローラでキーワード5個目以降を非表示とするフラグを設定
            if (DISPLAY_LIMIT_PIECE <= keywordCnt) {
                policyKeywordInfos.get(i).setViewFlag(false);
            }
            // ポリシーID保持
            tmpPolicyId = policyKeywordInfos.get(i).getPolicyId();
        }

        // 図・表およびその他ポリシーを削除（リストの後ろから削除）
        for (int i = policyInfoEntities.size() - 1 ; i >= 0 ; i--) {
            PolicyInfoEntity pe = policyInfoEntities.get(i);
            if (Objects.equals(pe.getPolicyName(), DISPLAY_NON_POLICY1)) {
                policyInfoEntities.remove(i);
            } else
            // 図・表
            if (Objects.equals(pe.getPolicyName(), DISPLAY_NON_POLICY2)) {
                policyInfoEntities.remove(i);
            }
        }

        // レスポンス情報セット
        model.addAttribute("policyInfo", policyInfoEntities);
        model.addAttribute("policyKeywordInfos", policyKeywordInfos);
        objLog.trace("policyInfoEntities:{}", policyInfoEntities);
        objLog.trace("policyInfoEntities:{}", policyInfoEntities);
        objLog.info("getPolicyInfo request end (success)");
        return "manege/policy";
    }

    /**
     * <p>黒塗りポリシー設定画面設定反映処理メソッド</p>
     * 処理内容：<br>
     * <ol>
     *   <li>画面上で削除した項目と紐づくDBの項目を削除する。</li>
     *   <li>画面上で編集した項目と紐づくDBの項目を更新する。</li>
     *   <li>画面上で追加した項目と紐づくDBの項目を追加する。</li>
     * </ol>
     * @param changedValue 画面上で編集した項目
     * @param deleteRows 画面上で削除した項目のポリシーID
     * @param addValue 画面上で追加した項目
     * @return ResponseEntity<String> 更新結果
     */
    @RequestMapping("/policy_reflect")
    @ResponseBody
    public ResponseEntity<String> policyReflect(
            @RequestBody PolicyInfoReflectForm form) throws Exception {

        objLog.info("policyReflect request start");
        // 存在チェック
        if (Objects.isNull(form)) {
            objLog.trace("form:{}", form);
            objLog.info("request data not found");
            objLog.info("TeacherCategoryReflect request end (error)");
            return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
        }
        objLog.info("form : {} ", form);

        List<AddValues> addValues = form.getAddValues();
        List<ChangedValues> changeValues = form.getChangedValues();
        List<Integer> deleteRow = form.getDeleteRow();
        System.out.println("設定反映ボタン");
        try {
            // システム日付を取得する
            Timestamp sysdate = Timestamp.valueOf(LocalDateTime.now());
            // 追加データがある場合
            if (!Objects.isNull(addValues)) {
                for (AddValues value : addValues) {
                    PolicyInfoEntity addPolicyInfo = new PolicyInfoEntity();
                    addPolicyInfo.setPolicyName(value.getPolicyName());
                    addPolicyInfo.setPolicyNumber(value.getPolicyNumber());
                    addPolicyInfo.setPolicyReason(value.getPolicyReason());
                    addPolicyInfo.setCreateTime(sysdate);
                    addPolicyInfo.setUpdateTime(sysdate);
                    // DBに反映
                    policyInfoService.insert(addPolicyInfo);
                }
            }

            // 編集データがある場合
            if (!Objects.isNull(changeValues)) {
                for (ChangedValues value : changeValues) {
                    PolicyInfoEntity changePolicyInfo = new PolicyInfoEntity();
                    // 更新データセット
                    changePolicyInfo.setPolicyId(value.getPolicyId());
                    changePolicyInfo.setPolicyName(value.getPolicyName());
                    changePolicyInfo.setPolicyNumber(value.getPolicyNumber());
                    changePolicyInfo.setPolicyReason(value.getPolicyReason());
                    changePolicyInfo.setUpdateTime(sysdate);
                    System.out.printf("[%s]の更新処理実施\r\n", value.getPolicyId());
                    policyInfoService.update(changePolicyInfo);
                }
            }


            // 削除項目
            if (!Objects.isNull(deleteRow)) {
                for (Integer value : deleteRow) {
                    List<TmpTeacherPolicyList> updateTmpTeacherPolicyList = tmpTeacherPolicyService.findPolicyId(value);
                    for (TmpTeacherPolicyList list : updateTmpTeacherPolicyList) {
                        // 削除するポリシーIDの項目をその他にする
                        list.setPolicyId(OTHER_ID);
                        // DB更新
                        tmpTeacherPolicyService.updateOther(list);
                    }
                    // ポリシー一覧から削除
                    policyInfoService.deleteById(value);
                    // 対応キーワード削除
                    policyKeywordInfoService.deleteKeyWord(value);
                }
            }
            saveStatus = SUCCESS;
        } catch (Exception e) {
            objLog.error("addValues:{}\r\nchangeValues:{}\r\ndeleteRow:{}", addValues, changeValues,deleteRow);
            objLog.error("error message", e);
            objLog.info("policyReflect request end (error)");
            e.printStackTrace();
            return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
        }
        objLog.info("policyReflect request end (success)");
        return new ResponseEntity<String>(HttpStatus.OK);
    }
}
