package jp.co.nec.docmng.manege.entity;

import java.util.List;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonInclude;

//@Data
@JsonInclude
public class SearchServerInfoSaveFrom {
    private List<AddValues> addValues;
    private List<ChangedValues> changedValues;
    private List<Integer> deleteRow;

    public List<AddValues> getAddValues() {
        return addValues;
    }
    public void setAddValues(List<AddValues> addValues) {
        this.addValues = addValues;
    }
    public List<ChangedValues> getChangedValues() {
        return changedValues;
    }
    public void setChangedValues(List<ChangedValues> changedValues) {
        this.changedValues = changedValues;
    }
    public List<Integer> getDeleteRow() {
        return deleteRow;
    }
    public void setDeleteRow(List<Integer> deleteRow) {
        this.deleteRow = deleteRow;
    }

    public static class AddValues {
        @NotBlank(message = "必須項目です。")
        private String displayName;
        @NotBlank(message = "必須項目です。")
        private String serverName;
        @NotBlank(message = "必須項目です。")
        private String loginUserName;
        @NotBlank(message = "必須項目です。")
        private String loginPassword;
        @NotBlank(message = "必須項目です。")
        private String directoryPath;

        public String getDisplayName() {
            return displayName;
        }
        public void setDisplayName(String displayName) {
            this.displayName = displayName;
        }
        public String getServerName() {
            return serverName;
        }
        public void setServerName(String serverName) {
            this.serverName = serverName;
        }
        public String getLoginUserName() {
            return loginUserName;
        }
        public void setLoginUserName(String loginUserName) {
            this.loginUserName = loginUserName;
        }
        public String getLoginPassword() {
            return loginPassword;
        }
        public void setLoginPassword(String loginPassword) {
            this.loginPassword = loginPassword;
        }
        public String getDirectoryPath() {
            return directoryPath;
        }
        public void setDirectoryPath(String directoryPath) {
            this.directoryPath = directoryPath;
        }

    }
    public static class ChangedValues {
        @NotBlank(message = "必須項目です。")
        private Integer serverId;
        @NotBlank(message = "必須項目です。")
        private String displayName;
        @NotBlank(message = "必須項目です。")
        private String serverName;
        @NotBlank(message = "必須項目です。")
        private String loginUserName;
        @NotBlank(message = "必須項目です。")
        private String loginPassword;
        @NotBlank(message = "必須項目です。")
        private String directoryPath;

        public Integer getServerId() {
            return serverId;
        }
        public void setServerId(Integer serverId) {
            this.serverId = serverId;
        }
        public String getDisplayName() {
            return displayName;
        }
        public void setDisplayName(String displayName) {
            this.displayName = displayName;
        }
        public String getServerName() {
            return serverName;
        }
        public void setServerName(String serverName) {
            this.serverName = serverName;
        }
        public String getLoginUserName() {
            return loginUserName;
        }
        public void setLoginUserName(String loginUserName) {
            this.loginUserName = loginUserName;
        }
        public String getLoginPassword() {
            return loginPassword;
        }
        public void setLoginPassword(String loginPassword) {
            this.loginPassword = loginPassword;
        }
        public String getDirectoryPath() {
            return directoryPath;
        }
        public void setDirectoryPath(String directoryPath) {
            this.directoryPath = directoryPath;
        }
    }
}


