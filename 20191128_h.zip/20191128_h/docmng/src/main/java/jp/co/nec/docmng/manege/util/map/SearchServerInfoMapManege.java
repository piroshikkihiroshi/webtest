package jp.co.nec.docmng.manege.util.map;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import jp.co.nec.docmng.manege.entity.SearchServerInfoEntity;

@Mapper
public interface SearchServerInfoMapManege {
    @Select("select * from admin.search_server_info where server_id = #{serverId}")
    SearchServerInfoEntity findOneMapper(String strId_i);

    @Select("select * from admin.search_server_info order by server_id")
    public List<SearchServerInfoEntity> findAll();

    @Select("select server_id from admin.search_server_info order by server_id")
    public List<Integer> selectServerId();

    @Insert("insert into admin.search_server_info (server_name,display_name,login_user_name,login_password,directory_path,create_time,update_time) values (#{serverName},#{displayName},#{loginUserName},#{loginPassword},#{directoryPath},#{createTime},#{updateTime})")
    public void insert(SearchServerInfoEntity searchServerInfo);

    @Update("update admin.search_server_info set server_name = coalesce(#{serverName}, server_name), display_name = coalesce(#{displayName}, display_name), login_user_name = coalesce(#{loginUserName}, login_user_name), login_password = coalesce(#{loginPassword}, login_password), directory_path = coalesce(#{directoryPath}, directory_path), update_time = coalesce(#{updateTime}, update_time) where server_id = #{serverId}")
    public void update(SearchServerInfoEntity searchServerInfo);

    @Delete("delete from admin.search_server_info where server_id = #{serverId}")
    public void deleteById(Integer id);

}
