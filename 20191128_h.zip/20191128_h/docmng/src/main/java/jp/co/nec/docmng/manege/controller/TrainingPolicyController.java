/**
 * 名称：TrainingPolicyControllerファイル
 * 機能名：教師データ登録（黒塗り箇所抽出）コントローラー
 * 概要：教師データ登録（黒塗り箇所抽出）の制御を実施する
 */
package jp.co.nec.docmng.manege.controller;

import java.io.File;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import jp.co.nec.docmng.library.train.MakeTrainingData;
import jp.co.nec.docmng.manege.entity.PolicyInfoEntity;
import jp.co.nec.docmng.manege.entity.TmpTeacherPolicyList;
import jp.co.nec.docmng.manege.entity.TmpTeacherPolicyListReqForm;
import jp.co.nec.docmng.manege.service.PolicyInfoService;
import jp.co.nec.docmng.manege.service.TmpTeacherPolicyService;

/**
 * 教師データ（黒塗り箇所摘出）のリクエストを制御する
 */
@Controller
@RequestMapping("/manege/training_policy")
public class TrainingPolicyController {

    /** ロガー */
    private static Logger objLog = LoggerFactory.getLogger(TrainingPolicyController.class);

    @Autowired
    PolicyInfoService policyInfoService;
    @Autowired
    TmpTeacherPolicyService tmpTeacherPolicyService;

    /** 正解データコンバート用API */
    MakeTrainingData train = new MakeTrainingData();

    /** 黒塗りポリシー一覧が空の場合のエラーメッセージ  */
    static final String POLICYINFO_EMPTYERR = "ポリシー情報が存在しません。";

    /** 非表示対象ポリシー名 */
    private static final String DISPLAY_NON_POLICY1 = "その他ポリシー";

    /**
     * <p>教師データ登録（黒塗り箇所摘出）初期表示処理</p>
     * 処理内容：<br>
     * <ol>
     *   <li>教師データ登録（黒塗り箇所摘出）を表示する</li>
     * </ol>
     * @param model モデル
     * @return 教師データ登録（黒塗り箇所摘出）画面のURL
     */
    @GetMapping
    public String getTrainingPolicy(Model model) {
        objLog.info("getTrainingPolicy request start");
        // 全件取得
        List<PolicyInfoEntity> policyInfos = policyInfoService.findAll();
        // ポリシー：その他を応答データには含めない
        if (!Objects.isNull(policyInfos) && policyInfos.size() != 0) {
            for(int i = 0; i < policyInfos.size() ; i++) {
                if (Objects.equals(policyInfos.get(i).getPolicyId() , 0 )
                        && Objects.equals(policyInfos.get(i).getPolicyName(), DISPLAY_NON_POLICY1)) {
                    // その他ポリシーを取得リストから削除
                    policyInfos.remove(i);
                }
            }
            // ポリシー一覧が取得できなかった場合
        } else {
//            // エラーを返しalertを表示させる
            model.addAttribute("err", POLICYINFO_EMPTYERR);
            objLog.info("policy info not found");
            objLog.trace("policyInfos null");
            objLog.info("getTrainingPolicy request end (error)");
            return "manege/trainingPolicy";
        }
        //
        List<TmpTeacherPolicyList> teacherPolicyLists = tmpTeacherPolicyService.findAll();

        // 表示用に分類名を付与する
        for (int i = 0; i < teacherPolicyLists.size(); i++) {
            for (int j = 0; j < policyInfos.size() ; j++) {
                if (policyInfos.get(j).getPolicyId() == teacherPolicyLists.get(i).getPolicyId()) {
                    teacherPolicyLists.get(i).setPolicyName(policyInfos.get(j).getPolicyName());
                    break;
                }
                teacherPolicyLists.get(i).setPolicyName(DISPLAY_NON_POLICY1);
            }
        }

        model.addAttribute("policyInfo", policyInfos);
        model.addAttribute("teacherPolicyList", teacherPolicyLists);
        objLog.trace("policyInfo:{}", policyInfos);
        objLog.trace("teacherPolicyList:{}", teacherPolicyLists);
        objLog.info("getTrainingPolicy request end (success)");
        return "manege/trainingPolicy";
    }

    /**
     * <p>設定反映処理メソッド</p>
     * 処理内容：<br>
     * <ol>
     *   <li>画面上で削除した項目と紐づくDBの項目を削除する。</li>
     *   <li>画面上で編集した項目と紐づくDBの項目を更新する。</li>
     *   <li>画面上で追加した項目と紐づくDBの項目を追加する。</li>
     * </ol>
     * @return ResponseEntity<String>
     * @throws Exception
     */


    /**
     * <p>教師データ登録（黒塗り箇所摘出）設定反映メソッド</p>
     * 処理内容：教師データ登録（黒塗り箇所摘出）画面で追加・編集・削除した教師データをDBに更新する。<br>
     * @param form 教師データ
     * @return レスポンス
     * @throws Exception 処理中に例外が発生した場合
     */
    @RequestMapping("/teacher_policy_reflect")
    @ResponseBody
    public ResponseEntity<String> teacherCategoryReflect (
            @RequestBody TmpTeacherPolicyListReqForm form) throws Exception {
        // 全件取得
        objLog.info("teacherCategoryReflect request start");

        if (Objects.isNull(form)) {
            objLog.trace("form:{}", form);
            objLog.info("request data not found");
            objLog.info("teacherCategoryReflect request end (error)");
            return new ResponseEntity<String>("request data not found",HttpStatus.BAD_REQUEST);
        }
        objLog.info("form : {} ", form);

        // システム日付を取得する
        Timestamp sysdate = Timestamp.valueOf(LocalDateTime.now());
        // 保存先
        String savePath = form.getSavePath();
        // 登録データ
        List<TmpTeacherPolicyList> teacherPolicyList = form.getTmpTeacherPolicyList();

        // 正解データコンバートAPI呼出し
        try {
            correctDataConvert(teacherPolicyList, savePath);
        } catch (Exception e) {
            objLog.error("teacherPolicyList:{}\r\n  savePath:{}", teacherPolicyList, savePath);
            objLog.error("error message", e);
            e.printStackTrace();
            return new ResponseEntity<String>(e.getMessage(),HttpStatus.BAD_REQUEST);
        }

        try {
            // DB更新処理
            // ALL削除
            tmpTeacherPolicyService.deleteAll();
            // ALL登録
            for (TmpTeacherPolicyList list : teacherPolicyList) {
                list.setCreateTime(sysdate);
                list.setUpdateTime(sysdate);
                tmpTeacherPolicyService.insert(list);
            }
        } catch (Exception e) {
            objLog.error("teacherPolicyList:{}\r\n", teacherPolicyList);
            objLog.error("error message", e);
            e.printStackTrace();
            return new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
        objLog.info("TeacherCategoryReflect request end (success)");
        return new ResponseEntity<String>(HttpStatus.OK);
    }
    /**
     * <p>設定反映処理メソッド</p>
     * 処理内容：正解データコンバートAPIの呼び出しと処理を実施する。
     * @param teacherPolicyList 追加データ
     * @param savePath 保存先フォルダ
     * @throws Exception 指定のフォルダが見つからなかった場合
     */
    private void correctDataConvert(List<TmpTeacherPolicyList> teacherPolicyList, String savePath) throws Exception {
        objLog.trace("teacherPolicyList:{} \r\nsavePath:{}", teacherPolicyList, savePath);
        File saveDrectory = new File(savePath);
        // 正解データコンバート保存先フォルダが存在しない場合
        if (!saveDrectory.exists()) {
            objLog.info("{} correct answer directoryPath path directory not found ", savePath);
            //TODO:エラー処理　ひとまず例外をスローしておく
            throw new Exception(savePath + " correct answer directoryPath path directory not found ");
        }
        //正解データコンバート用APIデータ（フォルダ）
        HashMap<Integer, String> input = new HashMap<Integer, String>();
        //
        for (Integer i = 0; i < teacherPolicyList.size(); i++) {
            String directoryPath = teacherPolicyList.get(i).getDirectoryPath();
            File directory = new File(directoryPath);
            // 教師データファイルが見つからなかった場合
            if (!directory.exists()) {
                objLog.info("{} file not found ", directoryPath);
                //TODO:エラー処理　ひとまず例外をスローしておく
                throw new Exception(directoryPath + " file not found");
            }
            //正解データコンバート用データ保存
            input.put(i+1, directoryPath);
        }
        train.makeBlackPrintTrainData(input, savePath);
    }
}
