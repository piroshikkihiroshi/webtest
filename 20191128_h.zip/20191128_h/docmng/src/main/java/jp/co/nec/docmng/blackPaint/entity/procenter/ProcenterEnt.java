package jp.co.nec.docmng.blackPaint.entity.procenter;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ProcenterEnt {
	private String result;
	private long time;
	private Return procenterEntReturn;
	private ExceptionClass exception;

	@JsonProperty("result")
	public String getResult() {
		return result;
	}

	@JsonProperty("result")
	public void setResult(String value) {
		this.result = value;
	}

	@JsonProperty("time")
	public long getTime() {
		return time;
	}

	@JsonProperty("time")
	public void setTime(long value) {
		this.time = value;
	}

	@JsonProperty("return")
	public Return getProcenterEntReturn() {
		return procenterEntReturn;
	}

	@JsonProperty("return")
	public void setProcenterEntReturn(Return value) {
		this.procenterEntReturn = value;
	}

	@JsonProperty("exception")
	public ExceptionClass getException() {
		return exception;
	}

	@JsonProperty("exception")
	public void setException(ExceptionClass value) {
		this.exception = value;
	}
}
