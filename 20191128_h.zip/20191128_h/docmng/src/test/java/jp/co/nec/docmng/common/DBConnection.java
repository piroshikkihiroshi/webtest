package jp.co.nec.docmng.common;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnection {
    /** DB接続インスタンス */
    Connection connection = null;

    PreparedStatement ps = null;

    /**
     * DB接続
     */
    public void DBConnect () {
        try {
            connection = DriverManager.getConnection(
                    "jdbc:postgresql://localhost:5432/document_manage", // "jdbc:postgresql://<場所>:<ポート>/<データベース名>"
                    "postgres", //user
                    "postgres");
        } catch (SQLException e) {
            e.printStackTrace();
        } //password;
    }

    /**
     * DB切断
     */
    public void DBClose () {
        try {
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    /**
     * 更新系のSQL実行
     * @param sql
     */
    public void SQLExe (String sql) {
        try {
            ps = connection.prepareStatement(sql);
            ps.executeUpdate();
//            connection.commit();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * 検索系のSQL実行
     * @param sql
     * @retunr ResultSet 検索結果
     */
    public ResultSet SelectSQLExe (String sql) {
        ResultSet resultSet = null;
        try {
            Statement st = connection.createStatement();
            resultSet = st.executeQuery(sql);
            ResultSetMetaData rsmd = resultSet.getMetaData();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return resultSet;
    }
}
