package jp.co.nec.manegedDoc.blackPaint.model.Aspose;

import com.aspose.words.Document;
import com.aspose.words.HtmlFixedPageHorizontalAlignment;
import com.aspose.words.HtmlFixedSaveOptions;

/**
 * AsposeライブラリのWordを操作するクラス
 * @author uedatats
 *
 */
public class AsposeWordModel {

	static String PAGE_CLS = "awpage";

	/**
	 * strDilPath_iのパスにstrOrgFileName_iからstrHtmlName_iのhtmlを作成する
	 * @param strDilPath_i
	 * @param strOrgFileName_i
	 * @param strHtmlName_i
	 * @return ページカウント
	 */
	public int wordToHtml(String strDilPath_i, String strOrgFileName_i, String strHtmlName_i) {
		//		 変換対象のファイルの読み込み
		Document objDoc;
		int intPageCnt = 0;
		String strHtmlName ="";


		try {
			// ASPOSEのライセンスの設定
//			com.aspose.words.License license = new com.aspose.words.License();
//			license.setLicense(new java.io.FileInputStream("C:/user/Aspose.Total.Java.lic"));

			// 保存するHTMLファイルの追加オプションの設定(HTMLの枠組みの作成)
			HtmlFixedSaveOptions htmlFixedSaveOptions = new HtmlFixedSaveOptions();
			htmlFixedSaveOptions.setPageHorizontalAlignment(HtmlFixedPageHorizontalAlignment.CENTER);

			objDoc = new Document(strDilPath_i + strOrgFileName_i);
			intPageCnt = objDoc.getPageCount() - 1;

			strHtmlName=strHtmlName_i.replace(".docx", "");

			objDoc.save(strDilPath_i + strHtmlName, htmlFixedSaveOptions);
		} catch (Exception e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		} //try

		return intPageCnt;
	} //wordToHtml


	/**
	 * html文字列からasposeで分割したページ数を返す
	 * @param strHtml_i 対象HTML
	 * @return ページ数
	 */
	public int aspPageGet(String strHtml_i) {
		int intRet =0;
		String[] strArr;
		strArr=strHtml_i.split(PAGE_CLS);
		intRet=strArr.length-1;
		return intRet;
	} //aspPageGet



} //class
