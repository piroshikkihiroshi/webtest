package jp.co.nec.manegedDoc.blackPaint.model.dirFile;

import java.io.File;
import java.io.IOException;

import org.apache.tomcat.util.http.fileupload.FileUtils;

public class DirCnt {

	/**
	 * ディレクトリを作成する。(存在していた場合削除して再作成する)
	 * @param String strDirPath_i 作成ディレクトリパス
	 * @param String strCopyDir_i コピー先ディレクトリパス
	 * @return int 成否ステータス
	 */
    synchronized public int makeDirWithCheck(String strDirPath_i){
		File objTgtDir = new File(strDirPath_i);

		if (objTgtDir.exists()) {
		    System.out.println("フォルダがすでに存在する為、一度削除します");
		    try {
				FileUtils.deleteDirectory(objTgtDir);
				System.out.println("フォルダの削除に成功しました");
			} catch (IOException e) {
				System.err.println("フォルダの削除に失敗しました");
				e.printStackTrace();
				return -1;
			}
		}
		if (objTgtDir.mkdir()) {
		    System.out.println("フォルダの作成に成功しました");
		} else {
		    System.out.println("フォルダの作成に失敗しました");
		    return -1;
		}
		return 0;
	}

	/**
	 * ディレクトリを削除する。
	 * @param String strDirPath_i 削除ディレクトリパス
	 * @return int 成否ステータス
	 */
	synchronized  public int DelDirctory(String strDirPath_i){
		File objTgtDir = new File(strDirPath_i);

		if (objTgtDir.exists()) {
		    System.out.println("フォルダがすでに存在する為、削除します");
		    try {
				FileUtils.deleteDirectory(objTgtDir);
				System.out.println("フォルダの削除に成功しました");
			} catch (IOException e) {
				System.err.println("フォルダの削除に失敗しました");
				e.printStackTrace();
				return -1;
			}
		}
		return 0;
	} //DelDirctory

} //DirCnt
