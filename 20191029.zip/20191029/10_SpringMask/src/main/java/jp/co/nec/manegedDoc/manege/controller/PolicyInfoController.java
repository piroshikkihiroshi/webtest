package jp.co.nec.manegedDoc.manege.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import jp.co.nec.manegedDoc.dao.entity.PolicyInfo;
import jp.co.nec.manegedDoc.manege.model.service.PolicyInfoService;

@Controller
@RequestMapping("/manege/policy")
public class PolicyInfoController {

    @Autowired
    PolicyInfoService policyInfoService;

    /**
     * <p>黒塗りポリシー設定画面GET処理</p>
     * 処理内容：<br>
     * <ol>
     *   <li>黒塗りポリシー設定画面をGETする</li>
     * </ol>
     * @param form 検索対象追加用フォーム
     * @param model モデル
     * @return 検索対象サーバ設定画面のURL
     */
    @GetMapping
    public String getPolicyInfo(Model model) {

        // 全件取得
        List<PolicyInfo> policyInfoEntities = policyInfoService.findAll();

        model.addAttribute("policyInfo", policyInfoEntities);
        return "manege/policy";
    }
}
