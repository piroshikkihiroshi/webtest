package jp.co.nec.manegedDoc.manege.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import jp.co.nec.manegedDoc.dao.entity.PolicyInfo;
import jp.co.nec.manegedDoc.dao.entity.TmpTeacherPolicyList;
import jp.co.nec.manegedDoc.manege.model.service.PolicyInfoService;
import jp.co.nec.manegedDoc.manege.model.service.TmpTeacherPolicyService;


@Controller
@RequestMapping("/manege/training_policy")
public class TrainingPolicyController {

    @Autowired
    PolicyInfoService policyInfoService;
    @Autowired
    TmpTeacherPolicyService tmpTeacherPolicyService;

    @GetMapping
    public String getTrainingPolicy(Model model) {
        // 全件取得
        List<PolicyInfo> policyInfos = policyInfoService.findAll();
        model.addAttribute("policyInfo", policyInfos);

        System.out.println(policyInfos);
//
        List<TmpTeacherPolicyList> teacherPolicyLists = tmpTeacherPolicyService.findAll();
        model.addAttribute("teacherPolicyList", teacherPolicyLists);


        System.out.println(teacherPolicyLists);

//        model.addAttribute("");

        return "manege/training_policy";
    }

}
