package jp.co.nec.manegedDoc.manege.controller;

import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.manegedDoc.dao.entity.SearchServerInfoEntity;
import jp.co.nec.manegedDoc.manege.form.SearchServerInfoForm;
import jp.co.nec.manegedDoc.manege.model.service.SearchServerInfoService;

@Controller
@RequestMapping("/manege/search_server")
public class SearchServerInfoController {

    private boolean isSaved = false;

    @Autowired
    private SearchServerInfoService searchServerInfoService;

    /**
     * <p>検索対象サーバ設定画面GET処理</p>
     * 処理内容：<br>
     * <ol>
     *   <li>検索対象サーバ設定画面をGETする</li>
     * </ol>
     * @param form 検索対象追加用フォーム
     * @param model モデル
     * @return 検索対象サーバ設定画面のURL
     */
    @GetMapping
    public String getSearchServerInfo(@ModelAttribute("searchServerInfoForm") SearchServerInfoForm form, Model model) {

        // 全件取得
        List<SearchServerInfoEntity> searchServerInfoList = searchServerInfoService.findAll();
        model.addAttribute("serchServerInfo", searchServerInfoList);



        //TODO 設定反映失敗時のアラート、エラー番号
        if (isSaved) {
            model.addAttribute("authFlg", "saved");
            isSaved = false;
        }

        return "manege/search_server";

    }

    //TODO 例外時の処理、ログ出力
    /**
     * <p>設定反映処理</p>
     * 処理内容：<br>
     * <ol>
     *   <li>画面上で削除した項目と紐づくDBの項目を削除する</li>
     *   <li>画面上で編集した項目と紐づくDBの項目を更新する</li>
     *   <li>画面上で追加した項目と紐づくDBの項目を追加する</li>
     * </ol>
     * @param editValue 画面上で編集した項目の値
     * @param deleteRows 画面上で削除した項目のサーバID
     * @param addValue
     * @return リロード
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @PostMapping(params = "save")
    public String save(@RequestParam("editValue") String editValue, @RequestParam("deleteRow") List<Integer> deleteRows,
            @RequestParam("addValue") String addValue) throws Exception {

        // システム日付を取得する
        Timestamp sysdate = Timestamp.valueOf(LocalDateTime.now());

        ObjectMapper mapper = new ObjectMapper();

        // 追加項目
        // 画面から受け取った追加項目の文字列をリスト化
        List<String> addValueList = mapper.readValue(addValue, List.class);

        // INSERTするエンティティのリスト
        List<SearchServerInfoEntity> addEntityList = new ArrayList<>();

        for (int i = 0; i < addValueList.size(); i++) {
            addEntityList.add(mapper.readValue(addValueList.get(i), SearchServerInfoEntity.class));
            // システム日付を設定する
            addEntityList.get(i).setCreateTime(sysdate);
        }

        // 画面上で一度追加した項目をすべて取得しているので、追加後に削除した項目をINSERTするリストから取り除く
        for (int i = 0; i < addEntityList.size(); i++) {
            if (addEntityList.get(i).getDeleteFlag()) {
                addEntityList.remove(i);
            }
        }

        // 追加項目がある場合INSERT
        if (!addEntityList.isEmpty()) {
            searchServerInfoService.insertAll(addEntityList);
        }

        // 編集項目
        // Json文字列をツリーとして扱う
        JsonNode root = mapper.readTree(editValue);

        Iterator<String> fieldNames = root.fieldNames();

        while (fieldNames.hasNext()) {

            // キー取得
            String fieldName = fieldNames.next();

            JsonNode jn = root.get(fieldName);

            // 取得したオブジェクトをエンティティにマッピングする
            SearchServerInfoEntity editServerInfo = mapper.readValue(jn.toString(), SearchServerInfoEntity.class);
            // キーを設定
            editServerInfo.setServerId(Integer.valueOf(fieldName));
            // システム日付を設定する
            editServerInfo.setUpdateTime(sysdate);

            searchServerInfoService.update(editServerInfo);
        }

        // 削除項目
        if (!CollectionUtils.isEmpty(deleteRows)) {

            for (int i = 0; i < deleteRows.size(); i++) {
                searchServerInfoService.deleteById(deleteRows.get(i));
            }

            // 表示順序を更新
            List<Integer> serverIdList = searchServerInfoService.selectServerId();
            for (int i = 0; i < serverIdList.size(); i++) {
                searchServerInfoService.updateDisplayOrder(i + 1, serverIdList.get(i));
            }
        }

        isSaved = true;

        return "redirect:search_server";

    }

    //TODO 二重送信対策
    @PostMapping(params = "auth")
    public String postAuth(@RequestParam("displayName") String displayName, @RequestParam("server") String server,
            @RequestParam("directoryPath") String directoryPath, @RequestParam("userName") String userName,
            @RequestParam("password") String password, @RequestParam("isEditMode") Integer editRow,
            @ModelAttribute("searchServerInfoForm") SearchServerInfoForm form, Model model)
            throws InterruptedException {

        try {
            Runtime rt = Runtime.getRuntime();

            // ユーザー認証を外部コマンド実行する
            String cmdNetUse = "net use " + directoryPath + " /user:" + userName + " " + password;
            Process runtimeProcess = rt.exec(cmdNetUse);

            // プロセス値を取得する
            int ret = runtimeProcess.waitFor();

            // 認証成功時
            if (ret == 0) {
                model.addAttribute("authFlg", "success");
                // 認証失敗時
            } else {
                model.addAttribute("authFlg", "failure");
            }

            // 接続を切断する
            rt.exec("net use " + directoryPath + "/delete /no");

        } catch (IOException e) {
            e.printStackTrace();
        }

        // 取得した入力値を再セットする
        form.setDisplayName(displayName);
        form.setServerName(server);
        form.setDirectoryPath(directoryPath);
        form.setLoginUserName(userName);
        form.setLoginPassword(password);
        model.addAttribute("searchServerInfoForm", form);

        // 全件取得
        List<SearchServerInfoEntity> searchServerInfoList = searchServerInfoService.findAll();
        model.addAttribute("serchServerInfo", searchServerInfoList);

        // 編集モード判定
        if (editRow != null) {
            // 編集モードの場合、編集行を画面に渡す
            model.addAttribute("editMode", editRow);
        }

        return "manege/search_server";
    }

}
