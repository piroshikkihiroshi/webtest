package jp.co.nec.manegedDoc.manege.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.manegedDoc.dao.entity.TmpTeacherCategoryList;
import jp.co.nec.manegedDoc.dao.mapper.TmpTeacherCategoryListMapper;



@Service
public class TmpTeacherCategoryService {

    @Autowired
    private TmpTeacherCategoryListMapper tmpTeacherCategoryListMapper;

    @Transactional
    public List<TmpTeacherCategoryList> findAll(){
        List<TmpTeacherCategoryList> entityList = tmpTeacherCategoryListMapper.findAll();
        return entityList;
    }

}
