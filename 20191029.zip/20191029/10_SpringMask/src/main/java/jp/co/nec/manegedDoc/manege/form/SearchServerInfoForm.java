package jp.co.nec.manegedDoc.manege.form;

import javax.validation.constraints.NotBlank;

import lombok.Data;

@Data
public class SearchServerInfoForm {
    @NotBlank(message = "必須項目です。")
    private String displayName;
    @NotBlank(message = "必須項目です。")
    private String serverName;
    @NotBlank(message = "必須項目です。")
    private String directoryPath;
    @NotBlank(message = "必須項目です。")
    private String loginUserName;
    @NotBlank(message = "必須項目です。")
    private String loginPassword;

}
