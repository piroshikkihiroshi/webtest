package jp.co.nec.manegedDoc.manege.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.manegedDoc.dao.entity.SearchServerInfoEntity;
import jp.co.nec.manegedDoc.dao.mapper.SearchServerInfoMapper;;

@Service
public class SearchServerInfoService {

    @Autowired
    private SearchServerInfoMapper searchServerInfoMapper;

    @Transactional
    public SearchServerInfoEntity findOneService(String server_id_i) {
        // １件検索実行
        return searchServerInfoMapper.findOneMapper(server_id_i);
    }

    @Transactional
    public List<SearchServerInfoEntity> findAll(){
        List<SearchServerInfoEntity> entityList = searchServerInfoMapper.findAll();
        return entityList;
    }

    @Transactional
    public List<Integer> selectServerId(){
        List<Integer> serverIdList = searchServerInfoMapper.selectServerId();
        return serverIdList;
    }

    @Transactional
    public void insert(SearchServerInfoEntity searchServerInfo) {
        searchServerInfoMapper.insert(searchServerInfo);
    }

    @Transactional
    public void insertAll(List<SearchServerInfoEntity> searchServerInfoList) {
        searchServerInfoMapper.insertAll(searchServerInfoList);
    }

    @Transactional
    public void update(SearchServerInfoEntity searchServerInfo) {
        searchServerInfoMapper.update(searchServerInfo);
    }

    @Transactional
    public void updateDisplayOrder(Integer displayOrder, Integer serverId) {
        searchServerInfoMapper.updateDisplayOrder(displayOrder, serverId);
    }

    @Transactional
    public void deleteById(Integer id){
        searchServerInfoMapper.deleteById(id);
    }

}
