package jp.co.nec.manegedDoc.manege.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.manegedDoc.dao.entity.CategoryInfo;

@Service
public class CategoryInfoService {

    @Autowired
    private CategoryInfo categoryInfoMapper;

    @Transactional
    public List<CategoryInfo> findAll(){
        List<CategoryInfo> entityList = categoryInfoMapper.findAll();
        return entityList;
    }

}
