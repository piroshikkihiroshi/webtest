package jp.co.nec.manegedDoc.manege.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.manegedDoc.dao.entity.TmpTeacherPolicyList;
import jp.co.nec.manegedDoc.dao.mapper.TmpTeacherPolicyListMapper;



@Service
public class TmpTeacherPolicyService {

    @Autowired
    private TmpTeacherPolicyListMapper tmpTeacherPolicyListMapper;

    @Transactional
    public List<TmpTeacherPolicyList> findAll(){
        List<TmpTeacherPolicyList> entityList = tmpTeacherPolicyListMapper.findAll();
        return entityList;
    }

}
