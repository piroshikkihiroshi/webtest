package jp.co.nec.manegedDoc.manege.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.manegedDoc.dao.entity.PolicyInfo;
import jp.co.nec.manegedDoc.dao.mapper.PolicyInfoMapper;


@Service
public class PolicyInfoService {
	 @Autowired
	 private PolicyInfoMapper objPolicyInfoMapper;
	 @Transactional
	 public List<PolicyInfo> findAll() {
	  // 全件
	  return objPolicyInfoMapper.findAll();
	 } //findAll
} //PolicyInfoServiceApi

