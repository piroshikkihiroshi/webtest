
    //グローバル変数
    Count = 0;
    deleterCount = 0;
    objDeleteAllCount = 0;
    editCheck = 0;
    AddBtnCheck = 0;
    editCancelCheck = 0;
    reflectCheck = 0;

    reflectflag = 0;

    // POST送信フラグ
    var isPost = false;

    $(function () {

      /**
       * 画面が変更または閉じれる時に動作
       * ダイアログを表示する
       * messageboxで表示を行いたいが、検知の限界が存在する為「beforeunload」を使用する
       * 参考サイト：https://teratail.com/questions/51831
      **/
      $(window).on("beforeunload", function (e) {
        // POST送信フラグが「true」の場合、ダイアログを表示しない
        if (isPost) {
          return;
        } else {
          return true;
        }
      });

      /**
       * 表の表示時に動作
       * ローカルストレージに格納されている値が存在した場合、取得、表示を行う
      **/
      $('.scrollBody').ready(function (e) {
        //ボタンの状態設定(disable)

        //編集キャンセルボタンをdisable
        editCancelCheck = 0;
        EditCancelBtnStateCng();

        //反映ボタンをdisable
        reflectCheck = 0;
        ReflectBtnStateCng();

        // localStorageすべての情報の取得
        for (var i = 0; i < localStorage.length; i++) {

          // 登録されているkey, valueを順に取得して表示
          var tr = $("<tr></tr>");
          var td = $("<td></td>");
          var strDisplay = $("<td></td>");
          var strServer = $("<td></td>");
          var strUserName = $("<td></td>");
          var objFilePass = $("<td></td>");

          //"キー"を取得する
          var objGetJson = localStorage.getItem('list' + '' + i);
          objTgtListName = JSON.parse(objGetJson);

          //削除flagが存在した場合、表示を行わない
          if (objTgtListName["delete_flag"] != "true") {
            //表に取得した値を挿入する
            $(".scrollBody").append(tr);
            tr.append(td).append(strDisplay).append(strServer).append(strUserName).append(objFilePass);
            td.html(objTgtListName["display_order"]);
            strDisplay.html(objTgtListName["display_name"]);
            strServer.html(objTgtListName["server_name"]);
            strUserName.html(objTgtListName["login_user_name"]);
            objFilePass.html(objTgtListName["directory_path"]);
            Count++;
          } else {
            Count++;
          }// if
        }// for
      });// function

      /**
       * 表をクリック時に動作
       * クリックを行った時に選択した行の色が変更される
      **/
      $('.scrollBody').mousedown(function (e) {
        //表の項目以外をクリック時には色を付けない
        if (e.target.id != "autoNo") {
          //一項目のみclick可能とする
          if (e.target.parentElement.id == 'selected') {
            document.getElementById('selected').removeAttribute("id");
          } else {
            if (document.getElementById('selected') == null) {
              e.target.parentElement.setAttribute('id', 'selected');
            }// if
            document.getElementById('selected').removeAttribute("id");
            e.target.parentElement.setAttribute('id', 'selected');
          }// if
        } else if (e.target.id == "autoNo") {
          return false;
        }// if

      });// function
    });// function

    /**
     * 反映ボタンクリック時に動作
     * 入力した内容をローカルストレージに格納し、表の最下部に挿入する
    **/

    //グローバル変数
    var changedValues = {};

    function check() {
      var array = [];
      var objDisplayName = document.getElementById('display_name');
      var objServerName = document.getElementById('server_name');
      var objDirectoryPath = document.getElementById('directory_path');
      var objLoginUserName = document.getElementById('login_user_name');
      var objLoginPassword = document.getElementById('login_password');

      var objAutoRowNo = document.getElementById("autoNo").rows.length + 1;
      strAutoRowNo = '' + objAutoRowNo;
      //未入力チェック
      if (objDisplayName.value == "") {
        alert('『表示名』が未入力です。');
        return false;
      } else if (objServerName.value == "") {
        alert('『対象サーバ』が未入力です。');
        return false;
      } else if (objDirectoryPath.value == "") {
        alert('『フォルダパス』が未入力です。');
        return false;
      }// if

      //編集状態がアクティブ化しているか判断を行う
      if (document.getElementsByClassName('EditMode').length == 0) {

        //値の設定
        var obj = {
          'display_order': strAutoRowNo,
          'display_name': objDisplayName.value,
          'server_name': objServerName.value,
          'directory_path': objDirectoryPath.value,
          'login_user_name': objLoginUserName.value,
          'delete_flag': "false"
        };// obj
        array.push(obj);

        //文字列として挿入
        var setjson = JSON.stringify(obj);
        localStorage.setItem('list' + Count, setjson);
        Count++;

        //表に入力された値を挿入
        viewStorage();

        //テキストボックス内の文字列削除
        objDisplayName.value = "";
        objServerName.value = "";
        objDirectoryPath.value = "";
        objLoginUserName.value = "";
        objLoginPassword.value = "";

        //反映ボタンをdisable
        reflectCheck = 0;
        ReflectBtnStateCng();
        reflectflag = 0;

        //編集状態アクティブ化の場合
      } else if (document.getElementsByClassName('EditMode').length > 0) {
        //項番の値取得
        var strChangeRow = $("#selected>td[style='display: none;']").text();

        //DB、または新規追加行か判別を行う
        if (document.getElementsByClassName("EditTable")[0].children[0].getAttribute("data-clm") == "server_id") {
          for (let index = 2; index < 6; index++) {
            if (index == 2) {
              document.getElementsByClassName("EditTable")[0].children[index].valueOf().textContent = objDisplayName.value;
            } else if (index == 3) {
              document.getElementsByClassName("EditTable")[0].children[index].valueOf().textContent = objServerName.value;
            } else if (index == 4) {
              document.getElementsByClassName("EditTable")[0].children[index].valueOf().textContent = objLoginUserName.value;
            } else if (index == 5) {
              document.getElementsByClassName("EditTable")[0].children[index].valueOf().textContent = objDirectoryPath.value;
            }// if
          }// for

          // 連想配列作成・追加
          if (!changedValues[strChangeRow]) {
            changedValues[strChangeRow] = { ["display_name"]: objDisplayName.value, ["server_name"]: objServerName.value, ["login_user_name"]: objLoginUserName.value, ["directory_path"]: objDirectoryPath.value };
          } else {
            changedValues[strChangeRow][display_name] = objDisplayName.value;
            changedValues[strChangeRow][server_name] = objServerName.value;
            changedValues[strChangeRow][login_user_name] = objLoginUserName.value;
            changedValues[strChangeRow][directory_path] = objDirectoryPath.value;
          }// if

          //テキストボックス内の文字列削除
          objDisplayName.value = "";
          objServerName.value = "";
          objDirectoryPath.value = "";
          objLoginUserName.value = "";
          objLoginPassword.value = "";
        } else {

          //現在の指定している行のリスト番号を取得
          ListNameCountPointCheckEdit();

          //"キー"を取得する
          var objGetJson = localStorage.getItem(strListNumber);
          objTgtListName = JSON.parse(objGetJson);

          for (let index = 1; index < 5; index++) {
            if (index == 1) {
              document.getElementsByClassName("EditTable")[0].children[index].valueOf().textContent = objDisplayName.value;
              objTgtListName["display_name"] = objDisplayName.value;
            } else if (index == 2) {
              document.getElementsByClassName("EditTable")[0].children[index].valueOf().textContent = objServerName.value;
              objTgtListName["server_name"] = objServerName.value;
            } else if (index == 3) {
              document.getElementsByClassName("EditTable")[0].children[index].valueOf().textContent = objLoginUserName.value;
              objTgtListName["login_user_name"] = objLoginUserName.value;
            } else if (index == 4) {
              document.getElementsByClassName("EditTable")[0].children[index].valueOf().textContent = objDirectoryPath.value;
              objTgtListName["directory_path"] = objDirectoryPath.value;
            }// if
          }// for

          //文字列として挿入
          var setjson = JSON.stringify(objTgtListName);
          localStorage.setItem(strListNumber, setjson);

          //テキストボックス内の文字列削除
          objDisplayName.value = "";
          objServerName.value = "";
          objDirectoryPath.value = "";
          objLoginUserName.value = "";
          objLoginPassword.value = "";
        }// if

        //非アクティブ化状態に移行するため、クラスの削除
        document.getElementById('autoNo').classList.remove("EditMode");
        document.getElementsByClassName("EditTable")[0].classList.remove("EditTable");

        //ボタンの状態設定(disable)
        //編集ボタンを活性化にする
        editCheck = 0;
        editBtnStateCng();

        //設定反映ボタンを活性化にする
        AddBtnCheck = 0;
        AddBtnStateCng();

        //編集キャンセルボタンをdisable
        editCancelCheck = 0;
        EditCancelBtnStateCng();

        //反映ボタンをdisable
        reflectCheck = 0;
        ReflectBtnStateCng();
        reflectflag = 0;

        return;
      }// if

    }// funcrion

    // localStorageからのデータの取得と表示
    function viewStorage() {

      // 登録されているkey, valueを順に取得する
      var tr = $("<tr></tr>");
      var td = $("<td></td>");
      var strDisplay = $("<td></td>");
      var strServer = $("<td></td>");
      var strUserName = $("<td></td>");
      var objFilePass = $("<td></td>");
      var strLocalStorageLength = localStorage.length - 1;

      //"キー"を取得する
      var objGetJson = localStorage.getItem('list' + '' + strLocalStorageLength);
      objTgtListName = JSON.parse(objGetJson);

      //表に取得した値を挿入する
      $(".scrollBody").append(tr);
      tr.append(td).append(strDisplay).append(strServer).append(strUserName).append(objFilePass);
      td.html(objTgtListName["display_order"]);
      strDisplay.html(objTgtListName["display_name"]);
      strServer.html(objTgtListName["server_name"]);
      strUserName.html(objTgtListName["login_user_name"]);
      objFilePass.html(objTgtListName["directory_path"]);
    }// function

    /**
     * キャンセルボタン押下時に動作
     * ダイアログを表示する
    **/
    function Cancel() {
      blCan = confirm("変更内容を破棄してもよろしいでしょうか。");
      if (blCan) {
        window.close();
        sessionStorage.clear();
      } else {
        return;
      }// if
    }// function

    /**
     * 編集キャンセルボタン押下時に動作
     * 編集状態を解除し、テキストボックス内を空にする
    **/
    function editCancel() {
      if (document.getElementsByClassName('EditMode').length > 0) {
        var objDisplayName = document.getElementById('display_name');
        var objServerName = document.getElementById('server_name');
        var objDirectoryPath = document.getElementById('directory_path');
        var objLoginUserName = document.getElementById('login_user_name');
        var objLoginPassword = document.getElementById('login_password');

        //テキストボックス内の文字列削除
        objDisplayName.value = "";
        objServerName.value = "";
        objDirectoryPath.value = "";
        objLoginUserName.value = "";
        objLoginPassword.value = "";

        //非アクティブ化状態に移行するため、クラスの削除
        document.getElementById('autoNo').classList.remove("EditMode");
        document.getElementsByClassName("EditTable")[0].classList.remove("EditTable");

        //設定反映ボタンを活性化にする
        AddBtnCheck = 0;
        AddBtnStateCng();

        //編集ボタンを活性化にする
        editCheck = 0;
        editBtnStateCng();

        //編集キャンセルボタンを活性化状態にする
        editCancelCheck = 0;
        EditCancelBtnStateCng();

        //認証ボタン成功後か確認を行う
        if (reflectflag == 1) {

          //反映ボタンをdisable
          reflectCheck = 0;
          ReflectBtnStateCng();

          //認証状態解除
          reflectflag = 0;
        }//if

      }// if
    }// function
    /**
     * 削除後の項番にローカルストレージを変更する
    **/
    function reListNameCountDelete() {

      //総削除数を検出
      deleteAllCount();
      // localStorageすべての情報の取得
      for (var i = 0; i < localStorage.length; i++) {

        //最新のカウント状況を取得する
        var objAutoRowNo = document.getElementById("autoNo").rows.length + 1 + objDeleteAllCount - localStorage.length + i;
        objAutoRowNo = objAutoRowNo - deleterCount;
        strAutoRowNo = '' + objAutoRowNo;

        //"キー"を取得する
        var objGetJson = localStorage.getItem('list' + '' + i);
        objTgtListName = JSON.parse(objGetJson);

        //deleteflagが"true"ではない場合
        if (objTgtListName["delete_flag"] == "false") {
          //ローカルストレージに再セット
          objTgtListName["display_order"] = strAutoRowNo;

          //文字列として挿入
          var setjson = JSON.stringify(objTgtListName);
          localStorage.setItem('list' + '' + i, setjson);
        } else {
          deleterCount++;
        }// if
      }// for
    }// function

    /**
     * 削除flag個数を数える
    **/
    function deleteAllCount() {
      // localStorageすべての情報の取得
      for (var i = 0; i < localStorage.length; i++) {

        //"キー"を取得する
        var objGetJson = localStorage.getItem('list' + '' + i);
        objTgtListName = JSON.parse(objGetJson);

        //deleteflagが"true"ではない場合
        if (objTgtListName["delete_flag"] == "true") {
          objDeleteAllCount++;
        }// if
      }// for
    }// function

    /**
     * 現在選択している、表示項番から検索をかける
    **/
    function ListNameCountPointCheck() {
      // localStorageすべての情報の取得
      for (var i = 0; i < localStorage.length; i++) {
        //最新のカウント状況を取得する
        var objAutoRowNo = $('#selected').eq(0).children().first().text();

        //"キー"を取得する
        var objGetJson = localStorage.getItem('list' + '' + i);
        objTgtListName = JSON.parse(objGetJson);

        //ローカルストレージに再セット
        if (objTgtListName["display_order"] == objAutoRowNo) {
          strListNumber = 'list' + '' + i;
          return true;
        }// if
      }// for
    }// function

    /**
     * 現在編集している、表示項番から検索をかける
    **/
    function ListNameCountPointCheckEdit() {
      // localStorageすべての情報の取得
      for (var i = 0; i < localStorage.length; i++) {
        //最新のカウント状況を取得する
        var objAutoRowNo = $('.EditTable').eq(0).children().first().text();

        //"キー"を取得する
        var objGetJson = localStorage.getItem('list' + '' + i);
        objTgtListName = JSON.parse(objGetJson);

        //ローカルストレージに再セット
        if (objTgtListName["delete_flag"] != "true") {
          if (objTgtListName["display_order"] == objAutoRowNo) {
            strListNumber = 'list' + '' + i;
            return true;
          }// if
        }//if
      }// for
    }// function

    /**
     * 削除ボタン押下時に動作
     * 選択した行を削除する
    **/
    //グローバル変数
    //DBデータの削除した項番
    var deleteDBNo = [];

    //行の削除を行う
    function DeleteRow() {

      //項番の値取得
      var strDeleteRow = $("#selected>td[style='display: none;']").text();

      //選択した行に非表示要素があるかの判断
      if (strDeleteRow != "") {
        deleteDBNo.push(strDeleteRow);
      } else {
        ListNameCountPointCheck();

        //"キー"を取得する
        var objGetJson = localStorage.getItem(strListNumber);
        objTgtListName = JSON.parse(objGetJson);

        //削除flagをtrueに変更する
        objTgtListName["delete_flag"] = "true";

        //文字列として挿入
        var setjson = JSON.stringify(objTgtListName);
        localStorage.setItem(strListNumber, setjson);

        //選択した行が最終行の場合、項番の付けなおしを行わない
        if (document.getElementById("autoNo").rows.length == objTgtListName["display_order"]) {
          //選択した行の削除
          $("#selected").remove();
          return true;
        }// if

      }// if
      //選択した行の削除
      $("#selected").remove();

      //ローカルストレージの項番更新
      reListNameCountDelete();

      //項番付け直し
      var strAutoRowNo = document.getElementById("autoNo").rows.length;
      /****************/
      //連想配列の削除を行う
      delete changedValues[strDeleteRow];
      /*****************/
      for (var i = 0; i < strAutoRowNo; i++) {
        //選択した行に非表示要素があるかの判断
        let hiddenKey = $(".scrollBody tr").eq(i).children("td[style='display: none;']").text();
        if (hiddenKey != "") {
          $('.scrollBody tr').eq(i).children().eq(1).text("" + (i + 1));
          // 編集済み項目がある場合
          if (changedValues[hiddenKey]) {
            // 受け渡し用の配列の表示項番を変更
            changedValues[hiddenKey]['display_order'] = i + 1;
          }// if
        } else {
          $('.scrollBody tr').eq(i).children().eq(0).text("" + (i + 1));
        }// if

      }// for

    }// function

    /**
       * 編集ボタン押下時に動作
       * 選択した項目を変更する
      **/
    function Edit() {

      //テキストボックスの変数化
      var objDisplayName = document.getElementById('display_name');
      var objServerName = document.getElementById('server_name');
      var objDirectoryPath = document.getElementById('directory_path');
      var objLoginUserName = document.getElementById('login_user_name');

      if (document.getElementById('selected') != null) {
        //編集状態アクティブ化か判断を行う
        if (document.getElementsByClassName('EditMode').length == 0) {
          //編集がアクティブ状態のため、クラス付与
          $('#autoNo').eq(0).addClass('EditMode');
          $('#selected').eq(0).addClass('EditTable');

          // 認証時チェック
          if (!objDisplayName.value) {

            //DB、または新規追加行か判別を行う
            if (document.getElementById("selected").children[0].getAttribute("data-clm") == "server_id") {
              for (let index = 2; index < 6; index++) {
                var strDisplayList = document.getElementById("selected").children[index].outerText;
                if (index == 2) {
                  objDisplayName.value = strDisplayList;
                } else if (index == 3) {
                  objServerName.value = strDisplayList;
                } else if (index == 4) {
                  objLoginUserName.value = strDisplayList;
                } else if (index == 5) {
                  objDirectoryPath.value = strDisplayList;
                }// if
              }// for

            } else {
              for (let index = 1; index < 5; index++) {
                var strDisplayList = document.getElementById("selected").children[index].outerText;
                if (index == 1) {
                  objDisplayName.value = strDisplayList;
                } else if (index == 2) {
                  objServerName.value = strDisplayList;
                } else if (index == 3) {
                  objLoginUserName.value = strDisplayList;
                } else if (index == 4) {
                  objDirectoryPath.value = strDisplayList;
                }// if
              }// for
            }// if
          }// if

          //設定反映ボタンを非活性化をする
          AddBtnCheck = 0;
          AddBtnStateCng();

          //編集ボタンを活性化状態にする
          editCheck = 0;

          //編集キャンセルボタンを活性化状態にする
          editCancelCheck = 0;
          EditCancelBtnStateCng();

          //認証ボタン成功後か確認を行う
          if (reflectflag == 1) {

            //反映ボタンをdisable
            reflectCheck = 0;
            ReflectBtnStateCng();

            //認証状態解除
            reflectflag = 0;
          }//if
          return;

        } else if (document.getElementsByClassName('EditMode').length != 0) {
          //非アクティブ化状態に移行するため、クラスの削除
          document.getElementById('autoNo').classList.remove("EditMode");
          document.getElementsByClassName("EditTable")[0].classList.remove("EditTable");

          //テキストボックス内の文字列削除
          objDisplayName.value = "";
          objServerName.value = "";
          objDirectoryPath.value = "";
          objLoginUserName.value = "";
          editCheck = 0;

          //設定反映ボタンを非活性化をする
          AddBtnCheck = 0;
          AddBtnStateCng();

          //編集キャンセルボタンを活性化状態にする
          editCancelCheck = 0;
          EditCancelBtnStateCng();

          //認証ボタン成功後か確認を行う
          if (reflectflag == 1) {

            //反映ボタンをdisable
            reflectCheck = 0;
            ReflectBtnStateCng();

            //認証状態解除
            reflectflag = 0;
          }//if
          return;
        }// if

        //設定反映ボタンを非活性化をする
        AddBtnCheck = 0;
        AddBtnStateCng();

        //編集キャンセルボタンを活性化状態にする
        editCancelCheck = 0;
        EditCancelBtnStateCng();

        //認証ボタン成功後か確認を行う
        if (reflectflag == 1) {

          //反映ボタンをdisable
          reflectCheck = 0;
          ReflectBtnStateCng();

          //認証状態解除
          reflectflag = 0;
        }//if
      } else {
        alert("行の選択を行った後「編集ボタン」を押下してください");

        //設定反映ボタンを活性化にしない
        editCheck = 1;

        return false;
      }//if
    }//function

    /**
    * 特定文字列カウント用function
    */
    var counter = function (str, seq) {
      return str.split(seq).length - 1;
    }// function

    /**
    * 設定反映ボタン押下時に動作
    */
    function postItem() {

      // 削除項目のIDをデータ受け渡し用タグに格納する
      $("input[name='deleteRow']").attr('value', deleteDBNo.toString());

      // 編集項目の値をデータ受け渡し用タグに格納する
      $("input[name='editValue']").attr('value', JSON.stringify(changedValues));

      // ※ローカルストレージは利用せずに、直接配列を受け取る予定
      // ローカルストレージの値(追加項目)を取得し、配列に格納する
      var localStorageArray = [];
      for (var i = 0; i < localStorage.length; i++) {
        localStorageArray.push(localStorage.getItem('list' + i));
      }// for
      // 追加項目の値をデータ受け渡し用タグに格納する
      $("input[name='addValue']").attr('value', JSON.stringify(localStorageArray));

      // ローカルストレージの初期化
      localStorage.clear();

      // POST送信フラグを「true」に設定
      isPost = true;

    }// function

    var EDIT_ABLE = "btn-success";

    /**
    * 編集ボタン制御 classがEDIT_ABLEのときだけ編集可能
    */
    function editBtnStateCng() {
      if (editCheck == 0) {
        $('#editBtn').toggleClass(EDIT_ABLE);
      }//if
    } //function

    /**
    * 編集ボタンの「活性」「非活性」を判定する
    */
    function isEdit() {
      if (editCheck == 0) {
        if ($('#editBtn').attr('class').indexOf(EDIT_ABLE) >= 0) {
          return true;
        }// if
        return false;
      }// if
    }// function

    var INFO_ABLE = "btn-info";

    /**
    * 設定反映ボタン制御 classがINFO_ABLEのときだけ編集可能
    */
    function AddBtnStateCng() {
      if (AddBtnCheck == 0) {
        isAdd();
        $('#addBtn').toggleClass(INFO_ABLE);
      }//if
    } //function

    /**
    * 設定反映ボタンの「活性」「非活性」を判定する
    */
    function isAdd() {
      if (AddBtnCheck == 0) {
        if ($('#addBtn').attr('class').indexOf(INFO_ABLE) >= 0) {
          $("#addBtn").prop("disabled", true);
          return true;
        }// if
        $("#addBtn").prop("disabled", false);
        return false;
      }// if
    }// function

    var PRIMARY_ABLE = "btn-primary";

    /**
    * 編集キャンセルボタン制御 classがPRIMARY_ABLEのときだけ編集可能
    */
    function EditCancelBtnStateCng() {
      if (editCancelCheck == 0) {
        isEditCancel();
        $('#editCancelBtn').toggleClass(PRIMARY_ABLE);
      }//if
    } //function

    /**
    * 編集キャンセルボタンの「活性」「非活性」を判定する
    */
    function isEditCancel() {
      if (editCancelCheck == 0) {
        if ($('#editCancelBtn').attr('class').indexOf(PRIMARY_ABLE) >= 0) {
          $("#editCancelBtn").prop("disabled", true);
          return true;
        }// if
        $("#editCancelBtn").prop("disabled", false);
        return false;
      }// if
    }// function

    /**
    * 反映ボタン制御 classがPRIMARY_ABLEのときだけ編集可能
    */
    function ReflectBtnStateCng() {
      if (reflectCheck == 0) {
        isReflect();
        $('#reflectBtn').toggleClass(PRIMARY_ABLE);
      }//if
    } //function

    /**
    * 反映ボタンの「活性」「非活性」を判定する
    */
    function isReflect() {
      if (reflectCheck == 0) {
        if ($('#reflectBtn').attr('class').indexOf(PRIMARY_ABLE) >= 0) {
          $("#reflectBtn").prop("disabled", true);
          return true;
        }// if
        $("#reflectBtn").prop("disabled", false);
        return false;
      }// if
    }// function

    // 認証結果表示
    function authCheck() {

      // 認証時に編集していた行を取得する
      var judgeEditMode = $('#authentedEditMode').attr('value');
      // 取得できた場合、該当行を選択し、編集モードに切り替える
      if (judgeEditMode) {
        $(".scrollBody").children().eq(judgeEditMode - 1).attr('id', 'selected');
        Edit();
      }// if

      // サーバ側で取得した認証結果を取得する
      var judgeAuth = $('#authentication').attr('value');
      if (judgeAuth == "success") {
        alert('認証に成功しました。');
        // 反映ボタンを有効にする
        reflectCheck = 0;
        ReflectBtnStateCng();
        reflectflag = 1;
      } else if (judgeAuth == "failure") {
        alert('認証に失敗しました。');
      }// if
      // 設定反映の結果を同じ変数で受け取るか検討
      else if (judgeAuth == "saved") {
        alert('登録完了しました。');
      }// if
    }// function

    // 認証ボタンの入力チェック
    function authInputCheck() {
      // POST送信フラグを「true」に設定
      isPost = true;

      var objDisplayName = document.getElementById('display_name');
      var objServerName = document.getElementById('server_name');
      var objDirectoryPath = document.getElementById('directory_path');
      var objLoginUserName = document.getElementById('login_user_name');
      var objLoginPassword = document.getElementById('login_password');

      //未入力チェック
      if (objDirectoryPath.value == "") {
        alert('『フォルダパス』が未入力です。');
        return false;
      } else if (objLoginUserName.value == "") {
        alert('『ユーザー名』が未入力です。');
        return false;
      } else if (objLoginPassword.value == "") {
        alert('『パスワード』が未入力です。');
        return false;
      }// if

      // 編集モードの場合
      if (document.getElementsByClassName('EditTable').length != 0) {
        // 編集行をコントローラーに渡す
        let disOrder = $('.EditTable').children('*[data-clm="display_order"]').text();
        $("input[name='isEditMode']").attr('value', disOrder);
      }// if
    }// function