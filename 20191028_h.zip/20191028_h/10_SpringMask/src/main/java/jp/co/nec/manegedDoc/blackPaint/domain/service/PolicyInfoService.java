package jp.co.nec.manegedDoc.blackPaint.domain.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.manegedDoc.dao.entity.admin.PolicyInfo;
import jp.co.nec.manegedDoc.dao.mapper.admin.PolicyInfoMapper;

//import jp.co.nec.manegedDoc.blackPaint.domain.entity.PolicyInfoEntity;
//import jp.co.nec.manegedDoc.blackPaint.domain.mapper.PolicyInfoMapper;




@Service
public class PolicyInfoService {
	 @Autowired
	 private PolicyInfoMapper objPolicyInfoMapper;
	 @Transactional
	 public List<PolicyInfo> findAll() {
	  // 全件
	  return objPolicyInfoMapper.findAll();
	 } //findAll
} //PolicyInfoService
