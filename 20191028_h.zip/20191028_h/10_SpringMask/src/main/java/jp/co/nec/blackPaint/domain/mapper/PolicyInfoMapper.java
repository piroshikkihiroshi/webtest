package jp.co.nec.blackPaint.domain.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import jp.co.nec.blackPaint.domain.entity.PolicyInfoEntity;



@Mapper
public interface PolicyInfoMapper {

//    @Select("select * from admin.policy_info order by policy_number")
    List<PolicyInfoEntity> findAll();

} //PolicyInfoMapper
