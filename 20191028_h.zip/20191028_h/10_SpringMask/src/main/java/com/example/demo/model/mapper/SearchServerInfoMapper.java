package com.example.demo.model.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.example.demo.model.entity.SearchServerInfoEntity;

@Mapper
public interface SearchServerInfoMapper {
    @Select("select * from search_server_info where server_id = #{server_id}")
    SearchServerInfoEntity findOneMapper(String strId_i);

    @Select("select * from search_server_info order by server_id")
    public List<SearchServerInfoEntity> findAll();

    @Select("select server_id from search_server_info order by server_id")
    public List<Integer> selectServerId();

    public void insertAll(@Param("searchServerInfoList") List<SearchServerInfoEntity> searchServerInfoList);

    public void insert(SearchServerInfoEntity searchServerInfo);

    public void update(SearchServerInfoEntity searchServerInfo);

    public void updateDisplayOrder(@Param("display_order") Integer displayOrder, @Param("server_id") Integer serverId);

    public void deleteById(Integer id);

}
