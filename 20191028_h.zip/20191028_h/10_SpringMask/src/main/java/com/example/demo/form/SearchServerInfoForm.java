package com.example.demo.form;

import javax.validation.constraints.NotBlank;

import lombok.Data;

@Data
public class SearchServerInfoForm {
    @NotBlank(message = "必須項目です。")
    private String display_name;
    @NotBlank(message = "必須項目です。")
    private String server_name;
    @NotBlank(message = "必須項目です。")
    private String directory_path;
    @NotBlank(message = "必須項目です。")
    private String login_user_name;
    @NotBlank(message = "必須項目です。")
    private String login_password;

}
