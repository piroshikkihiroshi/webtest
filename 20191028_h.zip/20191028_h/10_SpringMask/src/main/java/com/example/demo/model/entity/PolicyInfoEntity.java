package com.example.demo.model.entity;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class PolicyInfoEntity {

    private Integer policy_id;
    private Integer policy_number;
    private String policy_name;
    private String policy_author;
    private String policy_reason;
    private String policy_keyword;
    private String policy_remarks;
    private Timestamp create_time;
    private Timestamp update_time;

}
