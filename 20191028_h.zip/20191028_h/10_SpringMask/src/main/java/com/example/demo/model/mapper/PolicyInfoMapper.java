package com.example.demo.model.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.example.demo.model.entity.PolicyInfoEntity;

@Mapper
public interface PolicyInfoMapper {

    @Select("select * from policy_info order by policy_id")
    public List<PolicyInfoEntity> findAll();

}
