package com.example.demo.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.entity.PolicyInfoEntity;
import com.example.demo.model.mapper.PolicyInfoMapper;

@Service
public class PolicyInfoService {

    @Autowired
    private PolicyInfoMapper policyMapper;

    @Transactional
    public List<PolicyInfoEntity> findAll(){
        List<PolicyInfoEntity> entityList = policyMapper.findAll();
        return entityList;
    }

}
