package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.model.entity.PolicyInfoEntity;
import com.example.demo.model.service.PolicyInfoService;

@Controller
@RequestMapping("/settings/policy")
public class PolicyInfoController {

    @Autowired
    PolicyInfoService policyInfoService;

    /**
     * <p>黒塗りポリシー設定画面GET処理</p>
     * 処理内容：<br>
     * <ol>
     *   <li>黒塗りポリシー設定画面をGETする</li>
     * </ol>
     * @param form 検索対象追加用フォーム
     * @param model モデル
     * @return 検索対象サーバ設定画面のURL
     */
    @GetMapping
    public String getPolicyInfo(Model model) {

        // 全件取得
        List<PolicyInfoEntity> policyInfoEntities = policyInfoService.findAll();

        model.addAttribute("policyInfo", policyInfoEntities);
        return "settings/policy";
    }
}
