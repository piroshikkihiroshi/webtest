package com.example.demo.model.entity;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class SearchServerInfoEntity {
    private Integer server_id;
    private String server_name;
    private String display_name;
    private String ip_address;
    private String login_user_name;
    private String login_password;
    private String directory_path;
    private Integer display_order;
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss.SSS", timezone = "Asia/Tokyo")
    private Timestamp create_time;
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss.SSS", timezone = "Asia/Tokyo")
    private Timestamp update_time;
    // ローカルストレージ用フィールド
    private Boolean delete_flag;
}
