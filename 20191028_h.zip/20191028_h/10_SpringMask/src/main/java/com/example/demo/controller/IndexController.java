package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/index")
public class IndexController {

    @GetMapping
    public String getIndex() {
        return "index";
    }

    @PostMapping(params="training_data")
    public String goToTrainingData() {
        return "settings/training_data";
    }

    @PostMapping(params="category_shaft")
    public String goToCategoryShaft() {
        return "settings/category_shaft";
    }

    @PostMapping(params="search_server")
    public String goToSearch_server() {
        return "redirect:settings/search_server";
    }

    @PostMapping(params="policy")
    public String goToPolicy() {
        return "redirect:settings/policy";
    }

}
