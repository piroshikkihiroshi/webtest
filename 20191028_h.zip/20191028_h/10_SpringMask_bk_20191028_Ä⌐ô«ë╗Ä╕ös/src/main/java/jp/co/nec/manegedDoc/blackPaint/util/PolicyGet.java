package jp.co.nec.manegedDoc.blackPaint.util;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.web.bind.annotation.RestController;



@RestController
@MapperScan(basePackages = { "jp.co.nec.manegedDoc.mapper.admin.*"})
public class PolicyGet {

//	@Autowired
//	PolicyInfoService aaabjPolicyInfoService;
//
//	/**
//	 * ポリシーテーブル一覧をjsonで取得する
//	 * @return String ポリシーテーブル全件
//	 */
//	@GetMapping("/rest/policy/all")
//	public String getPolicyAll(){
//		String strRet = "";
//		List<String> listPolicy = aaabjPolicyInfoService.findAll();
//        ObjectMapper objMapper = new ObjectMapper();
//        try {
//        	strRet = objMapper.writeValueAsString(listPolicy);
//		} catch (JsonProcessingException e) {
//			// TODO 自動生成された catch ブロック
//			e.printStackTrace();
//		}
//		return strRet;
//	} //getPlicyAll

} //PolicyGet
