package jp.co.nec.manegedDoc.blackPaint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.manegedDoc.mapper.admin.PolicyInfoMapper;

@Service
public class PolicyInfoService {
	 @Autowired
	 private PolicyInfoMapper objPolicyInfoMapper;
	 @Transactional
	 public List<String> findAll() {
	  // 全件
	 return objPolicyInfoMapper.findAll();
	 } //findAll
} //PolicyInfoService
