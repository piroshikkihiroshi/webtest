/**
 * @fileOverview ログオン・ログオフ処理
 * @desc 機能名　　：ログオン機能
 */

var EditUserName = {};

/** 
 * ユーザー名表示関数
 * ログオン後画面ヘッダーにユーザー名を表示する。
 * @param {string} userName(in)
 */
EditUserName.displayWindowUserName = function (userName){
	
	var dispText = "ユーザー名：<span>" + userName + "</span>";
	document.getElementById("USER_NAME").innerHTML =  dispText;
};

/** 
 * ユーザー名消去関数
 * ログオフ後画面ヘッダーのユーザー名をクリアする。
 */
EditUserName.deleteWindowUserName = function(){
	var dispText = "ユーザー名：<span></span>";
	document.getElementById("USER_NAME").innerHTML =  dispText;
};