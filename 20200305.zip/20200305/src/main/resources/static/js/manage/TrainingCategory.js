/** 
 * @fileOverview 教師データ分類設定画面
 * @author NEC
 * @version 1.0.0
 */
//グローバル変数
var addListCount = 0;

var isPost = false;
var isCancel = false;
var isClear = false;
var addValues = [];
var changedValues = [];
var deleteDBNo = [];
var beforeCategoryName = "";

/**
 * ボタン無効状態の定数
 * @memberOf SearchServer
 * @constant {Number} DISABLE_TRUE
*/
DISABLE_TRUE = 0;
/**
 * ボタン有効状態の定数
 * @memberOf SearchServer
 * @constant {Number} DISABLE_FALSE
*/
DISABLE_FALSE = 1;

/**
 * 追加ボタンの有効(1)／無効(0)状態を保持する変数
 * @memberOf SearchServer
 * @type {Number}
 */
var addBtnCheck = DISABLE_FALSE;
/**
 * 編集ボタンの有効(1)／無効(0)状態を保持する変数
 * @memberOf SearchServer
 * @type {Number}
 */
var editBtnCheck = DISABLE_FALSE;
/**
 * 削除ボタンの有効(1)／無効(0)状態を保持する変数
 * @memberOf SearchServer
 * @type {Number}
 */
var delBtnCheck = DISABLE_FALSE;

/**
 * 設定反映ボタンの有効(1)／無効(0)状態を保持する変数
 * @memberOf SearchServer
 * @type {Number}
 */
var refBtnCheck = DISABLE_TRUE;
/**
 * 登録ボタンの有効(1)／無効(0)状態を保持する変数
 * @memberOf SearchServer
 * @type {Number}
 */
var regBtnCheck = DISABLE_TRUE;

/**
 * クリアボタンの有効(1)／無効(0)状態を保持する変数
 * @memberOf SearchServer
 * @type {Number}
 */
var cleBtnCheck = DISABLE_FALSE;

/**
 * 登録ボタンの変化前の状態を保持する変数
 * @memberOf SearchServer
 * @type {Number}
 */
var tmpRegBtn = 0;

/**
 * 編集前の登録データ一覧を保持する変数
 * @memberOf SearchServer
 * @type {Object}
 */
var beforeRegDataList = [];


/**
 * 編集前の登録データ一覧を保持する変数
 * @memberOf SearchServer
 * @type {Object}
 */
// 現在のURL
var hostUrl = location.protocol + '//' + location.host + location.pathname;

//アラートメッセージ
var alreadyDirectoryPassMessage = "入力したディレクトリパスは既に設定済みです。";
var selectedNotClickEditMessage = "行の選択を行った後「編集ボタン」を押下してください。";
var selectedNotClickDeleteMessage = "行の選択を行った後「削除ボタン」を押下してください。";
var selectedNotClickAddOrEditMessage = "選択した行は現在編集中または、追加中のため削除できません。";
var alreadyListEditMessage = "既に一覧に登録されているため、編集が確定できません。";
var alreadyListAddMessage = "既に一覧に登録されているため、追加できません。";
var editNowNotAddMessage = "現在編集中のため追加は行えません。";
var addNowNotAddMessage = "現在新規作成中のため編集は行えません。";
var categoryReflectSettingMessage = "分類一覧の更新処理に成功しました。";
var categoryReflectSettingFailureMessage = "分類一覧の更新処理に失敗しました。";
var addReflectSettingNotSavePassMessage = "保存先が入力されていません。";
var categoryNameNullMessage = "分類軸名を入力後再度ボタンを押下してください。";
var filePassNullMessage = "ディレクトリパスが未入力です。";
var addReflectSettingCheckMessage = "変更した内容を反映しますか。\n（この処理には数分かかる場合があります。）";
var addReflectSettingMessage = "登録データ一覧の更新に成功しました。";
var addReflectSettingFailureMessage = "登録データ一覧の更新処理に失敗しました。";
var clearSelectedMessage = "分類一覧設定と登録データ一覧の変更内容を破棄してもよろしいでしょうか。";
var cancelSelectedMessage = "変更内容を破棄してもよろしいでしょうか。";
var notUserRoleOrLoginOutMessage = "ログインを行っていない、または管理者ではありません。";
var notSelectCategoryMessage = "分類を選択してください。";
var notChangeCategoryMessage = "分類一覧は編集されていません。";
var addReflectCategoryCheckMessage = "登録データ一覧に編集中の内容は無効となります。\n分類一覧の変更内容を反映しますか。";

/** 
 * 動作関数
 * 読み込み時、ボタン制御等を行う。
 * @memberOf  Category
*/
$(function () {

    // 画面ロード時にボタンの表示状態更新
    btnAllCheck();

    /**
     * 動作関数
     * 画面が変更または閉じれる時に動作
     * ダイアログを表示する
     * messageboxで表示を行いたいが、検知の限界が存在する為「beforeunload」を使用する
     * 参考サイト：https://teratail.com/questions/51831
     * @memberOf  SearchServer
    **/
    $(window).on("beforeunload", function (e) {
        // NAS様opener対応(afterManageClose())
    	afterManageClose();
        // POST送信フラグが「true」の場合、ダイアログを表示しない
        if (isPost || isCancel || isClear) {
            return;
        } else {
            return true;
        }
    });

    
    /** 
     * 動作関数
     * @memberOf  Category
    */
    //Cookieを確認し、管理者権限またはログインしているかチェックを行う
    $(window).ready(function (e) {
        // ドメイン情報取得
        DomainCookie.initDomainCookie('[[${DomainInfo}]]');

        var userRole = DomainCookie.getUserRole();

        // ログインしてない場合
        if (userRole === null) {
            alert(notUserRoleOrLoginOutMessage);
            window.close();
        }

        //管理者権限か確認を行う
        if (userRole === "Administrators") {
            showUserName();
            showUserId();
            userRoleFlag = true;
        }

        //管理者権限、またはログインしていなかった場合画面を閉じる
        if (userRoleFlag !== true) {
            alert(notUserRoleOrLoginOutMessage);
            window.close();
        }

        //NAS様opener対応(beforeManageOpen())
        beforeManageOpen(2);
    })

    /**
     * 動作関数
     * ×ボタン押下後に動作
     * 選択した行を削除する
     * @memberOf  Category
     **/
    $('.DeleteRowTrainingPolicy').on('click', function (e) {
        //選択した行にIDを付与
        e.target.parentElement.setAttribute('id', 'delSelected');
        //選択した行の削除
        $("#delSelected").remove();
        // 初期表示状態の登録データ一覧と変化があるか確認する
        checkRegDataListCange();
    });

    /**
     * 動作関数
     * ×ボタン押下後に動作
     * 動的に生成された選択した行を削除する
     * @memberOf  Category
     **/
    $(document).on('click', '.NewDeleteRowTrainingPolicy', function (e) {
        //選択した行にIDを付与
        e.target.parentElement.setAttribute('id', 'delSelected');
        //選択した行の削除
        $("#delSelected").remove();
        // 初期表示状態の登録データ一覧と変化があるか確認する
        checkRegDataListCange();
    });

    /**
     * 動作関数
     * 表をクリック時に動作
     * クリックを行った時に選択した行の色が変更される
     * @memberOf Category
    **/
    $('#main_scroll_L').mousedown(function (e) {
        //表の項目以外をクリック時には色を付けない
        console.log(e);
        if (e.target.id != "main_scroll_L") {
            // 新規行や修正中の行のbolder部はクリック無視
            if (e.target.className.match("tr")
                || e.target.className.match("addListTable")
                || e.target.className.match("EditTable")) {
                return false;
            } else if (e.target.tagName == "INPUT") {
                return true;
            }// if
            //一項目のみclick可能とする
            if (e.target.parentElement.id == 'selected') {
                document.getElementById('selected').removeAttribute("id");
            } else {
                if (document.getElementById('selected') == null) {
                    e.target.parentElement.setAttribute('id', 'selected');
                }// if
                document.getElementById('selected').removeAttribute("id");
                e.target.parentElement.setAttribute('id', 'selected');
            }// if
        } else if (e.target.id == "main_scroll_L") {
            return false;
        }// if

    });// function
    // Ajax通信テスト ボタンクリック
    /** 
     * 動作関数
     * クリック時に動作
     * @memberOf  Category
    */
    $("#outputFileButton").click(function () {
        //テキストボックス内の文字列取得
        var strAddFilePassText = $('#addDirectoryPass').val();

        //未入力チェック
        if (strAddFilePassText == "") {
            alert(filePassNullMessage);
            return false;
        }

        //現在の行数を取得
        var objAutoRowNo = document.getElementById("main_scroll_R").children.length + 1;
        var strAutoRowNo = '' + objAutoRowNo;

        var successCount = 0;

        //最上位行のプルダウンメニュー内容を取得
        var strPullDownMenuList = document.getElementsByClassName("menu")[0].innerHTML;

        // コントローラに渡すjsonオブジェクトを作成する
        var jsonObj = new Object();
        jsonObj.directoryPass = strAddFilePassText;

        for (let index = 0; index < document.getElementById("main_scroll_R").children.length; index++) {
            var listFile = document.getElementById("main_scroll_R").children[index].children[3].outerText;
            if (listFile !== strAddFilePassText) {
                successCount++;
            }
        }

        if (document.getElementById("main_scroll_R").children.length === successCount) {
            //新規作成する欄を作成
            var ul = $('<ul class="tr"></ul>');
            var strDeleteButton = $('<li class="w40 bt_batsu NewDeleteRowTrainingPolicy"></li>');
            var strNonViewPlicyId = $('<li style="display: none">0</li>');
            var strPolicyPullDown = $('<li class="w100 menu dropdown_arrow_right" style="position: relative;"> </li>');
            var strFilePassList = $('<li class="wAutoA B text_align_left"></li>');
            //表に取得した値を挿入する
            $("#main_scroll_R").append(ul);
            ul.append(strDeleteButton).append(strNonViewPlicyId).append(strPolicyPullDown).append(strFilePassList);
            strDeleteButton.html('');
            strFilePassList.html(strAddFilePassText);
            //一覧追加用テキストボックスを空にする
            document.getElementById("addDirectoryPass").value = "";
            // 追加した結果登録データが初期状態と変化があるか確認する
            checkRegDataListCange();
            // 追加行にハイアラキーメニューを表示させるため再処理
            Array.from(document.querySelectorAll("#main_scroll_R ul li.menu")).map(item => hierarchyMenuProc(item));
            // wAutoAクラスのdomのサイズをほかのドムののこりのサイズで埋める
            fillDomWidth();
        } else {
            alert(alreadyDirectoryPassMessage);
        }

    });

    /**
     * 動作関数
     * 分類一覧表読み完了後動作関数
     * 分類一覧の読み込みが完了後、一覧表の数が0だった場合ボタンをdisabledに変更を行う。
     * @memberOf  Category
     */
    $("#main_scroll_L").ready(function (e) {
        console.log("main_scroll_L");
        if (document.getElementById('main_scroll_L').childElementCount == 1) {
            //「削除ボタン」をdisableに変更する
            delBtnCheck = DISABLE_TRUE;
            //「編集ボタン」をdisableに変更する
            editBtnCheck = DISABLE_TRUE;
            btnAllCheck();
        }
    });
    /**
     * 動作関数
     * 登録データ一覧表読み完了後動作関数
     * 登録データ一覧の読み込みが完了後、一覧表の数が0だった場合ボタンをdisabledに変更を行う。
     * @memberOf  Category
     */
    $("#main_scroll_R").ready(function (e) {
        console.log("main_scroll_R");
        var categoryList = $("#main_scroll_R")[0].children;

        // 1行目コピー用の空行となっているため開始番号は1
        for (var cnt = 1; cnt < categoryList.length; cnt++) {
            var teacherCategory = {};
            teacherCategory["categoryId"] = categoryList[cnt].children[1].textContent;
            teacherCategory["filePath"] = categoryList[cnt].children[3].textContent;
            // 開始番号が1のため-1
            beforeRegDataList[cnt - 1] = teacherCategory;
        }
        console.log(beforeRegDataList);
    });
    //beforeRegDataList
});// function

/**
 * 動作関数
 * ⇒ボタン押下時に動作
 * 分類一覧表を表示し、「⇐」ボタンを表示する
 * @memberOf  Category
**/
function categoryFadeInOut() {
    if (document.getElementById("categoryTable").style.cssText !== "display: none;") {
        //分類一覧表の非表示
        $('#categoryTable').fadeOut(100);
        $('#dataList').width("98%");
    } else {
        //分類一覧表の表示
        $('#categoryTable').fadeIn(100);
        $('#dataList').width("calc(100% - 230px)");
    }// if
}// function


/**
 * 動作関数
 * 追加ボタン押下時に動作
 * 一覧表の最下部に追加する
 * @memberOf  Category
**/
function categoryAddList() {

    //現在の最大行取得
    var objAutoRowNo = document.getElementById("main_scroll_L").children.length - 1;
    strAutoRowNo = '' + objAutoRowNo;

    //非編集状態かつ編集中ではない場合
    if (document.getElementsByClassName('EditMode').length == 0 && document.getElementsByClassName("EditTable").length == 0) {
        //最終行が新規作成テキストボックスか確認を行う
        var t = document.getElementById("main_scroll_L")
        var t2 = $("#main_scroll_L")
        console.log(document.getElementById("main_scroll_L").children[objAutoRowNo].classList[2]);
        if (document.getElementById("main_scroll_L").children[objAutoRowNo].classList[2] !== "addListTable") {
            //編集行を、最終行に変更を行う
            if (document.getElementById('selected') !== null) {
                document.getElementById('selected').removeAttribute("id");
            }// if

            //新規作成する欄を作成
            var tr = $('<ul id="selected" class="tr ' + addListCount + '"></ul>');
            var strCategoryName = $('<li class="w160"></li>');

            //表に取得した値を挿入する
            $('#main_scroll_L').append(tr);
            tr.append(strCategoryName);
            strCategoryName.html("<input size='17' type='text' id='newCategoryName' class='textBox' value=" + "" + " ></imput>");
            $('#selected').eq(0).addClass('addListTable');

            // ボタンの状態更新
            //編集ボタン無効
            editBtnCheck = DISABLE_TRUE;
            //削除ボタン無効
            delBtnCheck = DISABLE_TRUE;//
            //設定反映ボタン無効
            refBtnCheck = DISABLE_TRUE;

            //登録ボタンの現在の状態を保持
            tmpRegBtn = regBtnCheck;
            //登録ボタン無効
            regBtnCheck = DISABLE_TRUE;
            //ボタンの状態を画面に反映
            btnAllCheck();

        } else if (document.getElementById("main_scroll_L").children[objAutoRowNo].classList[2] === "addListTable") {
            console.log("addmode");
            //入力されているテキストボックス内容を取得
            var strNewCategoryNameText = document.getElementById("newCategoryName").value;
            //入力チェック
            if (strNewCategoryNameText == "") {
                alert(categoryNameNullMessage);
                return false;
            }// if

            //入力された値がすでに一覧に存在するかチェック
            for (let index = 0; index < objAutoRowNo; index++) {
                var doc = document.getElementById("main_scroll_L").children[index];
                //var strListContent = document.getElementById("main_scroll_L").children[index].children[1].textContent;
                // 既存行なら[1] 追加行なら[0]からチェック対象を参照
                var strListContent = doc.children[1] ? doc.children[1].textContent : doc.children[0].textContent;
                if (strListContent === strNewCategoryNameText) {
                    alert(alreadyListAddMessage);
                    return false;
                }// if
            }// for

            //連想配列の作成
            var userName = $("#USER_NAME")[0].innerText.replace("ユーザー名：", "");
            var addLen = addValues.length;
            addValues[addListCount] = { ["categoryName"]: strNewCategoryNameText, ["categoryAuthor"]: userName };//現在ログインしているユーザー名を取得する
            addListCount++;
            console.log(addValues);
            //テキストボックス化を解除する
            document.getElementById("newCategoryName").outerHTML = strNewCategoryNameText;

            //非アクティブ化状態に移行するため、クラスの削除
            document.getElementsByClassName("addListTable")[0].classList.remove("addListTable");

            // ボタンの状態更新
            //編集ボタン有効
            editBtnCheck = DISABLE_FALSE;
            //削除ボタン有効
            delBtnCheck = DISABLE_FALSE;//
            //設定反映ボタン有効
            refBtnCheck = DISABLE_FALSE;
            //登録ボタンは前の状態へ戻す
            regBtnCheck = tmpRegBtn;
            //ボタンの状態を画面に反映
            btnAllCheck();

            return;
        }// if
        //編集状態かつ編集中の場合
    } else if (document.getElementsByClassName('EditMode').length > 0 && document.getElementsByClassName("EditTable").length > 0) {
        alert(editNowNotAddMessage);
        return false;
    }// if
}// function

/**
 * 動作関数
   * 編集ボタン押下時に動作
   * 選択した項目内容を変更する
   * @memberOf  Category
  **/
function categoryEdit() {
    //現在新規作成中の場合アラートを表示する
    if (document.getElementsByClassName('addListTable').length == 0) {
        //非編集状態かつ編集中ではない場合
        if (document.getElementsByClassName('EditMode').length == 0 && document.getElementsByClassName("EditTable").length == 0) {
            if (document.getElementById('selected') !== null) {
                if (document.getElementById('selected').length != 0) {
                    //編集がアクティブ状態のため、クラス付与
                    $('#main_scroll_L').eq(0).addClass('EditMode');
                    $('#selected').eq(0).addClass('EditTable');

                    //分類軸ID取得
                    var strChangeRow = $("#selected>li[style='display: none;']").text();

                    //新規追加行チェック
                    if (strChangeRow === "") {
                        //選択行の分類軸名を取得
                        var strCategoryNameText = $('#selected').eq(0).children()[0].valueOf().textContent;
                        console.log(strCategoryNameText);
                        //更新前の追加した分類名を保持
                        beforeCategoryName = strCategoryNameText;
                        //選択行の分類軸名をTextBox化
                        $('#selected').eq(0).children()[0].innerHTML = "<input size='17' type='text' id='changeCategoryName' class='textBox' value=" + strCategoryNameText + " ></imput>";
                    } else {
                        //選択行の分類軸名を取得
                        var strCategoryNameText = $('#selected').eq(0).children()[1].valueOf().textContent;
                        //選択行の分類軸名をTextBox化
                        $('#selected').eq(0).children()[1].innerHTML = "<input size='17' type='text' id='changeCategoryName' class='changeTextBox' value=" + strCategoryNameText + " ></imput>";
                    }// if
                }// if

                // ボタンの状態更新
                //追加ボタン無効
                addBtnCheck = DISABLE_TRUE;
                //削除ボタン無効
                delBtnCheck = DISABLE_TRUE;//
                //設定反映ボタン無効
                refBtnCheck = DISABLE_TRUE;
                //登録ボタンの現在の状態を保持
                tmpRegBtn = regBtnCheck;
                //登録ボタン無効
                regBtnCheck = DISABLE_TRUE;
                //ボタンの状態を画面に反映
                btnAllCheck();

            } else {
                alert(selectedNotClickEditMessage);
            }// if
            //編集状態かつ編集中の場合
        } else if (document.getElementsByClassName('EditMode').length > 0 && document.getElementsByClassName("EditTable").length > 0) {

            //分類軸ID取得
            var strChangeRow = $(".EditTable>li[style='display: none;']").text();
            //DBで表示されているリストの場合、classからリスト番号を取得
            var strAddChangeRow = document.getElementsByClassName("EditTable")[0].classList[0];
            //表示されている値の登録
            var strTextBoxCategoryName = document.getElementById("changeCategoryName").value;
            //現在の最大行取得
            var objAutoRowNo = document.getElementById("main_scroll_L").childElementCount - 1;
            console.log(strChangeRow);

            //入力された値がすでに一覧に存在するかチェック
            if (document.getElementsByClassName("changeTextBox").length > 0) {
                //入力された値がすでに一覧に存在するかチェック
                for (let index = 0; index < objAutoRowNo; index++) {
                    var doc = document.getElementById("main_scroll_L").children[index];
                    // 既存行なら[1] 追加行なら[0]からチェック対象を参照
                    var strListContent = doc.children[1] ? doc.children[1].textContent : doc.children[0].textContent;
                    if (strListContent === strTextBoxCategoryName) {
                        alert(alreadyListEditMessage);
                        return false;
                    }// if
                }// for
            } else {
                //入力された値がすでに一覧に存在するかチェック
                for (let index = 0; index < objAutoRowNo; index++) {
                    var doc = document.getElementById("main_scroll_L").children[index];
                    // 既存行なら[1] 追加行なら[0]からチェック対象を参照
                    var strListContent = doc.children[1] ? doc.children[1].textContent : doc.children[0].textContent;
                    if (strListContent === strTextBoxCategoryName) {
                        alert(alreadyListEditMessage);
                        return false;
                    }// if
                }// for
            }// if
            var len = changedValues.length;
            // リクエスト用配列作成・追加
            var changeFlag = false;
            // 更新前の追加した分類名がある場合、連想配列は追加に対して修正を行う
            if (beforeCategoryName) {
                for (var cnt = 0; cnt < addValues.length; cnt++) {
                    // 編集前の分類名でAddValuesを検索
                    if (addValues[cnt]["categoryName"] === beforeCategoryName) {
                        // 編集した内容で更新
                        addValues[cnt]["categoryName"] = strTextBoxCategoryName;
                    }
                }
                // 既存の分類名を編集した場合
            } else {
                for (var cnt = 0; cnt < len; cnt++) {
                    if (changedValues[cnt]["categoryId"] == strChangeRow) {
                        changedValues[cnt]["categoryName"] = strTextBoxCategoryName;
                        changeFlag = true;
                    }//if
                }//for
                if (!changeFlag) {
                    var changedValue = {};
                    changedValue["categoryId"] = strChangeRow;
                    changedValue["categoryName"] = strTextBoxCategoryName;
                    changedValues[len] = changedValue;
                }
            }
            //テキストボックス化を解除する
            document.getElementById("changeCategoryName").outerHTML = strTextBoxCategoryName;

            //非アクティブ化状態に移行するため、クラスの削除
            document.getElementById('main_scroll_L').classList.remove("EditMode");
            document.getElementsByClassName("EditTable")[0].classList.remove("EditTable");

            // ボタンの状態更新
            //編集ボタン有効
            addBtnCheck = DISABLE_FALSE;
            //削除ボタン有効
            delBtnCheck = DISABLE_FALSE;
            //設定反映ボタン有効
            refBtnCheck = DISABLE_FALSE;
            //登録ボタンは前の状態へ戻す
            regBtnCheck = tmpRegBtn;
            //ボタンの状態を画面に反映
            btnAllCheck();

            return;
        }// if
    } else if (document.getElementsByClassName('addListTable').length > 0) {
        alert(addNowNotAddMessage);
        return false;
    }// if
}// function

/**
 * 動作関数
 * 削除ボタン押下時に動作
 * 選択した行を削除する
 * @memberOf  Category
**/
//行の削除を行う
function categoryDeleteRow() {
    //行を選択していない場合、アラートを表示
    if (document.getElementById('selected') !== null) {
        //選択している行が編集中の場合、アラートを表示
        if (document.getElementById("selected").classList.contains("EditTable") !== true && document.getElementById("selected").classList.contains("addListTable") !== true) {
            //分類軸ID取得
            var strDeleteRow = $("#selected>li[style='display: none;']").text();
            console.log(strDeleteRow);
            //新規作成で表示されているリストの場合、classからリスト番号を取得
            var strAddDeleteRow = $("#selected")[0].textContent;
            // グローバル変数に値を設定するのは既存行の時のみ
            if (strDeleteRow) {
                console.log(changedValues);
                //グローバル変数に分類軸IDの値を設定する
                deleteDBNo.push(strDeleteRow);
                //連想配列の削除を行う
                for (var cnt = 0; cnt < changedValues.length; cnt++) {
                    if (changedValues[cnt]["categoryId"] == strDeleteRow) {
                        changedValues.splice(cnt, 1);
                    }
                }
                // 新規作成行の場合
            } else {
                console.log(addValues);
                for (var cnt = 0; cnt < addValues.length; cnt++) {
                    if (addValues[cnt]["categoryName"] == strAddDeleteRow) {
                        addValues.splice(cnt, 1);
                        addListCount--;
                    }
                }
            }
            //選択した行の削除
            $("#selected").remove();

            //設定反映ボタン有効
            refBtnCheck = DISABLE_FALSE;
            // 削除の結果行がなくなった時
            console.log("現在の行数" + document.getElementById('main_scroll_L').childElementCount);
            if (document.getElementById('main_scroll_L').childElementCount == 1) {
                //削除ボタン無効
                delBtnCheck = DISABLE_TRUE;
                //編集ボタン無効
                editBtnCheck = DISABLE_TRUE;
            }
            // 削除した結果更新するデータがなくなった時
            if (!Object.keys(addValues).length && !Object.keys(changedValues).length && !deleteDBNo.length) {
                //設定反映ボタン無効
                refBtnCheck = DISABLE_TRUE;
            }// if
            btnAllCheck();

        } else {
            alert(selectedNotClickAddOrEditMessage);
        }//if
    } else {
        alert(selectedNotClickDeleteMessage);
    }// if
}// function

/**
 * 動作関数
 * キャンセルボタン押下時に動作
 * ダイアログを表示する
 * @memberOf  Category
**/
function teacherCategoryCancel() {
    blCan = confirm(cancelSelectedMessage);
    if (blCan) {
        isCancel = true;
        window.close();
    } else {
        return;
    }// if
}// function

/**
 * 動作関数
 * クリアボタン押下時に動作
 * ダイアログを表示する
 * @memberOf  Category
**/
function categoryClear() {
    blCan = confirm(clearSelectedMessage);
    if (blCan) {
        isClear = true;
        location.reload();
    } else {
        return;
    }// if
}// function

/**
 * 動作関数
 * 設定反映ボタン押下時に動作
 * 編集したカテゴリ一覧を登録処理する
 * @memberOf  Category
 */
function reflectCategory() {

    if (!Object.keys(addValues).length && !Object.keys(changedValues).length && !deleteDBNo.length) {
        alert(notChangeCategoryMessage);
        return;
    }// if

    if (!confirm(addReflectCategoryCheckMessage)) {
        return;
    }

    var jsonObj = new Object();

    if (Object.keys(addValues).length) {
        jsonObj.addValues = addValues;
    }
    if (Object.keys(changedValues).length) {
        jsonObj.changedValues = changedValues;
    }
    if (deleteDBNo.length) {
        jsonObj.deleteRow = deleteDBNo;
    }

    console.log(jsonObj);

    $.ajax({
        url: hostUrl + "/category_reflect",
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify(jsonObj),
        // ajax通信成功時の処理
    }).done(function (data) {
        let successOrFailure = "";
        console.log(data);
        isPost = true;
        location.reload();
        alert(categoryReflectSettingMessage);
        // ajax通信失敗時の処理
    }).fail(function (xhr, textStatus, errorThrown) {
        //alert(xhr.responseText + "\r\n分類一覧の更新処理に失敗しました。");
        alert(categoryReflectSettingFailureMessage);
    });
    /*  } else {
          return;
      }
    */
}

/**
 * 動作関数
 * 登録ボタン押下時に動作
 * 編集したカテゴリ一覧を登録処理する
 * @memberOf  Category
 */
function reflectTeacherCategory() {

    var categoryList = $("#main_scroll_R")[0].children;
    var userId = $("#USER_ID")[0].textContent;
    var teacherCategoryList = [];
    var savePath = $("#saveRegistrationList")[0].value;

    // 入力チェック（保存先未入力
    if (!savePath) {
        alert(addReflectSettingNotSavePassMessage);
        return;
    }

    // 1行目コピー用の空行となっているため開始番号は1
    for (var i = 1; i < categoryList.length; i++) {

        // 分類選択のチェック
        var categoryId = categoryList[i].children[1].outerText;
        if (!categoryId || categoryId === "0") {
            alert(notSelectCategoryMessage);
            return;
        }
    }

    blCanPost = confirm(addReflectSettingCheckMessage);
    if (blCanPost) {
        $("#regBtn").prop("disabled", true);

        // 1行目コピー用の空行となっているため開始番号は1
        for (var cnt = 1; cnt < categoryList.length; cnt++) {
            var TeacherCategory = {};
            TeacherCategory["userId"] = userId;
            TeacherCategory["sortId"] = cnt;
            TeacherCategory["categoryId"] = categoryList[cnt].children[1].textContent;
            TeacherCategory["filePath"] = categoryList[cnt].children[3].textContent;
            // 開始番号が1のため-1
            teacherCategoryList[cnt - 1] = TeacherCategory;
        }

        var jsonObj = new Object();
        jsonObj.tmpTeacherCategoryList = teacherCategoryList;
        jsonObj.savePath = savePath;

        console.log(jsonObj);

        $.ajax({
            url: hostUrl + "/teacher_category_reflect",
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify(jsonObj),
            // ajax通信成功時の処理
        }).done(function (data) {
            let successOrFailure = "";
            console.log(data);
            isPost = true;
            location.reload();
            alert(addReflectSettingMessage);
            // 画面を更新する
            // ajax通信失敗時の処理
        }).fail(function (xhr, textStatus, errorThrown) {
            $("#regBtn").prop("disabled", false);
        	if (xhr.status === 406) {
                alert(xhr.responseText);
        	} else {
                //alert(xhr.responseText + "\r\n登録データ一覧の更新処理に失敗しました");
                alert(addReflectSettingFailureMessage);
        	}
            // 成功でも失敗でも通信終了時に必要な処理があれば
        }).always(function () {
        });
    } else {
        return;
    }

}

/**
 * 動作関数
 * 全てのボタンの「活性」・「非活性」を判定する
 * @memberOf  Category
 */
function btnAllCheck() {
    isAdd();
    isEdit();
    isDel();
    isRef();
    isReg();
    isCle();
}

/**
* 動作関数
* 設定反映ボタンの「活性」「非活性」を判定する
* @memberOf  Category
*/
function isAdd() {
    if (addBtnCheck == 0) {
        $("#addBtn").prop("disabled", true);
    } else {
        $("#addBtn").prop("disabled", false);
    }//if
}// function

/**
 * 動作関数
* 設定反映ボタンの「活性」「非活性」を判定する
* @memberOf  Category
*/
function isEdit() {
    if (editBtnCheck == 0) {
        $("#editBtn").prop("disabled", true);
    } else {
        $("#editBtn").prop("disabled", false);
    }//if
}// function

/**
 * 動作関数
* 設定反映ボタンの「活性」「非活性」を判定する
* @memberOf  Category
*/
function isDel() {
    if (delBtnCheck == 0) {
        $("#delBtn").prop("disabled", true);
    } else {
        $("#delBtn").prop("disabled", false);
    }//if
}// function

/**
 * 動作関数
* 設定反映ボタンの「活性」「非活性」を判定する
* @memberOf  Category
*/
function isRef() {
    if (refBtnCheck == 0) {
        $("#refBtn").prop("disabled", true);
    } else {
        $("#refBtn").prop("disabled", false);
    }//if
}// function

/**
 * 動作関数
* 登録ボタンの「活性」「非活性」を判定する
* @memberOf  Category
*/
function isReg() {
    if (regBtnCheck == 0) {
        $("#regBtn").prop("disabled", true);
    } else {
        $("#regBtn").prop("disabled", false);
    }//if
}// function

/**
 * 動作関数
* クリアボタンの「活性」「非活性」を判定する
* @memberOf  Category
*/
function isCle() {
    if (cleBtnCheck == 0) {
        $("#cleBtn").prop("disabled", true);
    } else {
        $("#cleBtn").prop("disabled", false);
    }//if
}// function

/**
 * 動作関数
 * 初期表示したときの登録データ一覧と変化があるか確認する
 * @memberOf  Category
 */
function checkRegDataListCange() {
    console.log("checkRegDataListCange");
    var categoryList = $("#main_scroll_R")[0].children;
    //登録ボタンを無効にする
    regBtnCheck = DISABLE_TRUE;
    //初期状態の登録データ一覧と行数が同じか比較する（コピー行があるため、categoryListは-1）
    if (beforeRegDataList.length === categoryList.length - 1) {
        console.log("行数が同じ");
        //初期状態の登録データ一覧と分類及びファイルパスを比較する
        for (cnt = 0; cnt < beforeRegDataList.length; cnt++) {
            console.log("categoryid  " + beforeRegDataList[cnt]["categoryId"] + " == " + categoryList[cnt + 1].children[1].textContent)
            // 初期状態から変化があった場合
            if (beforeRegDataList[cnt]["categoryId"] != categoryList[cnt + 1].children[1].textContent
                || beforeRegDataList[cnt]["filePath"] != categoryList[cnt + 1].children[3].textContent) {
                //登録ボタンを有効にする
                regBtnCheck = DISABLE_FALSE;
                break;
            } //if
        }
    } else {
        //登録ボタンを有効にする
        regBtnCheck = DISABLE_FALSE;
    }// if
    // ボタンの状態を更新
    btnAllCheck();
}