package jp.co.nec.docmng.dao.accesser.admin;

import java.io.Reader;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import jp.co.nec.docmng.dao.entity.admin.UserInfo;
import jp.co.nec.docmng.dao.entity.admin.UserInfoExample;
import jp.co.nec.docmng.dao.mapper.admin.UserInfoMapper;

/**
 * UserInfoDao
 * ユーザ情報テーブルの全件を取得する。
 */
public class UserInfoDao {

	/**
	 * ユーザ情報テーブルの情報を表示する。
	 * @return List&lt;UserInfo&gt; userInfoList ユーザ情報テーブルの情報リストを取得する。
	 */
	public List<UserInfo> getUserAll() {
		
		List<UserInfo> userInfoList = null ;
		
		try (Reader readerConfig = Resources.getResourceAsReader("mybatis-config.xml");) {

			// 読み込んだ設定ファイルからSqlSessionFactoryを生成する
			SqlSessionFactory sqlFactory = new SqlSessionFactoryBuilder().build(readerConfig);

			// SQLセッションを取得する
			try (SqlSession sqlSession = sqlFactory.openSession()) {

				// ユーザ情報テーブルのMapperを取得する
				UserInfoMapper userInfoMapper = sqlSession.getMapper(UserInfoMapper.class);

				// ユーザ情報テーブルの条件検索用クラスを生成する
				UserInfoExample userInfoExample = new UserInfoExample();

				userInfoExample.setOrderByClause("user_id");

				// 上記の条件でテーブルを検索する
				userInfoList = userInfoMapper.selectByExample(userInfoExample);

			}
		} 
		catch (Exception e) {
			// テーブル情報を取得できない場合
			e.printStackTrace();
		}
		return userInfoList;
	} 

} 
