/**
 * 名称：MaskDocMarkerEntBlackPaint.java
 * 機能名：黒塗り処理黒塗り文書黒塗り箇所保存情報entity
 * 概要：黒塗り処理で使用する黒塗り文書黒塗り箇所保存情報entity
 */

package jp.co.nec.docmng.blackPaint.entity;

import java.sql.Timestamp;
import lombok.Data;

/**
 * 黒塗り処理黒塗り文書黒塗り箇所保存情報entity
 */
@Data
public class MaskDocMarkerEntBlackPaint {

	/**
	 * 文書ID
	 */
	private Integer documentId;

	/**
	 * 黒塗り先頭コード
	 */
	private String markerStartCd;

	/**
	 * 黒塗り終了コード
	 */
	private String markerEndCd;

	/**
	 * 黒塗り箇所ポリシーID
	 */
	private Integer markerPolicy;

	/**
	 * 黒塗り箇所備考
	 */
	private String markerRemarks;

	/**
	 * 作成日時
	 */
	private Timestamp createTime;

	/**
	 * 更新日時
	 */
	private Timestamp updateTime;
	
	/**
	 * ユーザーID
	 */
	private String userId;

}
