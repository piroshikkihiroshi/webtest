/**
 * 名称：PowerPointEdit.java
 * 機能名：PowerPointファイル 黒塗り文書作成画面初期表示メソッド
 * 概要：PowerPointファイルを黒塗り文書作成画面に初期表示する
 */

package jp.co.nec.docmng.blackPaint.logic.edit;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletContext;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.zeroturnaround.zip.ZipUtil;

import jp.co.nec.docmng.blackPaint.entity.DocumentInfoEntPaint;
import jp.co.nec.docmng.blackPaint.entity.MaskDocumentEntBlackPaint;
import jp.co.nec.docmng.blackPaint.logic.dirFile.DirCnt;
import jp.co.nec.docmng.blackPaint.logic.dirFile.FileCnt;
import jp.co.nec.docmng.blackPaint.logic.maskHtml.AiDataSelect;
import jp.co.nec.docmng.blackPaint.logic.maskHtml.HtmlStructure;
import jp.co.nec.docmng.blackPaint.logic.maskHtml.MaskHtmlModel;
import jp.co.nec.docmng.blackPaint.service.DocInfoServicePaint;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocMarkerServicePaint;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocumentServicePaint;
import jp.co.nec.docmng.library.blackprintextract.entity.BlackPrintPlace;
import jp.co.nec.docmng.library.blackprintextract.service.BlackPrintExtract;

/**
 * PowerPointファイル 黒塗り文書作成画面初期表示メソッド
 */
public class PowerPointEdit {
	static Logger objLog = LoggerFactory.getLogger(PowerPointEdit.class);

	@Autowired
	ServletContext context;
	@Autowired
	DocInfoServicePaint docInfoService;

	@Autowired
	TmpMaskDocMarkerServicePaint tmpMaskDocTmpMarkerService;

	@Autowired
	TmpMaskDocumentServicePaint tmpMaskDocumentService;

	HashMap<String, String> hashMap = new HashMap<String, String>();

	/**
	 * 黒塗り文書作成画面初期表示メソッド(PowerPoint) 画面初期表示の処理をする。
	 *
	 * @param listDoc        文書情報から取得したデータのリスト
	 * @param listMaskDoc    黒塗り文書保存テーブルから取得したデータのリスト
	 * @param strTmpDir      ファイル作成用フォルダパス
	 * @param resourceLoader ResourceLoader
	 * @param status         空文字: 初期処理 1: 再開 2: 黒塗りリスト確定
	 * @param policySelect   選択黒塗りポリシーID
	 * @return
	 */
	public HashMap<String, String> pptEditMain(List<DocumentInfoEntPaint> listDoc,
			List<MaskDocumentEntBlackPaint> listMaskDoc,
			String strTmpDir,
			ResourceLoader resourceLoader,
            String status, //空文字: 初期処理 1: 再開 2: 黒塗りリスト確定 3: 参照文書 4: 紐づけ処理(現文書表示)
			String policySelect

	) {

		int documentId = listDoc.get(0).getDocumentId();

		String strHeight = "485";
		String aiData = ""; // aiが返すデータ

		FileCnt objFileCnt = new FileCnt();
		MaskHtmlModel objMaskCls = new MaskHtmlModel();
		DirCnt objDirCls = new DirCnt();

		String strHtmlName = documentId + ".html"; // 作成html名
		String strHtmlPath = strTmpDir + documentId + ".html"; // 作成htmlパス

		String strStyle = ""; // CSSを作成する
		strStyle += "<style>";
		strStyle += ".tagRed{";
		strStyle += "    color: rgb(233, 84, 84);";
		strStyle += "    display: inline-grid;";
		strStyle += "    overflow: hidden;";
		strStyle += "}";
		strStyle += ".tagRng{";
		strStyle += "    color: rgb(233, 87, 51);";
		strStyle += "    background-color: rgba(159, 192, 230, 0.884);";
		strStyle += "}";
		strStyle += ".tagMsk{";
		strStyle += "    color: black;";
		strStyle += "    display: inline-grid;";
		strStyle += "    overflow: hidden;";
		strStyle += "    background-color: black;";

		strStyle += "}";
		strStyle += ".awpage {";
		strStyle += "    position: relative;";
		strStyle += "    border: none;";
		strStyle += "    margin: 0px;";
		strStyle += "}";
		strStyle += ".redimg{";
		strStyle += "    -webkit-filter: sepia(100%)  hue-rotate(300deg); ";
		strStyle += "    -moz-filter: sepia(100%)  hue-rotate(300deg);";
		strStyle += "    -o-filter: sepia(100%)  hue-rotate(300deg);";
		strStyle += "    -ms-filter: sepia(100%)  hue-rotate(300deg);";
		strStyle += "    filter: sepia(100%)  hue-rotate(300deg);";
		strStyle += "}";
		strStyle += "a {";
		strStyle += "    pointer-events: none;";
		strStyle += "}";

		// badge対応
		strStyle += ".redNumber {";
		strStyle += "	   position: absolute;";
		strStyle += "	   z-index: 1000;";
		strStyle += "	   padding: 5px;";
		strStyle += "    font-size: 10.5px;";
		strStyle += "	   background-color: #fff;";
		strStyle += "	   background-clip: padding-box;";
		strStyle += "	   border: 1px solid rgba(0,0,0,.2);";
		strStyle += "	   border-radius: 10rem;";

		strStyle += "    font-family: \"VL Gothic\";";
		strStyle += "    color: black;";
		strStyle += "    font-style: normal;";
		strStyle += "}";
		strStyle += " .redNumber:hover {";
		strStyle += "    opacity: 0.0;";
		strStyle += "}";
		strStyle += " .redHidden {";
		strStyle += "  visibility: hidden;";
		strStyle += "}";
		strStyle += ".mskNumber {";
		strStyle += "	    display: none;";
		strStyle += "}";
		strStyle += "a {";
		strStyle += "    pointer-events: none;";
		strStyle += "}";

		strStyle += "</style>";

		String[] arrMask = null;
		String[] arrRed = null;

		// 全文検索モックデータ コロン区切りでペアは+区切り intpos,そこからつづく,intpos,そこからつづく
		String strAllHtml = "";
		String strRepBody = "";
		String strMaskHtml = "";
		String strRedHtml = "";
		int intPageCnt = 0;

		String strEditMarker = "";

		String strOrgFilePath = listDoc.get(0).getDocumentName();
		// 一度RealPathへファイルをコピーする
		String strFileName = strOrgFilePath.substring(strOrgFilePath.lastIndexOf("\\") + 1, strOrgFilePath.length());
		String strFileWithoutExtension = objFileCnt.getNameWithoutExtension(strFileName);

		objLog.info("PPT処理開始");
		try {

			byte[] arrHtmlZip = null;
			// 20200227 元文書表示対応
			if (status.equals("4")) {
				arrHtmlZip = listMaskDoc.get(0).getHtmlZipData();
			} else {
				arrHtmlZip = listDoc.get(0).getHtmlZipData();
			} // if

			// file出力
			// 出力フォルダ作成
			String strFileOutDir = strTmpDir;
			String strZipPath = strFileOutDir + "mask.zip";

			Path objZipPath = Paths.get(strZipPath);

			try {

				objDirCls.makeDirWithCheck(strFileOutDir);
				// zipファイル出力
				Files.write(objZipPath, arrHtmlZip);
				// unzipする
				ZipUtil.unpack(new File(strZipPath), new File(strFileOutDir));

				// 作業ファイルかたづけ
				File fileZip = new File(strZipPath);
				fileZip.delete();

				// 20200115 ファイル名をdocumentIdに変更した対応
				// 20200227 元文書表示対応 //元文書表示対応語なのでリネーム処理は行わない
				if (!status.equals("4")) {
					// 変更前ファイル名
					File bfFile = new File(strFileOutDir + strFileWithoutExtension + ".html");
					// 変更後のファイル名
					File afFile = new File(strFileOutDir + documentId + ".html");
					bfFile.renameTo(afFile);

					// 変更前ファイル名
					File bfDir = new File(strFileOutDir + "/" + strFileWithoutExtension + "_files");
					// 変更後のファイル名
					File afDir = new File(strFileOutDir + "/" + documentId);
					bfDir.renameTo(afDir);

				} // if

				objLog.info("HTML群取得完了");

			} catch (IOException e1) {
				objLog.error("err message", e1);
				e1.printStackTrace();

			} // try
		} catch (Exception e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} // try

		try {
			// tmpDir作成
			// 対象HTMLを取得する
			if (!status.equals("4")) {
				strAllHtml = objMaskCls.readAll(strHtmlPath);

				// 20200115 ファイル名をdocumentIdに変更した対応
				strAllHtml = strAllHtml.replaceAll("\\<(.+=).+_files/", "<$1\\\"" + documentId + "/");
				strAllHtml = strAllHtml.replace("stl_02", "awdiv awpage");
			}

			// 圧縮されたBodyを取得
			// strOrgBody = objMaskCls.getBodyCompress(strAllHtml);

			// AIdata スタブ
			BlackPrintExtract objAiCls = new BlackPrintExtract();
			// if (status.equals("")) { //初期処理時のみ
			// aiDatalist
			List<BlackPrintPlace> listAi = null;
			// 20200227 元文書表示対応
			if (!status.equals("4")) {
				try {
					listAi = objAiCls.extractBlackPrintPlace(documentId);
					BlackPrintPlace tmpPrintPlace = null;
					aiData = "";
					for (int i = 0; i < listAi.size(); i++) {
						tmpPrintPlace = listAi.get(i);
						aiData += tmpPrintPlace.start + ":" + tmpPrintPlace.end + ":" + tmpPrintPlace.policyID + "+";
					} // for
					aiData = aiData.substring(0, aiData.length() - 1);
				} catch (Exception e2) {
					aiData = "";
					objLog.info("AIデータ取得処理でエラーが発生したため、取得したHTMLをそのまま表示");
					objLog.error("err message", e2);
					e2.printStackTrace();
				} // try
					// } //if
			} else {
				objLog.info("原文データを表示するため、AIにデータはわたさない");
			} // if

			if (aiData == null) {
				aiData = "";
			} // if

			// debug
			// aiData="206:230:1";

			// 20200204 add
			AiDataSelect objAiDataSelect = new AiDataSelect();
			aiData = objAiDataSelect.selectAiData(aiData, policySelect);

			objLog.info("aiData=" + aiData);

			if (!aiData.equals("")) {

				// 全文検索から戻ってきた値をhashへ成型
				HashMap<Integer, String> hashRepPos = objMaskCls.makePosHash(aiData);
				objMaskCls.makePosHash(aiData);

				objLog.info("makePosHash完了");

				// bodyの構造体hashを取得
				// HashMap<Integer, HtmlStructure> hashBodyStructure =
				// objMaskCls.getBodyStructure(strOrgBody);
				HashMap<Integer, HtmlStructure> hashBodyStructure = objMaskCls.getBodyStructure(strAllHtml);

				// 全文検索エンジンに返した結果を置換してbodyを入れ替えた文字列を取得(黒塗り)
				arrMask = objMaskCls.bodyReplace(hashRepPos, hashBodyStructure, 1);
				strRepBody = arrMask[0];
				strEditMarker = arrMask[1];

				// htmlのbodyの中身を入れ替え、置換HTMLを作成する
				// strMaskHtml = objMaskCls.makeBody(strAllHtml,strRepBody);
				strMaskHtml = strRepBody;

				// スタイルシートPath埋め込み
				strMaskHtml = objMaskCls.insertStylePpt(strMaskHtml, strStyle);

				// 全文検索エンジンに返した結果を置換してbodyを入れ替えた文字列を取得(赤文字)
				arrRed = objMaskCls.bodyReplace(hashRepPos, hashBodyStructure, 2);
				strRepBody = arrRed[0];
				// htmlのbodyの中身を入れ替え、置換HTMLを作成する
				// strRedHtml = objMaskCls.makeBody(strAllHtml,strRepBody);
				strRedHtml = strRepBody;

				// スタイルシートPath埋め込み
				strRedHtml = objMaskCls.insertStylePpt(strRedHtml, strStyle);
			} else { // aidataなし
				objLog.info("aiDataが無いため、サーバでの黒塗り処理は行いません。");
				if (!status.equals("4")) {
					strMaskHtml = strAllHtml;
					strRedHtml = strAllHtml;
				} else {
					strMaskHtml = objMaskCls.readAll(strTmpDir + "mask_" + documentId + ".html");
					strRedHtml = objMaskCls.readAll(strTmpDir + "red_" + documentId + ".html");
				} // if
					// スタイルシートPath埋め込み
				strMaskHtml = objMaskCls.insertStylePpt(strMaskHtml, strStyle);
				// スタイルシートPath埋め込み
				strRedHtml = objMaskCls.insertStylePpt(strRedHtml, strStyle);
			} // if

			synchronized (this) {
				// css,黒塗り画像ファイル配備 ※deploy時にエラーになるためresourceLoaderで取得
				String strCssPath = "/static/css/blackPaint/mask.css";
				String strImgPath = "/static/css/images/m";
				// deploy後に動かないので修正
				objLog.info("ファイル、イメージ配備開始");
				Resource resource = null;
				resource = resourceLoader.getResource("classpath:" + strCssPath);
				objLog.info(strCssPath + "存在判定：" + resource.exists());

				InputStream objIs = resource.getInputStream();
				byte[] arrByte = null;
				// arrByte=objIs.readAllBytes();
				arrByte = IOUtils.toByteArray(objIs);
				FileOutputStream objOutSr = null;
				objOutSr = new FileOutputStream(strTmpDir + "/" + documentId + "/mask.css");
				objOutSr.write(arrByte);// 出力（dataのbyte列をファイルに書き込む）
				objOutSr.close();// 閉じる(fosを使ったファイル操作を終えた時に実行)

				resource = resourceLoader.getResource("classpath:" + strImgPath);
				objLog.info(strCssPath + "存在判定：" + resource.exists());
				objIs = resource.getInputStream();
				arrByte = IOUtils.toByteArray(objIs);

				objOutSr = new FileOutputStream(strTmpDir + "/" + documentId + "/m");

				objOutSr.write(arrByte);// 出力（dataのbyte列をファイルに書き込む）
				objOutSr.close();// 閉じる(fosを使ったファイル操作を終えた時に実行)

				objLog.info("ファイル、イメージ配備完了");

				// 20200227 元文書表示対応
				if (!status.equals("4")) {
					objLog.info("SVGファイル修正開始");

					int intSvgCnt = 1600000;
					int intCnt = 0;
					// svgファイルを集める
					File objDir = new File(strTmpDir + documentId + "/");
					File[] objList = objDir.listFiles();
					for (int i = 0; i < objList.length; i++) {
						String strTmpName = objList[i].getName();
						String strExtension = strTmpName.substring(strTmpName.lastIndexOf(".") + 1,
								strTmpName.length());
						if (strExtension.equalsIgnoreCase("svg")) { // 対象がsvgファイルだった場合
							String strRedSvg = strTmpName.substring(0, strTmpName.lastIndexOf(".")) + "_red.svg";
							String strMskSvg = strTmpName.substring(0, strTmpName.lastIndexOf(".")) + "_msk.svg";

							// 変更前ファイル名
							Path sourcePath = Paths.get(strTmpDir + documentId + "/" + strTmpName);
							// 変更後のファイル名
							Path targetPath = Paths.get(strTmpDir + documentId + "/" + strRedSvg);
							Files.copy(sourcePath, targetPath);
							targetPath = Paths.get(strTmpDir + documentId + "/" + strMskSvg);
							Files.copy(sourcePath, targetPath);
							Files.delete(sourcePath);

							// htmlも変更
							strRedHtml = strRedHtml.replaceFirst(documentId + "/" + strTmpName,
									documentId + "/" + strRedSvg);
							strRedHtml = strRedHtml.replaceFirst(documentId + "/" + strTmpName + "\"",
									documentId + "/" + strRedSvg + " \"id='red" + (intSvgCnt + intCnt) + "'");

							strMaskHtml = strMaskHtml.replaceFirst(documentId + "/" + strTmpName,
									documentId + "/" + strMskSvg);
							strMaskHtml = strMaskHtml.replaceFirst(documentId + "/" + strTmpName + "\"",
									documentId + "/" + strMskSvg + " \"id='msk" + (intSvgCnt + intCnt) + "'");
							intCnt++;
						} // if

					} // for
					objLog.info("SVGファイル修正完了");

				} // if

				String strMaskOutPath = strTmpDir + "mask_" + strHtmlName;
				String strRedOutPath = strTmpDir + "red_" + strHtmlName;

				if(!status.equals("4")) {
					objLog.info("html出力開始");
					// htmlを出力する(黒塗り)
					if (objFileCnt.writeFile(strMaskOutPath, strMaskHtml)) {
						objLog.info("maskHTML完了");
					} else {
						objLog.error("maskHTML生成失敗");
					}
					// htmlを出力する(赤文字)
					if (objFileCnt.writeFile(strRedOutPath, strRedHtml)) {
						objLog.info("赤文字HTML完了");
					} else {
						objLog.error("赤文字HTML生成失敗");
					}
				}

			} // synchronized

			synchronized (this) {
				// ページカウント取得
				intPageCnt = objFileCnt.aspPageGet(strMaskHtml);
				hashMap.put("strPageCnt", intPageCnt + "");
				hashMap.put("strEditMarker", strEditMarker);
				hashMap.put("aiData", aiData);
				hashMap.put("strHeight", strHeight);
			} // synchronized

		} catch (Exception e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} // try

		return hashMap;

	} // method

} // class
