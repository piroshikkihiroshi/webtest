/**
 * 名称：MaskDocMarkerService.java
 * 機能名：黒塗り処理黒塗り文書黒塗り箇所保存情報連携
 * 概要：黒塗り処理にて使用する黒塗り文書黒塗り箇所保存情報への連携用サービス
 */

package jp.co.nec.docmng.blackPaint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.blackPaint.entity.MaskDocMarkerEntBlackPaint;
import jp.co.nec.docmng.blackPaint.repository.MaskDocMarkerMapPaint;

/**
 * 黒塗り処理黒塗り文書黒塗り箇所保存情報連携
 */
@Service
public class MaskDocMarkerServicePaint {
    @Autowired
    private MaskDocMarkerMapPaint maskDocMarkerMapPaint;

	/**
	 * データ登録処理
	 * @param objEnt 登録内容を格納したentity
	 */
    @Transactional
    public void insertMaskDocument(MaskDocMarkerEntBlackPaint objEnt) {
        maskDocMarkerMapPaint.insertMaskDocMarker(objEnt);
    } //insertMaskDocument

	/**
	 * ドキュメントID指定による取得
	 * @param documentId 取得条件となるドキュメントID
	 * @return 取得したデータのリスト
	 */
    @Transactional
    public List<MaskDocMarkerEntBlackPaint> selectMaskDocMarker(Integer documentId) {
        return maskDocMarkerMapPaint.selectMaskDocMarker(documentId);
    } //insertMaskDocument
    
    /**
	 * ドキュメントID指定による取得
	 * @param documentId 取得条件となるドキュメントID
	 * @return 取得したデータのリスト
	 */
    @Transactional
    public List<MaskDocMarkerEntBlackPaint> selectUserMaskDocMarker(Integer documentId ,String userId) {
        return maskDocMarkerMapPaint.selectUserMaskDocMarker(documentId,userId);
    } //insertMaskDocument

	/**
	 * ドキュメントID指定による削除処理
	 * @param document_id 削除条件となるドキュメントID
	 */
    @Transactional
    public void deleteMarkerDoc(Integer document_id) {
        maskDocMarkerMapPaint.deleteMarkerDoc(document_id);
    } //deleteMarkerDoc
    
	/**
	 * ドキュメントIDとユーザーID指定による削除処理
	 * @param document_id 削除条件となるドキュメントID
	 * @param user_id 削除条件となるUserID
	 */
    @Transactional
    public void deleteUserMarkerDoc(Integer document_id,String user_id) {
        maskDocMarkerMapPaint.deleteUserMarkerDoc(document_id,user_id);
    } //deleteMarkerDoc

	/**
	 * 黒塗り箇所ポリシーの更新処理
	 * @param targetPolicy 更新条件のポリシーID
	 * @param objEnt 更新値を格納したentity
	 */
    @Transactional
    public void updateMarkerDoc(Integer targetPolicy, MaskDocMarkerEntBlackPaint objEnt) {
        maskDocMarkerMapPaint.updateMarkerDoc(targetPolicy, objEnt);
    } //updateMarkerDoc

	/**
	 * 黒塗り箇所ポリシーID指定による取得
	 * @param policyId 取得条件となる黒塗り箇所ポリシーID
	 * @return 取得したデータのリスト
	 */
    @Transactional
    public List<MaskDocMarkerEntBlackPaint> findMakerPolicyId(Integer policyId) {
        return maskDocMarkerMapPaint.findMakerPolicyId(policyId);
    } //findMakerPolicyId

} //PolicyInfoServiceApi
