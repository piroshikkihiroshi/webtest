/**
 * 名称：SaveTmpReopenCnt.java
 * 機能名：一時保存再開Control
 * 概要：一時保存再開機能のControlを行う。
 */

package jp.co.nec.docmng.blackPaint.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.blackPaint.entity.MaskDocMarkerEntBlackPaint;
import jp.co.nec.docmng.blackPaint.service.DocInfoServicePaint;
import jp.co.nec.docmng.blackPaint.service.MaskDocMarkerServicePaint;

/**
 * 紐付け機能のControlを行う。
 */
@RestController
public class LinkOpen {

	/**
	 * context サーブレットのRealPathを取得する
	 */
	@Autowired
	ServletContext context;

	@Autowired
	MaskDocMarkerServicePaint maskDocMarkerServicePaint;
	@Autowired
	DocInfoServicePaint docInfoService;

	/**
	 * objLog log出力に使用する
	 */
	static Logger objLog = LoggerFactory.getLogger(LinkOpen.class);

	/**
	 * PAGE_CLASS ページを判定するHTMLClass。ページをSplitするのに使用する
	 */
	static String PAGE_CLASS = "awdiv awpage";

	/**
	 * ARR_HEAD ファイル名、フォルダ名を判定するために使用する
	 */
	static String[] ARR_HEAD = { "mask_", "red_" };

	/**
	 * 紐づけ時初期動作メソッド
	 * 紐づけ時初期動作時の処理制御をする。
	 * @param documentId ドキュメントID
	 * @param UserId ユーザID
	 * @param strTmpDir ファイル出力先フォルダパス
	 * @param response HttpServletResponse
	 * @param model 引渡しパラメータ用モデル
	 * @return policy等の情報
	 */
	@ResponseBody
	@PostMapping("/blackpaint/LinkOpen")
	@ResponseStatus(HttpStatus.OK)
	public synchronized String SaveTmpDocCntRest(
			@RequestBody String documentId,
			@CookieValue(value = "user_id") String UserId,
			@CookieValue(value = "strTmpDirName",required=false) String strTmpDir,
			HttpServletResponse response,Model model) {

		if (UserId==null) UserId="";

		objLog.info("UserId:"+UserId);


		//メンバ変数初期化
		int intDocumentId = Integer.parseInt(documentId); //documentId

		List<MaskDocMarkerEntBlackPaint> listInfo = null;

		try {
			//policy等取得
			listInfo = maskDocMarkerServicePaint.selectMaskDocMarker(intDocumentId);

		} catch (Exception e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} //try


		String strRet = "";
		//jsonにしてpolicy等の情報を返す
		ObjectMapper objMapper = new ObjectMapper();
		try {
			strRet = objMapper.writeValueAsString(listInfo);
		} catch (JsonProcessingException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} //if

		return strRet;

	} //method

	/**
	 * エラー画面遷移(一時保存再開処理)
     * @param e 発生したエラー
     * @param response HTTPレスポンス
     * @param model 引渡しパラメータ用モデル
     * @return 遷移先アドレス
	 */
	@ExceptionHandler(Exception.class)
	public String handleException(Exception e, HttpServletResponse response, Model model) {

		//GCを明示的によんでメモリ解放
		//System.gc();

		response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		objLog.error("Error occurred.", e);
		StringWriter objSw = new StringWriter();
		PrintWriter objPw = new PrintWriter(objSw);
		e.printStackTrace(objPw);
		objPw.flush();
		String strError = objSw.toString();
		try {
			objSw.close();
			objPw.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		} //try

		model.addAttribute("errorMessage", e.getMessage() + "\r\n" + "StackTrace" + "\r\n" + strError) ;

		return "blackPaint/Fail";
	} //method

} //MaskHtmlCnt
