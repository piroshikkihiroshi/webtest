/**
 * 名称：TmpMaskDocMarkerMapPaint.java
 * 機能名：黒塗り処理黒塗り文書黒塗り箇所一時保存情報連携
 * 概要：黒塗り処理にて使用する黒塗り文書黒塗り箇所一時保存情報への連携用レポジトリ
 */

package jp.co.nec.docmng.blackPaint.repository;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import jp.co.nec.docmng.blackPaint.entity.TmpMaskDocMarkerEntBlackPaint;

/**
 * 黒塗り処黒塗り文書黒塗り箇所一時保存情報連携
 */
@Mapper
public interface TmpMaskDocMarkerMapPaint {

	/**
	 * データ登録処理
	 * @param objEnt 登録内容を格納したentity
	 */
    @Insert("INSERT INTO common.tmp_mask_document_marker(document_id, user_id, marker_start_cd, marker_end_cd, marker_policy, marker_remarks, create_time,update_time) VALUES ( #{documentId}, #{userId}, #{markerStartCd}, #{markerEndCd}, #{markerPolicy}, #{markerRemarks}, #{createTime},#{updateTime})")
    public void insertTmpMaskDocMarker(TmpMaskDocMarkerEntBlackPaint objEnt);

	/**
	 * ドキュメントID、ユーザID指定による取得
	 * @param document_id 取得条件となるドキュメントID
	 * @param user_id 取得条件となるユーザID
	 * @return 取得したデータのリスト
	 */
    @Select("SELECT marker_id, document_id, user_id, marker_start_cd, marker_end_cd, marker_policy, marker_remarks, create_time, update_time FROM common.tmp_mask_document_marker WHERE document_id = #{document_id} and user_id = #{user_id} ORDER BY marker_id")
    public List<TmpMaskDocMarkerEntBlackPaint> selectTmpMaskDocMarker(Integer document_id,String user_id);

	/**
	 * ドキュメントID、ユーザID指定による削除処理
	 * @param document_id 削除条件となるドキュメントID
	 * @param user_id 削除条件となるユーザID
	 */
    @Delete("DELETE FROM common.tmp_mask_document_marker WHERE document_id = #{document_id} and user_id = #{user_id}")
    public void deleteTmpMarkerDoc(Integer document_id,String user_id);

	/**
	 * 黒塗り箇所ポリシーIDの更新処理
	 * @param targetPolicy 更新条件のポリシーID
	 * @param objEnt 更新値を格納したentity
	 */
    @Update("UPDATE common.tmp_mask_document_marker SET marker_policy = #{objEnt.markerPolicy} , update_time = #{objEnt.updateTime} WHERE marker_policy = #{targetPolicy}")
    public void updateTmpMarkerDoc(Integer targetPolicy, TmpMaskDocMarkerEntBlackPaint objEnt);

	/**
	 * 黒塗り箇所ポリシーID指定による取得
	 * @param marker_policy 取得条件となる黒塗り箇所ポリシーID
	 * @return 取得したデータのリスト
	 */
    @Select("SELECT marker_id, document_id, user_id, marker_start_cd, marker_end_cd, marker_policy, marker_remarks, create_time, update_time FROM common.tmp_mask_document_marker WHERE marker_policy = #{marker_policy} ORDER BY marker_id")
    public List<TmpMaskDocMarkerEntBlackPaint> findMakerPolicyId(Integer marker_policy);

} //interface
