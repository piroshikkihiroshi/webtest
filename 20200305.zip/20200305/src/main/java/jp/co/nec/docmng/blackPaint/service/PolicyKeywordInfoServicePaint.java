/**
 * 名称：PolicyKeywordInfoServicePaint.java
 * 機能名：黒塗り処理黒塗りポリシーキーワード情報連携
 * 概要：黒塗り処理にて使用する黒塗りポリシーキーワード情報への連携用サービス
 */

package jp.co.nec.docmng.blackPaint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.blackPaint.entity.PolicyKeywordInfoBlackPaint;
import jp.co.nec.docmng.blackPaint.repository.PolicyKeywordInfoMapPaint;
import jp.co.nec.docmng.manage.entity.PolicyKeywordInfo;

/**
 * 黒塗り処理黒塗りポリシーキーワード情報連携
 */
@Service
public class PolicyKeywordInfoServicePaint {

	@Autowired
	private PolicyKeywordInfoMapPaint policyKeywordInfoMapPaint;

	/**
	 * 全件取得
	 * @return 検索結果
	 */
    @Transactional
    public List<PolicyKeywordInfoBlackPaint> findAll(){
        List<PolicyKeywordInfoBlackPaint> entityList = policyKeywordInfoMapPaint.findAll();
        return entityList;
    }
	
	/**
	 * データ登録処理
	 * @param objEnt 登録内容を格納したentity
	 */
	@Transactional
	public void insertPolicyKeyword(PolicyKeywordInfoBlackPaint objEnt) {
		policyKeywordInfoMapPaint.insertPolicyKeyword(objEnt);
	} //method

} //PolicyInfoServiceApi
