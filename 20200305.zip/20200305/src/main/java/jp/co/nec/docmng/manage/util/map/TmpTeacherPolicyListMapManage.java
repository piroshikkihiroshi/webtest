/**
 * 名称：TmpTeacherPolicyListMapManage.java
 * 機能名：管理系教師データ(黒塗り箇所摘出)登録画面一時保存情報連携
 * 概要：管理系にて使用する教師データ(黒塗り箇所摘出)登録画面一時保存情報への連携用レポジトリ
 */

package jp.co.nec.docmng.manage.util.map;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import jp.co.nec.docmng.manage.entity.TmpTeacherPolicyList;

/**
 * 管理系教師データ(黒塗り箇所摘出)登録画面一時保存情報連携
 */
@Mapper
public interface TmpTeacherPolicyListMapManage {

	/**
	 * 全件取得
	 * @return 検索結果
	 */
    @Select("select * from admin.tmp_teacher_policy_list order by sort_id")
    public List<TmpTeacherPolicyList> findAll();

    /**
     * 全削除実施
     */
    @Delete("delete from admin.tmp_teacher_policy_list")
    public void deleteAll();

    /**
     * 登録処理
	 * @param record 登録情報
     */
    @Insert("insert into admin.tmp_teacher_policy_list (user_id, sort_id, policy_id,directory_path, create_time, update_time) values (#{userId}, #{sortId}, #{policyId},#{directoryPath}, #{createTime}, #{updateTime})")
    public void insertTmpPolicy(TmpTeacherPolicyList record);

    /**
     * その他ポリシーで更新する
	 * @param targetPolicy 更新条件のポリシーID
	 * @param tmpTeacherPolicyList 更新値を格納したentity
     */
    @Update("update admin.tmp_teacher_policy_list set policy_id = #{tmpTeacherPolicyList.policyId}, update_time = #{tmpTeacherPolicyList.updateTime} where policy_id = #{targetPolicy}")
    public void updateOther(Integer targetPolicy, TmpTeacherPolicyList tmpTeacherPolicyList);

}
