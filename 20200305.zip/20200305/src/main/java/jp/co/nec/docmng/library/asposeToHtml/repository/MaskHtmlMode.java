/**
 * 名称：MaskHtmlMode.java
 * 機能名：検索用テキスト取得クラス
 * 概要：HTMLファイルから検索用テキストを抜き出す処理を提供するクラス
 */

package jp.co.nec.docmng.library.asposeToHtml.repository;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * HTMLファイルから検索用テキストを抜き出す処理を提供するクラス
 */
public class MaskHtmlMode {

	/**
	 * strpath_iで指定したファイルをすべて読み込む
	 * @param strpath_i 対象のHTMLファイルのパス
	 * @return 読み込んだ文字列
	 * @throws IOException 入出力エラー
	 */
	public String readAll(final String strpath_i) throws IOException {
		return Files.lines(Paths.get(strpath_i), Charset.forName("UTF-8"))
				.collect(Collectors.joining(System.getProperty("line.separator")));
	} //readAll

	/**
	 * strHtml_i(htmlString)のBodyを正規表現で抜き出す(改行 必要以外の半角スペース削除)
	 * @param strHtml_i HTMLファイルの内容
	 * @return 抜き出したBody
	 */
	public String getBodyCompress(String strHtml_i) {
		String strRet = strHtml_i;

		//改行を削除
		strRet = strRet.replaceAll("\r\n", "");

		//2つ以上の半角スペースを一つにまとめる
		strRet = strRet.replaceAll("\\s+", " ");

		String strPattern = "\\<body\\>.+\\</body\\>";
		Pattern objPattern = Pattern.compile(strPattern);
		Matcher objMatch = objPattern.matcher(strRet);
		objMatch.find();
		strRet = objMatch.group();

		return strRet;
	} //getBody

	/**
	 * 全文検索エンジンに渡すための文字列を取得する
	 * @param strBody_i HTML文字列からBody要素だけを抜き出したもの
	 * @return タグ無し連結文字列
	 */
	public String getIllegalText(String strBody_i) {
		String strRet = strBody_i;
		//tagを全て除去
		String strPattern = "<(\"[^\"]*\"|'[^']*'|[^'\">])*>";
		strRet = strRet.replaceAll(strPattern, "");
		//trim
		strRet = strRet.trim();

		//半角スペース記号置換
		//		strPattern="&#xa0;";
		//		strRet = strRet.replace(strPattern, " ");

		return strRet;
	} //getIllegalText

} //class
