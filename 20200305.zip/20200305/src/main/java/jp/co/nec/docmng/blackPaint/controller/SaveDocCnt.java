/**
 * 名称：SaveDocCnt.java
 * 機能名：保存Control
 * 概要：保存機能のControlを行う。
 */

package jp.co.nec.docmng.blackPaint.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.UUID;

import javax.servlet.ServletContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.zeroturnaround.zip.ZipUtil;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.blackPaint.entity.DocumentInfoEntPaint;
import jp.co.nec.docmng.blackPaint.entity.MaskDocMarkerEntBlackPaint;
import jp.co.nec.docmng.blackPaint.entity.MaskDocumentEntBlackPaint;
import jp.co.nec.docmng.blackPaint.entity.PolicyKeywordInfoBlackPaint;
import jp.co.nec.docmng.blackPaint.logic.HtmlToPdf.HtmlToPdfModel;
import jp.co.nec.docmng.blackPaint.logic.dirFile.DirCnt;
import jp.co.nec.docmng.blackPaint.logic.dirFile.FileCnt;
import jp.co.nec.docmng.blackPaint.logic.maskHtml.MaskHtmlModel;
import jp.co.nec.docmng.blackPaint.service.DocInfoServicePaint;
import jp.co.nec.docmng.blackPaint.service.MaskDocMarkerServicePaint;
import jp.co.nec.docmng.blackPaint.service.MaskDocumentServicePaint;
import jp.co.nec.docmng.blackPaint.service.PolicyKeywordInfoServicePaint;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocMarkerServicePaint;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocumentServicePaint;

/**
 * 保存機能のControlを行う。
 */
@Controller
public class SaveDocCnt {

	/**
	 * サーブレットのRealPathを取得する
	 */
	@Autowired
	ServletContext context;

	@Autowired
	MaskDocumentServicePaint maskDocumentService;
	@Autowired
	MaskDocMarkerServicePaint maskDocMarkerService;
	@Autowired
	PolicyKeywordInfoServicePaint policyKeywordInfoServiceBlackPaint;
	@Autowired
	TmpMaskDocumentServicePaint tmpMaskDocumentService;
	@Autowired
	TmpMaskDocMarkerServicePaint tmpMaskDocTmpMarkerService;
	@Autowired
	DocInfoServicePaint docInfoService;

	/**
	 * log出力に使用する
	 */
	static Logger objLog = LoggerFactory.getLogger(SaveDocCnt.class);

	/**
	 * ページを判定するHTMLClass。ページをSplitするのに使用する
	 */
	static String PAGE_CLASS = "awdiv awpage"; //splitするページのHTMLClass

	/**
	 * ファイル名、フォルダ名を判定するために使用する
	 */
	static String[] ARR_HEAD = { "mask_", "red_" }; //ファイル名、フォルダ名のヘッダー配列

	/**
	 * 保存メソッド、保存を押下したときの処理制御をする。<br>
	 * 対象はPROCENTER/C と mask_document
	 * @param strJson jsonString
	 * @param strFilePath ファイルパス
	 * @param UserId ユーザID
	 * @param strTmpDir_i 作業ファイルパス
	 * @param UserName ユーザ名
	 * @param model 引渡しパラメータ用モデル
	 * @return 遷移先アドレス
	 * @throws ParseException 変換処理エラー
	 */
	@SuppressWarnings("deprecation")
	@PostMapping("/SaveDocCnt")
	public synchronized String SaveTmpDocCntRest(

			@RequestParam("strJson") String strJson,
			@RequestParam("strFilePath") String strFilePath,
			@CookieValue(value = "user_id", required = false) String UserId,
			@CookieValue(value = "strTmpDirName") String strTmpDir_i,
			@CookieValue(value = "user_name", required = false) String UserName,
			Model model) throws ParseException {

		if (UserId == null) {
			UserId = "";
		}

		if (!strJson.equals("")) {
			objLog.info("json："+ strJson);
		} //if

		//モデル初期化
		FileCnt objFileCnt = new FileCnt();
		DirCnt objDirCls = new DirCnt();
		HtmlToPdfModel objPdfCls = new HtmlToPdfModel();
		MaskHtmlModel objHtmllCls = new MaskHtmlModel();

		//メンバ変数初期化
		String strTmpDir = ""; //黒塗り編集画面で処理したHTMLが格納されたTMPディレクトリ名。
		String strFileName = ""; //オリジナルwordファイル名。
		int intDocumentId = -1; //documentId

		String strBasePath = ""; //黒塗り作成時の作業フォルダ
		String strFileOutDir = ""; //PDF出力フォルダ
		String strRealPath = context.getRealPath("/");

		String strTmpUuid = "";

		String updateTime =""; //更新日時
		String retentionPeriod=""; //保存期間
		int cateId=0; //categoryId
		String[] arrPrint = null; //印刷範囲のインデックス true：印刷 false 印刷無し
		String[] arrMaskPaths = null; //黒塗りpdfパス
		String[] arrRedPaths = null; //黒塗り候補pdfパス

		//以下黒塗りリスト配列
		String[] keywords = null;
		String[] pages = null;
		String[] policyNames = null;
		String[] Reasons = null;
		String[] Remarks = null;

		//以下黒塗りリスト配列
		String[] glArrBfIds = null;
		String[] glArrAfIds = null;
		String[] glArrPolicys = null;

		String strOrgOutDir= "";

		byte[] byteZip = null; //zipにした際のbyte配列
		File objZipFile = null;

//		strTmpUuid = String.valueOf(System.currentTimeMillis());
		strTmpUuid = UUID.randomUUID().toString() ;

		// 20200227 紐づけ対応
		String[] strHtmlUuid = null;
		String strRedBlackPath = "";
		String strMskBlackPath = "";

		//今回のみ使用
		ResourceBundle objRb = null;

		//POSTされたjsonをパースする
		ObjectMapper objMapper = new ObjectMapper();
		List<Map<String, String[]>> objTmpList = null;
		TypeReference<List<Map<String, String[]>>> objType = new TypeReference<List<Map<String, String[]>>>() {
		};

		try {
			objTmpList = objMapper.readValue(strJson, objType);
		} catch (JsonParseException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} catch (JsonMappingException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} catch (IOException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} //try

		HashMap<String, String[]> objMap = (HashMap<String, String[]>) objTmpList.get(0);

		for (String strKey : objMap.keySet()) {
			switch (strKey) {
			case "tmpDir":
				strTmpDir = objMap.get(strKey)[0];
				break;
			case "strFileName":
				strFileName = objMap.get(strKey)[0];
				break;
			case "updateTime":
				updateTime = objMap.get(strKey)[0];
				break;
			case "retentionPeriod":
				retentionPeriod = objMap.get(strKey)[0];
				break;
			case "cateId":
				cateId = Integer.parseInt(objMap.get(strKey)[0]);
				break;
			case "documentId":
				intDocumentId = Integer.parseInt(objMap.get(strKey)[0]);
				break;
			case "arrPrint":
				arrPrint = (String[]) objMap.get(strKey);
				break;
			case "arrMaskPaths":
				arrMaskPaths = (String[]) objMap.get(strKey);
				break;
			case "arrRedPaths":
				arrRedPaths = (String[]) objMap.get(strKey);
				break;
				//*******以下黒塗りリスト用
			case "keywords":
				keywords = (String[]) objMap.get(strKey);
				break;
			case "pages":
				pages = (String[]) objMap.get(strKey);
				break;
			case "policyNames":
				policyNames = (String[]) objMap.get(strKey);
				break;
			case "Reasons":
				Reasons = (String[]) objMap.get(strKey);
				break;
			case "Remarks":
				Remarks = (String[]) objMap.get(strKey);
				break;
			case "glArrBfIds":
				glArrBfIds = (String[]) objMap.get(strKey);
				break;
			case "glArrAfIds":
				glArrAfIds = (String[]) objMap.get(strKey);
				break;
			case "glArrPolicys":
				glArrPolicys = (String[]) objMap.get(strKey);
				break;
			default:
				break;
			}//switch

		} //for



		//拡張子無しファイル名取得
		String strFileWithoutExtension = objFileCnt.getNameWithoutExtension(strFileName);
		strBasePath = strRealPath + strTmpDir_i ;
		String strListOutDir = strBasePath + "listAll/";
		String strListAllPath = "";
		String strListAll = "";

		//DocumentIDでdocument_infoから情報を取得
		List<DocumentInfoEntPaint> listDoc=null;
		listDoc =docInfoService.selectDocInfo(intDocumentId);
		strFilePath = listDoc.get(0).getFilePath();


		try {
			strListAllPath = objHtmllCls.makeListPdf(strJson, UserName, strListOutDir, strRealPath, strFileWithoutExtension, strFilePath, strFileName);
			strListAll = objFileCnt.readAll(strListAllPath);
		} catch (IOException e) {

			objLog.info("makeBrackPaint err(IOException)", e);
		} catch (Exception e) {
			objLog.info("makeBrackPaint err(Exception)", e);
		} //try

//		//出力フォルダ(result)作成
		strBasePath = strRealPath + strTmpDir;

		objLog.info("作業ベースフォルダ：" + strBasePath);

		strFileOutDir = strBasePath + "result" + strTmpUuid + "/";

		strOrgOutDir = strBasePath + intDocumentId + strTmpUuid + "/";


		try {
			objDirCls.makeDirWithCheck(strFileOutDir);

			//結合PDFファイル作成
			PDFMergerUtility objUtMask = new PDFMergerUtility();
			PDFMergerUtility objUtRed = new PDFMergerUtility();
			for (int i = 1; i < arrPrint.length; i++) { //ページは1ページ目からなので1からスタート
				String strOutChk = arrPrint[i];
				if (strOutChk.equals("true")) { //trueの場合結合対象
//					File objFileMask = new File(strRealPathWithoutSlash+arrMaskPaths[i-1]);
//					File objFileRed = new File(strRealPathWithoutSlash+arrRedPaths[i-1].replaceAll("mask_","red_"));
					File objFileMask = new File(strRealPath+arrMaskPaths[i-1]);
					File objFileRed = new File(strRealPath+arrRedPaths[i-1].replaceAll("mask_","red_"));
					objUtMask.addSource(objFileMask);
					objUtRed.addSource(objFileRed);
					objLog.info("PDF:"+i+"枚目結合");
				} //if
			} //for
			objUtMask.setDestinationFileName(strFileOutDir+strFileWithoutExtension+"(公開用).pdf");
			objUtMask.mergeDocuments();

			objUtRed.setDestinationFileName(strFileOutDir+strFileWithoutExtension+"(査閲用).pdf");
			objUtRed.mergeDocuments();

			String strListPdfPath = strFileOutDir+strFileWithoutExtension+"(黒塗諸元).pdf";
			try {
				//黒塗りリストはとりあえず出なくてもすすめる
	    		objPdfCls.convertHtmlToPdf(strListAllPath,strListPdfPath,listDoc);
			} catch (Exception e) {
	    		objLog.info("黒塗りリスト出力失敗",e);
			} //try


    		objLog.info("PDF結合処理完了");

    		//※※※※※※※暫定 設定ファイルから取得したフォルダにコピー
    		//格納情報(今回のPoCのみ
    		objLog.info("保存Directoryに保存処理開始");
    		try {
        		objRb = ResourceBundle.getBundle("config/procenter");
        		String strSaveDir = objRb.getString("save_directory");
        		objLog.info("保存Directory" + strSaveDir);
//    			FileUtils.copyDirectory(new File(strFileOutDir), new File(strSaveDir));
        		//環境依存の為1ファイルずつコピー

        		objLog.info("公開用pdf:" + strFileOutDir+strFileWithoutExtension+"(公開用).pdf");
        		objLog.info("公開用保存先:" + strSaveDir+strFileWithoutExtension+"(公開用).pdf");
                Path sourcePath = Paths.get(strFileOutDir+strFileWithoutExtension+"(公開用).pdf");
                Path targetPath = Paths.get(strSaveDir+strFileWithoutExtension+"(公開用).pdf");
                synchronized (this) {
                	Files.copy(sourcePath, targetPath, StandardCopyOption.REPLACE_EXISTING); //上書き保存
                } //synchronized
        		objLog.info("公開用保存先:" + strSaveDir+strFileWithoutExtension+"(公開用).pdf保存成功");

        		objLog.info("査閲用pdf:" + strFileOutDir+strFileWithoutExtension+"(査閲用).pdf");
        		objLog.info("査閲用保存先:" + strSaveDir+strFileWithoutExtension+"(査閲用).pdf");
                sourcePath = Paths.get(strFileOutDir+strFileWithoutExtension+"(査閲用).pdf");
                targetPath = Paths.get(strSaveDir+strFileWithoutExtension+"(査閲用).pdf");
                synchronized (this) {
                	Files.copy(sourcePath, targetPath, StandardCopyOption.REPLACE_EXISTING); //上書き保存
                } //synchronized
        		objLog.info("査閲用保存先:" + strSaveDir+strFileWithoutExtension+"(査閲用).pdf保存成功");

        		objLog.info("黒塗諸元pdf:" + strFileOutDir+strFileWithoutExtension+"(黒塗諸元).pdf");
        		objLog.info("黒塗諸元保存先:" + strSaveDir+strFileWithoutExtension+"(黒塗諸元).pdf");
                sourcePath = Paths.get(strFileOutDir+strFileWithoutExtension+"(黒塗諸元).pdf");
                targetPath = Paths.get(strSaveDir+strFileWithoutExtension+"(黒塗諸元).pdf");
                synchronized (this) {
                	Files.copy(sourcePath, targetPath, StandardCopyOption.REPLACE_EXISTING); //上書き保存
                } //synchronized
        		objLog.info("黒塗諸元保存先:" + strSaveDir+strFileWithoutExtension+"(黒塗諸元).pdf保存成功");

        		objLog.info("保存Directoryに保存完了：" + strSaveDir);
			} catch (Exception e) {
				objLog.info("PDF保存に失敗しました：",e);
			} //try


    		//zipに固める
    		objLog.info("zip処理開始");
    		try {
    			// 20200227 紐づけ対応
    			//html群をコピー
    			objDirCls.makeDirWithCheck(strOrgOutDir);
    			FileUtils.copyDirectory(new File(strRealPath + strTmpDir+intDocumentId), new File(strOrgOutDir+intDocumentId));
    			Files.copy(Paths.get(strRealPath + strTmpDir+"mask_"+intDocumentId+".html"), Paths.get(strOrgOutDir+"mask_"+intDocumentId+".html"), StandardCopyOption.REPLACE_EXISTING);
    			Files.copy(Paths.get(strRealPath + strTmpDir+"red_"+intDocumentId+".html"), Paths.get(strOrgOutDir+"red_"+intDocumentId+".html"), StandardCopyOption.REPLACE_EXISTING);

        		String strZipOut = strRealPath + "zip" + strTmpUuid + "/" + "mask.zip";
        		objDirCls.makeDirWithCheck(strRealPath + "zip" + strTmpUuid + "/");

        		ZipUtil.pack(new File(strOrgOutDir), new File(strZipOut));

//        		ZipUtil.pack(new File(strFileOutDir), new File(strZipOut));

        		//zipをbyte配列にする
    			objZipFile = new File(strZipOut);
    			byteZip = Files.readAllBytes(objZipFile.toPath());
        		objLog.info("zip処理完了");
			} catch (Exception e) {
				objLog.info("ZIPに失敗しました：",e);
			} //try

		} catch (IOException e1) {
			objLog.error("err message", e1);
		} catch (Exception e1) {
			objLog.error("err message", e1);
		} //try


		// システム日付を取得する
		Timestamp sysdate = Timestamp.valueOf(LocalDateTime.now());
		//エンティティインスタンス化
		MaskDocumentEntBlackPaint objEnt = new MaskDocumentEntBlackPaint();

		//DBに格納
		objLog.info("DB保存処理開始");

		//document_infoテーブル
		//String→date整形
		objLog.info("String→date整形開始");
		retentionPeriod= retentionPeriod.replace(retentionPeriod, retentionPeriod+" 00:00:00");
		SimpleDateFormat sdFormat = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");
		Date dateRetentionPeriod = sdFormat.parse(retentionPeriod);

		sdFormat = new SimpleDateFormat("yyyy/MM/dd hh:mm");
		Date dateUpdateTime = sdFormat.parse(updateTime);
		objLog.info("String→date整形終了");

		//document_infoのupdateはなくす
//		docInfoService.updateDocFileInfo(intDocumentId,cateId,dateRetentionPeriod,dateUpdateTime);


		//policy_keyword_info table
		PolicyKeywordInfoBlackPaint objEnt3 = null;
		for (int i = 0; i < glArrBfIds.length; i++) {
			objEnt3 = new PolicyKeywordInfoBlackPaint();
			objEnt3.setPolicyId(Integer.parseInt(glArrPolicys[i]));
			if(keywords[i].length() > 128) {
				keywords[i] = keywords[i].substring(0, 128);
			} //if
			objEnt3.setPolicyKeyword(keywords[i]);
			objEnt3.setCreateTime(sysdate);
			objEnt3.setUpdateTime(sysdate);
			policyKeywordInfoServiceBlackPaint.insertPolicyKeyword(objEnt3);
		} //for


		//mask_document_markerのもとdocumentIdは削除
		maskDocMarkerService.deleteUserMarkerDoc(intDocumentId, UserId);
		//同様のユーザのデータは削除
		maskDocumentService.deleteDoc(intDocumentId, UserId);

		try {

			//紐づけ対応 3レコード挿入
			//tmp_mask_documentテーブル //mask_status 1:黒塗り候補	2:黒塗り済み　3:黒塗りリスト
			for (int i = 1; i <= 3; i++) {
				objEnt.setDocumentId(intDocumentId);
				objEnt.setUserId(UserId);
				objEnt.setHtmlZipData(byteZip);
				objEnt.setUpdateTime(sysdate);
				objEnt.setCreateTime(sysdate);
				objEnt.setCategoryId(cateId);
				objEnt.setMaskStatus(i);
				maskDocumentService.insertMaskDocument(objEnt);

			} //for

			//markerTable
			MaskDocMarkerEntBlackPaint objEnt2 = null;
			for (int i = 0; i < glArrBfIds.length; i++) {
				objEnt2 = new MaskDocMarkerEntBlackPaint();
				objEnt2.setDocumentId(intDocumentId);
				objEnt2.setMarkerStartCd(glArrBfIds[i]);
				objEnt2.setMarkerEndCd(glArrAfIds[i]);
				objEnt2.setMarkerPolicy(Integer.parseInt(glArrPolicys[i]));
				if (Remarks.length == 0) {
					objEnt2.setMarkerRemarks("");
				} else {
					objEnt2.setMarkerRemarks(Remarks[i]);
				} //if insertTmpMaskDocument
				objEnt2.setUpdateTime(sysdate);
				objEnt2.setCreateTime(sysdate);
				objEnt2.setUserId(UserId);
				maskDocMarkerService.insertMaskDocument(objEnt2);

			} //for



    		objLog.info("DB保存処理終了");

		} catch (Exception e) {
			objLog.error("err message", e);
			System.err.println(e);
		} //try

		//DB削除処理
		objLog.info("DB保存処理開始");
		try {
			//markerTable
			tmpMaskDocTmpMarkerService.deleteTmpMarkerDoc(intDocumentId, UserId);
			//tmp_mask_documentテーブル対象削除
			tmpMaskDocumentService.deleteTmpDoc(intDocumentId, UserId);
			objLog.info("DB削除処理終了");
		} catch (Exception e) {
			objLog.error("err message", e);
			System.err.println(e);
		} //try

		//作業ディレクトリかたずけ
		try {
			//作業ディレクトリ,ファイルかたづけ
			objDirCls.delDirectory(strFileOutDir);
			objDirCls.delDirectory(strOrgOutDir);
			objZipFile.delete();
			objDirCls.delDirectory(strBasePath);
			objLog.info("作業ディレクトリ削除完了");
		} catch (Exception e) {
			objLog.error("作業ディレクトリ削除失敗",e);
		} //try


		//*************PROCENTER/Cの保存処理**********************

		//承認処理呼び出し
		String strApprovalUrl ="";
		try {
//			ProcnterWebApi objProCls = new ProcnterWebApi();
			objRb=null;
			objRb = ResourceBundle.getBundle("config/procenter");
			String strBaseUrl = objRb.getString("procenter_url");
			strApprovalUrl = strBaseUrl + "m.do?i=" + intDocumentId;
			objLog.info("PROCENTER承認呼び出しURL：" + strApprovalUrl);
//			objProCls.getUrlCall(strApprovalUrl);
//			objLog.info("PROCENTER承認呼び出し成功");
		} catch (Exception e) {
//			objLog.info("PROCENTER承認呼び出し失敗");
			objLog.error("err message", e);
		} //try

		//*************黒塗り画面終了**********************

		model.addAttribute("procenterUrl", strApprovalUrl) ;

		return "blackPaint/Success";
	} //getView1

	/**
	 * エラー画面遷移(黒塗り処理)
     * @param e 発生したエラー
     * @param request HTTPリクエスト
     * @param response HTTPレスポンス
     * @param model 引渡しパラメータ用モデル
     * @return 遷移先アドレス
	 */
	@ExceptionHandler(Exception.class)
	public String handleException(
			Exception e,
			HttpServletRequest request,
			HttpServletResponse response,
			Model model
			){
		//GCを明示的によんでメモリ解放
		//System.gc();


		//モデル初期化
		DirCnt objDirCls = new DirCnt();
		Cookie cookie[] = request.getCookies();
		String strTmpDir_i = "";
		if (cookie != null){
			for (int i = 0 ; i < cookie.length ; i++){
				if (cookie[i].getName().equals("strTmpDirName")){
					strTmpDir_i = cookie[i].getValue();
				} //if
			} //for
		} //if

		//作業ディレクトリかたずけ
		if(strTmpDir_i.equals(""))  {
			objLog.info("作業ディレクトリの取得が失敗しました");
		}else {
			try {
				//作業ディレクトリ,ファイルかたづけ
				objDirCls.delDirectory(context.getRealPath("/") + strTmpDir_i);
				objLog.info("作業ディレクトリ削除完了");
			} catch (Exception e1) {
				objLog.info("作業ディレクトリ削除失敗");
			} //try

		} //if


		response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		objLog.error("Error occurred.", e);
		StringWriter objSw = new StringWriter();
		PrintWriter objPw = new PrintWriter(objSw);
		e.printStackTrace(objPw);
		objPw.flush();
		String strError = objSw.toString();
		try {
			objSw.close();
			objPw.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		} //try

		model.addAttribute("errorMessage", e.getMessage() + "\r\n" + "StackTrace" + "\r\n" + strError) ;

		return "blackPaint/Fail";
	} //method


} //MaskHtmlCnt
