# coding: UTF-8
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from time import sleep
from datetime import datetime
import configparser
import distutils.util
# import ctypes #debug msgbox用 ctypes.windll.user32.MessageBoxW(0, "Your text", "Your title", 1)
#※※※※注意 基本クロームは最新版！！！

#独自定義
# from mailFunc import *

# Chrome Driver https://sites.google.com/a/chromium.org/chromedriver/downloads

#その他オプション
intWaitSec = 10
blDebug = True
strStTime='開始時刻：'+datetime.now().strftime("%Y/%m/%d %H:%M:%S")
strEdTime=''
strToday=datetime.now().strftime("%Y/%m/%d")

strTgtUrl='https://tabelog.com/'

# ブラウザのオプションを格納する変数。
options = Options()
if blDebug == False:
    options.add_argument('--headless') #Headlessモードを有効にする

try:
    #スマホモード(位置情報設定の為)
    options.add_argument("--user-agent=Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A403 Safari/8536.25");
    # ブラウザを起動する
    objWebDriver = webdriver.Chrome(executable_path='chromedriver.exe',chrome_options=options)    
    objWebDriver.implicitly_wait(intWaitSec) # 要素が見つかるまで10秒待つ設定(seconds)
    objWebDriver.get(strTgtUrl) # ブラウザでアクセスする   


except:
    strBody+= '\r\n'+'予期せぬエラーが発生しました。正確に掲示板情報を取得できていません。'+'\r\n'
    strSubject+='※エラー発生'
finally:
    # release
    objWebDriver.close()
    objWebDriver.quit()
    strEdTime='終了時刻：' + datetime.now().strftime("%Y/%m/%d %H:%M:%S")

    #send mail
    # strSubject+=' ' + strToday + ' '
    # if intBbsNoRead==0:
    #     strSubject+='未読なし'
    # else:
    #     strSubject+='未読あり'    
    # strBody+=strStTime + '\r\n' + strEdTime + '\r\n'
    # if blReadOut:
    #     strBody+='既読・未読ともに出力します。' + '\r\n'
    # else:
    #     strBody+='未読のみ出力します。' + '\r\n'
    # strBody+='未読/スレッド数・・・' + str(intBbsNoRead) + '/' + str(intBbsCount) + '\r\n'
    # strBody+=strHtmlBody
    # arrToAddr=strToAddr.split(',')

    # for objItem in arrToAddr:
    #     strSendMsg = createMailMsg(strFrommAddr, objItem, strBbc, strSubject, strBody)
    #     sendMailFromGmail(strFrommAddr, objItem, strSendMsg,strMailPass)





