package word;

import java.awt.Desktop;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.log4j.Logger;
import org.apache.poi.xwpf.converter.pdf.PdfConverter;
import org.apache.poi.xwpf.converter.pdf.PdfOptions;
import org.apache.poi.xwpf.usermodel.XWPFDocument;

public class DocxToPdfTest {
	static Logger objLog = Logger.getLogger(DocxToPdfTest.class);
	//	static FontCnt objFontCls = new FontCnt();
	final String MASK_MARK = "━"; //マスクする記号
	//	final String MASK_MARK = "■"; //マスクする記号
	final int EXCEL_SPACE = 3; //Excelの文字間隔は3px(仮定)
	final String PROPORTIONAL_STR = "Ｐ"; //プロポーショナルを判定(暫定)

	public static void main(String[] args) {
		// 処理前の時刻を取得
		long startTime = System.currentTimeMillis();

		//設定
		String strMaskMsg = "メイ";

		String strFilePath = "C:/Users/ueda tatsuya/Desktop/poisample-master/test.docx";
		String strCopyPath = strFilePath + "_" + System.currentTimeMillis() + ".pdf";
		//		String strFilePath = "C:/Users/ueda tatsuya/Desktop/poisample-master/test.doc";
		//		String strCopyPath = strFilePath + "_" + System.currentTimeMillis() + ".doc";


		DocxToPdfTest objWordTest = new DocxToPdfTest();
		objWordTest.docxToPdf(strFilePath, strCopyPath, strMaskMsg);

		// 処理後の時刻を取得
		long endTime = System.currentTimeMillis();

		objLog.info("開始時刻：" + startTime + " ms");
		objLog.info("終了時刻：" + endTime + " ms");
		objLog.info("処理時間：" + (endTime - startTime) + " ms");
		File objMakeFile = new File(strCopyPath);
		try {
			Desktop.getDesktop().open(objMakeFile);
		} catch (IOException e) {
			e.printStackTrace();
		} //try


	} //main


	/**
	 * @param strFilePath_i
	 * @param strOutPath_i
	 * @param strMaskMsg_i
	 */
	public void docxToPdf(String strFilePath_i, String strOutPath_i, String strMaskMsg_i) {
		XWPFDocument objDoc;
		InputStream objIS;
		try {
			String inputFile = strFilePath_i;
			String outputFile = strOutPath_i;

			System.out.println("inputFile:" + inputFile + ",outputFile:" + outputFile);
			InputStream in = new FileInputStream(inputFile);
			XWPFDocument document = new XWPFDocument(in);
			File outFile = new File(outputFile);
			OutputStream out = new FileOutputStream(outFile);
			PdfOptions options = null;
			PdfConverter.getInstance().convert(document, out, options);
		} catch (Exception e) {
			e.printStackTrace();

		} //try
	} 	//wordSetMask


} //WordTest
