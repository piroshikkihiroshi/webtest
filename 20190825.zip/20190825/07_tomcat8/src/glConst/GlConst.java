package glConst;

public class GlConst {
	public final static String PROJECT_NAME = "07_tomcat8";
//	public final static String PROJECT_NAME = "04_tomcatTest";
	public final static String TGT_FILE_NAME = "\\\\192.168.33.1\\poitest\\test.docx";
//	public final static String TGT_FILE_NAME = "\\\\yoks3104\\Project\\NES_文書管理システム\\99_tmp\\上田\\test.docx";

} //class
