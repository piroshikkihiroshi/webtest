package controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.zeroturnaround.zip.ZipUtil;

import glConst.GlConst;
import model.dirFile.FileCnt;
/**
 * Servlet implementation class HtmlCnt
 */
@WebServlet("/HtmlCnt")
public class WordHtmlCnt extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger objLog = Logger.getLogger(WordHtmlCnt.class);
    /**
     * @see HttpServlet#HttpServlet()
     */
    public WordHtmlCnt() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String strPackName = GlConst.PROJECT_NAME;
		request.setCharacterEncoding("UTF8");
		String strMakeFilePath = request.getParameter("wordHtmlPath");
		FileCnt objFileCnt = new FileCnt();
		objLog.info("対象パス：" + strMakeFilePath);

		String strFileName = strMakeFilePath.substring(strMakeFilePath.lastIndexOf("\\") + 1,strMakeFilePath.length());
		String strDirName = objFileCnt.getNameWithoutExtension(strFileName) + ".files";
		String strDirNamePath = strMakeFilePath.replace(strFileName,strDirName);
        String strRealPath = getServletContext().getRealPath("/");


        try {
            Path objSrcPath = Paths.get(strMakeFilePath);
            Path objTgtPath = Paths.get(strRealPath + "/" + strFileName);

            Files.move(objSrcPath, objTgtPath);

            //Directory copyが効家内場合、dirは圧縮→解凍
            String strZipFromNamePath = objFileCnt.getNameWithoutExtension(strFileName) + ".zip";
            String strZipFromPath = strMakeFilePath.replace(strFileName,strZipFromNamePath);

            objLog.info("wordをHTML化した際のzip処理開始");
            //一度圧縮
    		ZipUtil.pack(new File(strDirNamePath), new File(strZipFromPath));
            objLog.info("wordをHTML化した際のzip処理完了");
            //移動
            Path objSrcZipPath = Paths.get(strZipFromPath);
            Path objTgtZipPath = Paths.get(strRealPath + "/" + strZipFromNamePath);
            Files.move(objSrcZipPath, objTgtZipPath);

            objLog.info("wordをHTML化した際のzip解凍開始");
            //解凍先
    		ZipUtil.unpack(new File(strRealPath + "/" + strZipFromNamePath), new File(strRealPath + "/" + strDirName));

            objLog.info("wordをHTML化した際のzip解凍完了");
            objLog.info("移動が成功しました");
            objLog.info("/" + strPackName + "/" + strFileName + "へリダイレクトします。");
            response.sendRedirect("/" + strPackName + "/" + strFileName);


        } catch (IOException e) {
            e.printStackTrace();
        } //try

	} //doGet

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
