package controller;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

//import dirFile.FileCnt;

import model.dirFile.FileCnt;

/**
 * Servlet implementation class DlCnt
 */
@WebServlet("/DownloadCnt")
public class DownloadCnt extends HttpServlet {
	static Logger objLog = Logger.getLogger(DownloadCnt.class);
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DownloadCnt() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF8");
		FileCnt objFile = new FileCnt();
//		String strDlFilePath = request.getParameter("batPath");
//		String strFileName = "test.js";
		String strFileName = "test_" + System.currentTimeMillis() + ".js";
		String strDlFilePath = getServletContext().getRealPath("/") + strFileName;


//		objLog.info("対象batchパス：" + strDlFilePath);
//		String strFileName = strDlFilePath.substring(strDlFilePath.lastIndexOf("\\") + 1,strDlFilePath.length());

		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment; filename=" + strFileName);
		File objDlFile = new File(strDlFilePath); //からのDlFileを先に作成
		objFile.makeOfficeBat(strDlFilePath, "", 2);
		FileInputStream objFileIs = new FileInputStream(strDlFilePath);
		BufferedInputStream in = new BufferedInputStream(objFileIs);
		ServletOutputStream out2 = response.getOutputStream();

		int x;
		while ((x = in.read()) >= 0) {
			out2.write(x);
		}
		in.close();
		out2.flush();
		out2.close();

	} //doGet

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
