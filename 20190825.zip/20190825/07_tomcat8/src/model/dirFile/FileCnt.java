package model.dirFile;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.UnknownHostException;

import glConst.GlConst;
public class FileCnt {
	/**
	 * File名から拡張子を抜いたファイル名を取得する。
	 * @param String strFileName_i ファイルのフルパス
	 * @return String 取得文字列
	 */
	synchronized public String getNameWithoutExtension(String strFileName_i) {
		int index = strFileName_i.lastIndexOf('.');
		if (index != -1) {
			return strFileName_i.substring(0, index);
		}
		return strFileName_i;
	} //getNameWithoutExtension

	/**
	 * strPath_iにstrOfficePath_iを開くbatchを作成する
	 * @param String strFileName_i ファイルのフルパス
	 * @param ※使用予定String strOfficePath_i 対象officeファイル
	 * @param ※使用予定int intStatus_i 1:Excel 2:word 3:PPT
	 * @return void
	 */
	public void makeOfficeBat(String strPath_i,String strOfficePath_i,int intStatus_i) {

		PrintWriter objPw = null;
		String strServerAddr = "";
		try {
			strServerAddr = java.net.InetAddress.getLocalHost().toString();
			strServerAddr = strServerAddr.substring(strServerAddr.indexOf("/") + 1,strServerAddr.length());
		} catch (UnknownHostException e1) {
			// TODO 自動生成された catch ブロック
			e1.printStackTrace();
		} //try
        try {

//        	objPw = new PrintWriter(new BufferedWriter(objFile));

        	objPw = new PrintWriter(new BufferedWriter
                    (new OutputStreamWriter(new FileOutputStream(strPath_i),"Shift-JIS")));


//        	objPw.println("@echo off");
//        	if(intStatus_i ==1) {
//            	objPw.println(" start /WAIT EXCEL \"" + strOfficePath_i +  "\" ");
//        	}else if(intStatus_i == 2) {
//            	objPw.println(" start /WAIT WINWORD \"" + strOfficePath_i +  "\" ");
//        	}else {
//            	objPw.println(" start /WAIT POWERPNT \"" + strOfficePath_i +  "\" ");
//        	} //if

        	objPw.println("function wordToHtml(strTgtFilePath_i) {" );
        	objPw.println("    //   WScript.Echo(strTgtFilePath_i);" );
        	objPw.println("    var blAXObject = false;" );
        	objPw.println("    var objDoc = null;" );
        	objPw.println("    var objWshShell = null;" );
        	objPw.println("    try {" );
        	objPw.println("        //ActiveXObjectオブジェクトを試しに生成" );
        	objPw.println("        var objAXObject = new ActiveXObject('Microsoft.XMLHTTP');" );
        	objPw.println("        objAXObject = null;" );
        	objPw.println("        blAXObject = true;" );
        	objPw.println("    } catch (e) {" );
        	objPw.println("        blAXObject = false;" );
        	objPw.println("    } //try" );
        	objPw.println("    try {" );
        	objPw.println("        if (blAXObject) { //ActiveXObjectが有効な場合指定ファイルを開く" );
        	objPw.println("            objWshShell = new ActiveXObject('Word.Application');" );
        	objPw.println("            //objWshShell.Visible = true;" );
        	objPw.println("            objWshShell.Visible = false;" );
        	objPw.println("            var strTgtPath = strTgtFilePath_i + getCurrentTime() + '.html';" );
        	objPw.println("            //WScript.Echo(1);" );
        	objPw.println("            objDoc = objWshShell.Documents.Open(strTgtFilePath_i,false,true);" );
        	objPw.println("            objDoc.SaveAs(strTgtPath, 8); // html 8" );
        	objPw.println("            postHtmlWithIe(strTgtPath);" );
        	objPw.println("        } else { //無効な場合バッチをダウンロードして開く" );
        	objPw.println("//" );
        	objPw.println("//            if (intStatsu_i == 0) {" );
        	objPw.println("//                dlBat(strOrgBatPath);" );
        	objPw.println("//            } else {" );
        	objPw.println("//                dlBat(strMaskBatPath);" );
        	objPw.println("//            } //if" );
        	objPw.println("//" );
        	objPw.println("        } //if" );
        	objPw.println("    } catch (e) {" );
        	objPw.println("        blAXObject = false;" );
        	objPw.println("    } finally {" );
        	objPw.println("        objDoc.Close();" );
        	objPw.println("        objWshShell.Quit();" );
        	objPw.println("    } //try" );
        	objPw.println("} //function" );

        	objPw.println("        function postHtmlWithIe(strVal_i) {");
        	objPw.println("            var objIE = new ActiveXObject('InternetExplorer.Application');");
        	objPw.println("            objIE.visible = true;");
        	objPw.println("");
        	objPw.println("            //ポストデータ");
        	objPw.println("            //複数の値を送信するときは '&' でつなぐ");
        	objPw.println("            var objStream = new ActiveXObject('ADODB.Stream');");
        	objPw.println("            objStream.Open();");
        	objPw.println("            objStream.Charset = 'UTF-8';");
        	objPw.println("            objStream.WriteText('dummy=1'); // 1つ目のキーはゴミデータが入るのでダミーを挿入;");
        	objPw.println("            objStream.WriteText('&wordHtmlPath=' + strVal_i);");
        	objPw.println("            objStream.Position = 0;");
        	objPw.println("            objStream.Type = 1;");
        	objPw.println("            var objPostData = objStream.Read;");
        	objPw.println("            objStream.Close();");
        	objPw.println("");
        	objPw.println("            //POST を送るための必須ヘッダー");
        	objPw.println("            strHeaders = 'Content-Type: application/x-www-form-urlencoded' + " + "\"\\r\\n\"" + ";");
        	objPw.println("");
        	objPw.println("            //送信");
        	objPw.println("            //2番目の null を '_self' に変更するとブラウザで表示される");
        	objPw.println("            //objIE.Navigate('http://"+strServerAddr+":8080/" + GlConst.PROJECT_NAME + "/HtmlCnt', null, null, objPostData, strHeaders);");
        	objPw.println("            objIE.Navigate('http://"+strServerAddr+":8080/" + GlConst.PROJECT_NAME + "/HtmlCnt', '_self', null, objPostData, strHeaders);");
        	objPw.println("            while ((objIE.Busy) || (objIE.readystate != 4)) {");
        	objPw.println("                WScript.Sleep(100);");
        	objPw.println("            } //while");
        	objPw.println("            strRet = objIE.Document.body.innerText;");
        	objPw.println("            //objIE.Quit();");
        	objPw.println("        } //function");

//        	objPw.println("function postHtml(strVal_i) {");
//        	objPw.println("    var objForm = document.createElement('form');");
//        	objPw.println("    var objReq = document.createElement('input');");
//        	objPw.println("    objForm.method = 'POST';");
//        	objPw.println("    objForm.action = 'http://localhost:8080/" + GlConst.PROJECT_NAME + "/HtmlCnt';");
//        	objPw.println("    objReq.type = 'hidden'; //入力フォームが表示されないように");
//        	objPw.println("    objReq.name = 'wordHtmlPath';");
//        	objPw.println("    objReq.value = strVal_i;");
//        	objPw.println("    objForm.appendChild(objReq);");
//        	objPw.println("    document.body.appendChild(objForm);");
//        	objPw.println("    objForm.submit();");
//        	objPw.println("} //function");


        	objPw.println("//timestampを返す" );
        	objPw.println("//現在時刻取得（yyyymmddhhmmss）" );
        	objPw.println("function getCurrentTime() {" );
        	objPw.println("    var now = new Date();" );
        	objPw.println("    var res = '' + now.getFullYear() + padZero(now.getMonth() + 1) + padZero(now.getDate()) + padZero(now.getHours()) +" );
        	objPw.println("        padZero(now.getMinutes()) + padZero(now.getSeconds());" );
        	objPw.println("    return res;" );
        	objPw.println("} //function" );
        	objPw.println("//先頭ゼロ付加" );
        	objPw.println("function padZero(num) {" );
        	objPw.println("    return (num < 10 ? '0' : '') + num;" );
        	objPw.println("} //function" );
        	objPw.println("wordToHtml('" + GlConst.TGT_FILE_NAME.replace("\\","\\\\") + "');" );
        	objPw.close();

		} catch (IOException e) {
			e.printStackTrace();
		} //if


	} //makeOfficeBat



//	//---------zip処理--------//
//		/**
//		 * 指定されたディレクトリ内のファイルを ZIP アーカイブし、指定されたパスに作成。
//		 * デフォルト文字コードは Shift_JIS なので、日本語ファイル名も対応可。
//		 * @param directory 圧縮するディレクトリ ( 例; C:/sample )
//		 * @param fullPath 圧縮後の出力ファイル名をフルパスで指定 ( 例: C:/sample.zip )
//		 * @return 処理結果ステータス
//		 */
//		public int zipDirectory( String strDirectory_i,String strZipPath_i  ) {
//			File objBaseFile = new File(strZipPath_i);
//			File objFile = new File(strDirectory_i);
//			ZipOutputStream objOutZip = null;
//			try {
//				// ZIPファイル出力オブジェクト作成
//				objOutZip = new ZipOutputStream(new FileOutputStream(objBaseFile));
//				archive(objOutZip, objBaseFile, objFile);
//			} catch ( Exception e ) {
//				// ZIP圧縮失敗
//				System.err.println(e);
//				return -1;
//			} finally {
//				// ZIPエントリクローズ
//				if ( objOutZip != null ) {
//					try { objOutZip.closeEntry(); } catch (Exception e) {}
//					try { objOutZip.flush(); } catch (Exception e) {}
//					try { objOutZip.close(); } catch (Exception e) {}
//				}
//			}
//			return 0;
//		}
//
//		/**
//		 * 指定された ArrayList のファイルを ZIP アーカイブし、指定されたパスに作成します。
//		 * デフォルト文字コードは Shift_JIS ですので、日本語ファイル名も対応できます。
//		 *
//		 * @param filePath 圧縮後のファイル名をフルパスで指定 ( 例: C:/sample.zip )
//		 * @param fileList 圧縮するファイルリスト  ( 例; {C:/sample1.txt, C:/sample2.txt} )
//		 * @return 処理結果 true:圧縮成功 false:圧縮失敗
//		 */
//		public boolean compressFileList( String filePath, ArrayList<String> fileList ) {
//
//			ZipOutputStream outZip = null;
//			File baseFile = new File(filePath);
//			try {
//				// ZIPファイル出力オブジェクト作成
//				outZip = new ZipOutputStream(new FileOutputStream(baseFile));
//				// 圧縮ファイルリストのファイルを連続圧縮
//				for ( int i = 0 ; i < fileList.size() ; i++ ) {
//					// ファイルオブジェクト作成
//					File file = new File((String)fileList.get(i));
//					archive(outZip, baseFile, file, file.getName(), "Shift_JIS");
//				}
//			} catch ( Exception e ) {
//				// ZIP圧縮失敗
//				return false;
//			} finally {
//				// ZIPエントリクローズ
//				if ( outZip != null ) {
//					try { outZip.closeEntry(); } catch (Exception e) {}
//					try { outZip.flush(); } catch (Exception e) {}
//					try { outZip.close(); } catch (Exception e) {}
//				}
//			}
//			return true;
//		}
//
//		/**
//		 * ディレクトリ圧縮のための再帰処理
//		 *
//		 * @param outZip ZipOutputStream
//		 * @param baseFile File 保存先ファイル
//		 * @param file File 圧縮したいファイル
//		 */
//		private void archive(ZipOutputStream outZip, File baseFile, File targetFile) {
//			if ( targetFile.isDirectory() ) {
//				File[] files = targetFile.listFiles();
//				for (File f : files) {
//					if ( f.isDirectory() ) {
//						archive(outZip, baseFile, f);
//					} else {
//						if ( !f.getAbsoluteFile().equals(baseFile)  ) {
//							// 圧縮処理
//							archive(outZip, baseFile, f, f.getAbsolutePath().replace(baseFile.getParent(), "").substring(1), "Shift_JIS");
//						}
//					}
//				}
//			}
//		}
//
//		/**
//		 * 圧縮処理
//		 *
//		 * @param outZip ZipOutputStream
//		 * @param baseFile File 保存先ファイル
//		 * @param targetFile File 圧縮したいファイル
//		 * @parma entryName 保存ファイル名
//		 * @param enc 文字コード
//		 */
//		private boolean archive(ZipOutputStream outZip, File baseFile, File targetFile, String entryName, String enc) {
//			// 圧縮レベル設定
//			outZip.setLevel(5);
//
//			// 文字コードを指定
////			outZip.setEncoding(enc);
//			try {
//
//				// ZIPエントリ作成
//				outZip.putNextEntry(new ZipEntry(entryName));
//
//				// 圧縮ファイル読み込みストリーム取得
//				BufferedInputStream in = new BufferedInputStream(new FileInputStream(targetFile));
//
//				// 圧縮ファイルをZIPファイルに出力
//				int readSize = 0;
//				byte buffer[] = new byte[1024]; // 読み込みバッファ
//				while ((readSize = in.read(buffer, 0, buffer.length)) != -1) {
//					outZip.write(buffer, 0, readSize);
//				}
//				// クローズ処理
//				in.close();
//				// ZIPエントリクローズ
//				outZip.closeEntry();
//			} catch ( Exception e ) {
//				// ZIP圧縮失敗
//				return false;
//			}
//			return true;
//		}
//
//
//
//    /**
//     * 指定された ZIP ファイルを、指定されたパスに、ファイル名のディレクトリを作成して解凍します。 <br>
//     *
//     * @param zipFileFullPath ZIP ファイルのフルパス
//     * @param unzipPath 解凍するパス
//     * @return 処理結果 true:解凍成功 false:解凍失敗
//     */
//    public static boolean unzip( String zipFileFullPath, String unzipPath ) {
//
//        File baseFile = new File(zipFileFullPath);
//        File baseDir = new File(baseFile.getParent(), baseFile.getName().substring(0, baseFile.getName().lastIndexOf(".")));
//        if ( !baseDir.mkdir() )
//            System.out.println("Couldn't create directory because directory with the same name exists.: " + baseDir);
//
//        ZipFile zipFile = null;
//        try {
//            // ZIPファイルオブジェクト作成
//            zipFile = new ZipFile(zipFileFullPath);
//
//            // ZIPファイル内のファイルを列挙
//            Enumeration<? extends ZipEntry>  enumZip = zipFile.entries();
//
//            // ZIPファイル内の全てのファイルを展開
//            while ( enumZip.hasMoreElements() ) {
//
//                // ZIP内のエントリを取得
//                ZipEntry zipEntry = (java.util.zip.ZipEntry)enumZip.nextElement();
//
//                //出力ファイル取得
//                File unzipFile = new File(unzipPath);
//                File outFile = new File(unzipFile.getAbsolutePath() + "/" + baseDir.getName(), zipEntry.getName());
//
//                if ( zipEntry.isDirectory() )
//                    outFile.mkdir();
//                else {
//                    // 圧縮ファイル入力ストリーム作成
//                    BufferedInputStream in = new BufferedInputStream(zipFile.getInputStream(zipEntry));
//
//                    // 親ディレクトリがない場合、ディレクトリ作成
//                    if ( !outFile.getParentFile().exists() )
//                        outFile.getParentFile().mkdirs();
//
//                    // 出力オブジェクト取得
//                    BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(outFile));
//
//                    // 読み込みバッファ作成
//                    byte[] buffer = new byte[1024];
//
//                    // 解凍ファイル出力
//                    int readSize = 0;
//                    while ( (readSize = in.read(buffer)) != -1 ) {
//                        out.write(buffer, 0, readSize);
//                    }
//                    // クローズ
//                    try { out.close(); } catch (Exception e) {}
//                    try { in.close(); } catch (Exception e) {}
//                }
//            }
//            // 解凍処理成功
//            return true;
//        } catch(Exception e) {
//            // エラーログ出力
//            System.out.println(e.toString());
//            // 解凍処理失敗
//            return false;
//        } finally {
//            if ( zipFile != null )
//                try { zipFile.close();    } catch (Exception e) {}
//        }
//    } //unzip
//








} //FileCnt
