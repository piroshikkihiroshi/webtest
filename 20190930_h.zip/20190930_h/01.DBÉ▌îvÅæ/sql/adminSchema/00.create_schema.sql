-- Schema: admin

-- DROP SCHEMA admin;

CREATE SCHEMA admin
  AUTHORIZATION postgres;

GRANT ALL ON SCHEMA admin TO postgres;
COMMENT ON SCHEMA admin
  IS 'admin schema';

