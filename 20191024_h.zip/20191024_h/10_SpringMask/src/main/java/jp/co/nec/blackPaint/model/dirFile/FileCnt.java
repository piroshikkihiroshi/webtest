package jp.co.nec.blackPaint.model.dirFile;

public class FileCnt {
	/**
	 * File名から拡張子を抜いたファイル名を取得する。
	 * @param String strFileName_i ファイルのフルパス
	 * @return String 取得文字列
	 */
	synchronized public String getNameWithoutExtension(String strFileName_i) {
		int index = strFileName_i.lastIndexOf('.');
		if (index != -1) {
			return strFileName_i.substring(0, index);
		}
		return strFileName_i;
	} //getNameWithoutExtension










} //FileCnt
