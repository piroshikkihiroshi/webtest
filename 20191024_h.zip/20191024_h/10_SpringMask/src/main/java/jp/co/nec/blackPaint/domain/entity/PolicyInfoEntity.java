package jp.co.nec.blackPaint.domain.entity;

import lombok.Data;

@Data
public class PolicyInfoEntity {
	private int policy_id;
	private int policy_number;
	private String policy_name;
	private String policy_author;
	private String policy_reason;
	private String policy_keyword;
	private String mask_reason;
//	private String create_time;
//	private String update_time;

} //PolicyInfoEntity
