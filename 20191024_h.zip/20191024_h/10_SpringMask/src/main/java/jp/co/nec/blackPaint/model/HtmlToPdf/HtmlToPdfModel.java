package jp.co.nec.blackPaint.model.HtmlToPdf;

import io.woo.htmltopdf.HtmlToPdf;
import io.woo.htmltopdf.HtmlToPdfObject;

public class HtmlToPdfModel {
	/**
	 * strHtml_iからPDFを作成する
	 * @param strHtml_i
	 * @param strImgDir_i imgタグは相対パスを絶対パスに変更する必要があるのでimgが格納されているDirを指定
	 * @param strPdfOutPath_i pdf出力先のファイル名を含めたフルパス
	 */
	public void convertHtmlToPdf(String strHtml_i,String strImgDir_i,String strPdfOutPath_i){

		// imgタグのsrcが相対パスであるため、絶対パスに変換する
		strHtml_i = strHtml_i.replace("img src=\"", "img src=\""+ strImgDir_i +"/");

		// HTMLをPDFファイルに変更する
		HtmlToPdf.create().object(HtmlToPdfObject.forHtml(strHtml_i)).convert(strPdfOutPath_i);

	} //convertHtmlToPdf
} //class
