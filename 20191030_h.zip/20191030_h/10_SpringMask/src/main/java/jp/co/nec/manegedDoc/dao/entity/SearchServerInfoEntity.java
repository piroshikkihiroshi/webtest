package jp.co.nec.manegedDoc.dao.entity;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class SearchServerInfoEntity {
    private Integer serverId;
    private String serverName;
    private String displayName;
    private String ipAddress;
    private String loginUserName;
    private String loginPassword;
    private String directoryPath;
    private Integer displayOrder;
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss.SSS", timezone = "Asia/Tokyo")
    private Timestamp createTime;
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss.SSS", timezone = "Asia/Tokyo")
    private Timestamp updateTime;
    // ローカルストレージ用フィールド
    private Boolean deleteFlag;
}
