package jp.co.nec.manegedDoc.blackPaint.util.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.manegedDoc.blackPaint.entity.PolicyInfoEntPaint;
import jp.co.nec.manegedDoc.blackPaint.repository.PolicyInfoMapPaint;



@RestController
public class PolicyGet {

	@Autowired
	PolicyInfoMapPaint objPolicyInfoService;

	/**
	 * ポリシーテーブル一覧をjsonで取得する
	 * @return String ポリシーテーブル全件
	 */
	@GetMapping("/rest/policy/all")
	public String getPolicyAll(){
		String strRet = "";
		List<PolicyInfoEntPaint> listPolicy = objPolicyInfoService.findAll();

        ObjectMapper objMapper = new ObjectMapper();
        try {
        	strRet = objMapper.writeValueAsString(listPolicy);
		} catch (JsonProcessingException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		return strRet;
	} //getPlicyAll

} //PolicyGet
