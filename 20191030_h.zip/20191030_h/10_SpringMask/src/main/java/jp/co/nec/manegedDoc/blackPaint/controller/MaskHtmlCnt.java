package jp.co.nec.manegedDoc.blackPaint.controller;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;

import javax.servlet.ServletContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jp.co.nec.manegedDoc.blackPaint.logic.Aspose.AsposeWordModel;
import jp.co.nec.manegedDoc.blackPaint.logic.dirFile.DirCnt;
import jp.co.nec.manegedDoc.blackPaint.logic.dirFile.FileCnt;
import jp.co.nec.manegedDoc.blackPaint.logic.maskHtml.HtmlStructure;
import jp.co.nec.manegedDoc.blackPaint.logic.maskHtml.MaskHtmlModel;

@Controller
public class MaskHtmlCnt {

	static Logger objLog = LoggerFactory.getLogger(MaskHtmlCnt.class);

	@Autowired
	ServletContext context;

	@PostMapping("/MaskHtmlCnt")
	public String getblackTextTest(@RequestParam("wordPath") String strWordPath_i,@RequestParam("allSearchMock") String allSearchMock_i,Model model) {

		String strHeight = "785"; //word A4の時 他は未考慮

		FileCnt objFileCnt = new FileCnt();
		DirCnt objDilCnt = new DirCnt();
		AsposeWordModel objAspCls = new AsposeWordModel();
		MaskHtmlModel  objMaskCls = new MaskHtmlModel();

		String strOrgFilePath = strWordPath_i;
		objLog.info("対象パス：" + strOrgFilePath);

		//一度RealPathへファイルをコピーする
		String strFileName = strOrgFilePath.substring(strOrgFilePath.lastIndexOf("\\") + 1,strOrgFilePath.length());
		String strFileWithoutExtension = objFileCnt.getNameWithoutExtension(strFileName);
		String strCopyFileName = strFileName + ".docx"; //tmpで使用するfilename
        String strRealPath = context.getRealPath("/");
        String strTmpDirName="tmp" + System.currentTimeMillis() + "/";
        String strTmpDir = strRealPath + "/" + strTmpDirName; //作業用フォルダ
        String strCophyPath = strTmpDir + strFileName; //コピー先のwordPath


        String strHtmlName = strFileWithoutExtension + ".html"; //作成html名
        //String strHtmlName = objFileCnt.getNameWithoutExtension(strCopyFileName) + ".html"; //作成html名
        String strHtmlPath = strTmpDir + strFileWithoutExtension + ".html"; //作成htmlパス
//        String strHtmlPath = strTmpDir + objFileCnt.getNameWithoutExtension(strCopyFileName) + ".html"; //作成htmlパス


		FileWriter objFile=null;
		PrintWriter objPw=null;
		String[] arrMask=null;
		String[] arrRed=null;

		//全文検索モックデータ コロン区切りでペアは+区切り intpos,そこからつづく,intpos,そこからつづく
		String strTestData = allSearchMock_i;
		String strAllHtml = "";
		String strOrgBody = "";
		String strNotTagBody = "";
		String strRepBody = "";
		String strMaskHtml= "";
		String strRedHtml = "";

//		String strMaskDir= strTmpDir +"mask/"; //黒塗り用Dir
//		String strRedDir = strTmpDir +"red/";; //赤文字用Dir
		int intPageCnt = 0;

        try {
        	//tmpDir作成
        	objDilCnt.makeDirWithCheck(strTmpDir);
//        	objDilCnt.makeDirWithCheck(strMaskDir);
//        	objDilCnt.makeDirWithCheck(strRedDir);

            Path objSrcPath = Paths.get(strOrgFilePath);
            Path objTgtPath = Paths.get(strCophyPath);

            Files.copy(objSrcPath, objTgtPath);
            objLog.info("コピーが成功しました");
            //htmlを作成する。
            objAspCls.wordToHtml(strTmpDir, strFileName, strHtmlName);
            objLog.info("HTMLの作成に成功しました。");

            //対象HTMLを取得する
            strAllHtml = objMaskCls.readAll(strHtmlPath);

	        //圧縮されたBodyを取得
			strOrgBody = objMaskCls.getBodyCompress(strAllHtml);

			//全文検索エンジンに渡す用の文字列を取得する
			strNotTagBody=objMaskCls.getIllegalText(strOrgBody);

//			※※※※※※※検索エンジンに送ったと想定※※※※※※※

			//全文検索から戻ってきた値をhashへ成型
			HashMap<Integer, String> hashRepPos = objMaskCls.makePosHash(strTestData);
			objMaskCls.makePosHash(strTestData);

			//bodyの構造体hashを取得
			HashMap<Integer, HtmlStructure> hashBodyStructure = objMaskCls.getBodyStructure(strOrgBody);

//			String strStyleSheetPath = "<link rel='stylesheet' href='./"+strFileWithoutExtension+"/mask.css'>";
			String strStyleSheetPath = "<link rel='stylesheet' href='"+strFileWithoutExtension+"/mask.css'>";

			//全文検索エンジンに返した結果を置換してbodyを入れ替えた文字列を取得(黒塗り)
//			strRepBody=objMaskCls.bodyReplace(hashRepPos, hashBodyStructure,1);
			arrMask=objMaskCls.bodyReplace(hashRepPos, hashBodyStructure,1);
			strRepBody = arrMask[0];

			//htmlのbodyの中身を入れ替え、置換HTMLを作成する
			strMaskHtml = objMaskCls.makeBody(strAllHtml,strRepBody);

			//スタイルシートPath埋め込み
			strMaskHtml = objMaskCls.insertStyle(strMaskHtml,strStyleSheetPath);

			//全文検索エンジンに返した結果を置換してbodyを入れ替えた文字列を取得(赤文字)
//			strRepBody=objMaskCls.bodyReplace(hashRepPos, hashBodyStructure,2);
			arrRed=objMaskCls.bodyReplace(hashRepPos, hashBodyStructure,2);
			strRepBody=arrRed[0];

			//htmlのbodyの中身を入れ替え、置換HTMLを作成する
			strRedHtml = objMaskCls.makeBody(strAllHtml,strRepBody);

			//スタイルシートPath埋め込み
			strRedHtml = objMaskCls.insertStyle(strRedHtml,strStyleSheetPath);


			//css,黒塗り画像ファイル配備
			String strCssPath = "src/main/resources/static/css/blackPaint/mask.css";
			String strImgPath = "src/main/resources/static/css/images/mask.png";
			//命名きちんと取れるように修正予定
			Path objCssPath = Paths.get(strCssPath);
			Path objImgpPath = Paths.get(strImgPath);
			Path objTgtCssPath = Paths.get(strTmpDir + "/" + strFileWithoutExtension+ "/mask.css");
			Path objTgtImgPath = Paths.get(strTmpDir + "/" + strFileWithoutExtension+ "/mask.png");

            Files.copy(objCssPath, objTgtCssPath);
            Files.copy(objImgpPath, objTgtImgPath);


			String strMaskOutPath = strTmpDir + "mask_" + strHtmlName;
			String strRedOutPath = strTmpDir + "red_" + strHtmlName;

			//htmlを出力する(黒塗り)
			objFile = new FileWriter(strMaskOutPath);
			objPw = new PrintWriter(new BufferedWriter(objFile));
			objPw.println(strMaskHtml);
			objPw.close();
			objLog.info("maskHTML完了");

			//htmlを出力する(赤文字)
			objFile = new FileWriter(strRedOutPath);
			objPw = new PrintWriter(new BufferedWriter(objFile));
			objPw.println(strRedHtml);
			objPw.close();
			objLog.info("赤文字HTML完了");

			//ページカウント取得
			intPageCnt = objAspCls.aspPageGet(strMaskHtml);


			//viewへ値を渡す
			// 呼び出し先Jspに渡すデータセット(html出力パスを相対で指定)
			model.addAttribute("strMaskOutPath", "/" + strTmpDirName + "mask_" + strHtmlName );
			model.addAttribute("strRedOutPath", "/" + strTmpDirName + "red_" + strHtmlName);
			model.addAttribute("strTmpDirName", strTmpDirName); //tmpdirの情報も送る
			model.addAttribute("strPagePx", strHeight); //1ページの量
			model.addAttribute("intPageCnt", String.valueOf(intPageCnt)); //ページ数
			model.addAttribute("strFileName",strFileName); //オリジナルfile名 保存時に使用

			//AIデータがどのように来るかわからないのでポリシーなどはクライアントで処理
			model.addAttribute("strEditMarker", arrRed[1]);

        } catch (Exception e) {
            e.printStackTrace();
        } //try

		return "blackPaint/MaskHtmlVeiw";
	} //getView1

} //MaskHtmlCnt
