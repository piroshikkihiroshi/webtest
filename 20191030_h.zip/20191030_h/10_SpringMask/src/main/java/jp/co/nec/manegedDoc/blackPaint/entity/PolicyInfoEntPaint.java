package jp.co.nec.manegedDoc.blackPaint.entity;
import lombok.Data;


public class PolicyInfoEntPaint {
	public int getPolicy_id() {
		return policy_id;
	}
	public void setPolicy_id(int policy_id) {
		this.policy_id = policy_id;
	}
	public int getPolicy_number() {
		return policy_number;
	}
	public void setPolicy_number(int policy_number) {
		this.policy_number = policy_number;
	}
	public String getPolicy_name() {
		return policy_name;
	}
	public void setPolicy_name(String policy_name) {
		this.policy_name = policy_name;
	}
	public String getPolicy_author() {
		return policy_author;
	}
	public void setPolicy_author(String policy_author) {
		this.policy_author = policy_author;
	}
	public String getPolicy_reason() {
		return policy_reason;
	}
	public void setPolicy_reason(String policy_reason) {
		this.policy_reason = policy_reason;
	}
	public String getPolicy_keyword() {
		return policy_keyword;
	}
	public void setPolicy_keyword(String policy_keyword) {
		this.policy_keyword = policy_keyword;
	}
	public String getMask_reason() {
		return mask_reason;
	}
	public void setMask_reason(String mask_reason) {
		this.mask_reason = mask_reason;
	}
	private int policy_id;
	private int policy_number;
	private String policy_name;
	private String policy_author;
	private String policy_reason;
	private String policy_keyword;
	private String mask_reason;
//	private String create_time;
//	private String update_time;
}
