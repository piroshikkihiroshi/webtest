package jp.co.nec.manegedDoc.blackPaint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

//import jp.co.nec.manegedDoc.dao.entity.PolicyInfo;
//import jp.co.nec.manegedDoc.dao.mapper.PolicyInfoMapper;
import jp.co.nec.manegedDoc.blackPaint.entity.PolicyInfoEntPaint;
import jp.co.nec.manegedDoc.blackPaint.repository.PolicyInfoMapPaint;


@Service
public class PolicyInfoServicePaint {
	 @Autowired
	 private  PolicyInfoMapPaint objPolicyInfoMapper;
	 @Transactional
	 public List<PolicyInfoEntPaint> findAll() {
	  // 全件
	  return objPolicyInfoMapper.findAll();
	 } //findAll
} //PolicyInfoServicePaint
