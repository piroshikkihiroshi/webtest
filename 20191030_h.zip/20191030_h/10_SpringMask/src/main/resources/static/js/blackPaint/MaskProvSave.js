//定数等
const TODAY = getNowYMD();
const MASK_HEAD = "mask_";
const RED_FILE_NAME = "(査閲用)";
const MSK_FILE_NAME = "(公開用)";
const LST_FILE_NAME = "(黒塗諸元)";
const DROP_DOWN_ON_CLS = "dropdown_on";
const CATE_LIST_CLS ="cate_list"

var glIntPageAct = 1;
var glArrPaths = [];
var glStrJson='';

/**
 * 本日日付を取得する
 * @return yyyy-mm-dd形式の本日日付
 *  */
function getNowYMD() {
    var objDate = new Date();
    var strYear = objDate.getFullYear();
    var strMonth = ("00" + (objDate.getMonth() + 1)).slice(-2);
    var strDate = ("00" + objDate.getDate()).slice(-2);
    var result = strYear + "-" + strMonth + "-" + strDate;
    return result;
} //getNowYMD


/**
 * 保存ファイル名を作成し、親フレームに埋め込む
 */
function makeSaveName() {
    var arrNames = glFileName.split(".");
    $("#redFileName")[0].innerText = arrNames[0]+RED_FILE_NAME;
    $("#mskFileName")[0].innerText = arrNames[0]+MSK_FILE_NAME;
    $("#lstFileName")[0].innerText = arrNames[0]+LST_FILE_NAME;
} //makeSaveName


/**
 * 次のページへページネーションする
 */
function pageNext() {
    if ( glIntPageAct < PAGE_MAX ) {
        //iframeの入れ替え
        var intActPage = glIntPageAct; //ページは自由入力なのでgl変数に保持している
        intActPage++;
        var strSrc = glArrPaths[intActPage-1];
        document.getElementById("pdf_src").src = strSrc;

        //親フレームの表示変更  
        document.getElementById('pager_page_id').value = intActPage;
        glIntPageAct = intActPage;        
    } //if
} //functon

/**
 * 前のページへページネーションする
 */
function pageBack() {
    if ( Number(glIntPageAct)>1 ) {
        //iframeの入れ替え
        var intActPage = glIntPageAct; //ページは自由入力なのでgl変数に保持している
        intActPage--;
        var strSrc = glArrPaths[intActPage-1];
        document.getElementById("pdf_src").src = strSrc;

        //親フレームの表示変更  
        document.getElementById('pager_page_id').value = intActPage;
        glIntPageAct = intActPage;        
    } //if
	
} //functon

/**
 * 指定したページへページネーションする
 */
function pageSelect(intTgtPage_i) {
    var strSrc = glArrPaths[intTgtPage_i-1];
    document.getElementById("pdf_src").src = strSrc;

    glIntPageAct = intTgtPage_i;        
} //functon


/**
 * テキストボックスに入力したページへページネーションする
 */
function enterPager() {
	var intPage = Number(document.getElementById('pager_page_id').value);
	if((intPage!==undefined) && (intPage !==0) && (intPage<=PAGE_MAX) ){
    	pageSelect(intPage);
    	glIntPageAct= intPage;

	} //if
} //function

/**
* 分類一覧を取得する
* @return boolean
*/
function getCategoryAll(){
    $.ajax({
        type: 'GET',
        url: '/rest/category/all',
        processData: false, // Ajaxがdataを整形しない指定
        contentType: false, // contentTypeもfalseに指定(Fileをアップロード時は必要)
        async:false, //非同期false
        success: function (retData) {
            glCategoryLists=JSON.parse(retData);
            console.log("success");
            return false;
        }, //function
        error: function (e) {
            console.log("fail");
            return false;
        } //function
    }); //ajax
} //function


/**
* 分類プルダウンの初期設定する
*/
function setInitCategory() {

    //categoryList用HTML
    var strCateHtml = '';
    for (let i = 0; i < glCategoryLists.length; i++) {
        if (i===0) {
            strCateHtml+='<li class=" '+CATE_LIST_CLS+ ' '+DROP_DOWN_ON_CLS+'" value="'+ glCategoryLists[i].category_id + '">'+ glCategoryLists[i].category_name + '</li>';
        }else{
            strCateHtml+='<li class=" '+CATE_LIST_CLS+ '" value="'+ glCategoryLists[i].category_id + '">'+ glCategoryLists[i].category_name + '</li>';
        } //if  
    } //for
    $("#catedrop")[0].innerHTML = strCateHtml;
    var objInitCate= document.getElementById("cateselect");
    objInitCate.innerText = glCategoryLists[0].category_name;

} //function

/**
 **********イベント イベント操作関係 **********
*/

/**
 * マウスダウンイベント
*/
function cateSelect(e) {

    //list内処理
    var listClass=$("."+CATE_LIST_CLS);
    var objtgt = null;
    for (let i = 0; i < listClass.length; i++) {
        objtgt = listClass[i];
        if (objtgt.className.indexOf(DROP_DOWN_ON_CLS) >= 0) {
            break;
        } //if
    } //for
    //label変更
    var strLabel = objtgt.innerText;
    var objCate= document.getElementById("cateselect");
    objCate.innerText = strLabel;

    //全消し
    listClass.removeClass(DROP_DOWN_ON_CLS);
    //addClass
    e.target.classList.add(DROP_DOWN_ON_CLS);

} //function


/**
 * マウスダウンイベント
*/
function mouseDownAct(e) {

    //分類軸設定イベント
    if (e.target.className.indexOf(CATE_LIST_CLS) >= 0) {
        cateSelect(e);
        return ;
    } //if


} //function



