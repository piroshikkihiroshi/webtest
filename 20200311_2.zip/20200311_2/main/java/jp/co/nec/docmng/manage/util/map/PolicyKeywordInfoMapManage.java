/**
 * 名称：PolicyKeywordInfoMapManage.java
 * 機能名：管理系ポリシーキーワード情報連携
 * 概要：管理系にて使用するポリシーキーワード情報への連携用レポジトリ
 */

package jp.co.nec.docmng.manage.util.map;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import jp.co.nec.docmng.manage.entity.PolicyKeywordInfo;

/**
 * 管理系ポリシーキーワード情報連携
 */
@Mapper
public interface PolicyKeywordInfoMapManage {

	/**
	 * 全件取得
	 * @return 検索結果
	 */
    @Select("select * from admin.policy_keyword_info order by policy_id asc, update_time desc")
    public List<PolicyKeywordInfo> findAll();

	/**
	 * データ削除_ポリシー指定
	 * @param policyId ポリシーID
	 */
    @Delete("delete from admin.policy_keyword_info where policy_id = #{policyId}")
    public void deleteKeyWord(Integer policyId);

}
