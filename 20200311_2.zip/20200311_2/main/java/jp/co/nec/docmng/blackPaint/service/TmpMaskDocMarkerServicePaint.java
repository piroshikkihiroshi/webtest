/**
 * 名称：TmpMaskDocTmpMarkerService.java
 * 機能名：黒塗り処黒塗り文書黒塗り箇所一時保存情報連携
 * 概要：黒塗り処理にて使用する黒塗り文書黒塗り箇所一時保存情報への連携用サービス
 */

package jp.co.nec.docmng.blackPaint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.blackPaint.entity.TmpMaskDocMarkerEntBlackPaint;
import jp.co.nec.docmng.blackPaint.repository.TmpMaskDocMarkerMapPaint;

/**
 * 黒塗り処黒塗り文書黒塗り箇所一時保存情報連携
 */
@Service
public class TmpMaskDocMarkerServicePaint {

	@Autowired
	private TmpMaskDocMarkerMapPaint tmpMaskDocTmpMarkerMapPaint;

	/**
	 * データ登録処理
	 * @param objEnt 登録内容を格納したentity
	 */
	@Transactional
	public void insertTmpMaskDocument(TmpMaskDocMarkerEntBlackPaint objEnt) {
		tmpMaskDocTmpMarkerMapPaint.insertTmpMaskDocMarker(objEnt);
	} //insertTmpMaskDocument

	/**
	 * ドキュメントID、ユーザID指定による取得
	 * @param documentId 取得条件となるドキュメントID
	 * @param userId 取得条件となるユーザID
	 * @return 取得したデータのリスト
	 */
	@Transactional
	public List<TmpMaskDocMarkerEntBlackPaint> selectTmpMaskDocMarker(Integer documentId, String userId) {
		return tmpMaskDocTmpMarkerMapPaint.selectTmpMaskDocMarker(documentId, userId);
	} //selectTmpMaskDocMarker

	/**
	 * ドキュメントID、ユーザID指定による削除処理
	 * @param document_id 削除条件となるドキュメントID
	 * @param user_id 削除条件となるユーザID
	 */
	@Transactional
	public void deleteTmpMarkerDoc(Integer document_id, String user_id) {
		tmpMaskDocTmpMarkerMapPaint.deleteTmpMarkerDoc(document_id, user_id);
	} //deleteTmpMarkerDoc

	/**
	 * 黒塗り箇所ポリシーIDの更新処理
	 * @param targetPolicy 更新条件のポリシーID
	 * @param objEnt 更新値を格納したentity
	 */
	@Transactional
	public void updateTmpMarkerDoc(Integer targetPolicy, TmpMaskDocMarkerEntBlackPaint objEnt) {
		tmpMaskDocTmpMarkerMapPaint.updateTmpMarkerDoc(targetPolicy, objEnt);
	} //updateTmpMarkerDoc

	/**
	 * 黒塗り箇所ポリシーID指定による取得
	 * @param policyId 取得条件となる黒塗り箇所ポリシーID
	 * @return 取得したデータのリスト
	 */
	@Transactional
	public List<TmpMaskDocMarkerEntBlackPaint> findMakerPolicyId(Integer policyId) {
		return tmpMaskDocTmpMarkerMapPaint.findMakerPolicyId(policyId);
	} //findMakerPolicyId

} //PolicyInfoServiceApi
