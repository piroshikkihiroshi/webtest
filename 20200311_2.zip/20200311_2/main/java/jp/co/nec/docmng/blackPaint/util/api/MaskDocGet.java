/**
 * 名称：DocGet.java
 * 機能名：DocumentIngoデータ取得
 * 概要：DocumentIngoのデータを取得(zip 全文テキストを除く)しjsonで返却する
 */

package jp.co.nec.docmng.blackPaint.util.api;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.blackPaint.entity.MaskDocumentEntBlackPaint;
import jp.co.nec.docmng.blackPaint.service.MaskDocumentServicePaint;

/**
 * MaskDocumentデータ取得
 */
@RestController
public class MaskDocGet {

	@Autowired
	MaskDocumentServicePaint maskDocumentServicePaint;

	/**
	 * objLog log出力に使用する
	 */
	static Logger objLog = LoggerFactory.getLogger(MaskDocGet.class);

	/**
	 * DocumentIngoのデータを取得(zip 全文テキストを除く)しjsonで返却する
	 * @param documentId
	 * @return String documentIdで指定したレコード
	 */
	@GetMapping("/rest/maskdoc/rec")
	public String getMaskDocInfo(
			@RequestParam("fileId") int fileId) {

		String strRet = "";
		final List<MaskDocumentEntBlackPaint> listMaskDoc = maskDocumentServicePaint.getNoZipMaskDoc(fileId);

		final ObjectMapper objMapper = new ObjectMapper();
		try {
			strRet = objMapper.writeValueAsString(listMaskDoc);
		} catch (final JsonProcessingException e) {
			objLog.error("err message", e);

		}
		return strRet;
	} //method

} //class
