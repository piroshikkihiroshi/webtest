/**
 * 名称：MaskDocumentMapPaint.java
 * 機能名：黒塗り処理黒塗り文書保存情報連携
 * 概要：黒塗り処理にて使用する黒塗り文書保存情報への連携用レポジトリ
 */

package jp.co.nec.docmng.blackPaint.repository;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import jp.co.nec.docmng.blackPaint.entity.MaskDocumentEntBlackPaint;

/**
 *黒塗り処理黒塗り文書保存情報連携
 */
@Mapper
public interface MaskDocumentMapPaint {

	/**
	 * データ登録処理
	 * @param MaskDocumentEnt 登録内容を格納したentity
	 */
	@Insert("INSERT INTO common.mask_document(document_id, user_id, html_zip_data, create_time, update_time,category_id,mask_status) VALUES (#{documentId}, #{userId}, #{htmlZipData}, #{createTime}, #{updateTime} , #{categoryId} , #{maskStatus})") void insertMaskDocument(MaskDocumentEntBlackPaint MaskDocumentEnt);

	/**
	 * ドキュメントID、ユーザID指定によるHTML群(zip圧縮)の取得
	 * @param document_id 取得条件となるドキュメントID
	 * @param user_id 取得条件となるユーザID
	 * @return 取得したデータのリスト
	 */
	@Select("SELECT html_zip_data FROM common.mask_document WHERE document_id = #{document_id} and user_id = #{user_id}") List<MaskDocumentEntBlackPaint> getHtmlZip(Integer document_id, String user_id);

	/**
	 * ドキュメントID、ユーザID指定による削除処理
	 * @param document_id 削除条件となるドキュメントID
	 * @param user_id 削除条件となるユーザID
	 */
	@Delete("DELETE FROM common.mask_document WHERE document_id = #{document_id} and user_id = #{user_id}") void deleteDoc(Integer document_id, String user_id);

	/**
	 * ファイルID指定でレコードを取得する
	 * @param file_id Procenter/CのファイルID
	 * @return 取得したデータのリスト
	 */
	@Select("SELECT * FROM common.mask_document WHERE file_id = #{file_id}") List<MaskDocumentEntBlackPaint> getMaskDoc(Integer file_id);

	/**
	 * ファイルID指定でレコードを取得する
	 * @param file_id Procenter/CのファイルID
	 * @param user_id ユーザーID
	 * @return 取得したデータのリスト
	 */
	@Select("SELECT * FROM common.mask_document WHERE file_id = #{file_id} AND user_id = #{user_id}") List<MaskDocumentEntBlackPaint> getUserMaskDoc(Integer file_id, String user_id);

	/**
	 * ファイルID ユーザーID指定でレコードを取得する(html_zipなし)
	 * @param file_id Procenter/CのファイルID
	 * @param user_id ユーザーID
	 * @return 取得したデータのリスト
	 */
	@Select("SELECT mask_id, document_id, user_id, create_time, update_time, node_id, file_id, category_id, mask_status FROM common.mask_document WHERE file_id = #{file_id} ") List<MaskDocumentEntBlackPaint> getNoZipMaskDoc(Integer file_id);


} //interface
