/**
 * 名称：DocInfoService.java
 * 機能名：黒塗り処理文書情報連携
 * 概要：黒塗り処理にて使用する文書情報への連携用サービス
 */

package jp.co.nec.docmng.blackPaint.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.blackPaint.entity.DocumentInfoEntPaint;
import jp.co.nec.docmng.blackPaint.repository.DocumentMapPaint;

/**
 * 黒塗り処理文書情報連携
 */
@Service
public class DocInfoServicePaint {
	@Autowired
	private DocumentMapPaint documentMapPaint;

	/**
	 * プライマリキー指定による取得（バイナリデータ含む）
	 * @param document_id 取得条件となるドキュメントID
	 * @return 取得したデータのリスト
	 */
	@Transactional
	public List<DocumentInfoEntPaint> selectDocInfo(int document_id) {
		return documentMapPaint.selectDocInfo(document_id);
	} //method

	/**
	 * プライマリキー指定による取得（バイナリデータ含まない）
	 * @param document_id 取得条件となるドキュメントID
	 * @return 取得したデータのリスト
	 */
	@Transactional
	public List<DocumentInfoEntPaint> selectDocFileInfo(int document_id) {
		return documentMapPaint.selectDocFileInfo(document_id);
	} //method

	/**
	 * FileId指定による取得（バイナリデータ含まない）
	 * @param file_id 取得条件となるファイルID
	 * @return 取得したデータのリスト
	 */
	@Transactional
	public List<DocumentInfoEntPaint> selectDocToFileId(int file_id) {
		return documentMapPaint.selectDocToFileId(file_id);
	} //method

	/**
	 * カテゴリー、保存期間の更新処理
	 * @param document_id 取得条件となるドキュメントID
	 * @param category_id カテゴリーIDの更新値
	 * @param retention_period 保存期間の更新値
	 * @param update_time 更新日時
	 */
	@Transactional
	public void updateDocFileInfo(int document_id, int category_id, Date retention_period, Date update_time) {
		documentMapPaint.updateDocFileInfo(document_id, category_id, retention_period, update_time);
	} //method

} //PolicyInfoServiceApi
