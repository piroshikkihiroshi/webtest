/**
 * 名称：DocumentInfoMapManege.java
 * 機能名：文書情報（内部処理用）連携
 * 概要：文書情報（内部処理用）への連携用レポジトリ
 */

package jp.co.nec.docmng.manage.util.map;

import java.util.Date;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Update;

/**
 * 文書情報（内部処理用）連携
 */
@Mapper
public interface DocumentInfoInternalMapManege {

	/**
	 * カテゴリーの更新処理
	 * @param targetCategory 取得条件となるドキュメントID
	 * @param categoryId カテゴリーIDの更新値
	 * @param updateTime 更新日時
	 */
	@Update("UPDATE common.document_info_internal SET category_id = #{categoryId}, update_time = #{updateTime} WHERE category_id = #{targetCategory}" )
	public void updateDocFileInfo(int targetCategory, int categoryId, Date updateTime);

}
