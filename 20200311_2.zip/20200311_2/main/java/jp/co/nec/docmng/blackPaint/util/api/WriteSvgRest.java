/**
 * 名称：WriteSvgRest.java
 * 機能名：一時保存Control
 * 概要：一時保存機能のControlを行う。
 */

package jp.co.nec.docmng.blackPaint.util.api;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.blackPaint.logic.dirFile.DirCnt;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocMarkerServicePaint;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocumentServicePaint;

/**
 * SVGファイル保存機能のControlを行う。
 */
@RestController
public class WriteSvgRest {

	/**
	 * context サーブレットのRealPathを取得する
	 */
	@Autowired
	ServletContext context;

	@Autowired
	TmpMaskDocumentServicePaint tmpMaskDocumentService;
	@Autowired
	TmpMaskDocMarkerServicePaint tmpMaskDocTmpMarkerService;

	/**
	 * objLog log出力に使用する
	 */
	static Logger objLog = LoggerFactory.getLogger(WriteSvgRest.class);

	/**
	 * PAGE_CLASS ページを判定するHTMLClass。ページをSplitするのに使用する
	 */
	static String PAGE_CLASS = "awdiv awpage"; //splitするページのHTMLClass

	/**
	 * ARR_HEAD ファイル名、フォルダ名を判定するために使用する
	 */
	static String[] ARR_HEAD = { "mask_", "red_" }; //ファイル名、フォルダ名のヘッダー配列

	/**
	 * SVGファイル保存メソッド
	 * SVGファイル保存の処理制御をする。
	 * @param strHashJson 以下の値を入れ込んだjsonString
	 * <ol>
	 *   <li>strTmpDir 黒塗り編集画面で処理したHTMLが格納されたTMPディレクトリ名</li>
	 *   <li>strRedHtml 黒塗り編集候補HTMLのouterHTML</li>
	 *   <li>strMaskHtml 黒塗り編集HTMLのouterHTML</li>
	 *   <li>strFileName オリジナルwordファイル名</li>
	 *   <li>documentId ドキュメントID</li>
	 * </ol>
	 * @param UserId ユーザID
	 * @param model 引渡しパラメータ用モデル
	 * @return
	 */
	@ResponseBody
	@PostMapping("/blackpaint/WriteSvgRest")
	@ResponseStatus(HttpStatus.OK)
	public synchronized String SaveTmpDocCntRest(
			@RequestBody String strHashJson,
			@CookieValue(value = "user_id", required = false) String UserId,
			Model model) {

		if (UserId == null)
			UserId = "";

		if (!strHashJson.equals("")) {
			objLog.info("json：" + strHashJson);
		} //if

		objLog.info("UserId:" + UserId);

		//メンバ変数初期化
		String strTmpDir = ""; //黒塗り編集画面で処理したHTMLが格納されたTMPディレクトリ名。
		int intDocumentId = -1; //documentId

		String strBasePath = ""; //黒塗り作成時の作業フォルダ
		String strRealPath = context.getRealPath("/");

		//以下黒塗りリスト配列
		String[] svgRedVal = null;
		String[] svgRedSrc = null;
		String[] svgMskVal = null;
		String[] svgMskSrc = null;

		//POSTされたjsonをパースする
		final ObjectMapper objMapper = new ObjectMapper();
		List<Map<String, String[]>> objTmpList = null;
		final TypeReference<List<Map<String, String[]>>> objType = new TypeReference<List<Map<String, String[]>>>() {
		};
		try {
			objTmpList = objMapper.readValue(strHashJson, objType);
		} catch (final JsonParseException e) {
			objLog.error("err message", e);
			return "500"; // Internal Server Error;
		} catch (final JsonMappingException e) {
			objLog.error("err message", e);
			return "500"; // Internal Server Error
		} catch (final IOException e) {
			objLog.error("err message", e);
			return "500"; // Internal Server Error
		} //try

		final HashMap<String, String[]> objMap = (HashMap<String, String[]>) objTmpList.get(0);

		for (final String strKey : objMap.keySet()) {
			switch (strKey) {
			case "tmpDir":
				strTmpDir = objMap.get(strKey)[0];
				break;
			case "documentId":
				intDocumentId = Integer.parseInt(objMap.get(strKey)[0]);
				break;
			case "svgRedVal":
				svgRedVal = objMap.get(strKey);
				break;
			case "svgRedSrc":
				svgRedSrc = objMap.get(strKey);
				break;
			case "svgMskVal":
				svgMskVal = objMap.get(strKey);
				break;
			case "svgMskSrc":
				svgMskSrc = objMap.get(strKey);
				break;
			default:
				break;
			}//switch

		} //for

		strRealPath = context.getRealPath("/");

		strBasePath = strRealPath + strTmpDir;

		for (int i = 0; i < svgRedVal.length; i++) {

			File fileSvg = new File(strBasePath + intDocumentId + "/" + svgRedSrc[i]);
			PrintWriter filewriter;
			try {
				filewriter = new PrintWriter(
						new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileSvg), "UTF-8")));
				filewriter.write(svgRedVal[i]);

				if (filewriter != null)
					filewriter.close();
			} catch (final Exception e) {
				objLog.error("err message", e);
				return "500"; // Internal Server Error
			} //try

			fileSvg = new File(strBasePath + intDocumentId + "/" + svgMskSrc[i]);
			try {
				filewriter = new PrintWriter(
						new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileSvg), "UTF-8")));
				filewriter.write(svgMskVal[i]);

				if (filewriter != null)
					filewriter.close();
			} catch (final Exception e) {
				objLog.error("err message", e);
				return "500"; // Internal Server Error
			} //try

		} //for

		return "200";
	} //getView1

	/**
	 * エラー画面遷移(一時保存処理)
	 * @param e 発生したエラー
	 * @param request HTTPリクエスト
	 * @param response HTTPレスポンス
	 * @param model 引渡しパラメータ用モデル
	 * @return 遷移先アドレス
	 */
	@ExceptionHandler(Exception.class)
	public String handleException(
			Exception e,
			HttpServletRequest request,
			HttpServletResponse response,
			Model model) {

		//GCを明示的によんでメモリ解放
		//System.gc();

		//モデル初期化
		final DirCnt objDirCls = new DirCnt();
		final Cookie cookie[] = request.getCookies();
		String strTmpDir_i = "";
		if (cookie != null) {
			for (int i = 0; i < cookie.length; i++) {
				if (cookie[i].getName().equals("strTmpDirName")) {
					strTmpDir_i = cookie[i].getValue();
				} //if
			} //for
		} //if

		//作業ディレクトリかたずけ
		if (strTmpDir_i.equals("")) {
			objLog.info("作業ディレクトリの取得が失敗しました");
		} else {
			try {
				//作業ディレクトリ,ファイルかたづけ
				objDirCls.delDirectory(context.getRealPath("/") + strTmpDir_i);
				objLog.info("作業ディレクトリ削除完了");
			} catch (final Exception e1) {
				objLog.info("作業ディレクトリ削除失敗");
			} //try

		} //if

		response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		objLog.error("Error occurred.", e);
		final StringWriter objSw = new StringWriter();
		final PrintWriter objPw = new PrintWriter(objSw);
		e.printStackTrace(objPw);
		objPw.flush();
		final String strError = objSw.toString();
		try {
			objSw.close();
			objPw.close();
		} catch (final IOException e1) {
			e1.printStackTrace();
		} //try

		model.addAttribute("errorMessage", e.getMessage() + "\r\n" + "StackTrace" + "\r\n" + strError);

		return "blackPaint/Fail";
	} //method

} //MaskHtmlCnt
