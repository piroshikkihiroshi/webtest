/**
 * @fileOverview 検索対象サーバ設定画面（管理者用）用スクリプト
 * @desc 機能名：管理機能
 * @desc 画面名：検索対象サーバ設定画面
 * @author NEC
 * @version 1.0.0
 */

/**
 * ボタン無効状態の定数
 * @memberOf SearchServer
 * @constant {Number} DISABLE_TRUE ボタン無効状態
*/
DISABLE_TRUE = 0;
/**
 * ボタン有効状態の定数
 * @memberOf SearchServer
 * @constant {Number} DISABLE_FALSE ボタン有効状態
*/
DISABLE_FALSE = 1;

/**
 * 編集ボタンの有効(1)／無効(0)状態を保持する変数
 * @memberOf SearchServer
 * @type {Number}
 */
editCheck = DISABLE_FALSE;
/**
 * 設定反映ボタンの有効(1)／無効(0)状態を保持する変数
 * @memberOf SearchServer
 * @type {Number}
 */
addBtnCheck = DISABLE_TRUE;
/**
 * 編集キャンセルボタンの有効(1)／無効(0)状態を保持する変数
 * @memberOf SearchServer
 * @type {Number}
 */
editCancelCheck = DISABLE_FALSE;
/**
 * 反映ボタンの有効(1)／無効(0)状態を保持する変数
 * @memberOf SearchServer
 * @type {Number}
 */
reflectCheck = DISABLE_FALSE;
/**
 * 削除ボタンの有効(1)／無効(0)状態を保持する変数
 * @memberOf SearchServer
 * @type {Number}
 */
deleteCheck = DISABLE_FALSE;
/**
 * 編集前の登録データ一覧を保持する変数
 * @memberOf SearchServer
 * @type {Object}
 */
var beforeRegDataList = [];

/**
 * テキストボックスの有効(1)／無効(0)状態を保持する変数
 * @memberOf SearchServer
 * @type {Number}
 */
var textBoxCheckFlag = DISABLE_FALSE;

/**
 * 追加したサーバ情報のカウントをする変数
 * @memberOf SearchServer
 * @type {Number}
 * @default 0
 */
addListCount = 0;
/**
 * サーバへのリクエストが成功(true)／失敗(false)を保持する変数
 * @memberOf SearchServer
 * @type {Number}
 * @default
 */
var isPost = false;

/**
 * キャンセルボタンが押下されたかを保持する変数
 * @memberOf SearchServer
 * @type {Number}
 * @default
 */
var isCancel = false;

/**
 * 値の変換を保持する変数
 * @memberOf SearchServer
 * @type {Number}
 * @default
 */
var changedValues = {};

/**
 * 値を追加する変数
 * @memberOf SearchServer
 * @type {Number}
 * @default
 */
var addValues = {};

/**
 * DBNoを削除する変数
 * @memberOf SearchServer
 * @type {Number}
 * @default
 */
var deleteDBNo = [];

var hostUrl = location.protocol + '//' + location.host + location.pathname;

//アラートメッセージ
var displayNameNullMessage = "『表示名』が未入力です。";
var serverNameValidMessage = "『サーバ名』に「/」「\\」を含めないでください。";
var serverNameNullMessage = "『サーバ名』が未入力です。";
var directoryPathNullMessage = "『フォルダパス』が未入力です。";
var deleteEditListMessage = "選択した行は現在編集中のため削除できません。";
var selectedNotClickDeleteMessage = "行の選択を行った後「削除ボタン」を押下してください。"
var selectedNotClickEditMessage = "行の選択を行った後「編集ボタン」を押下してください。";
var authenticationSettingMessage = "認証に成功しました。";
var authenticationSettingFailureMessage = "認証に失敗しました。";
var addReflectSettingMessage = "変更が反映されました。";
var addReflectSettingFailureMessage = "設定反映に失敗しました。";
var cancelSelectedMessage = "変更内容を破棄してもよろしいでしょうか。";
var notUserRoleOrLoginOutMessage = "ログインを行っていない、または管理者ではありません。";


/**
 * 動作関数
 * 読み込み時、ボタン制御等を行う。
 * @memberOf  SearchServer
 */
$(function () {

  //Cookieを確認し、管理者権限またはログインしているかチェックを行う
  // ドメイン情報取得
  DomainCookie.initDomainCookie('[[${DomainInfo}]]');
  var userRole = DomainCookie.getUserRole();
  userRoleFlag = false;

  // ログインしてない場合
  if (userRole === null) {
    alert(notUserRoleOrLoginOutMessage);
    //「反映ボタン」を非活性状態に変更する
    reflectCheck = DISABLE_TRUE;
    //「編集ボタン」を非活性状態に変更する
    editCheck = DISABLE_TRUE;
    //「削除ボタン」を非活性状態に変更する
    deleteCheck = DISABLE_TRUE;

    //「設定反映ボタン」を非活性状態に変更する
    addBtnCheck = DISABLE_TRUE;
    //「編集キャンセルボタン」を非活性状態に変更する
    editCancelCheck = DISABLE_TRUE;
    //「キャンセルボタン」を非活性化状態にする
    $("#cancelBtn").prop("disabled", true);
  }

  //管理者権限か確認を行う
  if (userRole === "Administrators") {
    showUserName();
    userRoleFlag = true;
  }

  //管理者権限、またはログインしていなかった場合画面を閉じる
  if (userRoleFlag !== true) {
    alert(notUserRoleOrLoginOutMessage);
    //「反映ボタン」を非活性状態に変更する
    reflectCheck = DISABLE_TRUE;
    //「編集ボタン」を非活性状態に変更する
    editCheck = DISABLE_TRUE;
    //「削除ボタン」を非活性状態に変更する
    deleteCheck = DISABLE_TRUE;

    //「設定反映ボタン」を非活性状態に変更する
    addBtnCheck = DISABLE_TRUE;
    //「編集キャンセルボタン」を非活性状態に変更する
    editCancelCheck = DISABLE_TRUE;
    //「キャンセルボタン」を非活性化状態にする
    $("#cancelBtn").prop("disabled", true);
  }

  //NAS様opener対応(beforeManageOpen())
  beforeManageOpen(0);

  // 画面ロード時にボタンの表示状態更新
  btnAllCheck();


  /**
   * 再読み込み時動作関数
   * 画面が変更、または閉じられる時に動作する。
   * @memberOf  SearchServer
   * @param {value} isPost POST送信フラグ
   */
  //画面が変更または閉じられる時に動作する
  $(window).on("beforeunload", function (e) {
    // NAS様opener対応(afterManageClose())
	  afterManageClose();
    // POST送信フラグが「true」の場合、ダイアログを表示しないようにする
    if (isPost || isCancel) {
      return;
    } else {
      return true;
    }
  });



  /**
   * 一覧表読み完了後動作関数
   * 一覧表の読み込みが完了後、一覧表の数が0だった場合ボタンをdisabledに変更を行う。
   * @memberOf  SearchServer
   * @param {value} editCancelCheck 編集キャンセルボタン確認
   * @param {value} editCheck 編集ボタン確認
   * @param {value} deleteCheck 削除ボタン確認
   * @param {value} addBtnCheck 設定反映ボタン確認
   */
  //一覧表の表示が完了した時、DBに登録されているデータが0だった場合、ボタンをdisabledに変更する
  $('.scrollBody').ready(function (e) {

    //表示項番の設定をする
    DisplayNo();

    if (document.getElementById('main_scroll').childElementCount == 0) {
      //「編集ボタン」を非活性状態に変更する
      editCheck = DISABLE_TRUE;

      //「削除ボタン」を非活性状態に変更する
      deleteCheck = DISABLE_TRUE;

      //「設定反映ボタン」を非活性状態に変更する
      addBtnCheck = DISABLE_TRUE;
    }
    // 全ボタンの状態更新
    btnAllCheck();

  });


  /**
   * 一覧表押下時動作関数
   * 表をクリック時に動作し、クリックを行った時に選択した行の色が変更する。
   * @memberOf  SearchServer
   */
  //表をクリック時に動作し、クリックを行った時に選択した行の色が変更する
  $('.scrollBody').mousedown(function (e) {
    //表の項目以外をクリック時には色を付けないようにする
    if (e.target.id != "main_scroll") {
      //テキストボックスに'selected'が挿入されてしまうため、判定しない
      if (e.target.className == "textBox" || e.target.className == "tr l" || e.target.className == "0 tr l"
        || e.target.className.match("EditTable")) {
        return;
      }
      if (e.target.nodeName == "SPAN") {
        if (e.target.parentElement.parentElement.id == 'selected') {
          document.getElementById('selected').removeAttribute("id");
          return true;
        } else {
          if (document.getElementById('selected') == null) {
            e.target.parentElement.parentElement.setAttribute('id', 'selected');
          }
          document.getElementById('selected').removeAttribute("id");
          e.target.parentElement.parentElement.setAttribute('id', 'selected');
          return true;
        }
      }
      //一項目のみclick可能とする
      if (e.target.parentElement.id == 'selected') {
        document.getElementById('selected').removeAttribute("id");
      } else {
        if (document.getElementById('selected') == null) {
          e.target.parentElement.setAttribute('id', 'selected');
        }
        document.getElementById('selected').removeAttribute("id");
        e.target.parentElement.setAttribute('id', 'selected');
      }
    } else if (e.target.id == "main_scroll") {
      return false;
    }

  });
  //テキストボックスでキーボード入力を感知したとき反映ボタンを非活性
  $('#displayName').keyup(function (e) {
    textBoxCheck();
    if (textBoxCheckFlag === DISABLE_FALSE) {
      editCheck = DISABLE_TRUE;
      isEdit();
    } else {
      editCheck = DISABLE_FALSE;
      isEdit();
    }
  });
  $('#serverName').keyup(function (e) {
    textBoxCheck();
    if (textBoxCheckFlag === DISABLE_FALSE) {
      editCheck = DISABLE_TRUE;
      isEdit();
    } else {
      editCheck = DISABLE_FALSE;
      isEdit();
    }
  });
  $('#directoryPath').keyup(function (e) {
    textBoxCheck();
    if (textBoxCheckFlag === DISABLE_FALSE) {
      editCheck = DISABLE_TRUE;
      isEdit();
    } else {
      editCheck = DISABLE_FALSE;
      isEdit();
    }
  });
  $('#loginUserName').keyup(function (e) {
    textBoxCheck();
    if (textBoxCheckFlag === DISABLE_FALSE) {
      editCheck = DISABLE_TRUE;
      isEdit();
    } else {
      editCheck = DISABLE_FALSE;
      isEdit();
    }
  });
  $('#loginPassword').keyup(function (e) {
    textBoxCheck();
    if (textBoxCheckFlag === DISABLE_FALSE) {
      editCheck = DISABLE_TRUE;
      isEdit();
    } else {
      editCheck = DISABLE_FALSE;
      isEdit();
    }
  });
  //テキストボックスで右クリックを検知したとき反映ボタンを非活性
  $('#displayName').on('contextmenu', function (e) {
    textBoxCheck();
    if (textBoxCheckFlag === DISABLE_FALSE) {
      editCheck = DISABLE_TRUE;
      isEdit();
    } else {
      editCheck = DISABLE_FALSE;
      isEdit();
    }
  });
  $('#serverName').on('contextmenu', function (e) {
    textBoxCheck();
    if (textBoxCheckFlag === DISABLE_FALSE) {
      editCheck = DISABLE_TRUE;
      isEdit();
    } else {
      editCheck = DISABLE_FALSE;
      isEdit();
    }
  });
  $('#directoryPath').on('contextmenu', function (e) {
    textBoxCheck();
    if (textBoxCheckFlag === DISABLE_FALSE) {
      editCheck = DISABLE_TRUE;
      isEdit();
    } else {
      editCheck = DISABLE_FALSE;
      isEdit();
    }
  });
  $('#loginUserName').on('contextmenu', function (e) {
    textBoxCheck();
    if (textBoxCheckFlag === DISABLE_FALSE) {
      editCheck = DISABLE_TRUE;
      isEdit();
    } else {
      editCheck = DISABLE_FALSE;
      isEdit();
    }
  });
  $('#loginPassword').on('contextmenu', function (e) {
    textBoxCheck();
    if (textBoxCheckFlag === DISABLE_FALSE) {
      editCheck = DISABLE_TRUE;
      isEdit();
    } else {
      editCheck = DISABLE_FALSE;
      isEdit();
    }
  });
  //テキストボックスにドラッグ＆ドロップされた時反映ボタン非活性
  $('#displayName').on('drop', function (e) {
    textBoxCheck();
    if (textBoxCheckFlag === DISABLE_FALSE) {
      editCheck = DISABLE_TRUE;
      isEdit();
    } else {
      editCheck = DISABLE_FALSE;
      isEdit();
    }
  });
  $('#serverName').on('drop', function (e) {
    textBoxCheck();
    if (textBoxCheckFlag === DISABLE_FALSE) {
      editCheck = DISABLE_TRUE;
      isEdit();
    } else {
      editCheck = DISABLE_FALSE;
      isEdit();
    }
  });
  $('#directoryPath').on('drop', function (e) {
    textBoxCheck();
    if (textBoxCheckFlag === DISABLE_FALSE) {
      editCheck = DISABLE_TRUE;
      isEdit();
    } else {
      editCheck = DISABLE_FALSE;
      isEdit();
    }
  });
  $('#loginUserName').on('drop', function (e) {
    textBoxCheck();
    if (textBoxCheckFlag === DISABLE_FALSE) {
      editCheck = DISABLE_TRUE;
      isEdit();
    } else {
      editCheck = DISABLE_FALSE;
      isEdit();
    }
  });
  $('#loginPassword').on('drop', function (e) {
    textBoxCheck();
    if (textBoxCheckFlag === DISABLE_FALSE) {
      editCheck = DISABLE_TRUE;
      isEdit();
    } else {
      editCheck = DISABLE_FALSE;
      isEdit();
    }
  });
});

/**
 *
 *
 */
function textBoxCheck() {
  var objDisplayName = document.getElementById('displayName');
  var objServerName = document.getElementById('serverName');
  var objDirectoryPath = document.getElementById('directoryPath');
  var objLoginUserName = document.getElementById('loginUserName');
  var objLoginPassword = document.getElementById('loginPassword');

  if (objDisplayName.value !== "") {
    textBoxCheckFlag = DISABLE_FALSE;
  } else if (objServerName.value !== "") {
    textBoxCheckFlag = DISABLE_FALSE;
  } else if (objDirectoryPath.value !== "") {
    textBoxCheckFlag = DISABLE_FALSE;
  } else if (objLoginUserName.value !== "") {
    textBoxCheckFlag = DISABLE_FALSE;
  } else if (objLoginPassword.value !== "") {
    textBoxCheckFlag = DISABLE_FALSE;
  } else {
    textBoxCheckFlag = DISABLE_TRUE;
  }
}

/** 
 * 表示項番を更新する
 */
function DisplayNo() {
  for (let i = 1; i < document.getElementById('main_scroll').childElementCount + 1; i++) {
    document.getElementById('main_scroll').children[i - 1].children[1].innerText = "" + i;
  }
}

/**
 * キャンセルボタン押下時に動作しダイアログを表示する
 */
function searchServerCancel() {
  blCan = confirm(cancelSelectedMessage);
  if (blCan) {
    isCancel = true;
    window.close();
  } else {
    return;
  }
}

/**
 * 編集キャンセルボタン押下時に動作し編集状態を解除し、テキストボックス内を空にする
 */
function editCancel() {
  if (document.getElementsByClassName('EditMode').length > 0) {
    var objDisplayName = document.getElementById('displayName');
    var objServerName = document.getElementById('serverName');
    var objDirectoryPath = document.getElementById('directoryPath');
    var objLoginUserName = document.getElementById('loginUserName');
    var objLoginPassword = document.getElementById('loginPassword');

    //テキストボックス内の文字列削除する
    objDisplayName.value = "";
    objServerName.value = "";
    objDirectoryPath.value = "";
    objLoginUserName.value = "";
    objLoginPassword.value = "";

    //非アクティブ化状態に移行するため、クラスの削除する
    document.getElementById('main_scroll').classList.remove("EditMode");
    document.getElementsByClassName("EditTable")[0].classList.remove("EditTable");

    //ラベル名を修正する
    document.getElementById("reflectBtn").value = "追加";
    document.getElementById("editCancelBtn").value = "入力クリア";

    //「設定反映ボタン」をenableに変更する
    addBtnCheck = DISABLE_FALSE;
    //「編集ボタン」を非活性状態に変更する
    editCheck = DISABLE_FALSE;

    // 全ボタンの状態更新
    btnAllCheck();
  } else {
    var objDisplayName = document.getElementById('displayName');
    var objServerName = document.getElementById('serverName');
    var objDirectoryPath = document.getElementById('directoryPath');
    var objLoginUserName = document.getElementById('loginUserName');
    var objLoginPassword = document.getElementById('loginPassword');

    //テキストボックス内の文字列削除する
    objDisplayName.value = "";
    objServerName.value = "";
    objDirectoryPath.value = "";
    objLoginUserName.value = "";
    objLoginPassword.value = "";

    //「編集ボタン」を非活性状態に変更する
    editCheck = DISABLE_FALSE;
    isEdit();
  }
}

/**
 * 削除ボタン押下時に動作し、選択した行を削除する
 */
function searchServerDeleteRow() {
  if (document.getElementById('selected') !== null) {

    if (!document.getElementById("selected").classList.contains("EditTable")) {

      //項番の値取得する
      var strDeleteRow = document.getElementById("selected").children[0].outerText;

      //新規作成で表示されているリストの場合、classからリスト番号を取得する
      var strAddChangeRow = document.getElementById("selected").classList[0];

      //グローバル変数に項番の値を設定する
      deleteDBNo.push(strDeleteRow);

      //連想配列の削除する
      if (changedValues[strDeleteRow]) {
        delete changedValues[strDeleteRow];
        if (addValues[strAddChangeRow]) {
          delete addValues[strAddChangeRow];
        }
      } else if (addValues[strAddChangeRow]) {
        delete addValues[strAddChangeRow];
      }

      //選択した行の削除する
      $("#selected").remove();

      //項番の付け直しをする
      var strAutoRowNo = document.getElementById("main_scroll").childElementCount;
      for (var i = 0; i < strAutoRowNo; i++) {
        //選択した行に非表示要素があるかの判断する
        $('.scrollBody ul').eq(i).children().eq(1).text("" + (i + 1));
      }
      // 削除した結果0件になった場合編集／削除ボタンを非活性状態に変更する
      if (document.getElementById('main_scroll').childElementCount == 0) {
        //「編集ボタン」を非活性状態に変更する
        editCheck = DISABLE_TRUE;
        //「削除ボタン」を非活性状態に変更する
        deleteCheck = DISABLE_TRUE;
      }

      // 全ボタンの状態更新
      btnAllCheck();

    } else {
      alert(deleteEditListMessage);
    }
  } else {
    alert(selectedNotClickDeleteMessage);
  }
}


/** 
 * 編集ボタン押下時に動作し、選択した項目内容を変更する 
 */
function searchServerEdit() {

  //テキストボックスの変数化する
  var objDisplayName = document.getElementById('displayName');
  var objServerName = document.getElementById('serverName');
  var objDirectoryPath = document.getElementById('directoryPath');
  var objLoginUserName = document.getElementById('loginUserName');
  var objLoginPassword = document.getElementById('loginPassword');

  if (document.getElementById('selected') != null || document.getElementsByClassName('EditMode').length != 0) {
    //編集状態アクティブ化か判断する
    if (document.getElementsByClassName('EditMode').length == 0) {

      //編集がアクティブ状態のため、クラス付与する
      $('#main_scroll').eq(0).addClass('EditMode');
      $('#selected').eq(0).addClass('EditTable');

      // 認証時チェック
      if (!objDisplayName.value) {
        var strDisplayList = document.getElementById("selected");
        var serverName = strDisplayList.children[3].outerText;
        objDisplayName.value = strDisplayList.children[2].outerText;
        objServerName.value = strDisplayList.children[3].outerText;
        objLoginUserName.value = strDisplayList.children[4].outerText;
        objDirectoryPath.value = strDisplayList.children[5].outerText;
      }

      //ラベル名を修正する
      document.getElementById("reflectBtn").value = "反映";
      document.getElementById("editCancelBtn").value = "編集キャンセル";

      //「設定反映ボタン」を非活性状態に変更する
      addBtnCheck = DISABLE_TRUE;
      //「編集ボタン」を非活性状態に変更する
      editCheck = DISABLE_TRUE;

      btnAllCheck();
      return;

    } else if (document.getElementById('selected') == null || document.getElementsByClassName('EditMode').length != 0) {
      return;
    }

  } else {
    alert(selectedNotClickEditMessage);

    //「設定反映ボタン」をenableに変更しない
    editCheck = DISABLE_FALSE;

    return false;
  }
}

/** 
 * 設定反映ボタン押下時に動作する 
 */
function postItem() {
  // POST用json
  var jsonObj = new Object();
  // 削除項目のIDをデータ受け渡し用タグに格納する
  jsonObj.deleteRow = deleteDBNo;
  // 編集項目の値をデータ受け渡し用タグに格納する
  var postChangeValues = [];
  for (var cv in changedValues) {
    postChangeValues.push(changedValues[cv]);
  }
  jsonObj.changedValues = postChangeValues;
  // 追加項目の値をデータ受け渡し用タグに格納する
  var postAddValues = [];
  // リクエストパラメータに合うように変更する
  for (var av in addValues) {
    console.log(addValues[av]);
    postAddValues.push(addValues[av]);
  }
  jsonObj.addValues = postAddValues;
  console.log(jsonObj);

  //POST処理を実施する
  $.ajax({
    url: hostUrl + "/save",
    type: "POST",
    contentType: "application/json",
    data: JSON.stringify(jsonObj),
    // ajax通信成功時の処理を実施する
  }).done(function (data) {
    let successOrFailure = "";
    console.log(data);
    // 画面を更新する
    isPost = true;
    alert(addReflectSettingMessage);
    location.reload();
    // 更新フラグをONに変更する
    // ajax通信失敗時の処理を実施実施
  }).fail(function (xhr, textStatus, errorThrown) {
    //alert(xhr.responseText + "\r\n設定反映に失敗しました。");
    alert(addReflectSettingFailureMessage);
    // 成功でも失敗でも通信終了時に必要な処理があれば記載する
  }).always(function () {
  });
}

/**
 * 全てのボタンの「活性」・「非活性」を判定する
 */
function btnAllCheck() {
  // 追加／編集／削除のデータが無い場合
  if (!Object.keys(addValues).length && !Object.keys(changedValues).length && !deleteDBNo.length) {
    // 設定反映ボタンを非活性状態にする
    addBtnCheck = DISABLE_TRUE;
  } else {
    // 設定反映ボタンを活性状態にする
    addBtnCheck = DISABLE_FALSE;
  }// if

  isAdd();
  isEdit();
  isEditCancel();
  isReflect();
  isDelete();
}

/** 
 * 設定反映ボタンの「活性」「非活性」を判定する 
 */
function isAdd() {
  if (addBtnCheck == 0) {
    $("#addBtn").prop("disabled", true);
    return true;
  }
  $("#addBtn").prop("disabled", false);
  return false;
}

/** 
 * 編集ボタンの「活性」「非活性」を判定する 
 */
function isEdit() {
  if (editCheck == 0) {
    $("#editBtn").prop("disabled", true);
    return true;
  }
  $("#editBtn").prop("disabled", false);
  return false;
}

/** 
 * 編集キャンセルボタンの「活性」「非活性」を判定する 
 */
function isEditCancel() {
  if (editCancelCheck == 0) {
    $("#editCancelBtn").prop("disabled", true);
    return true;
  }
  $("#editCancelBtn").prop("disabled", false);
  return false;
}

/** 
 * 反映ボタンの「活性」「非活性」を判定する 
 */
function isReflect() {
  if (reflectCheck == 0) {
    $("#reflectBtn").prop("disabled", true);
    return true;
  }
  $("#reflectBtn").prop("disabled", false);
  return false;
}

/** 
 * 削除ボタンの「活性」「非活性」を判定する 
 */
function isDelete() {
  if (deleteCheck == 0) {
    $("#deleteBtn").prop("disabled", true);
    return true;
  }
  $("#deleteBtn").prop("disabled", false);
  return false;
}

$(function () {
  // Ajax通信テスト ボタンクリックする
  $("#reflectBtn").click(function () {
    var strServerName = $('#serverName').val();
    var strDisplayName = $('#displayName').val();
    var strDirectoryPath = $('#directoryPath').val();
    var strLoginUserName = $('#loginUserName').val();
    var strLoginPassword = $('#loginPassword').val();

    //未入力チェックを実施する
    if (strServerName == "") {
      alert(serverNameNullMessage);
      return false;
    } else if (strDisplayName == "") {
      alert(displayNameNullMessage);
      return false;
    } else if (strDirectoryPath == "") {
      alert(directoryPathNullMessage);
      return false;
    }
    // 対象サーバに/\が入力されていない事の確認
    if (strServerName.match(/[\/\\]/)) {
      alert(serverNameValidMessage);
      return false;
    }

    // コントローラに渡すjsonオブジェクトを作成する
    var jsonObj = new Object();
    jsonObj.displayName = strDisplayName;
    jsonObj.serverName = strServerName;
    jsonObj.directoryPath = strDirectoryPath;
    jsonObj.loginUserName = strLoginUserName;
    jsonObj.loginPassword = strLoginPassword;

    $.ajax({
      url: hostUrl + "/auth",
      type: "POST",
      contentType: "application/json",
      data: JSON.stringify(jsonObj),
      dataType: "json"
      // ajax通信成功時の処理を実施する
    }).done(function (data, textStatus, jqXHR) {
      let successOrFailure = "";
      if (data == "success") {

        var objDisplayName = document.getElementById('displayName');
        var objServerName = document.getElementById('serverName');
        var objDirectoryPath = document.getElementById('directoryPath');
        var objLoginUserName = document.getElementById('loginUserName');
        var objLoginPassword = document.getElementById('loginPassword');
        var objAutoRowNo = document.getElementById("main_scroll").childElementCount + 1;
        strAutoRowNo = '' + objAutoRowNo;

        //編集状態がアクティブ化しているか判断をする
        if (document.getElementsByClassName('EditMode').length == 0) {
          //連想配列の作成する
          addValues[addListCount] = {
            ["displayName"]: objDisplayName.value,
            ["serverName"]: objServerName.value,
            ["directoryPath"]: objDirectoryPath.value,
            ["loginUserName"]: objLoginUserName.value,
            ["loginPassword"]: objLoginPassword.value
          };

          // 登録されているkey, valueを順に取得する
          var ul = $('<ul class="' + addListCount + ' tr l"></ul>');
          var strNotDisplay = $('<li class="w0" style="display: none;"></li>');
          var strDisplay = $('<li class="w40"></li>');
          var strDisplayName = $('<li class="w180"></li>');
          var strServerName = $('<li class="w240"></li>');
          var strUserName = $('<li class="w180"></li>');
          var objFilePass = $('<li class="wAutoA B text_align_left"></li>');
          addListCount++;

          //表に取得した値を挿入する
          $(".scrollBody").append(ul);
          ul.append(strNotDisplay).append(strDisplay).append(strDisplayName).append(strServerName).append(strUserName).append(objFilePass);
          strDisplay.html(objAutoRowNo);
          strDisplayName.html(objDisplayName.value);
          strServerName.html(objServerName.value);
          strUserName.html(objLoginUserName.value);
          objFilePass.html(objDirectoryPath.value);

          //テキストボックス内の文字列削除する
          objDisplayName.value = "";
          objServerName.value = "";
          objDirectoryPath.value = "";
          objLoginUserName.value = "";
          objLoginPassword.value = "";

          //「編集ボタン」をenableに変更する
          editCheck = DISABLE_FALSE;
          //「削除ボタン」をenableに変更する
          deleteCheck = DISABLE_FALSE;
          // 全ボタンの状態更新
          btnAllCheck();

          fillDomWidth();
          var mainDom = document.querySelector(".table.LIST");
          var trs = mainDom.querySelectorAll("ul")
          var lineAndColumns = Array.from(trs).map(item => {
            return Array.from(item.querySelectorAll("li"))
          })
          new ResizableGrid(mainDom, lineAndColumns)


          var alignHeight = new AlignHeight(
            Array.from(document.querySelectorAll("#main_scroll ul"))
          )

          console.log(addValues);

          //編集状態アクティブ化の場合下記処理を実施する
        } else if (document.getElementsByClassName('EditMode').length > 0) {
          //項番の値取得する
          var strChangeRow = document.getElementsByClassName("EditTable")[0].children[0].outerText;

          //「編集ボタン」を非活性状態に変更する
          editCheck = DISABLE_FALSE;
          //ラベル名を修正する
          document.getElementById("reflectBtn").value = "追加";
          document.getElementById("editCancelBtn").value = "入力クリア";

          var serverList = document.getElementsByClassName("EditTable")[0];
          serverList.children[2].valueOf().textContent = objDisplayName.value;
          serverList.children[3].valueOf().textContent = objServerName.value;
          serverList.children[4].valueOf().textContent = objLoginUserName.value;
          serverList.children[5].valueOf().textContent = objDirectoryPath.value;

          // 連想配列作成・追加する
          if (!changedValues[strChangeRow]) {
            changedValues[strChangeRow] = {
              ["serverId"]: strChangeRow,
              ["displayName"]: objDisplayName.value,
              ["serverName"]: objServerName.value,
              ["loginUserName"]: objLoginUserName.value,
              ["loginPassword"]: objLoginPassword.value,
              ["directoryPath"]: objDirectoryPath.value
            };
          } else {
            changedValues[strChangeRow]["serverId"] = strChangeRow;
            changedValues[strChangeRow]['displayName'] = objDisplayName.value;
            changedValues[strChangeRow]['serverName'] = objServerName.value;
            changedValues[strChangeRow]['loginUserName'] = objLoginUserName.value;
            changedValues[strChangeRow]['loginPassword'] = objLoginPassword.value;
            changedValues[strChangeRow]['directoryPath'] = objDirectoryPath.value;
          }

          //テキストボックス内の文字列削除する
          objDisplayName.value = "";
          objServerName.value = "";
          objDirectoryPath.value = "";
          objLoginUserName.value = "";
          objLoginPassword.value = "";

          console.log(changedValues);
          //非アクティブ化状態に移行するため、クラスの削除する
          document.getElementById('main_scroll').classList.remove("EditMode");
          document.getElementsByClassName("EditTable")[0].classList.remove("EditTable");

          //「設定反映ボタン」をenableに変更する
          addBtnCheck = DISABLE_FALSE;
          // 全ボタンの状態更新
          btnAllCheck();

          var mainDom = document.querySelector(".table.LIST");
          var trs = mainDom.querySelectorAll("ul")
          var lineAndColumns = Array.from(trs).map(item => {
            return Array.from(item.querySelectorAll("li"))
          })
          new ResizableGrid(mainDom, lineAndColumns)


          var alignHeight = new AlignHeight(
            Array.from(document.querySelectorAll("#main_scroll ul"))
          )

        }

      } else if (data == "failure" || data == "1219" || data == "86") {
        alert(authenticationSettingFailureMessage);
      }
      console.log(jqXHR.status);
      // ajax通信失敗時の処理を実施する
    }).fail(function (jqXHR, textStatus, errorThrown) {
      console.log(jqXHR.status);
      alert(authenticationSettingFailureMessage);
      // 成功でも失敗でも通信終了時に必要な処理があれば追加記載をする
    }).always(function () {
    });

    console.log(jsonObj);

  });
});
