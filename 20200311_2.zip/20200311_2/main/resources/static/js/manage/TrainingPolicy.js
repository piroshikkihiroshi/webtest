/** 
 * @fileOverview 教師データポリシー設定画面
 * @author NEC
 * @version 1.0.0
 */
//グローバル変数

/**
 * ボタン無効状態の定数
 * @memberOf SearchServer
 * @constant {Number} DISABLE_TRUE
*/
DISABLE_TRUE = 0;
/**
 * ボタン有効状態の定数
 * @memberOf SearchServer
 * @constant {Number} DISABLE_FALSE
*/
DISABLE_FALSE = 1;

/**
 * 登録ボタンの有効(1)／無効(0)状態を保持する変数
 * @memberOf SearchServer
 * @type {Number}
 */
var regBtnCheck = DISABLE_TRUE;

/**
 * 編集前の登録データ一覧を保持する変数
 * @memberOf SearchServer
 * @type {Object}
 */
var beforeRegDataList = [];

/**
 * サーバへのリクエストが成功(true)／失敗(false)を保持する変数
 * @memberOf SearchServer
 * @type {Number}
 * @default false
 */
var isPost = false;

/**
 * キャンセルボタンが押下されたかを保持する変数
 * @memberOf SearchServer
 * @type {Number}
 * @default false
 */
var isCancel = false;


// 現在のURL
var hostUrl = location.protocol + '//' + location.host + location.pathname;

//アラートメッセージ
var alreadyDirectoryPassMessage = "入力したディレクトリパスは既に設定済みです。";
var selectedNotClickLoadMessage = "ディレクトリパスを入力後、再度ボタンを押下してください。"
var savePassAddNullMessage = "保存先パスが入力されていません。";
var addReflectSettingCheckMessage = "変更した内容を反映しますか。";
var addReflectSettingMessage = "変更が反映されました。";
var addReflectSettingFailureMessage = "登録に失敗しました。";
var cancelSelectedMessage = "変更内容を破棄してもよろしいでしょうか。";
var notUserRoleOrLoginOutMessage = "ログインを行っていない、または管理者ではありません。";
var notSelectPolicyMessage = "ポリシーを選択してください。";

/** 
 * 動作関数
 * 読み込み時、ボタン制御等を行う。
 * @memberOf  Policy
*/
$(function () {

    // 画面ロード時にボタンの表示状態更新
    btnAllCheck();

    /**
     * 動作関数
     * 画面が変更または閉じれる時に動作
     * ダイアログを表示する
     * messageBoxで表示を行いたいが、検知の限界が存在する為「beforeunload」を使用する
     * 参考サイト：https://teratail.com/questions/51831
     * @memberOf  SearchServer
    **/
    $(window).on("beforeunload", function (e) {
        // NAS様opener対応(afterManageClose())
    	afterManageClose();
        // POST送信フラグが「true」の場合、ダイアログを表示しない
        if (isPost || isCancel) {
            return;
        } else {
            return true;
        }
    });

    
    /** 
     * 動作関数
     * @memberOf  Category
    */
    //Cookieを確認し、管理者権限またはログインしているかチェックを行う
    $(window).ready(function (e) {
        // ドメイン情報取得
        DomainCookie.initDomainCookie('[[${DomainInfo}]]');

        var userRole = DomainCookie.getUserRole();
        userRoleFlag = false;

        // ログインしてない場合
        if (userRole === null) {
            alert(notUserRoleOrLoginOutMessage);
            window.close();
            $("#addBtn").prop("disabled", true);
            $("#canBtn").prop("disabled", true);
        }

        //管理者権限か確認を行う
        if (userRole === "Administrators") {
            showUserName();
            showUserId();
            userRoleFlag = true;
        }

        //管理者権限、またはログインしていなかった場合画面を閉じる
        if (userRoleFlag !== true) {
            alert(notUserRoleOrLoginOutMessage);
            window.close();
            $("#addBtn").prop("disabled", true);
            $("#canBtn").prop("disabled", true);
        }

        //NAS様opener対応(beforeManageOpen())
        beforeManageOpen(3);
    })

    /**
     * 動作関数
     * 行をクリック後に動作
     * 何がクリックされたかによってイベントを振り分ける
     * @memberOf  SearchServer
     **/
    document.getElementById("main_scroll_R").addEventListener("click", function (event) {
        var li = event.target;
        console.log(li);
        // ×ボタン押下時動作
        if (li.classList.contains("DeleteRowTrainingPolicy") || li.classList.contains("NewDeleteRowTrainingPolicy")) {
            deleteRow(li);
        }// if

    }, false);// function

    /**
     * 動作関数
     * 登録データ一覧表読み完了後動作関数
     * 登録データ一覧の読み込みが完了後、一覧表の数が0だった場合ボタンをdisabledに変更を行う。
     * @memberOf  policy
     */
    $("#main_scroll_R").ready(function (e) {
        console.log("main_scroll_R");
        var policyList = $("#main_scroll_R")[0].children;

        // 1行目コピー用の空行となっているため開始番号は1
        for (var cnt = 1; cnt < policyList.length; cnt++) {
            var teacherPolicy = {};
            teacherPolicy["policyId"] = policyList[cnt].children[1].textContent;
            teacherPolicy["filePath"] = policyList[cnt].children[3].textContent;
            // 開始番号が1のため-1
            beforeRegDataList[cnt - 1] = teacherPolicy;
        }
        console.log(beforeRegDataList);
    });
});// function

/**
 * 動作関数
 * 選択された行を削除する。
 * @function
 * @memberOf SearchServer
 */
function deleteRow(li) {
    //選択した行にIDを付与
    li.parentElement.setAttribute("id", "selected");
    //選択した行の削除
    $("#selected").remove();
    // 削除した結果登録データが初期状態と変化しているかチェックする
    checkRegDataListChange();
}

/**
 * 動作関数
 * 出力ボタン押下時に動作
 * 一覧表に行の新規追加を行う
 * @function
 * @memberOf  SearchServer
**/
function addListData() {
    //現在の行数を取得
    var objAutoRowNo = document.getElementById("main_scroll_R").children.length + 1;
    var strAutoRowNo = '' + objAutoRowNo;

    var successCount = 0;
    //テキストボックス内の文字列取得
    var strAddFilePassListText = document.getElementById("addFilePassList").value;

    //最上位行のプルダウンメニュー内容を取得
    var strPullDownMenuList = document.getElementsByClassName("menu")[0].innerHTML;

    if (strAddFilePassListText !== "") {
        for (let index = 0; index < document.getElementById("main_scroll_R").children.length; index++) {
            var listFile = document.getElementById("main_scroll_R").children[index].children[3].outerText;
            if (listFile !== strAddFilePassListText) {
                successCount++;
            }
        }
        if (document.getElementById("main_scroll_R").children.length === successCount) {
            //新規作成する欄を作成
            var ul = $('<ul class="tr"></ul>');
            var strDeleteButton = $('<li class="w40 bt_batsu NewDeleteRowTrainingPolicy"></li>');
            var strNonViewPolicyId = $('<li style="display: none">0</li>');
            var strPolicyPullDown = $('<li class="w100 menu dropdown_arrow_right" style="position: relative;"> </li>');
            var strFilePassList = $('<li class="wAutoA B text_align_left"></li>');
            //表に取得した値を挿入する
            $(".scrollBody").append(ul);
            ul.append(strDeleteButton).append(strNonViewPolicyId).append(strPolicyPullDown).append(strFilePassList);
            strDeleteButton.html('');
            strFilePassList.html(strAddFilePassListText);
            //一覧追加用テキストボックスを空にする
            document.getElementById("addFilePassList").value = "";
            // 追加した結果登録データが初期状態と変化があるか確認する
            checkRegDataListChange();
            // 追加行にハイアラキーメニューを表示させるため再処理
            Array.from(document.querySelectorAll("#main_scroll_R ul li.menu")).map(item => hierarchyMenuProc(item));
            // wAutoAクラスのdomのサイズをほかのドムののこりのサイズで埋める
            fillDomWidth();
        } else {
            alert(alreadyDirectoryPassMessage);
        }
    } else {
        alert(selectedNotClickLoadMessage);
    }
}// function

/**
 * 動作関数
 * キャンセルボタン押下時に動作
 * ダイアログを表示する
 * @function
 * @memberOf  SearchServer
**/
function cancel() {
    blCan = confirm(cancelSelectedMessage);
    if (blCan) {
        isCancel = true;
        window.close();
        sessionStorage.clear();
    } else {
        return;
    }// if
}// function

/**
 * 動作関数
 * 登録ボタン押下時に動作
 * コントローラーへDB更新データをPOSTする
 * @function
 * @memberOf  SearchServer
 */
function postItem() {

    var savePath = $('#saveRegistrationList')[0].value;
    var policyList = $("#main_scroll_R")[0].children;
    var userId = $("#USER_ID")[0].textContent;

    console.log(savePath);
    // 保存先パスの入力チェック
    if (!savePath) {
        alert(savePassAddNullMessage);
        return;
    }

    //ポリシーIDのチェック、 1行目はコピー用の空行になっているため1から開始
    for (var i = 1; i < policyList.length; i++) {
        // ポリシーID
        var policyId = policyList[i].children[1].outerText;

        // ポリシーIDのチェック
        if (!policyId || policyId === "0") {
            alert(notSelectPolicyMessage);
            return;
        }
    }

    blCanPost = confirm(addReflectSettingCheckMessage);
    if (blCanPost) {

        //データ送信用
        var postData = {}
        // 送信データ列部
        var teacherPolicyList = [];
        // 1行目はコピー用の空行になっているため1から開始
        for (let i = 1; i < policyList.length; i++) {
            // ポリシーID
            var policyData = {};
            var policyId = policyList[i].children[1].outerText;
            var path = policyList[i].children[3].textContent;

            // ユーザ名
            policyData['userId'] = userId;
            // ソードID
            policyData['sortId'] = i;
            // ポリシーID
            policyData['policyId'] = policyId;
            // 格納先パス
            policyData['directoryPath'] = path;
            // iが1から開始しているため、-1
            teacherPolicyList[i - 1] = policyData;
        }
        //送信データ生成
        var jsonObj = new Object();

        jsonObj.tmpTeacherPolicyList = teacherPolicyList;
        jsonObj.savePath = savePath;

        console.log(jsonObj);

        $.ajax({
            url: hostUrl + "/teacher_policy_reflect",
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify(jsonObj),
            // ajax通信成功時の処理
        }).done(function (data) {
            isPost = true;
            let successOrFailure = "";
            console.log(data);
            alert(addReflectSettingMessage);
            // ajax通信失敗時の処理
            // 画面を更新する
            location.reload();
        }).fail(function (xhr, textStatus, errorThrown) {
        	if (xhr.status === 406) {
                alert(xhr.responseText);
        	} else {
                //alert(xhr.responseText + "\r\n登録データ一覧の更新処理に失敗しました");
                alert(addReflectSettingFailureMessage);
        	}
            // 成功でも失敗でも通信終了時に必要な処理があれば
        }).always(function () {
        });
    } else {
        return;
    }
}

/**
 * 動作関数
 * 全てのボタンの「活性」・「非活性」を判定する
 * @function
 * @memberOf  SearchServer
 */
function btnAllCheck() {
    isReg();
}

/**
 * 動作関数
 * 登録ボタンの「活性」「非活性」を判定する
 * @function
 * @memberOf  SearchServer
 */
function isReg() {
    if (regBtnCheck == 0) {
        $("#regBtn").prop("disabled", true);
    } else {
        $("#regBtn").prop("disabled", false);
    }//if
}// function

/**
 * 動作関数
 * 初期表示したときの登録データ一覧と変化があるか確認する
 * @function
 * @memberOf  SearchServer
 */
function checkRegDataListChange() {
    var policyList = $("#main_scroll_R")[0].children;
    //登録ボタンを無効にする
    regBtnCheck = DISABLE_TRUE;
    //初期状態の登録データ一覧と行数が同じか比較する（コピー行があるため、policyListは-1）
    if (beforeRegDataList.length === policyList.length - 1) {
        console.log("行数が同じ");
        //初期状態の登録データ一覧と分類及びファイルパスを比較する
        for (cnt = 0; cnt < beforeRegDataList.length; cnt++) {
            console.log("policyId  " + beforeRegDataList[cnt]["policyId"] + " == " + policyList[cnt + 1].children[1].textContent)
            // 初期状態から変化があった場合
            if (beforeRegDataList[cnt]["policyId"] != policyList[cnt + 1].children[1].textContent
                || beforeRegDataList[cnt]["filePath"] != policyList[cnt + 1].children[3].textContent) {
                //登録ボタンを有効にする
                regBtnCheck = DISABLE_FALSE;
                break;
            } //if
        }
    } else {
        //登録ボタンを有効にする
        regBtnCheck = DISABLE_FALSE;
    }// if
    // ボタンの状態を更新
    btnAllCheck();
}// function