
/** 
 * @fileOverview HTMLにおける表示上の最低限のコントロールを行います。
 * @author NEC
 * @version 1.0.0
 */
/*
 * @class StageManager
 * @param param.targetDoms
 *  サイズの調整を行うDom コレクション
 *  最初のdomに合わせてサイズの調整を行う
 *
 * @description
 * HTMLにおける表示上の最低限のコントロールを行います。
 * 参考：
 * ウィンドウの大きさを取得
 * https://web-designer.cman.jp/javascript_ref/window/size/
 * 要素の位置を取得
 * https://maku77.github.io/js/dom/elem-pos.html
 *
 */
'use strict'
class StageManager {
    constructor(param) {
        if(param.type === undefined){
            this.targetDoms = param.targetDoms;
            this.setTargetsSize();
            window.addEventListener("resize", this.setTargetsSize.bind(this))
        } else if (param.type === "type2"){
            this.targetDom = param.targetDom;
            this.referenceHeight = param.referenceHeight;
            this.setTargetsSizeType2()
            window.addEventListener("resize", this.setTargetsSizeType2.bind(this))
        }
    }
    setTargetsSizeType2(){
        var target = this.targetDom;
        var oldHeight = target.clientHeight;
        var top = target.getBoundingClientRect().top
        var windowHeight = document.documentElement.clientHeight - 1;
        // var documentHeight = document.body.clientHeight;
        var height = windowHeight - this.referenceHeight - top;
        target.style.height = height + "px";
    }
    setTargetsSize() {
        var target = this.targetDoms[0]
        var oldHeight = target.clientHeight;
        var top = target.getBoundingClientRect().top
        var documentHeight = document.body.clientHeight;
        var bottomHeight = documentHeight - top - oldHeight;
        var windowHeight = document.documentElement.clientHeight - 1;
        var height = windowHeight - bottomHeight - top;
        Array.from(this.targetDoms).map(item => {
            item.style.height = height + "px";
        })
    }
}