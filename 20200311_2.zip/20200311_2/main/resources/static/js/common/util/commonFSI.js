/**
 * @author NEC
 * @version 1.0.0
 */

var glMaskDocumentLists=[];
var glDocFileIdInfoLists=[];

/**
************通常関数************
*/

/**
* 初期表示：ユーザー名を表示する。
*/
function showUserName() {

    ////20191202 DomainCookieから取得
    var objUserDom = document.getElementById("USER_NAME");
    var domainUserName = "";
    try {
        domainUserName = DomainCookie.getUserName();
    } catch (error) {
        console.log(error);
    } //try
    if (domainUserName !== null) {
        objUserDom.innerText = objUserDom.innerText + domainUserName;
    } else {
        objUserDom.innerText = "";
    } //if


} //function

/**
* 初期表示：ユーザー名IDを表示する。
*/
function showUserId() {

    ////20191202 DomainCookieから取得
    var objUserIdDom = document.getElementById("USER_ID");
    var domainUserId = "";
    try {
        domainUserId = DomainCookie.getUserId();
    } catch (error) {
        console.log(error);
    } //try
    if (domainUserId !== null) {
        objUserIdDom.innerText = objUserIdDom.innerText + domainUserId;
    } else {
        objUserIdDom.innerText = "";
    } //if

} //function

/**
*  初期表示：ファイル名を表示する。 
*      fieldIdから紐付け文書か判定し、以下の条件で文書名を返却する
*      紐付け文書:紐付け元文書名
*      通常文書:通常文書名
*/
function showFileName() {
    //FileIdからMaskDocument経由で紐付け元文書逆引き
    getDocumentInfoFileId(glIntFileId);
    if(glDocFileIdInfoLists.length===0){ //通常表示
        var fileName = glFileName.substr(0, glFileName.lastIndexOf("."));
        var objFileDom = document.getElementById("FILE_NAME");
        objFileDom.innerText = objFileDom.innerText + fileName;

    }else{
        //元文書のdocument_id取得
        var strLinkFileName = glDocFileIdInfoLists[0].documentName;
        strLinkFileName = strLinkFileName.replace('.'+glDocFileIdInfoLists[0].extension,'');
        var objFileDom = document.getElementById("FILE_NAME");
        objFileDom.innerText = objFileDom.innerText + strLinkFileName;        
    } //if

} //function

// /**
// *  初期表示：ファイル名を表示する。 
// *      fieldIdから紐付け文書か判定し、以下の条件で文書名を返却する
// *      紐付け文書:紐付け元文書名
// *      通常文書:通常文書名
// */
// function showFileName() {
//     getDocumentInfo(glDocumentId);
//     var isProFlag = glDocumentInfoLists[0].procenterFlg;
//     var intNodeId = glDocumentInfoLists[0].nodeId;
//     var intFileId = glDocumentInfoLists[0].fileId;
//     var intFileUpdateTime = glDocumentInfoLists[0].fileUpdateTime;
//     var intMaskStatus = glDocumentInfoLists[0].maskStatus;
//     var isLink = false;

//     if(isProFlag&&(intMaskStatus === 1 || intMaskStatus === 2) && (intNodeId!==0) && (intFileId!==0)){ //Procenter連携候補
//         getMaskDocument(intFileId);
//         var intMaskUpdate = glMaskDocumentLists[0].updateTime;
//         //「document_info」の「file_update_time」>「mask_document」の「update_time」なら文書更新とみなす
//         if(intFileUpdateTime<intMaskUpdate){ //文書が更新されていない場合
//             isLink=true;
//         } //if
//     } //if

//     if(!isLink){ //通常表示
//         var fileName = glFileName.substr(0, glFileName.lastIndexOf("."));
//         var objFileDom = document.getElementById("FILE_NAME");
//         objFileDom.innerText = objFileDom.innerText + fileName;
//     }else{ //紐付け表示なので元文書のファイル名を表示する
//         getDocumentInfoFileId(intFileId);
//         var strLinkFileName = glDocFileIdInfoLists[0].filePath.replace(/^.*[\\\/]/, '').replace('.'+glDocFileIdInfoLists[0].extension,'');
//         var objFileDom = document.getElementById("FILE_NAME");
//         objFileDom.innerText = objFileDom.innerText + strLinkFileName;        

//     } //if

// } //function


/**
*  DocumentInfoのデータを取得(zip 全文テキストを除く)しjsonで返却する
* @return boolean
*/
function getDocumentInfo(documentId) {
    $.ajax({
        type: 'GET',
        url: 'rest/doc/rec?documentId=' + documentId,
        processData: false, // Ajaxがdataを整形しない指定
        contentType: false, // contentTypeもfalseに指定(Fileをアップロード時は必要)
        async: false, //非同期false
        success: function (retData) {
            glDocumentInfoLists = JSON.parse(retData);
            for (let i = 0; i < glDocumentInfoLists.length; i++) { //nullがあったら空文字にする
                //nullは空文字にしておく
                for (const key in glDocumentInfoLists[i]) {
                    if (glDocumentInfoLists[i][key] === null) {
                        glDocumentInfoLists[i][key] = '';
                    } //if
                } //for
            } //for
            console.log("success");
            return false;
        }, //function
        error: function (e) {
            console.log("fail");
            return false;
        } //function
    }); //ajax
} //function

/**
*  DocumentInfoのデータをfileIdで取得(zip 全文テキストを除く)しjsonで返却する
* @return boolean
*/
function getDocumentInfoFileId(fileId_i) {
    $.ajax({
        type: 'GET',
        url: 'rest/doc/rec/fileid?fileId=' + fileId_i,
        processData: false, // Ajaxがdataを整形しない指定
        contentType: false, // contentTypeもfalseに指定(Fileをアップロード時は必要)
        async: false, //非同期false
        success: function (retData) {
            glDocFileIdInfoLists = JSON.parse(retData);
            for (let i = 0; i < glDocFileIdInfoLists.length; i++) { //nullがあったら空文字にする
                //nullは空文字にしておく
                for (const key in glDocFileIdInfoLists[i]) {
                    if (glDocFileIdInfoLists[i][key] === null) {
                        glDocFileIdInfoLists[i][key] = '';
                    } //if
                } //for
            } //for
            console.log("success");
            return false;
        }, //function
        error: function (e) {
            console.log("fail");
            return false;
        } //function
    }); //ajax
} //function


/**
*  MaskDocumentのデータを取得(zipを除く)しjsonで返却する
* @return boolean
*/
function getMaskDocument(fileId) {
    $.ajax({
        type: 'GET',
        url: 'rest/maskdoc/rec?fileId=' + fileId,
        processData: false, // Ajaxがdataを整形しない指定
        contentType: false, // contentTypeもfalseに指定(Fileをアップロード時は必要)
        async: false, //非同期false
        success: function (retData) {
            glMaskDocumentLists = JSON.parse(retData);
            for (let i = 0; i < glMaskDocumentLists.length; i++) { //nullがあったら空文字にする
                //nullは空文字にしておく
                for (const key in glMaskDocumentLists[i]) {
                    if (glMaskDocumentLists[i][key] === null) {
                        glMaskDocumentLists[i][key] = '';
                    } //if
                } //for
            } //for
            console.log("success");
            return false;
        }, //function
        error: function (e) {
            console.log("fail");
            return false;
        } //function
    }); //ajax
} //function


/**
*  クライアントからサーバにクローズ処理を投げる
*/
function closeBlackPaint() {
    $.ajax({
        type: 'GET',
        url: 'rest/tmpdir/del',
        processData: false, // Ajaxがdataを整形しない指定
        contentType: false, // contentTypeもfalseに指定(Fileをアップロード時は必要)
        async: false, //非同期false
        success: function (retData) {
            console.log("success");
            return false;
        }, //function
        error: function (e) {
            console.log("fail");
            return false;
        } //function
    }); //ajax
} //function

function beforeOpen() {
    try {
        if ((window.opener) && (Object.keys(window.opener).length)) {
            if (window.opener.SearchMain && typeof window.opener.SearchMain.beforeChildOpen === 'function') {
                window.opener.SearchMain.beforeChildOpen();
            } //if
        } //if

    } catch (error) {
        console.log(error);
    } //try

} //function
