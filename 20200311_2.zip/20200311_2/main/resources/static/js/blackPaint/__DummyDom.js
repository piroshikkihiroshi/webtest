/**
 *
 * @class __DummyDom
 * @description
 *  Hierarchy.js のテスト用にターゲットのdomを生成します。
 *  これは実際のデータではなく表示確認用のダミーです
 *
 */
'use strict'
class __DummyDom {
    constructor(param) {
        var targetDom = param.targetDom;
        var dom = document.createElement("div")
        dom.innerText = "ハイアラキーメニューテスト用ダミー\nこれは実際のデータではなく表示確認用のダミーです.";
        dom.style.position = "absolute";
        dom.style.background = "#fff";
        dom.style.padding = "15px";
        dom.style.color = "#ff0000";
        dom.style.fontSize = "16px";
        dom.style.fontWeight = "normal";
        dom.style.top = "103px";
        dom.style.left = "68px";
        dom.style.border = "solid 1px #f00";
        targetDom.style = "reletive";
        targetDom.appendChild(dom);
        dom.addEventListener("mouseover", event => dom.style.fontWeight = "bold")
        dom.addEventListener("mouseout", event => dom.style.fontWeight = "normal")
        this.dom = dom;
    }
}
