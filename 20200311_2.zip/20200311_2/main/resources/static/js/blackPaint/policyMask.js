/**
 * @fileOverview 黒塗りポリシー選択画面
 * @author NEC
 * @version 1.0.0
 */

/**
 * 全解除ボタン押下時の処理を実施する
 * チェックボックスのON／OFFの切替えを行う
 * @function
 */
function allSelecet() {
	var checkCnt = 0;
	for (i = 0; i < document.all.c1.length; i++) {
		if (document.all.c1[i].checked == true) {
			checkCnt++;
		} // if
	} // for

	if (document.all.c1.length == checkCnt) {
		for (var i = 0; i < document.all.c1.length; i++) {
			document.all.c1[i].checked = false;
		} // for
		document.getElementById("allSelecet").innerText = "全選択";
	} else {
		for (i = 0; i < document.all.c1.length; i++) {
			document.all.c1[i].checked = true;
		} // for

		document.getElementById("allSelecet").innerText = "全解除";
	} // if
} //function


/**
 * 選択リセットボタン押下時の処理を実施する
 * 操作によるチェックボックスの選択をリセットする
 * @function
 */
function resetList() {
	for (i = 0; i < document.all.c1.length; i++) {
		document.all.c1[i].checked = false;
		for (j = 0; j < splitPolicySelect.length; j++) {
			strPolicyId = strPolicyList[i].substring(strPolicyList[i]
				.indexOf("policyId=") + 9, strPolicyList[i].indexOf(","));
			if (splitPolicySelect[j] == strPolicyId) {
				document.all.c1[i].checked = true;
			} // if
		} //f or
	} // for
	var checkCnt = 0;
	for (i = 0; i < document.all.c1.length; i++) {
		if (document.all.c1[i].checked == true) {
			checkCnt++;
		} //if
	} // for
	if (document.all.c1.length == checkCnt) {
		document.getElementById("allSelecet").innerText = "全解除";
	} else {
		document.getElementById("allSelecet").innerText = "全選択";
	} // if
} //function

/**
 * キャンセルボタン押下時の処理を実施する
 * 確認メッセージを表示する
 * @function
 */
function closePolicyList() {
	var blSel = confirm("本当にキャンセル操作をしますか？");
	if (blSel) {
		isPost = true;
		try {
			if ((window.opener) && (Object.keys(window.opener).length)) {
				if (window.opener.MaskMain
					&& typeof window.opener.MaskMain.afterChildClose === 'function') {
					window.opener.MaskMain.afterChildClose();
				} // if
			} // if
		} catch (error) {
			console.log(error);
		} finally {
			window.close();
		} // try

	} // if

} // function

/**
 * 確定ボタン押下時の処理を実施する
 * @function
 */
function confirmList() {
	var blSel = confirm("確定しますか？");
	if (blSel) {
		var selectPolicy = "";
		for (i = 0; i < document.all.c1.length; i++) {
			if (document.all.c1[i].checked == true) {
				strPolicyId = strPolicyList[i].substring(strPolicyList[i]
					.indexOf("policyId=") + 9, strPolicyList[i]
						.indexOf(","));
				selectPolicy += strPolicyId + ",";
			} // if
		} // for
		if (selectPolicy != "") {
			selectPolicy = selectPolicy.substring(0, selectPolicy.length - 1);
		} else {
			selectPolicy = "-1"
		} // if

		isPost = true;
		try {
			if ((window.opener) && (Object.keys(window.opener).length)) {
				if (window.opener.MaskMain
					&& typeof window.opener.MaskMain.afterChildClose === 'function') {
					window.opener.MaskMain.afterConfirm(selectPolicy);
				} // if
			} // if
		} catch (error) {
			console.log(error);
		} finally {
			window.close();
		} // try

	}// if

} // function

