package jp.co.nec.docmng.blackPaint.entity;
import java.sql.Timestamp;



public class MaskDocMarkerEntBlackPaint {



	public Integer getDocumentId() {
		return document_id;
	}
	public void setDocumentId(Integer document_id) {
		this.document_id = document_id;
	}
	public String getUserId() {
		return user_id;
	}
	public void setUserId(String user_id) {
		this.user_id = user_id;
	}
	public String getMarkerStartCd() {
		return marker_start_cd;
	}
	public void setMarkerStartCd(String marker_start_cd) {
		this.marker_start_cd = marker_start_cd;
	}
	public String getMarkerEndCd() {
		return marker_end_cd;
	}
	public void setMarkerEndCd(String marker_end_cd) {
		this.marker_end_cd = marker_end_cd;
	}
	public Integer getMarkerPolicy() {
		return marker_policy;
	}
	public void setMarkerPolicy(Integer marker_policy) {
		this.marker_policy = marker_policy;
	}
	public String getMarkerRemarks() {
		return marker_remarks;
	}
	public void setMarkerRemarks(String marker_remarks) {
		this.marker_remarks = marker_remarks;
	}
	public Timestamp getCreateTime() {
		return create_time;
	}
	public void setCreateTime(Timestamp create_time) {
		this.create_time = create_time;
	}
	public Timestamp getUpdateTime() {
		return update_time;
	}
	public void setUpdateTime(Timestamp update_time) {
		this.update_time = update_time;
	}
	private Integer document_id;
	private String user_id ;
	private String marker_start_cd;
	private String marker_end_cd;
	private Integer marker_policy;
	private String marker_remarks;
	private Timestamp create_time ;
	private Timestamp update_time ;


}
