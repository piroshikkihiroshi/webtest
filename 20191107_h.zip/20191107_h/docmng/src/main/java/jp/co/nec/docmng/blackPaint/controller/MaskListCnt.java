package jp.co.nec.docmng.blackPaint.controller;
import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MaskListCnt {

	@Autowired
	ServletContext context;

	@PostMapping("/MaskListCnt")
	public String getblackPaintInfo(@RequestParam("blackPaintList") String blackPaintList_i,Model model) {
		//来たJsonをそのまま帰す 必要があれば処理追加
		model.addAttribute("blackPaintList", blackPaintList_i); //黒塗りリスト表示画面用JSON


		return "blackPaint/MaskListView";
	} //getView1

} //MaskHtmlCnt
