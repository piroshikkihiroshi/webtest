package jp.co.nec.docmng.manege.util.map;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import jp.co.nec.docmng.manege.entity.PolicyKeywordInfo;

@Mapper
public interface PolicyKeywordInfoMapManege {

    @Select("select * from admin.policy_keyword_info order by policy_id")
    public List<PolicyKeywordInfo> findAll();

//    @Select("select * from admin.policy_keyword_info as keyword where keyword.policy_id = #{} order by keyword.keyword_id")
//    public List<PolicyKeywordInfo> selectByPolicyId();


}
