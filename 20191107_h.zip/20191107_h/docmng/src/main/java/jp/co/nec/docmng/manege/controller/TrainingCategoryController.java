package jp.co.nec.docmng.manege.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import jp.co.nec.docmng.manege.entity.CategoryInfo;
import jp.co.nec.docmng.manege.entity.CategoryInfoForm;
import jp.co.nec.docmng.manege.entity.TmpTeacherCategoryList;
import jp.co.nec.docmng.manege.service.CategoryInfoService;
import jp.co.nec.docmng.manege.service.TmpTeacherCategoryService;

@Controller
@RequestMapping("/manege/training_category")
public class TrainingCategoryController {

    @Autowired
    CategoryInfoService categoryInfoService;

    @Autowired
    TmpTeacherCategoryService tmpTeacherCategoryService;

    @GetMapping
    public String getTrainingCategory(Model model) {
        // 全件取得
        List<CategoryInfo> categoryInfos = categoryInfoService.findAll();
        model.addAttribute("categoryInfo", categoryInfos);

        List<TmpTeacherCategoryList> teacherCategoryLists = tmpTeacherCategoryService.findAll();
        model.addAttribute("teacherCategoryList", teacherCategoryLists);



//        model.addAttribute("");

        return "manege/training_category";
    }

    @PostMapping
    @ResponseBody
    public ArrayList<String> outputFile(@RequestBody CategoryInfoForm form) throws Exception {

        String directoryPass = form.getDirectoryPass();

        //Fileクラスのオブジェクトを生成する
        File dir = new File(directoryPass);

        //listFilesメソッドを使用して一覧を取得する
        File[] dirList = dir.listFiles();

        //指定した拡張子のファイルを格納する
        ArrayList<String> fileList = new ArrayList<>();

        if(dirList != null) {

            for(int i=0; i<dirList.length; i++) {

                //ファイルの場合
                if(dirList[i].isFile()) {
                    System.out.println("ファイルです : " + dirList[i].toString());
                    fileList.add(dirList[i].toString());
                }
                //ディレクトリの場合
                else if(dirList[i].isDirectory()) {
                    System.out.println("ディレクトリです : " + dirList[i].toString());
                }
            }
        } else {
            System.out.println("指定した配下にはファイル、またはディレクトリが存在しません");
        }

        return fileList;
    }
}
