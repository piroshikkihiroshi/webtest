//定数等
const TODAY = getNowYMD();
const MASK_HEAD = "mask_";
const RED_HEAD = 'red_';
const RED_FILE_NAME = "(査閲用)";
const MSK_FILE_NAME = "(公開用)";
const LST_FILE_NAME = "(黒塗諸元)";
const DROP_DOWN_ON_CLS = "dropdown_on";
const CATE_LIST_CLS ="cate_list"

var glIntPageAct = 1;
var glArrPaths = []; //maskpdfPath
var glArrRedPaths = []; //maskpdfPath

var glStrJson='';

/**
 * 本日日付を取得する
 * @return yyyy-mm-dd形式の本日日付
 *  */
function getNowYMD() {
    var objDate = new Date();
    var strYear = objDate.getFullYear();
    var strMonth = ("00" + (objDate.getMonth() + 1)).slice(-2);
    var strDate = ("00" + objDate.getDate()).slice(-2);
    var result = strYear + "-" + strMonth + "-" + strDate;
    return result;
} //getNowYMD


/**
 * 保存ファイル名を作成し、親フレームに埋め込む
 */
function makeSaveName() {
    var arrNames = glFileName.split(".");
    $("#redFileName")[0].innerText = arrNames[0]+RED_FILE_NAME;
    $("#mskFileName")[0].innerText = arrNames[0]+MSK_FILE_NAME;
    $("#lstFileName")[0].innerText = arrNames[0]+LST_FILE_NAME;
} //makeSaveName


/**
 * 次のページへページネーションする
 */
function pageNext() {
    if ( glIntPageAct < PAGE_MAX ) {
        //iframeの入れ替え
        var intActPage = glIntPageAct; //ページは自由入力なのでgl変数に保持している
        intActPage++;
        var strSrc = glArrPaths[intActPage-1];
        document.getElementById("pdf_src").src = strSrc;

        //親フレームの表示変更
        document.getElementById('pager_page_id').value = intActPage;
        glIntPageAct = intActPage;
    } //if
} //functon

/**
 * 前のページへページネーションする
 */
function pageBack() {
    if ( Number(glIntPageAct)>1 ) {
        //iframeの入れ替え
        var intActPage = glIntPageAct; //ページは自由入力なのでgl変数に保持している
        intActPage--;
        var strSrc = glArrPaths[intActPage-1];
        document.getElementById("pdf_src").src = strSrc;

        //親フレームの表示変更
        document.getElementById('pager_page_id').value = intActPage;
        glIntPageAct = intActPage;
    } //if

} //functon

/**
 * 指定したページへページネーションする
 */
function pageSelect(intTgtPage_i) {
    var strSrc = glArrPaths[intTgtPage_i-1];
    document.getElementById("pdf_src").src = strSrc;

    glIntPageAct = intTgtPage_i;
} //functon


/**
 * テキストボックスに入力したページへページネーションする
 */
function enterPager() {
	var intPage = Number(document.getElementById('pager_page_id').value);
	if((intPage!==undefined) && (intPage !==0) && (intPage<=PAGE_MAX) ){
    	pageSelect(intPage);
    	glIntPageAct= intPage;

	} //if
} //function

/**
* 分類一覧を取得する
* @return boolean
*/
function getCategoryAll(){
    $.ajax({
        type: 'GET',
        url: '/rest/category/all',
        processData: false, // Ajaxがdataを整形しない指定
        contentType: false, // contentTypeもfalseに指定(Fileをアップロード時は必要)
        async:false, //非同期false
        success: function (retData) {
            glCategoryLists=JSON.parse(retData);
            console.log("success");
            return false;
        }, //function
        error: function (e) {
            console.log("fail");
            return false;
        } //function
    }); //ajax

} //function


/**
* 分類プルダウンの初期設定する
*/
function setInitCategory() {

    //categoryList用HTML
    var strCateHtml = '';
    for (let i = 0; i < glCategoryLists.length; i++) {
        if (i===0) {
            strCateHtml+='<li class=" '+CATE_LIST_CLS+ ' '+DROP_DOWN_ON_CLS+'" value="'+ glCategoryLists[i].category_id + '">'+ glCategoryLists[i].category_name + '</li>';
        }else{
            strCateHtml+='<li class=" '+CATE_LIST_CLS+ '" value="'+ glCategoryLists[i].category_id + '">'+ glCategoryLists[i].category_name + '</li>';
        } //if
    } //for
    $("#catedrop")[0].innerHTML = strCateHtml;
    var objInitCate= document.getElementById("cateselect");
    objInitCate.innerText = glCategoryLists[0].category_name;

} //function

/**
 **********イベント イベント操作関係 **********
*/

/**
 * マウスダウンイベント
*/
function cateSelect(e) {

    //list内処理
    var listClass=$("."+CATE_LIST_CLS);
    var objCate= document.getElementById("cateselect");
    objCate.innerText = e.target.innerText;

    //全消し
    listClass.removeClass(DROP_DOWN_ON_CLS);
    //addClass
    e.target.classList.add(DROP_DOWN_ON_CLS);

} //function


/**
 * マウスダウンイベント
*/
function mouseDownAct(e) {

    //分類軸設定イベント
    if (e.target.className.indexOf(CATE_LIST_CLS) >= 0) {
        cateSelect(e);
        return ;
    } //if

} //function


/**
 * PROCENTER/C、mask_documentテーブルに指定ページの黒塗りPDF、黒塗り候補PDF、黒塗りリストを保存する
*/
function saveDoc() {
    var arrPrint = []; //印刷範囲のインデックス true：印刷 false 印刷無し
    //印刷範囲を取得する
    if ($("#PAGE_SETTING1").prop("checked")) { //全てのページ
        for (let i = 1; i < PAGE_MAX; i++) {
            arrPrint[i] = true;
        } //for

    }else{ //指定したページ
        for (let i = 1; i < PAGE_MAX; i++) { //一度全部false
            arrPrint[i] = false;
        } //for
        var strPages = $('#page_input')[0].value;
        //カンマでスプリットして特定ページを取得する
        var arrComma = strPages.split(',');
        for (let i = 0; i < arrComma.length; i++) {
            if (arrComma[i].indexOf('-') >= 0) { //ハイフンがあったら連続で格納
                var arrHyphen=arrComma[i].split('-');
                for (let j = Number(arrHyphen[0]); j <= Number(arrHyphen[arrHyphen.length-1]); j++) {
                    arrPrint[j] = true;
                } //for
            }else{
                arrPrint[Number(arrComma[1])] = true;
            } //if
        } //for
    } //if

    //glJsonを解体しておく
    var glblackPaintList = JSON.parse(glStrJson);
    keywords=glblackPaintList.keywords; //黒塗り単語の配列
    pages=glblackPaintList.pages;  //登場箇所の配列
    policyNames=glblackPaintList.policyNames; //ポリシー名の配列
    Reasons=glblackPaintList.Reasons; //黒塗り対処理由の配列
    Remarks=glblackPaintList.Remarks //黒塗りリストで記述した備考

    //categoryを引き当てる
    var cateId = 0;
    var strSelectCate=document.getElementById('cateselect').innerText;

    for (let i = 0; i < glCategoryLists.length; i++) {
        if (strSelectCate===glCategoryLists[i].category_name) {
            cateId=glCategoryLists[i].category_id;
            break;
        } //if
    } //for

    //更新日付
    var updateTime = document.getElementById('modifyDate').innerText;
    //保存期間
    var retentionPeriod = document.getElementById('FLAT_PICKER').value;

    //連想配列→jsonでpost
    let HashJson = {
        'tmpDir': [glStrTmpDir],
        'strFileName':[glFileName],
        'updateTime':[updateTime],
        'retentionPeriod':[retentionPeriod],
        'documentId':[gldocumentId],
        'arrPrint': arrPrint,
        'arrMaskPaths':glArrPaths,
        'arrRedPaths':glArrRedPaths,
        //以下は黒塗りリスト作成用(ページ番号分からないと作れないのでここで作成)
        'keywords':keywords,
        'pages':pages,
        'policyNames':policyNames,
        'Reasons':Reasons,
        'Remarks':Remarks

    };

    //保存controllerへポスト
    var strJson = '[' + JSON.stringify(HashJson) + ']';

    var objForm = document.createElement('form');
    var objReq = document.createElement('input');

    objForm.method = 'POST';
    objForm.action = "/SaveDocCnt";

    objReq.type = 'hidden'; //入力フォームが表示されないように
    objReq.name = 'strJson';
    objReq.value = strJson;

    objForm.appendChild(objReq);
    document.body.appendChild(objForm);
    objForm.submit();






} //function

