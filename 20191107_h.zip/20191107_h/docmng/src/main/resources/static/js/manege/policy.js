
//グローバル変数
Count = 0;

$(function () {

  /**
   * 画面が変更または閉じれる時に動作
   * ダイアログを表示する
   * messageboxで表示を行いたいが、検知の限界が存在する為「beforeunload」を使用する
   * 参考サイト：https://teratail.com/questions/51831
  **/
  $(window).on("beforeunload", function (e) {
    return true;
  });

  /**
   * 表をクリック時に動作
   * クリックを行った時に選択した行の色が変更される
  **/
  $('.scrollBody').mousedown(function (e) {
    //表の項目以外をクリック時には色を付けない
    if (e.target.id != "main_scroll") {
      //テキストボックスに'selected'が挿入されてしまうため、回避コード
      if (e.target.className == "textbox" || e.target.className == "tr l") {
        return;
      }// if
      if (e.target.nodeName == "SPAN") {
        if (e.target.parentElement.parentElement.id == 'selected') {
          document.getElementById('selected').removeAttribute("id");
          return true;
        } else {
          if (document.getElementById('selected') == null) {
            e.target.parentElement.parentElement.setAttribute('id', 'selected');
          }// if
          document.getElementById('selected').removeAttribute("id");
          e.target.parentElement.parentElement.setAttribute('id', 'selected');
          return true;
        }// if
      }// if
      //一項目のみclick可能とする
      if (e.target.parentElement.id == 'selected') {
        document.getElementById('selected').removeAttribute("id");
      } else {
        if (document.getElementById('selected') == null) {
          e.target.parentElement.setAttribute('id', 'selected');
        }// if
        document.getElementById('selected').removeAttribute("id");
        e.target.parentElement.setAttribute('id', 'selected');
      }// if
    } else if (e.target.id == "main_scroll") {
      return false;
    }// if

  });// function
});// function

//グローバル変数
var addValues = {};
var addListCount = 0;

/**
 * 新規作成ボタン押下時に動作
 * 一覧表の最下部に追加する
**/
function addList() {
  //非編集状態かつ編集中ではない場合
  if (document.getElementsByClassName('EditMode').length == 0 && document.getElementsByClassName("EditTable").length == 0) {
    //自動順位項番
    var objAutoRowNo = document.getElementById("main_scroll").childElementCount + 1;
    strAutoRowNo = '' + objAutoRowNo;

    //最大順位取得
    var objChildrenCountPoint = objAutoRowNo - 2;

    //最終行が新規作成テキストボックスか確認を行う
    if (document.getElementById("main_scroll").children[objChildrenCountPoint].children[2].children[0] == null || document.getElementById("main_scroll").children[objChildrenCountPoint].children[5].children[0] == null) {
      //編集行を、最終行に変更を行う
      if (document.getElementById('selected') != null) {
        document.getElementById('selected').removeAttribute("id");
      }// if

      //新規作成する欄を作成
      var ul = $('<ul id="selected"  class="tr l addListTable ' + addListCount + '"></ul>');
      var strPolicyNumber = $('<li style="display: none;"></li>');
      var strDisplayRanktd = $('<li class="w40"></li>');
      var strPolicyNametd = $('<li class="w120" ></li>');
      var strCreateTimetd = $('<li class="w120" ></li>');
      var strCreateUserNametd = $('<li class="w90 text_align_left" ></li>');
      var strBlackReasontd = $('<li class="w140" ></li>');
      var strBlackPointKeywordtd = $('<li class="wAutoA B text_align_left" style="width: 1347px;"></li>');

      //表に取得した値を挿入する
      $(".scrollBody").append(ul);
      ul.append(strPolicyNumber).append(strDisplayRanktd).append(strPolicyNametd).append(strCreateTimetd).append(strCreateUserNametd).append(strBlackReasontd).append(strBlackPointKeywordtd);
      strPolicyNumber.html("");
      strDisplayRanktd.html(strAutoRowNo);
      strPolicyNametd.html("<input type='text' id='newPolicyName' class='textbox' size='10' value=" + "" + "></imput>");
      strCreateTimetd.html("");//APサーバ設定時の時刻のため、表示を行わない
      strCreateUserNametd.html("");//現在ログインしているユーザー名を取得し、ここに入れる
      strBlackReasontd.html("<input type='text' id='newBlackReason' class='textbox' size='10' value=" + "" + " ></imput>");
      strBlackPointKeywordtd.html("");//対象キーワードは後々設定されるため、記載は行わない

    } else if (document.getElementById("main_scroll").children[objChildrenCountPoint].children[2].children[0].id == "newPolicyName" || document.getElementById("main_scroll").children[objChildrenCountPoint].children[5].children[0].id == "newBlackReason") {
      //現在新規作成中の順位を取得
      var objRowNo = document.getElementById("main_scroll").childElementCount;
      strRowNo = '' + objRowNo;

      //入力されているテキストボックス内容を取得
      var objNewPolicyNameText = document.getElementById("newPolicyName").value;
      var objNewBlackReasonText = document.getElementById("newBlackReason").value;

      //入力チェック
      if (objNewPolicyNameText == "") {
        alert("ポリシー名を入力後再度ボタンを押下してください");
        return false;
      } else if (objNewBlackReasonText == "") {
        alert("黒塗り対処理由を入力後再度ボタンを押下してください");
        return false;
      }// if

      //連想配列の作成
      addValues[addListCount] = { ["policyNumber"]: strRowNo, ["policyName"]: objNewPolicyNameText, ["policyReason"]: objNewBlackReasonText };
      addListCount++;

      //テキストボックス化を解除する
      document.getElementById("newPolicyName").outerHTML = objNewPolicyNameText;
      document.getElementById("newBlackReason").outerHTML = objNewBlackReasonText;

      //非アクティブ化状態に移行するため、クラスの削除
      document.getElementsByClassName("addListTable")[0].classList.remove("addListTable");

      return;
    }// if
    //編集状態かつ編集中の場合
  } else if (document.getElementsByClassName('EditMode').length > 0 && document.getElementsByClassName("EditTable").length > 0) {
    alert("現在編集中のため新規作成は行えません");
    return false;
  }// if
}// function


//グローバル変数
var changedValues = {};

/**
   * 編集ボタン押下時に動作
   * 選択した項目内容を変更する
  **/
function Edit() {
  //現在新規作成中の場合アラートを表示する
  if (document.getElementsByClassName('addListTable').length == 0) {
    //非編集状態かつ編集中ではない場合
    if (document.getElementsByClassName('EditMode').length == 0 && document.getElementsByClassName("EditTable").length == 0) {
      if (document.getElementById('selected').length != 0) {
        //編集がアクティブ状態のため、クラス付与
        $('#main_scroll').eq(0).addClass('EditMode');
        $('#selected').eq(0).addClass('EditTable');

        //選択行のポリシー名を取得
        var strPolicyText = $('#selected').eq(0).children()[2].valueOf().textContent;
        //選択行の黒塗り対処理由を取得
        var strPolicyReasonText = $('#selected').eq(0).children()[5].valueOf().textContent;

        //選択行のポリシー名をTextBox化
        $('#selected').eq(0).children()[2].innerHTML = "<input type='text' size='10' id='changePolicyName' class='textbox' value=" + strPolicyText + " ></imput>";
        //選択行の黒塗り対処理由をTextBox化
        $('#selected').eq(0).children()[5].innerHTML = "<input type='text' size='10' id='changeBlackReason' class='textbox' value=" + strPolicyReasonText + " ></imput>";
      }// if
      //編集状態かつ編集中の場合
    } else if (document.getElementsByClassName('EditMode').length > 0 && document.getElementsByClassName("EditTable").length > 0) {

      //追加時のリスト番号値取得
      var strChangeRow = $(".EditTable>li[style='display: none;']").text();

      //現在新規作成中の順位を取得
      var strRanktdNumber = document.getElementsByClassName("EditTable")[0].children[1].outerText

      //addValuesのリスト番号を取得
      var strAddChangeRow = document.getElementsByClassName("EditTable")[0].classList[2];

      //表示されている値の登録
      var strTextBoxPolicyName = document.getElementById("changePolicyName").value;
      var strTextBoxBlackReason = document.getElementById("changeBlackReason").value;

      // 連想配列作成・追加
      if (addValues[strAddChangeRow]) {
        addValues[strAddChangeRow]["policyName"] = strTextBoxPolicyName;
        addValues[strAddChangeRow]["policyReason"] = strTextBoxBlackReason;
        if (changedValues[strChangeRow]) {
          changedValues[strChangeRow]["policyName"] = strTextBoxPolicyName;
          changedValues[strChangeRow]["policyReason"] = strTextBoxBlackReason;
        }// if
      } else {
        if (!changedValues[strChangeRow]) {
          changedValues[strChangeRow] = { ["policyNumber"]: strRanktdNumber, ["policyName"]: strTextBoxPolicyName, ["policyReason"]: strTextBoxBlackReason };
        } else {
          changedValues[strChangeRow]["policyName"] = strTextBoxPolicyName;
          changedValues[strChangeRow]["policyReason"] = strTextBoxBlackReason;
        }// if
      }// if
      //テキストボックス化を解除する
      document.getElementById("changePolicyName").outerHTML = strTextBoxPolicyName;
      document.getElementById("changeBlackReason").outerHTML = strTextBoxBlackReason;

      //非アクティブ化状態に移行するため、クラスの削除
      document.getElementById('main_scroll').classList.remove("EditMode");
      document.getElementsByClassName("EditTable")[0].classList.remove("EditTable");

      return;
    }// if
  } else if (document.getElementsByClassName('addListTable').length > 0) {
    alert("現在新規作成中のため編集は行えません");
    return false;
  }// if
}// function

/**
 * 削除ボタン押下時に動作
 * 選択した行を削除する
**/
//グローバル変数
//DBデータの削除した項番
var deleteDBNo = [];

//行の削除を行う
function DeleteRow() {

  //ポリシーIDの値取得
  var strDeleteRow = $("#selected>li[style='display: none;']").text();

  //新規作成で表示されているリストの場合、classからリスト番号を取得
  var strAddChangeRow = document.getElementById("selected").classList[2];

  var changeValuesFlag = "false";
  //選択行のポリシー名を取得
  var strPolicyText = $('#selected').eq(0).children()[2].valueOf().textContent;
  //選択行の黒塗り対処理由を取得
  var strPolicyReasonText = $('#selected').eq(0).children()[5].valueOf().textContent;

  //グローバル変数にポリシーIDの値を取得する
  deleteDBNo.push(strDeleteRow);

  //連想配列の削除を行う
  if (changedValues[strDeleteRow]) {
    delete changedValues[strDeleteRow];
    if (addValues[strAddChangeRow]) {
      delete addValues[strAddChangeRow];
    }// if
  } else if (addValues[strAddChangeRow]) {
    delete addValues[strAddChangeRow];
  }// if

  //選択した行の削除
  $("#selected").remove();

  //ポリシーID付け直し
  var strAutoRowNo = document.getElementById("main_scroll").childElementCount;
  for (var i = 0; i < strAutoRowNo; i++) {
    //選択した行に非表示要素があるかの判断
    let hiddenKey = $(".scrollBody ul").eq(i).children("li[style='display: none;']").text();
    if (hiddenKey != "") {
      if ($('.scrollBody ul').eq(i).children().eq(1)[0].innerText !== "" + (i + 1)) {
        $('.scrollBody ul').eq(i).children().eq(1).text("" + (i + 1));
        changeValuesFlag = "true";
      }// if

      // 編集済み項目がある場合
      if (changedValues[hiddenKey]) {
        // 受け渡し用の配列の順位を変更
        changedValues[hiddenKey]['policyNumber'] = i + 1;
      } else if (changeValuesFlag === "true") {

        changedValues[hiddenKey] = { ["policyNumber"]: "" + (i + 1), ["policyName"]: strPolicyText, ["policyReason"]: strPolicyReasonText };
        changeValuesFlag = "false";
      }// if

    } else {
      //選択行の行番号を取得
      var strAddRow = $(".scrollBody ul").eq(i)[0].className;

      if (addValues[strAddRow]) {
        // 受け渡し用の配列の順位を変更
        addValues[strAddRow]['policyNumber'] = i + 1;
      }// if
      $(".scrollBody ul").eq(i).children()[1].valueOf().textContent = ("" + (i + 1));
    }// if
  }// for
}// function

/**
 * 順位▲ボタン押下時に動作
 * 選択した行の順位を上げる
**/

//行の位置変更を行う
function ChangeRankUp() {

  // tbody要素に指定したIDを取得し、変数「tbody」に代入
  var tbody = document.getElementById('main_scroll');
  // objのノードを取得し、変数「tr」に代入
  var ul = document.getElementById("selected");

  // もし「tr」の直前の兄弟ノード名が「TR」だった場合
  // （上に「行」が存在している場合）
  if (ul.children[1].outerText !== '1') {
    // 「tr」を直後の兄弟ノードの上に挿入
    tbody.insertBefore(ul, ul.previousSibling);
    tbody.insertBefore(ul, ul.previousSibling);
  } else {
    alert("現在指定している行が最上位順位のため変更出来ません")
    return false;
  }// if

  //ポリシーID付け直し
  var strAutoRowNo = document.getElementById("main_scroll").childElementCount;
  var changeValuesFlag = "false";

  for (var i = 0; i < strAutoRowNo; i++) {
    //選択した行に非表示要素があるかの判断
    let hiddenKey = $(".scrollBody ul").eq(i).children("li[style='display: none;']").text();
    if (hiddenKey != "") {
      if ($('.scrollBody ul').eq(i).children().eq(1)[0].innerText !== "" + (i + 1)) {
        $('.scrollBody ul').eq(i).children().eq(1).text("" + (i + 1));
        changeValuesFlag = "true";
      }// if

      // 編集済み項目がある場合
      if (changedValues[hiddenKey]) {
        // 受け渡し用の配列の順位を変更
        changedValues[hiddenKey]['policyNumber'] = i + 1;
      } else if (addValues[hiddenKey]) {
        // 受け渡し用の配列の順位を変更
        addValues[hiddenKey]['policyNumber'] = i + 1;
      } else if (changeValuesFlag === "true") {
        //選択行のポリシー名を取得
        var strPolicyText = $('#selected').eq(0).children()[2].valueOf().textContent;
        //選択行の黒塗り対処理由を取得
        var strPolicyReasonText = $('#selected').eq(0).children()[5].valueOf().textContent;

        changedValues[hiddenKey] = { ["policyNumber"]: "" + (i + 1), ["policyName"]: strPolicyText, ["policyReason"]: strPolicyReasonText };
        changeValuesFlag = "false";
      }// if
    } else {
      //選択行の行番号を取得
      var strAddRow = $(".scrollBody ul").eq(i)[0].className;

      if (addValues[strAddRow]) {
        // 受け渡し用の配列の順位を変更
        addValues[strAddRow]['policyNumber'] = i + 1;
      }// if
      $('.scrollBody ul').eq(i).children().eq(1).text("" + (i + 1));
    }// if
  }// for
};// function

/**
 * 順位▼ボタン押下時に動作
 * 選択した行の順位を下げる
**/

//行の位置変更を行う
function ChangeRankDown() {

  // tbody要素に指定したIDを取得し、変数「tbody」に代入
  var tbody = document.getElementById('main_scroll');
  // objのノードを取得し、変数「tr」に代入
  var ul = document.getElementById("selected");
  // 最大順位の取得
  var strMaxRanked = '' + tbody.childElementCount;

  // 指定している行が最終行の場合
  if (ul.nextSibling != null) {
    // もし「tr」の直前の兄弟ノード名が「TR」だった場合
    // （上に「行」が存在している場合）
    if (ul.children[1].outerText !== strMaxRanked) {
      // 「tr」を直後の兄弟ノードの上に挿入
      tbody.insertBefore(ul.nextSibling, ul);
      tbody.insertBefore(ul.nextSibling, ul);
    } else {
      alert("現在指定している行が最下位順位のため変更出来ません")
      return false;
    }// if

    //ポリシーID付け直し
    var strAutoRowNo = document.getElementById("main_scroll").childElementCount;
    //変更箇所の表示順位の変更に伴い変更箇所のフラグ判定
    var changeValuesFlag = "false";
    for (var i = 0; i < strAutoRowNo; i++) {
      //選択した行に非表示要素があるかの判断
      let hiddenKey = $(".scrollBody ul").eq(i).children("li[style='display: none;']").text();
      if (hiddenKey != "") {
        if ($('.scrollBody ul').eq(i).children().eq(1)[0].innerText !== "" + (i + 1)) {
          $('.scrollBody ul').eq(i).children().eq(1).text("" + (i + 1));
          changeValuesFlag = "true";
        }// if

        // 編集済み項目がある場合
        if (changedValues[hiddenKey]) {
          // 受け渡し用の配列の順位を変更
          changedValues[hiddenKey]['policyNumber'] = i + 1;
        } else if (addValues[hiddenKey]) {
          // 受け渡し用の配列の順位を変更
          addValues[hiddenKey]['policyNumber'] = i + 1;
        } else if (changeValuesFlag === "true") {
          //選択行のポリシー名を取得
          var strPolicyText = $('#selected').eq(0).children()[2].valueOf().textContent;
          //選択行の黒塗り対処理由を取得
          var strPolicyReasonText = $('#selected').eq(0).children()[5].valueOf().textContent;

          changedValues[hiddenKey] = { ["policyNumber"]: "" + (i + 1), ["policyName"]: strPolicyText, ["policyReason"]: strPolicyReasonText };
          changeValuesFlag = "false";
        }// if

      } else {
        //選択行の行番号を取得
        var strAddRow = $(".scrollBody ul").eq(i)[0].className;

        if (addValues[strAddRow]) {
          // 受け渡し用の配列の順位を変更
          addValues[strAddRow]['policyNumber'] = i + 1;
        }// if
        $('.scrollBody ul').eq(i).children().eq(1).text("" + (i + 1));
      }// if
    }// for
  } else {
    return false;
  }// if

};// function

/**
 * キャンセルボタン押下時に動作
 * ダイアログを表示する
**/
function Cancel() {
  blCan = confirm("変更内容を破棄してもよろしいでしょうか。");
  if (blCan) {
    window.close();
  } else {
    return;
  }// if
}// function


/**
* 設定反映ボタン押下時に動作
**/
function postItem() {
  console.log(addValues);
  console.log(changedValues);

  // 削除項目のIDをデータ受け渡し用タグに格納する
  $("input[name='deleteRow']").attr('value', deleteDBNo.toString());

  // 編集項目の値をデータ受け渡し用タグに格納する
  $("input[name='editValue']").attr('value', JSON.stringify(changedValues));

  // 追加項目の値をデータ受け渡し用タグに格納する
  alert(JSON.stringify(addValues));
  $("input[name='addValue']").attr('value', JSON.stringify(addValues));

  // POST送信フラグを「true」に設定
  isPost = true;

}

