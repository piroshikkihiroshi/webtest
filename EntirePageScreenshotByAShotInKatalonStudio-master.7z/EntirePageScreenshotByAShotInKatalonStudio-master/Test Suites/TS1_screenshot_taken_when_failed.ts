<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TS1_screenshot_taken_when_failed</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2018-09-04T17:15:23</lastRun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>2</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>true</rerunFailedTestCasesOnly>
   <testSuiteGuid>0b822a17-728f-489a-ba3f-49296ebb35fa</testSuiteGuid>
   <testCaseLink>
      <guid>340b6297-bcf1-456f-bde7-a46290dbfad5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC1_screenshot_taken_when_failed</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
