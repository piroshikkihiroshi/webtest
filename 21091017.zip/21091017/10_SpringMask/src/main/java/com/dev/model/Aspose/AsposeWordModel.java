package com.dev.model.Aspose;


import com.aspose.words.Document;
import com.aspose.words.SaveFormat;


/**
 * AsposeライブラリのWordを操作するクラス
 * @author uedatats
 *
 */
public class AsposeWordModel {


	/**
	 * strDilPath_iのパスにstrOrgFileName_iからstrHtmlName_iのhtmlを作成する
	 * @param strDilPath_i
	 * @param strOrgFileName_i
	 * @param strHtmlName_i
	 * @return ページカウント
	 */
	public int wordToHtml(String strDilPath_i,String strOrgFileName_i,String strHtmlName_i) {
//		 変換対象のファイルの読み込み
		Document objDoc;
		int intPageCnt = 0;
		try {
			objDoc = new Document(strDilPath_i + strOrgFileName_i);
			intPageCnt=  objDoc.getPageCount() - 1;
			objDoc.save(strDilPath_i + strHtmlName_i , SaveFormat.HTML);
		} catch (Exception e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}  //try

		return intPageCnt;
	} //wordToHtml


} //class

