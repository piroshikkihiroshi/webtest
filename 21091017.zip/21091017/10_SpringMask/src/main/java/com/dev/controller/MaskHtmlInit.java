package com.dev.controller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MaskHtmlInit {

	@GetMapping("maskedit/MaskHtmlInit")
	public String getblackTextTest(Model model) {

		//testデータを入れる
//		String TGT_FILE_NAME= "\\\\yoks3104\\Project\\NES_文書管理システム\\99_tmp\\上田\\aspTest\\test.docx";
		String TGT_FILE_NAME= "C:\\temp\\SpringBoot.docx";
		String ALL_SEARCH_MOCK_DATA = "2:9+15:5";

		model.addAttribute("TGT_FILE_NAME", TGT_FILE_NAME);
		model.addAttribute("ALL_SEARCH_MOCK_DATA", ALL_SEARCH_MOCK_DATA);


		return "maskedit/MaskHtmlInit";
	} //getView1

} //MaskHtmlCnt
