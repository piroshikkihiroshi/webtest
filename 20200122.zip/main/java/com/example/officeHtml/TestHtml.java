package com.example.officeHtml;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

import com.aspose.html.HTMLDocument;
import com.aspose.html.rendering.HtmlRenderer;
import com.aspose.html.rendering.pdf.PdfDevice;
import com.aspose.words.Document;
import com.aspose.words.HtmlFixedPageHorizontalAlignment;
import com.aspose.words.HtmlFixedSaveOptions;

public class TestHtml {

	public static void main(String[] args){
		try {
			tester();
		} catch (Exception e) {
			e.printStackTrace();
		} //try
	} //main

	public static void tester() throws Exception {

		String strDir = "C:/Users/Public/Documents/test/";

		//Fileクラスのオブジェクトを生成する
        File dir = new File(strDir);

        //listFilesメソッドを使用して一覧を取得する
        File[] list = dir.listFiles();
        String strFile = "" ;
        String dstHtmlFile ="";
        String dstPdfFile ="";
        String strFileName ="";

        for(int i=0; i<list.length; i++) {
        	strFile = list[1].getAbsolutePath();
        	strFileName = list[i].getName();
        	if(list[i].isFile() && list[i].getName().contains(".doc")) {

        		if(strFileName.substring(strFileName.length() -4).equals(".doc")) {
        			dstHtmlFile = strFileName.replace(".doc", ".html");
            		dstPdfFile = strFileName.replace(".doc", ".pdf");
        		}else if(strFileName.substring(strFileName.length() -4).equals("docm")) {
        			dstHtmlFile = strFileName.replace(".docm", ".html");
            		dstPdfFile = strFileName.replace(".docm", ".pdf");
        		}else if(strFileName.substring(strFileName.length() -4).equals("docx")) {
        			dstHtmlFile = strFileName.replace(".docx", ".html");
            		dstPdfFile = strFileName.replace(".docx", ".pdf");
        		}


        		/* Word→HTML convert start */
        		System.out.println("Word→HTML convert start");

        		HtmlFixedSaveOptions htmlFixedSaveOptions = new HtmlFixedSaveOptions();
        		htmlFixedSaveOptions.setPageHorizontalAlignment(HtmlFixedPageHorizontalAlignment.CENTER);

        		htmlFixedSaveOptions.setExportEmbeddedSvg(false);

        		Document objDoc = new Document(strDir + strFileName);
        		objDoc.save(strDir + dstHtmlFile , htmlFixedSaveOptions);

        		System.out.println("Word→HTML convert end");
        		/* Word→HTML convert end */

        		/* HTML→PDF convert start */
        		System.out.println("HTML→PDF convert start");

        		InputStream fileStream=null;
        		fileStream = new FileInputStream(strDir + dstHtmlFile);
        		HTMLDocument htmlDocument = new HTMLDocument(fileStream,strDir + dstHtmlFile);

        		HtmlRenderer renderer = new HtmlRenderer();
        		FileOutputStream objOs = null;
        		PdfDevice objPdfDevice=null;
        		objOs = new FileOutputStream(strDir + dstPdfFile, true);
        		objPdfDevice = new PdfDevice(objOs);
        		renderer.render(objPdfDevice, htmlDocument);

        		System.out.println("HTML→PDF convert end");
        		/* HTML→PDF convert end */

        	}

        }






	} //tester
}