package com.example.officeHtml;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

import com.aspose.html.HTMLDocument;
import com.aspose.html.rendering.HtmlRenderer;
import com.aspose.html.rendering.pdf.PdfDevice;
import com.aspose.words.Document;
import com.aspose.words.HtmlFixedPageHorizontalAlignment;
import com.aspose.words.HtmlFixedSaveOptions;

public class TestHtml_bk {

	public static void main(String[] args){
		try {
			tester();
		} catch (Exception e) {
			e.printStackTrace();
		} //try
	} //main

	public static void tester() throws Exception {

		String strDir = "C:/TestHtml/";
		//strFile:InputFileName(Word)
		String strFile = "検索機能要件定義検討資料_20190902.docx";
//		String strFile = "黒塗り化検討について_20190828.docx";
		//dstFile:OutputFileName(HTML)
		String dstHtmlFile = "検索機能要件定義検討資料_20190902.html";
//		String dstHtmlFile = "黒塗り化検討について_20190828.html";
		//dstFile:OutputFileName(PDF)
		String dstPdfFile = "検索機能要件定義検討資料_20190902.pdf";
//		String dstPdfFile = "黒塗り化検討について_20190828.pdf";
		
		/* Word→HTML convert start */
		System.out.println("Word→HTML convert start");
		
		HtmlFixedSaveOptions htmlFixedSaveOptions = new HtmlFixedSaveOptions();
		htmlFixedSaveOptions.setPageHorizontalAlignment(HtmlFixedPageHorizontalAlignment.CENTER);
		
		htmlFixedSaveOptions.setExportEmbeddedSvg(false);

		Document objDoc = new Document(strDir + strFile);
		objDoc.save(strDir + dstHtmlFile , htmlFixedSaveOptions);
		
		System.out.println("Word→HTML convert end");
		/* Word→HTML convert end */
		
		/* HTML→PDF convert start */
		System.out.println("HTML→PDF convert start");
		
		InputStream fileStream=null;
		fileStream = new FileInputStream(strDir + dstHtmlFile);
		HTMLDocument htmlDocument = new HTMLDocument(fileStream,strDir + dstHtmlFile);
		
		HtmlRenderer renderer = new HtmlRenderer();
		FileOutputStream objOs = null;
		PdfDevice objPdfDevice=null;	
		objOs = new FileOutputStream(strDir + dstPdfFile, true);
		objPdfDevice = new PdfDevice(objOs);
		renderer.render(objPdfDevice, htmlDocument);
		
		System.out.println("HTML→PDF convert end");
		/* HTML→PDF convert end */
		
		
		

	} //tester
}