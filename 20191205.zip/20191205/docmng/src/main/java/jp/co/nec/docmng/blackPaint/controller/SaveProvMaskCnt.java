/**
 * 名称：SaveProvMaskCnt.java
 * 機能名：保存画面のControlを行う。
 * 概要：保存画面のControlを行う。
 */

package jp.co.nec.docmng.blackPaint.controller;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ResourceBundle;

import javax.servlet.ServletContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jp.co.nec.docmng.blackPaint.logic.HtmlToPdf.HtmlToPdfModel;
import jp.co.nec.docmng.blackPaint.logic.dirFile.DirCnt;
import jp.co.nec.docmng.blackPaint.logic.dirFile.FileCnt;
import jp.co.nec.docmng.blackPaint.logic.maskHtml.MaskHtmlModel;

/**
 * 保存画面のControlを行う。
 */

@Controller
public class SaveProvMaskCnt {

	/**
	 * context サーブレットのRealPathを取得する
	 * objLog log出力に使用する
	 * PAGE_CLASS ページを判定するHTMLClass。ページをSplitするのに使用する
	 * ARR_HEAD ファイル名、フォルダ名を判定するために使用する
	 */
	@Autowired
	ServletContext context;
	static Logger objLog = LoggerFactory.getLogger(SaveProvMaskCnt.class);

	static String PAGE_CLASS = "awdiv awpage"; //splitするページのHTMLClass
	static String[] ARR_HEAD = {"mask_","red_"}; //ファイル名、フォルダ名のヘッダー配列

	/**
	 * 保存画面初期表示メソッド
	 * 保存画面初期表示の処理をする。
	 * @param strTmpDir_i 黒塗り編集画面で処理したHTMLが格納されたTMPディレクトリ名。
	 * @param strRedHtml_i 黒塗り編集候補HTMLのouterHTML。
	 * @param strMaskHtml_i 黒塗り編集HTMLのouterHTML。
	 * @param strListJson_i 黒塗りリスト情報JSON。
	 * @param strTmpDir_i オリジナルwordファイル名。
	 * @throws IOException
	 */
	@PostMapping("/SaveProvMaskCnt")
	public String getblackPaintInfo(
			@CookieValue(value = "strTmpDirName") String strTmpDir_i,
			@RequestParam("strRedHtml") String strRedHtml_i,
			@RequestParam("strMaskHtml") String strMaskHtml_i,
			@RequestParam("listJson") String strListJson_i,
			@RequestParam("strFileName") String strFileName_i,
			@RequestParam("documentId") String documentId,
			@RequestParam("strFilePath") String strFilePath,
			@CookieValue(value = "user_id", required = false) String UserId,
			Model model) throws IOException{

		//モデル初期化
		FileCnt objFileCnt = new FileCnt();
		DirCnt objDirCls = new DirCnt();
		HtmlToPdfModel objPdfCls = new HtmlToPdfModel();
		MaskHtmlModel objHtmllCls = new MaskHtmlModel();

		objLog.info("作業フォルダ：" + strTmpDir_i);

		//メンバ変数初期化
		Document objDoc=null;
		String strBasePath =""; //黒塗り作成時の作業フォルダ
		String strHead=""; //ファイル名、フォルダ名のヘッダー
		String strFileOutDir=""; //PDF出力フォルダ
		String strHtmlDir=""; //黒塗り作成時HTMLに対するimg,css等が入っているフォルダ
		String strRealPath = context.getRealPath("/");
		String strOrgFileName = strFileName_i; //オリジナルwordファイル名
		String strRelativePath = ""; //iFrameに表示するための相対パス
		int intPages = 0; //PDFページ枚数
		String strTmpTimeStamp=""; //tempファイルタイムスタンプ
		strTmpTimeStamp=String.valueOf(System.currentTimeMillis());
		//拡張子無しファイル名取得
		String strFileWithoutExtension = objFileCnt.getNameWithoutExtension(strOrgFileName);

		int sizeRedPdf = 0; //黒塗り候補文書PDFのファイルサイズの合計
		int sizeMaskPdf = 0; //黒塗り文書PDFのファイルサイズの合計
		int sizeMaskListPdf = 0; //黒塗り文書リストPDFのファイルサイズ

		String strSizeRedPdf = ""; //黒塗り候補文書PDFのファイルサイズの合計
		String strSizeMaskPdf = ""; //黒塗り文書PDFのファイルサイズの合計
		String strSizeMaskListPdf = ""; //黒塗り文書リストPDFのファイルサイズ

		//黒塗りリスト(ファイルサイズ測る用)作成
        //******resources配下コピーしておく(controllerでないとできない)
        String strResouceOutPath = strRealPath + strTmpDir_i+"resources";
//		objDirCls.makeDirWithCheck(strResouceOutPath);
		//resouce配下をコピー
		String strResoucePath = "src/main/resources/";

		File objListPath =new File(strResoucePath);
		File objResoucePath = new File(strResouceOutPath);

		try {
			if (!objResoucePath.exists()) { //resouceがない場合だけコピー
				FileUtils.copyDirectory(objListPath, objResoucePath);
			} //

		} catch (IOException e) {
			e.printStackTrace();
			objLog.error("err message", e);
		} //try
		objListPath=null;
		objResoucePath=null;
		strBasePath=strRealPath + strTmpDir_i ;
		String strListOutDir = strBasePath+strHead+"listAll/";
		String strListAllPath = objHtmllCls.makeBrackPaint("["+strListJson_i+"]",UserId,strListOutDir,strRealPath,strFileWithoutExtension,strFilePath);
		//pdf化 sizeの取得
		String strListAll="";
		String strListPdfPath="";
		String strChkHtml="";

		objLog.info("strListOutDir：" + strListOutDir);

		try {
			strListAll = objFileCnt.readAll(strListAllPath);
			//strListAll = objFileCnt.readAll(strListAllPath);
//			strListPdfPath = strRealPath+strListOutDir+"/MaskListPrev.pdf";
			strListPdfPath =strBasePath+"MaskListPrev.pdf";
			//strChkHtml = objPdfCls.convertListHtmlToPdf(strListAll,strFileOutDir,strListPdfPath);

			objLog.info("strListPdfPath：" + strListPdfPath);

			strListPdfPath = objPdfCls.convertListHtmlToPdf(strListAllPath,strListPdfPath);
		} catch (IOException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} //try


		File maskListfile = new File(strListPdfPath);
		sizeMaskListPdf += maskListfile.length();
		FileInputStream maskListfis = new FileInputStream(maskListfile);
		maskListfis.close();


		//黒塗り候補PDFの作成 黒塗りPDFの作成
		for (int intIndex = 0; intIndex < ARR_HEAD.length; intIndex++) {
			strHead=ARR_HEAD[intIndex];
			strBasePath=strRealPath + strTmpDir_i ;
			FileWriter objFile=null;
			PrintWriter objPw=null;
			try {

				String strGetHtml = "";

				//出力フォルダ作成
				strFileOutDir=strBasePath+strHead+strTmpTimeStamp+"split"+"/";
				Path objSrcPath = Paths.get(strBasePath);
				Path objTgtPath = Paths.get(strFileOutDir);
				Files.copy(objSrcPath, objTgtPath);

				//html群をコピー
				strHtmlDir=strBasePath+strFileWithoutExtension+"/";
				File objHtmlPath = new File(strHtmlDir);
				File objTgtHtmlPath = new File(strFileOutDir+strFileWithoutExtension);
				FileUtils.copyDirectory(objHtmlPath, objTgtHtmlPath);

				//動的templateを作成
				String strOutHtml = "";
				strOutHtml+="<!DOCTYPE html> <html> <head> <meta http-equiv='Content-Type' content='text/html; charset=utf-8' /> <title>";
				strOutHtml+=strFileWithoutExtension;
				strOutHtml+="</title> <link rel='stylesheet' type='text/css' href='";
				strOutHtml+=strFileWithoutExtension;
				strOutHtml+="/styles.css' media='all' /> ";
				strOutHtml+=" <link rel='stylesheet' type='text/css' href='";
				strOutHtml+=strFileWithoutExtension;
				strOutHtml+="/mask.css' media='all' /> </head> <body>";

				//PDF作成処理
				if(strHead.equals("mask_")) {
					strGetHtml = strMaskHtml_i;
				}else {
					strGetHtml = strRedHtml_i;
				} //if


				objDoc = Jsoup.parse(strGetHtml);
				Elements elmCls= objDoc.getElementsByClass(PAGE_CLASS);

				for (int i = 0; i < elmCls.size(); i++) {
					//html out
					Element elmTgt = elmCls.get(i);
					String strGetOuterHtml = elmTgt.outerHtml();
					String strOutPath = strFileOutDir+strHead+ (i + 1) + ".html";
					//html out
					String strRepHtml=strOutHtml;
					strRepHtml+=strGetOuterHtml;
					strRepHtml+="</body> </html>";

					objFile = new FileWriter(strOutPath);
					objPw = new PrintWriter(new BufferedWriter(objFile));
					objPw.println(strRepHtml);
					objPw.close();
					//html end

					//pdfout
					String strOutPdfPath = strFileOutDir+strHead+ (i + 1) + ".pdf";
					objPdfCls.convertHtmlToPdf(strOutPath,strOutPdfPath);

					if(strHead.equals("mask_")) {
						File maskfile = new File(strOutPdfPath);
						sizeMaskPdf += maskfile.length();
						FileInputStream maskfis = new FileInputStream(maskfile);
						maskfis.close();

					}else {
						File redfile = new File(strOutPdfPath);
						sizeRedPdf += redfile.length();
						FileInputStream redfis = new FileInputStream(redfile);
						redfis.close();
					} //if


					objLog.info(strHead.substring(0,strHead.length()-1) + (i + 1) +"枚目pdf出力完了");

				} //for

				//クライアントにわたす情報格納
				intPages = elmCls.size();
				strRelativePath="/"+strTmpDir_i+strHead+"split"+"/"+strHead;
				objLog.info(strHead.substring(0,strHead.length()-1)+ "のpdf出力すべて完了");


			} catch (IOException e) {
				// TODO 自動生成された catch ブロック
				e.printStackTrace();
				objLog.error("err message", e);
			} //try

		} //for

		//ファイルサイズを三桁区切りで表示
		strSizeRedPdf = String.format("%,d", sizeRedPdf/1000); //黒塗り候補文書PDFのファイルサイズの合計
		strSizeMaskPdf = String.format("%,d", sizeMaskPdf/1000); //黒塗り文書PDFのファイルサイズの合計
		strSizeMaskListPdf = String.format("%,d", sizeMaskListPdf/1000); //黒塗り文書リストPDFのファイルサイズ

		//格納情報(今回のPoCのみ
		ResourceBundle objRb = ResourceBundle.getBundle("config/procenter");
		String strSaveDir = objRb.getString("save_directory");


		model.addAttribute("strTmpDir", strTmpDir_i); //親作業directory
		model.addAttribute("strListJson", strListJson_i); //黒塗りリスト情報
		model.addAttribute("strFileName", strFileName_i); //オリジナルファイルネーム
		model.addAttribute("strTmpTimeStamp", strTmpTimeStamp); //今回の作業derectory
		model.addAttribute("intPages",  String.valueOf(intPages)); //PDFページ数 documentId
		model.addAttribute("documentId", documentId); //親作業directory
		model.addAttribute("strFilePath", strFilePath); //オリジナルファイルパス


		model.addAttribute("sizeRedPdf",  strSizeRedPdf); //黒塗り候補文書PDFのファイルサイズの合計 (KB)
		model.addAttribute("sizeMaskPdf", strSizeMaskPdf); //黒塗り文書PDFのファイルサイズの合計 (KB)
		model.addAttribute("sizeMaskListPdf", strSizeMaskListPdf); //黒塗り文書リストPDFのファイルサイズ (KB)
		model.addAttribute("strSaveDir", strSaveDir);


	return "blackPaint/MaskProvSave";
} //getView1

	/**
	 * エラー画面遷移(黒塗り処理)
	 */
	@ExceptionHandler(Exception.class)
	public String handleException(
			Exception e,
			HttpServletRequest request,
			HttpServletResponse response,
			Model model
			){


		//モデル初期化
		DirCnt objDirCls = new DirCnt();
		Cookie cookie[] = request.getCookies();
		String strTmpDir_i = "";
		if (cookie != null){
			for (int i = 0 ; i < cookie.length ; i++){
				if (cookie[i].getName().equals("strTmpDirName")){
					strTmpDir_i = cookie[i].getValue();
				} //if
			} //for
		} //if

		//作業ディレクトリかたずけ
		if(strTmpDir_i.equals(""))  {
			objLog.info("作業ディレクトリの取得が失敗しました");
		}else {
			try {
				//作業ディレクトリ,ファイルかたづけ
				objDirCls.DelDirctory(context.getRealPath("/") + strTmpDir_i);
				objLog.info("作業ディレクトリ削除完了");
			} catch (Exception e1) {
				objLog.info("作業ディレクトリ削除失敗");
			} //try

		} //if


		response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		objLog.error("Error occurred.", e);
		StringWriter objSw = new StringWriter();
		PrintWriter objPw = new PrintWriter(objSw);
		e.printStackTrace(objPw);
		objPw.flush();
		String strError = objSw.toString();
		model.addAttribute("errorMessage", e.getMessage() + "\r\n" + "StackTrace" + "\r\n" + strError) ;


		return "blackPaint/Fail";
	} //method

} //MaskHtmlCnt
