/**
 * 名称：SaveTmpDocCnt.java
 * 機能名：一時保存Control
 * 概要：一時保存機能のControlを行う。
 */

package jp.co.nec.docmng.blackPaint.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.file.Files;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.servlet.ServletContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.zeroturnaround.zip.ZipUtil;
import org.zeroturnaround.zip.commons.FileUtils;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.blackPaint.entity.MaskDocMarkerEntBlackPaint;
import jp.co.nec.docmng.blackPaint.entity.MaskDocumentEntBlackPaint;
import jp.co.nec.docmng.blackPaint.entity.PolicyKeywordInfoBlackPaint;
import jp.co.nec.docmng.blackPaint.logic.HtmlToPdf.HtmlToPdfModel;
import jp.co.nec.docmng.blackPaint.logic.dirFile.DirCnt;
import jp.co.nec.docmng.blackPaint.logic.dirFile.FileCnt;
import jp.co.nec.docmng.blackPaint.logic.maskHtml.MaskHtmlModel;
import jp.co.nec.docmng.blackPaint.logic.procenter.ProcnterWebApi;
import jp.co.nec.docmng.blackPaint.service.MaskDocMarkerService;
import jp.co.nec.docmng.blackPaint.service.MaskDocumentService;
import jp.co.nec.docmng.blackPaint.service.PolicyKeywordInfoServiceBlackPaint;

/**
 * 保存機能のControlを行う。
 */
@Controller
public class SaveDocCnt {

	/**
	 * context サーブレットのRealPathを取得する
	 * objLog log出力に使用する
	 * PAGE_CLASS ページを判定するHTMLClass。ページをSplitするのに使用する
	 * ARR_HEAD ファイル名、フォルダ名を判定するために使用する
	 */
	@Autowired
	ServletContext context;
	@Autowired
	MaskDocumentService maskDocumentService;
	@Autowired
	MaskDocMarkerService maskDocMarkerService;
	@Autowired
	PolicyKeywordInfoServiceBlackPaint policyKeywordInfoServiceBlackPaint;

	static Logger objLog = LoggerFactory.getLogger(SaveDocCnt.class);

	static String PAGE_CLASS = "awdiv awpage"; //splitするページのHTMLClass
	static String[] ARR_HEAD = { "mask_", "red_" }; //ファイル名、フォルダ名のヘッダー配列

	/**
	 * 保存メソッド
	 * 保存を押下したときの処理制御をする。
	 * 対象はPROCENTER/C と　mask_document
	 * @param strHashJson jsonString
	 * @param strFilePath 作業ファイルパス
	 */
	@SuppressWarnings("deprecation")
	@PostMapping("/SaveDocCnt")
	public String SaveTmpDocCntRest(
			@RequestParam("strJson") String strJson,
			@RequestParam("strFilePath") String strFilePath,
			@CookieValue(value = "user_id", required = false) String UserId,
			@CookieValue(value = "strTmpDirName") String strTmpDir_i,
			Model model) {


		//モデル初期化
		FileCnt objFileCnt = new FileCnt();
		DirCnt objDirCls = new DirCnt();
		HtmlToPdfModel objPdfCls = new HtmlToPdfModel();
		MaskHtmlModel objHtmllCls = new MaskHtmlModel();

		//メンバ変数初期化
		String strTmpDir = ""; //黒塗り編集画面で処理したHTMLが格納されたTMPディレクトリ名。
		String strRedHtml = ""; //黒塗り編集候補HTMLのouterHTML。
		String strMaskHtml = ""; //黒塗り編集HTMLのouterHTML。
		String strFileName = ""; //オリジナルwordファイル名。
		int intDocumentId = -1; //documentId
		String strListJson = ""; //黒塗りリストの情報のjson

		String strBasePath = ""; //黒塗り作成時の作業フォルダ
		String strHead = ""; //ファイル名、フォルダ名のヘッダー
		String strFileOutDir = ""; //PDF出力フォルダ
		String strHtmlDir = ""; //黒塗り作成時HTMLに対するimg,css等が入っているフォルダ
		String strRealPath = context.getRealPath("/");
		String strTmpTimeStamp = ""; //tempファイルタイムスタンプ

		String updateTime =""; //更新日時
		String retentionPeriod=""; //保存期間
		String[] arrPrint = null; //印刷範囲のインデックス true：印刷 false 印刷無し
		String[] arrMaskPaths = null; //黒塗りpdfパス
		String[] arrRedPaths = null; //黒塗り候補pdfパス

		//以下黒塗りリスト配列
		String[] keywords=null;
		String[] pages=null;
		String[] policyNames=null;
		String[] Reasons=null;
		String[] Remarks=null;

		//以下黒塗りリスト配列
		String[] glArrBfIds = null;
		String[] glArrAfIds = null;
		String[] glArrPolicys = null;

		byte[] byteZip = null; //zipにした際のbyte配列
		File objZipFile = null;

		strTmpTimeStamp = String.valueOf(System.currentTimeMillis());

		//今回のみ使用
		ResourceBundle objRb=null;

		//POSTされたjsonをパースする
		ObjectMapper objMapper = new ObjectMapper();
		List<Map<String, String[]>> objTmpList = null;
		TypeReference<List<Map<String, String[]>>> objType = new TypeReference<List<Map<String, String[]>>>() {
		};
		try {
			objTmpList = objMapper.readValue(strJson, objType);
		} catch (JsonParseException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} catch (JsonMappingException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} catch (IOException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} //try

		HashMap<String, String[]> objMap = (HashMap<String, String[]>) objTmpList.get(0);

		Object objTmp = null;
		for (String strKey : objMap.keySet()) {
			switch (strKey) {
			case "tmpDir":
				strTmpDir = objMap.get(strKey)[0];
				break;
			case "strFileName":
				strFileName = objMap.get(strKey)[0];
				break;
			case "updateTime":
				updateTime = objMap.get(strKey)[0];
				break;
			case "retentionPeriod":
				retentionPeriod = objMap.get(strKey)[0];
				break;
			case "documentId":
				intDocumentId = Integer.parseInt(objMap.get(strKey)[0]);
				break;
			case "arrPrint":
				arrPrint = (String[]) objMap.get(strKey);
				break;
			case "arrMaskPaths":
				arrMaskPaths = (String[]) objMap.get(strKey);
				break;
			case "arrRedPaths":
				arrRedPaths = (String[]) objMap.get(strKey);
				break;
				//*******以下黒塗りリスト用
			case "keywords":
				keywords = (String[]) objMap.get(strKey);
				break;
			case "pages":
				pages = (String[]) objMap.get(strKey);
				break;
			case "policyNames":
				policyNames = (String[]) objMap.get(strKey);
				break;
			case "Reasons":
				Reasons = (String[]) objMap.get(strKey);
				break;
			case "Remarks":
				Remarks = (String[]) objMap.get(strKey);
				break;
			case "glArrBfIds":
				glArrBfIds = (String[]) objMap.get(strKey);
				break;
			case "glArrAfIds":
				glArrAfIds = (String[]) objMap.get(strKey);
				break;
			case "glArrPolicys":
				glArrPolicys = (String[]) objMap.get(strKey);
				break;
			default:
				break;
			}//switch

		} //for

		//拡張子無しファイル名取得
		String strFileWithoutExtension = objFileCnt.getNameWithoutExtension(strFileName);
		strBasePath=strRealPath + strTmpDir_i ;
		String strListOutDir = strBasePath+"listAll/";
		String strListAllPath = objHtmllCls.makeBrackPaint(strJson,UserId,strListOutDir,strRealPath,strFileWithoutExtension,strFilePath);
		String strListAll="";
		try {
			strListAll = objFileCnt.readAll(strListAllPath);
		} catch (IOException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		}

//		//出力フォルダ(result)作成
		strBasePath = strRealPath + strTmpDir;

		objLog.info("作業ベースフォルダ：" + strBasePath);

		strFileOutDir = strRealPath + "result" + strTmpTimeStamp + "/";
		String strRealPathWithoutSlash = strRealPath.substring(0,strRealPath.length()-1); //末尾必要ないRealPathが必要
		try {
			objDirCls.makeDirWithCheck(strFileOutDir);

			//結合PDFファイル作成
			//結合対象が不定なので一度リストに格納
			PDFMergerUtility objUtMask = new PDFMergerUtility();
			PDFMergerUtility objUtRed = new PDFMergerUtility();
			for (int i = 1; i < arrPrint.length; i++) { //ページは1ページ目からなので1からスタート
				String strOutChk = arrPrint[i];
				if (strOutChk.equals("true")) { //trueの場合結合対象
					File objFileMask = new File(strRealPathWithoutSlash+arrMaskPaths[i-1]);
					File objFileRed = new File(strRealPathWithoutSlash+arrRedPaths[i-1].replaceAll("mask_","red_"));
					objUtMask.addSource(objFileMask);
					objUtRed.addSource(objFileRed);
				} //if
			} //for
			objUtMask.setDestinationFileName(strFileOutDir+strFileWithoutExtension+"(公開用).pdf");
			objUtMask.mergeDocuments();

			objUtRed.setDestinationFileName(strFileOutDir+strFileWithoutExtension+"(査閲用).pdf");
			objUtRed.mergeDocuments();

			String strListPdfPath = strFileOutDir+strFileWithoutExtension+"(黒塗諸元).pdf";
    		String strChkHtml = objPdfCls.convertListHtmlToPdf(strListAllPath,strListPdfPath);

    		objLog.info("PDF結合処理完了");

    		//※※※※※※※暫定 設定ファイルから取得したフォルダにコピー
    		//格納情報(今回のPoCのみ
    		objRb = ResourceBundle.getBundle("config/procenter");
    		String strSaveDir = objRb.getString("save_directory");
			FileUtils.copyDirectory(new File(strFileOutDir), new File(strSaveDir));

    		objLog.info("保存Directoryに保存完了：" + strSaveDir);

    		//zipに固める
    		String strZipOut = strRealPath + "zip" + strTmpTimeStamp + "/" + "mask.zip";
    		objDirCls.makeDirWithCheck(strRealPath + "zip" + strTmpTimeStamp + "/");
    		ZipUtil.pack(new File(strFileOutDir), new File(strZipOut));

    		//zipをbyte配列にする
			objZipFile = new File(strZipOut);
			byteZip = Files.readAllBytes(objZipFile.toPath());

		} catch (IOException e1) {
			objLog.error("err message", e1);
			e1.printStackTrace();

		} catch (Exception e1) {
			objLog.error("err message", e1);
			e1.printStackTrace();
		} //tyr

		//DBに格納
		// システム日付を取得する
		Timestamp sysdate = Timestamp.valueOf(LocalDateTime.now());
		//エンティティインスタンス化
		MaskDocumentEntBlackPaint objEnt = new MaskDocumentEntBlackPaint();
		try {
    		objLog.info("DB保存処理開始");
			//tmp_mask_documentテーブル
			objEnt.setDocumentId(intDocumentId);
			objEnt.setUserId(UserId);
			objEnt.setHtmlZipData(byteZip);
			objEnt.setUpdateTime(null);
			objEnt.setCreateTime(sysdate);
			maskDocumentService.insertMaskDocument(objEnt);

			//markerTable
			MaskDocMarkerEntBlackPaint objEnt2 = null;
			for (int i = 0; i < glArrBfIds.length; i++) {
				objEnt2 = new MaskDocMarkerEntBlackPaint();
				objEnt2.setDocumentId(intDocumentId);
				objEnt2.setMarkerStartCd(glArrBfIds[i]);
				objEnt2.setMarkerEndCd(glArrAfIds[i]);
				objEnt2.setMarkerPolicy(Integer.parseInt(glArrPolicys[i]));
				if (Remarks.length == 0) {
					objEnt2.setMarkerRemarks("");
				} else {
					objEnt2.setMarkerRemarks(Remarks[i]);
				} //if insertTmpMaskDocument
				objEnt2.setCreateTime(sysdate);
				maskDocMarkerService.insertMaskDocument(objEnt2);

			} //for

			//policy_keyword_info table
			PolicyKeywordInfoBlackPaint objEnt3 = null;
			for (int i = 0; i < glArrBfIds.length; i++) {
				objEnt3 = new PolicyKeywordInfoBlackPaint();
				objEnt3.setPolicyId(Integer.parseInt(glArrPolicys[i]));
				objEnt3.setPolicyKeyword(keywords[i]);
				objEnt3.setCreateTime(sysdate);
				policyKeywordInfoServiceBlackPaint.insertPolicyKeyword(objEnt3);
			} //for

    		objLog.info("DB保存処理終了");

		} catch (Exception e) {
			objLog.error("err message", e);
			System.err.println(e);
		} //try

		//作業ディレクトリかたずけ
		try {
			//作業ディレクトリ,ファイルかたづけ
			objDirCls.DelDirctory(strFileOutDir);
			objZipFile.delete();
			objDirCls.DelDirctory(strBasePath);
		} catch (Exception e) {
			objLog.info("作業ディレクトリ削除完了");
		} //try


		//*************PROCENTER/Cの保存処理**********************
		//承認処理呼び出し
		ProcnterWebApi objProCls = new ProcnterWebApi();
		String strBaseUrl = objRb.getString("procenter_url");
		String strApprovalUrl = strBaseUrl + "m.do?i=" + intDocumentId;
		objLog.info("PROCENTER承認呼び出しURL：" + strApprovalUrl);
		try {
			objProCls.getUrlCall(strApprovalUrl);
			objLog.info("PROCENTER承認呼び出し成功");
		} catch (Exception e) {
			objLog.info("PROCENTER承認呼び出し失敗");
			objLog.error("err message", e);
		} //try

		//*************黒塗り画面終了**********************
		return "blackPaint/Success";
	} //getView1

	/**
	 * エラー画面遷移(黒塗り処理)
	 */
	@ExceptionHandler(Exception.class)
	public String handleException(
			Exception e,
			HttpServletRequest request,
			HttpServletResponse response,
			Model model
			){


		//モデル初期化
		DirCnt objDirCls = new DirCnt();
		Cookie cookie[] = request.getCookies();
		String strTmpDir_i = "";
		if (cookie != null){
			for (int i = 0 ; i < cookie.length ; i++){
				if (cookie[i].getName().equals("strTmpDirName")){
					strTmpDir_i = cookie[i].getValue();
				} //if
			} //for
		} //if

		//作業ディレクトリかたずけ
		if(strTmpDir_i.equals(""))  {
			objLog.info("作業ディレクトリの取得が失敗しました");
		}else {
			try {
				//作業ディレクトリ,ファイルかたづけ
				objDirCls.DelDirctory(context.getRealPath("/") + strTmpDir_i);
				objLog.info("作業ディレクトリ削除完了");
			} catch (Exception e1) {
				objLog.info("作業ディレクトリ削除失敗");
			} //try

		} //if


		response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		objLog.error("Error occurred.", e);
		StringWriter objSw = new StringWriter();
		PrintWriter objPw = new PrintWriter(objSw);
		e.printStackTrace(objPw);
		objPw.flush();
		String strError = objSw.toString();
		model.addAttribute("errorMessage", e.getMessage() + "\r\n" + "StackTrace" + "\r\n" + strError) ;


		return "blackPaint/Fail";
	} //method


} //MaskHtmlCnt
