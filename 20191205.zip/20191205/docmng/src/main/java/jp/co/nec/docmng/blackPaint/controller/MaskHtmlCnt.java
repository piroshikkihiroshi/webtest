/**
 * 名称：MaskHtmlCnt.java
 * 機能名：黒塗り文書作成Control
 * 概要：塗り文書作成のControlを行う。
 */

package jp.co.nec.docmng.blackPaint.controller;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.zeroturnaround.zip.ZipUtil;

import jp.co.nec.docmng.blackPaint.entity.DocumentInfoEntPaint;
import jp.co.nec.docmng.blackPaint.logic.Aspose.AsposeWordModel;
import jp.co.nec.docmng.blackPaint.logic.dirFile.DirCnt;
import jp.co.nec.docmng.blackPaint.logic.dirFile.FileCnt;
import jp.co.nec.docmng.blackPaint.logic.maskHtml.HtmlStructure;
import jp.co.nec.docmng.blackPaint.logic.maskHtml.MaskHtmlModel;
import jp.co.nec.docmng.blackPaint.service.DocInfoService;
import jp.co.nec.docmng.library.blackprintextract.entity.BlackPrintPlace;
import jp.co.nec.docmng.library.blackprintextract.service.BlackPrintExtract;

@Controller
public class MaskHtmlCnt {

	static Logger objLog = LoggerFactory.getLogger(MaskHtmlCnt.class);

	@Autowired
	ServletContext context;
	@Autowired DocInfoService docInfoService;

    @Autowired
    private ResourceLoader resourceLoader;

    String strTmpDir = ""; //作業用フォルダ

	/**
	 * 黒塗り文書作成画面初期表示メソッド
	 * 画面初期表示の処理をする。
	 * @param documentId 文書を一意に特定するID
	 * @param status 空文字: 初期処理 1: 再開 2: 黒塗りリスト確定
	 * @param blackPaintListJson 空文字: 初期処理、再開 値あり：備考のjson
	 * @CookieValue user_id ユーザID
	 */
	@GetMapping("/MaskHtmlCnt")
	public String getblackTextTest(
			@RequestParam("documentId") int documentId,
			@RequestParam(name="status", defaultValue = "") String status, //空文字: 初期処理 1: 再開 2: 黒塗りリスト確定
			@RequestParam(name="blackPaintListJson", defaultValue = "") String blackPaintListJson, //空文字: 初期処理、再開 値あり：備考のjson
			@CookieValue(value="user_id", required=false) String UserId,
			HttpServletResponse response,
			Model model) {

		String aiData = ""; //aiが返すデータ

		String strHeight = "785"; //word A4の時 他は未考慮

		FileCnt objFileCnt = new FileCnt();
		AsposeWordModel objAspCls = new AsposeWordModel();
		MaskHtmlModel  objMaskCls = new MaskHtmlModel();
		DirCnt objDirCls = new DirCnt();

		String strContext="";
		try {
			strContext = context.getContextPath().substring(1,context.getContextPath().length());
		} catch (Exception e) {
			objLog.info("contextパスは設定されていません");
		} //


        String strRealPath = context.getRealPath("/") + context.getContextPath().substring(1,context.getContextPath().length());
        String strTmpTimeStamp = String.valueOf(System.currentTimeMillis()) ;
        String strTmpDirName="";
        if (strContext.equals("")) {
        	strTmpDirName="tmp" + strTmpTimeStamp + "/";
		}else {
			strTmpDirName=strContext+"/tmp" + strTmpTimeStamp + "/";
		} //if
        strTmpDir = context.getRealPath("/") +  strTmpDirName; //作業用フォルダ
//        strTmpDir = strRealPath + "/" + strTmpDirName; //作業用フォルダ
//        strTmpDir = strRealPath + context.getContextPath() + "/"  + strTmpDirName; //作業用フォルダ
        objLog.info("作業directory:"+strTmpDir);

		Cookie cookie = new Cookie("strTmpDirName", strTmpDirName);
	    cookie.setMaxAge(60*3600);
	    cookie.setPath("/");
		response.addCookie(cookie);

		objLog.info("作業フォルダ：" + strTmpDirName);

		//contextのディレクトリ作成
		try {
			objDirCls.makeDirWithCheck(strRealPath);
		} catch (Exception e) {
			objLog.info("作業フォルダの作成に失敗しました。" + strRealPath);
		} //try


		//DocumentIDでdocument_infoから情報を取得
		List<DocumentInfoEntPaint> listDoc=null;
		listDoc =docInfoService.selectDocInfo(documentId);

		String strOrgFilePath = listDoc.get(0).getDocumentName();
		objLog.info("対象パス：" + strOrgFilePath);

		String strOrgPath = listDoc.get(0).getFilePath();

		//一度RealPathへファイルをコピーする
		String strFileName = strOrgFilePath.substring(strOrgFilePath.lastIndexOf("\\") + 1,strOrgFilePath.length());
		String strFileWithoutExtension = objFileCnt.getNameWithoutExtension(strFileName);

        String strHtmlName = strFileWithoutExtension + ".html"; //作成html名
        String strHtmlPath = strTmpDir + strFileWithoutExtension + ".html"; //作成htmlパス

        String strStyle = ""; //CSSを作成する
        strStyle+="<style>";
        strStyle+=".tagRed{";
        strStyle+="    color: rgb(233, 84, 84);";
        strStyle+="    background-color: #ffff7b;";
        strStyle+="}";
        strStyle+=".tagRng{";
        strStyle+="    color: rgb(233, 87, 51);";
        strStyle+="    background-color: rgba(159, 192, 230, 0.884);";
        strStyle+="}";
        strStyle+=".tagMsk{";
        strStyle+="    color: black;";
        strStyle+="    font-size: 10.5pt;";
        strStyle+="}";
        strStyle+=".awpage {";
        strStyle+="    position: relative;";
        strStyle+="    border: none;";
        strStyle+="    margin: 0px;";
        strStyle+="}";

        strStyle+=".redimg{";
        strStyle+="    -webkit-filter: sepia(100%)  hue-rotate(300deg); ";
        strStyle+="    -moz-filter: sepia(100%)  hue-rotate(300deg);";
        strStyle+="    -o-filter: sepia(100%)  hue-rotate(300deg);";
        strStyle+="    -ms-filter: sepia(100%)  hue-rotate(300deg);";
        strStyle+="    filter: sepia(100%)  hue-rotate(300deg);";
        strStyle+="}";


        strStyle+="</style>";

		FileWriter objFile=null;
		PrintWriter objPw=null;
		String[] arrMask=null;
		String[] arrRed=null;

		//全文検索モックデータ コロン区切りでペアは+区切り intpos,そこからつづく,intpos,そこからつづく
		String strTestData = aiData;
		String strAllHtml = "";
		String strOrgBody = "";
		String strNotTagBody = "";
		String strRepBody = "";
		String strMaskHtml= "";
		String strRedHtml = "";
		int intPageCnt = 0;

		//とりあえずcontrollerで処理分け のちにロジックに移行
		if (listDoc.get(0).getExtension().equals("txt")) {
			objLog.info("txt処理開始");
			try {
				//出力フォルダ作成
				objDirCls.makeDirWithCheck(strTmpDir);
				objDirCls.makeDirWithCheck(strTmpDir + strFileWithoutExtension);
				//動的templateを作成
				String strOutHtml = "";
				strOutHtml+="<body>";
				strOutHtml+=listDoc.get(0).getDocumentContents();
				strOutHtml+="</body>";

				//全文検索エンジンに渡す用の文字列を取得する
				strNotTagBody=listDoc.get(0).getDocumentContents();

	//			※※※※※※※検索エンジンに送ったと想定※※※※※※※

				//AIdata スタブ
				BlackPrintExtract objAiCls  = new BlackPrintExtract();
				//aiDatalist
				List<BlackPrintPlace> listAi = null;
				try {
//					listAi = objAiCls.extractBlackPrintPlace(2001);
					listAi = objAiCls.extractBlackPrintPlace(documentId);
					BlackPrintPlace tmpPrintPlace = null;
					aiData = "";
					for (int i = 0; i < listAi.size(); i++) {
						tmpPrintPlace = listAi.get(i);
						aiData+=tmpPrintPlace.start + ":" + tmpPrintPlace.end + ":" + tmpPrintPlace.policyID + "+";
					} //for
					aiData = aiData.substring(0,aiData.length()-1);
				} catch (Exception e2) {
					aiData="";
					objLog.info("AIデータ取得処理でエラーが発生したため、取得したHTMLをそのまま表示");
					objLog.error( "err message", e2 );
					e2.printStackTrace();
				} //try

				if(aiData==null) aiData="";

				if(!aiData.equals("")) {
					//全文検索から戻ってきた値をhashへ成型
					HashMap<Integer, String> hashRepPos = objMaskCls.makePosHash(aiData);
					objMaskCls.makePosHash(aiData);

					//bodyの構造体hashを取得
					HashMap<Integer, HtmlStructure> hashBodyStructure = objMaskCls.getBodyStructure(strOutHtml);
					//全文検索エンジンに返した結果を置換してbodyを入れ替えた文字列を取得(黒塗り)
					arrMask=objMaskCls.bodyReplace(hashRepPos, hashBodyStructure,1);
					strRepBody = arrMask[0];

					//htmlのbodyの中身を入れ替え、置換HTMLを作成する
					strMaskHtml = objMaskCls.makeBody(strOutHtml,strRepBody);

					//スタイルシートPath埋め込み
					strMaskHtml = objMaskCls.insertStyleTxt(strMaskHtml,strStyle);

					//全文検索エンジンに返した結果を置換してbodyを入れ替えた文字列を取得(赤文字)
					arrRed=objMaskCls.bodyReplace(hashRepPos, hashBodyStructure,2);
					strRepBody=arrRed[0];

					//htmlのbodyの中身を入れ替え、置換HTMLを作成する
					strRedHtml = objMaskCls.makeBody(strOutHtml,strRepBody);
					//スタイルシートPath埋め込み
					strRedHtml = objMaskCls.insertStyleTxt(strRedHtml,strStyle);

				}else {
					strMaskHtml = strOutHtml;
					//スタイルシートPath埋め込み
					strMaskHtml = objMaskCls.insertStyleTxt(strMaskHtml,strStyle);

					//htmlのbodyの中身を入れ替え、置換HTMLを作成する
					strRedHtml = strOutHtml;
					//スタイルシートPath埋め込み
					strRedHtml = objMaskCls.insertStyleTxt(strRedHtml,strStyle);


				} //if
					//css,黒塗り画像ファイル配備
					String strCssPath = "src/main/resources/static/css/blackPaint/mask.css";
					String strImgPath = "src/main/resources/static/css/images/m";
					//命名きちんと取れるように修正予定
					Path objCssPath = Paths.get(strCssPath);
					Path objImgpPath = Paths.get(strImgPath);
					Path objTgtCssPath = Paths.get(strTmpDir + "/" + strFileWithoutExtension+ "/mask.css");
					Path objTgtImgPath = Paths.get(strTmpDir + "/" + strFileWithoutExtension+ "/m");


					Files.copy(objCssPath, objTgtCssPath);
		            Files.copy(objImgpPath, objTgtImgPath);

		            //黒塗り候補用
					objTgtImgPath = Paths.get(strTmpDir + "/" + strFileWithoutExtension+ "/red.png");
		            Files.copy(objImgpPath, objTgtImgPath);

					String strMaskOutPath = strTmpDir + "mask_" + strHtmlName;
					String strRedOutPath = strTmpDir + "red_" + strHtmlName;

					//htmlを出力する(黒塗り)
					objFile = new FileWriter(strMaskOutPath);
					objPw = new PrintWriter(new BufferedWriter(objFile));
					objPw.println(strMaskHtml);
					objPw.close();
					objLog.info("maskHTML完了");

					//htmlを出力する(赤文字)
					objFile = new FileWriter(strRedOutPath);
					objPw = new PrintWriter(new BufferedWriter(objFile));
					objPw.println(strRedHtml);
					objPw.close();
					objLog.info("赤文字HTML完了");
					//ページカウント取得
					intPageCnt = 1; //暫定


			} catch (IOException e) {
				objLog.error( "err message", e );
				e.printStackTrace();
			} //try


		} else { //※※※※※※※※※※※word※※※※※※※※※※
			objLog.info("word処理開始");
			byte[] arrHtmlZip=null;
			arrHtmlZip = listDoc.get(0).getHtmlZipData();
			//file出力
			//出力フォルダ作成
			String strFileOutDir=strRealPath+"/tmp"+strTmpTimeStamp+"/";
//			String strFileOutDir=strRealPath+"/";
			String strZipPath = strFileOutDir + "mask.zip";

			Path objZipPath = Paths.get(strZipPath);
			try {

				objDirCls.makeDirWithCheck(strFileOutDir);
				//zipファイル出力
				Files.write(objZipPath, arrHtmlZip);
				//unzipする
				ZipUtil.unpack(new File(strZipPath), new File(strFileOutDir));

				//作業ファイルかたづけ
				File fileZip = new File(strZipPath);
				fileZip.delete();

				objLog.info("HTML群取得完了");

			} catch (IOException e1) {
				objLog.error( "err message", e1 );
				e1.printStackTrace();
			} //try
			catch (Exception e) {
				objLog.error( "err message", e );
				e.printStackTrace();
			} //try

	        try {
	        	//tmpDir作成
	            //対象HTMLを取得する
	            strAllHtml = objMaskCls.readAll(strHtmlPath);

		        //圧縮されたBodyを取得
				strOrgBody = objMaskCls.getBodyCompress(strAllHtml);

				//全文検索エンジンに渡す用の文字列を取得する
				strNotTagBody=listDoc.get(0).getDocumentContents();



//				※※※※※※※検索エンジンに送ったと想定※※※※※※※

				//AIdata スタブ
				BlackPrintExtract objAiCls  = new BlackPrintExtract();
				//aiDatalist
				List<BlackPrintPlace> listAi = null;
				try {
//					listAi = objAiCls.extractBlackPrintPlace(2001);
					listAi = objAiCls.extractBlackPrintPlace(documentId);
					BlackPrintPlace tmpPrintPlace = null;
					aiData = "";
					for (int i = 0; i < listAi.size(); i++) {
						tmpPrintPlace = listAi.get(i);
						aiData+=tmpPrintPlace.start + ":" + tmpPrintPlace.end + ":" + tmpPrintPlace.policyID + "+";
					} //for
					aiData = aiData.substring(0,aiData.length()-1);
				} catch (Exception e2) {
					aiData="";
					objLog.info("AIデータ取得処理でエラーが発生したため、取得したHTMLをそのまま表示");
					objLog.error( "err message", e2 );
					e2.printStackTrace();
				} //try

				if(aiData==null) {
					aiData="";
				} //if

				objLog.info("aiData="+aiData);

				if(!aiData.equals("")) {

					//全文検索から戻ってきた値をhashへ成型
					HashMap<Integer, String> hashRepPos = objMaskCls.makePosHash(aiData);
					objMaskCls.makePosHash(aiData);

					objLog.info("makePosHash完了");

					//bodyの構造体hashを取得
					HashMap<Integer, HtmlStructure> hashBodyStructure = objMaskCls.getBodyStructure(strOrgBody);

					objLog.info("1");

					//全文検索エンジンに返した結果を置換してbodyを入れ替えた文字列を取得(黒塗り)
					arrMask=objMaskCls.bodyReplace(hashRepPos, hashBodyStructure,1);
					strRepBody = arrMask[0];

					objLog.info("2");

					//htmlのbodyの中身を入れ替え、置換HTMLを作成する
					strMaskHtml = objMaskCls.makeBody(strAllHtml,strRepBody);


					objLog.info("3");
					//スタイルシートPath埋め込み
					strMaskHtml = objMaskCls.insertStyle(strMaskHtml,strStyle);

					objLog.info("4");
					//全文検索エンジンに返した結果を置換してbodyを入れ替えた文字列を取得(赤文字)
					arrRed=objMaskCls.bodyReplace(hashRepPos, hashBodyStructure,2);
					strRepBody=arrRed[0];
					objLog.info("5");
					//htmlのbodyの中身を入れ替え、置換HTMLを作成する
					strRedHtml = objMaskCls.makeBody(strAllHtml,strRepBody);

					//スタイルシートPath埋め込み
					strRedHtml = objMaskCls.insertStyle(strRedHtml,strStyle);
				} else {
					objLog.info("色塗り箇所はありません");
					strMaskHtml=strAllHtml;
					strRedHtml=strAllHtml;
					//スタイルシートPath埋め込み
					strMaskHtml = objMaskCls.insertStyle(strMaskHtml,strStyle);
					//スタイルシートPath埋め込み
					strRedHtml = objMaskCls.insertStyle(strRedHtml,strStyle);
				} //if


				//css,黒塗り画像ファイル配備 ※deploy時にエラーになるためresourceLoaderで取得
				String strCssPath = "/static/css/blackPaint/mask.css";
				String strImgPath = "/static/css/images/m";
				File objCssOutFile = new File(strTmpDir + "/" + strFileWithoutExtension+ "/mask.css");
				File objTgtImgFile = new File(strTmpDir + "/" + strFileWithoutExtension+ "/m");
				//deploy後に動かないので修正
				objLog.info("ファイル、イメージ配備開始");
				Resource resource =null;
				resource = resourceLoader.getResource("classpath:" + strCssPath);
				FileUtils.copyFile(resource.getFile(), objCssOutFile);

				resource = resourceLoader.getResource("classpath:" + strImgPath);
				FileUtils.copyFile(resource.getFile(), objTgtImgFile);
				objLog.info("ファイル、イメージ配備完了");

				String strMaskOutPath = strTmpDir + "mask_" + strHtmlName;
				String strRedOutPath = strTmpDir + "red_" + strHtmlName;

				objLog.info("html出力開始");
				//htmlを出力する(黒塗り)
				objFile = new FileWriter(strMaskOutPath);
				objPw = new PrintWriter(new BufferedWriter(objFile));
				objPw.println(strMaskHtml);
				objPw.close();
				objLog.info("maskHTML完了");

				//htmlを出力する(赤文字)
				objFile = new FileWriter(strRedOutPath);
				objPw = new PrintWriter(new BufferedWriter(objFile));
				objPw.println(strRedHtml);
				objPw.close();
				objLog.info("赤文字HTML完了");

				//ページカウント取得
				intPageCnt = objAspCls.aspPageGet(strMaskHtml);


	        } catch (Exception e) {
				objLog.error("err message", e);
	            e.printStackTrace();
	        } //try

		} //if

		//viewへ値を渡す
		// 呼び出し先Jspに渡すデータセット(html出力パスを相対で指定)
		model.addAttribute("strMaskOutPath", strTmpDirName + "mask_" + strHtmlName );
		model.addAttribute("strRedOutPath",  strTmpDirName + "red_" + strHtmlName);
		model.addAttribute("strTmpDirName", strTmpDirName); //tmpdirの情報も送る
		model.addAttribute("strPagePx", strHeight); //1ページの量
		model.addAttribute("intPageCnt", String.valueOf(intPageCnt)); //ページ数
		model.addAttribute("strFileName",strFileName); //オリジナルfile名 保存時に使用
		model.addAttribute("strFilePath",strOrgPath); //オリジナルfileパス リスト表示時に使用

		//AIデータがどのように来るかわからないのでポリシーなどはクライアントで処理
		if(aiData.equals("")) {
			model.addAttribute("strEditMarker", "");
		}else {
			model.addAttribute("strEditMarker", arrRed[1]); //aiでマークしたid等を格納
		} //if

		model.addAttribute("documentId", documentId);//documentId
		model.addAttribute("strFileWithoutExtension", strFileWithoutExtension);//strFileWithoutExtension
		model.addAttribute("reOpenFlg",status);
		model.addAttribute("blackPaintListJson",blackPaintListJson);

		return "blackPaint/MaskHtmlVeiw";
	} //getView1

	/**
	 * エラー画面遷移(黒塗り処理)
	 */
	@ExceptionHandler(Exception.class)
	public String handleException(
			Exception e,
			HttpServletRequest request,
			HttpServletResponse response,
			Model model
			){


		//モデル初期化
		DirCnt objDirCls = new DirCnt();
		String strTmpDir_i = strTmpDir;

		//作業ディレクトリかたずけ
		if(strTmpDir_i.equals(""))  {
			objLog.info("作業ディレクトリの取得が失敗しました");
		}else {
			try {
				//作業ディレクトリ,ファイルかたづけ
				objDirCls.DelDirctory(context.getRealPath("/") + strTmpDir_i);
				objLog.info("作業ディレクトリ削除完了");
			} catch (Exception e1) {
				objLog.info("作業ディレクトリ削除失敗");
			} //try

		} //if

		response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		objLog.error("Error occurred.", e);
		StringWriter objSw = new StringWriter();
		PrintWriter objPw = new PrintWriter(objSw);
		e.printStackTrace(objPw);
		objPw.flush();
		String strError = objSw.toString();
		model.addAttribute("errorMessage", e.getMessage() + "\r\n" + "StackTrace" + "\r\n" + strError) ;

		return "blackPaint/Fail";
	} //method

} //MaskHtmlCnt
