/**
 *
 */
package jp.co.nec.docmng.library.train;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
/*
import jp.sf.orangesignal.csv.CsvConfig;
import jp.sf.orangesignal.csv.manager.CsvManager;
import jp.sf.orangesignal.csv.manager.CsvManagerFactory;
*/
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.FileTime;
import java.nio.file.attribute.UserPrincipal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
* クラス MakeTrainingData は教師データフォーマット形式のCSVファイルを作成するメソッド makeBlackPrintTrainData()を供与する.
*/
public class MakeTrainingData {
	private String fname_training = "train_data.csv";
	private final String ORGFILE = "orgfile/";
	private final String ORGTEXT = "orgtext/";
	private String fname_orgfile = "output/orgfile/";
	private String fname_orgtext = "output/orgtext/";
//	private String fname_extension = "-org.txt";
	private String fname_extension = "";
	private String param;

	private Pattern p_span = Pattern.compile("\\[\\[\\[([^\\]\\]\\]]*)\\]\\]\\]");
	private int tagsize = "]]]".length();
	private List<Span> span;
	private String original;
	private String newOriginal;

	private final String ID = "index";
	private final String TEXT = "text";
	private final String LABEL = "marker";
	private final String DBDATA = "dabata";

	private final String H_document_id		= "document_id";
	private final String H_document_name	= "document_name";
	private final String H_category_id		= "category_id";
	private final String H_document_time	= "document_time";
	private final String H_size				= "size";
	private final String H_text				= "text";
	private final String H_marker			= "marker";
	private final String H_marked_flag		= "marked_flag";
	private final String H_save_timestamp	= "save_timestamp";
	private final String H_save_place		= "save_place";
	private final String H_regist_timestamp	= "regist_timestamp";
	private final String H_regist_user		= "regist_user";
	private final String H_update_timestamp	= "update_timestamp";
	private final String H_update_user		= "update_user";

	/*
	 * コンストラクタ
	 * 不要につき削除
	 */
	/*
	public MakeTrainingData() {
	}
	*/

	/*
	 * 黒塗り用教師データを作成する
	 */
    /**
    * makeBlackPrintTrainDataメソッド
    * @param input 入力情報「<黒塗りポリシーID,左記IDに対応する入力データのディレクトリパス>のマップ」。 in。
    * @param output 出力ディレクトリパス。 in。
    * @return なし。
    * @throws IOException ファイル、ディレクトリアクセスに失敗した場合はIOExceptionを投げる。
    */
	public void makeBlackPrintTrainData(Map<Integer, String> input, String output) throws IOException {
		if (output.endsWith("/") != true)
			output = output + "/";

    	for(Map.Entry<Integer, String> entry : input.entrySet()) {
    		// TAP入力ファイルのヘッダー出力
    		File file_training;
    		file_training = new File(output + entry.getKey() + "_" + fname_training);
    		wrtieTrainingDataHeader(file_training);
    		makePolicyTrainData(entry.getValue(), file_training);
    	}
	}

	/*
	 * 黒塗りポリシーに対する教師データを作成する
	 */
	private void makePolicyTrainData(String fname_input, File file_training) {
		// TAP入力ファイルに出力するフォーマットされた正解データ生成と出力
	    File dir = new File(fname_input);
	    File[] files = dir.listFiles();
	    int id = 1;
	    for (File file: files) {
	    	// 1ファイルごと、処理を実行
	    	try {
				execute(file, file_training, id++);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	}

	// 1ファイルごと、処理を実行
	private void execute(File file, File train, int id) throws IOException {
		MakeTrainingData db = this;
		// 1	入力ファイル読み込み
		db.read_original_data(file);
		String org = db.getOriginalData();

		// 2	黒塗り箇所の特定
		db.patternMatch(org);
		List<Span> span = db.getSpan();

		// 3	黒塗り指定正規表現([[[～]]])削除　⇒※この文書を「整形したオリジナル文書」とする
		 db.createNewOriginal(org, span);
		 String org_text = db.getNewOriginalData();

		// 4	上記文字列中の黒塗り箇所情報（開始位置、終了位置）計算
		span =  db.recalcSpanPosition(span);

		// スパンの調整
		span = db.chousei(span);

        // 5	テキストAI入力形式ファイル出力
		 db.writeTrainingData(train, id, org_text, span);	// スパン抽出学習用

		 return;
	}

	// 1	入力ファイル読み込み
	private void read_original_data(String file) throws IOException {
		try {
			original = new String(Files.readAllBytes(Paths.get(file)));
			// ★暫定対処
			// 入力データに「"」が入っている場合は削除
			if (original.indexOf("\"") >= 0) {
				System.out.println("入力データに「\"」が入っている場合は削除: " + file);
				original = original.replaceAll("\"", "");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void read_original_data(File file) throws IOException {
		read_original_data(file.getAbsolutePath());
	}

	// 2	黒塗り箇所の特定
	private List<Span> patternMatch(String str) {
		List<Span> span = new ArrayList<Span>();

		Matcher m = p_span.matcher(str);
		while (m.find()) {
			Span s = new Span();
			s.span = m.group(1);
			s.start = m.start() + tagsize;
			s.end = m.end() - tagsize;
			span.add(s);

			// for debug
			// System.out.println("span: " + s.span + " start: " + s.start + " end: " + s.end);
		}
		this.span = span;
		return span;
	}

	// 3	黒塗り指定正規表現([[[～]]])削除　⇒※この文書を「オリジナル文書」とする
	private String createNewOriginal(String org, List<Span> span) {
		StringBuffer b = new StringBuffer();

		int i = 0;
		int size = span.size();
		int prepos = 0;	// 出力済の文字列位置　の記録用

		// 先頭スパンの前の部分をそのまま抜出
		if (size > 0) {
			Span s = span.get(i);
			if (s.start < tagsize) {
				System.out.println("s.start(" + s.start +  ") < tagsize");
			}
			else {
				b.append(org.substring(0, s.start - tagsize));
			}
			b.append(org.substring(s.start, s.end));
			prepos = s.end + tagsize;
		}

		// スパン部分を抜出
		for (i = 1; i < size; i++) {
			Span s = span.get(i);
			b.append(org.substring(prepos, s.start - tagsize));
			b.append(org.substring(s.start, s.end));
			prepos = s.end + tagsize;
		}

		// 最終スパンの後の部分をそのまま抜出
		b.append(org.substring(prepos));

		newOriginal = b.toString();
		return newOriginal;
	}

	// 4	上記文字列中の黒塗り箇所情報（開始位置、終了位置）計算
	private List<Span> recalcSpanPosition(List<Span> sp) {
		List<Span> newspan = new ArrayList<Span>();
		int size = sp.size();
		for (int i = 0; i < size; i++) {
			Span s = sp.get(i);
			Span n = new Span();
			n.span = s.span;
			n.start = s.start - (2 * i + 1) * tagsize;
			n.end = s.end - (2 * i + 1) * tagsize -1; // TAPでは、終了位置は、終端文字のポジションなので、正規表現での範囲より 1 引く必要がある
			newspan.add(n);
		}

		this.span = newspan;
		return newspan;
	}

	// 4	上記文字列中の黒塗り箇所情報（開始位置、終了位置）計算
	private List<Span> chousei(List<Span> sp) {
		List<Span> newspan = new ArrayList<Span>();
		Span pre = null;
		for (Span s: sp) {
			if (pre != null) {
				if ((pre.end +1) == s.start) {
					s.start = pre.start;
					s.span = pre.span + s.span;
				}
				else {
					newspan.add(pre);
				}
			}
			pre = s;
		}
		if (pre != null) {
			newspan.add(pre);
		}

		this.span = newspan;
		return newspan;
	}


	// 5	整形したオリジナル文書出力
	private void writeNewOriginal(File file, String org_text) throws IOException {
		File out = new File(fname_orgtext + file.getName() + fname_extension);
		PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(out)));
		pw.print(org_text);
        pw.close();

	}

	private void writeNewOriginal(File file, String org_text, int id) throws IOException {
		int n = 10000 + id;
		String number = "" + n;
		number = number.substring(1);
		File out = new File(fname_orgfile + number);
		// ヘッダ行の出力
		this.wrtieTrainingDataHeader(out);

		PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(out, true)));
		// フォーマットされたデータ行を出力
		String data = formatSpanData(number, org_text);
		pw.print(data);
        pw.close();

	}


	// 6	TAP入力形式ファイル出力
	private void writeTrainingData(File train, int id, String org_text, List<Span> span) throws IOException {
		PrintWriter pw_train = new PrintWriter(new BufferedWriter(new FileWriter(train, true)));

		String traindata = formatSpanData(id, org_text, span);

		pw_train.println(traindata);
		pw_train.close();
	}

	private void writeTrainingData2(File train, int id, String org_text, List<Span> span, File org) throws IOException {
		PrintWriter pw_train = new PrintWriter(new BufferedWriter(new FileWriter(train, true)));

		String traindata = formatSpanData2(id, org_text, span, org);

		pw_train.println(traindata);
		pw_train.close();
	}



	// オリジナルデータの取得
	public String getOriginalData() {
		return original;
	}

	// 抽出したスパン情報
	public List<Span> getSpan() {
		return span;
	}

	//　整形したオリジナルデータの取得
	public String getNewOriginalData() {
		return newOriginal;
	}

	public String getDateStr() {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd_HHmmss");
        return sdf.format(cal.getTime());
	}

	public String getHeader() {
		return "\""
				+ this.ID + "\",\""
				+ this.TEXT + "\",\""
				+ this.LABEL + "\""
				;
	}

	public String getHeader2() {
		return "\""
				/*
				+ this.ID + "\",\""
				+ this.TEXT + "\",\""
				+ this.LABEL + "\",\""
				+ this.DBDATA + "\",\""
				*/

				+ this.H_document_id + "\",\""
				+ this.H_document_name + "\",\""
				+ this.H_category_id + "\",\""
				+ this.H_document_time + "\",\""
				+ this.H_size + "\",\""
				+ this.H_text + "\",\""
				+ this.H_marker + "\",\""
				+ this.H_marked_flag + "\",\""
				+ this.H_save_timestamp + "\",\""
				+ this.H_save_place + "\",\""
				+ this.H_regist_timestamp + "\",\""
				+ this.H_regist_user + "\",\""
				+ this.H_update_timestamp + "\",\""
				+ this.H_update_user + "\""
				;
	}

	// TAP入力データのヘッダー部の出力
	public void wrtieTrainingDataHeader(File training)  throws IOException {
		PrintWriter pw_train = new PrintWriter(new BufferedWriter(new FileWriter(training)));
		pw_train.println(getHeader());
		pw_train.close();
	}

	public void wrtieTrainingDataHeader2(File training)  throws IOException {
		PrintWriter pw_train = new PrintWriter(new BufferedWriter(new FileWriter(training)));
		pw_train.println(getHeader2());
		pw_train.close();
	}

	// TAP入力データのデータ部の整形
	public String formatSpanData(int id, String text, List<Span> span) {
		StringBuffer b = new StringBuffer();;

		if (span != null) {
			for (Span s: span) {
				b.append(this.LABEL + ":" + this.TEXT + ":" + s.start + ":" + s.end + "+");
			}
		}

		String kuronuri =  b.toString();
		if (kuronuri.endsWith("+")) {
			kuronuri = kuronuri.substring(0, kuronuri.length()-1);
		}

		return "\""
				+ id + "\",\""
				+ text + "\",\""
				+ kuronuri + "\""
				;
	}

	public String formatSpanData(String id, String text) {
		StringBuffer b = new StringBuffer();;

		return "\""
				+ id + "\",\""
				+ text + "\",\""
				+ "\""
				;
	}

	public String formatSpanData2(int id, String text, List<Span> span, File org) throws IOException {
		StringBuffer b = new StringBuffer();;

		if (span != null) {
			for (Span s: span) {
				b.append(this.LABEL + ":" + this.TEXT + ":" + s.start + ":" + s.end + "+");
			}
		}

		String kuronuri =  b.toString();
		if (kuronuri.endsWith("+")) {
			kuronuri = kuronuri.substring(0, kuronuri.length()-1);
		}

		String data = kuronuri.replaceAll(this.LABEL + ":" + this.TEXT + ":", "");

		int number = 10000 + id;
		String index = "" + number;
		index = index.substring(1);

		Path path = org.toPath();

		FileTime time = Files.getLastModifiedTime(path);
		String document_time = time.toString();
		UserPrincipal owner = Files.getOwner(path);


		return "\""
				/*
				+ index + "\",\""
				+ text + "\",\""
				+ kuronuri + "\",\""
				+ data + "\",\""
				*/

				+ index + "\",\""
				+ org.getName() + "\",\""
				+ "記事" + "\","
				+ document_time + ","
				+ Files.size(path) + ",\""
				+ text + "\",\""
				+ data + "\","
				+ "False" + ","
				+ document_time + ",\""
				+ "\\\\10.41.116.9\\a00321-01\\pub\\09_森谷G\\PJ\\防衛省" + "\","
				+ document_time + ",\""
				+ owner.getName() + "\""
				;
	}



	/*
	 * ディレクトリの存在をチェックし、なければ、作成する
	 */
	private boolean chackDir(String dir) {
		File file = new File(dir);
		if (file.exists())
			return true;
		// 存在しない場合は作成する。
		return file.mkdir();
	}

	/**
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		String fname_input = "fortest/data"; // for test
		String fname_input2 = "fortest/data2"; // for test
		String fname_output = "fortest/output/"; //for test
		MakeTrainingData train = new MakeTrainingData();

		HashMap input = new HashMap<Integer, String>();
		input.put(1, fname_input);
		input.put(2, fname_input2);
		train.makeBlackPrintTrainData(input, fname_output);
	}

}
