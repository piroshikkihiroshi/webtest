package jp.co.nec.docmng.blackPaint.repository;


import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import jp.co.nec.docmng.blackPaint.entity.CategoryEntPaint;
import jp.co.nec.docmng.blackPaint.entity.DocumentInfoEntPaint;
import jp.co.nec.docmng.blackPaint.entity.MaskDocMarkerEntBlackPaint;


@Mapper
public interface DocumentMapPaint {

	//�S�擾
	@Select("SELECT * FROM common.document_info WHERE document_id = #{document_id}")
	public List<DocumentInfoEntPaint> selectDocInfo(int document_id);

	//�d���̂�zip��S����`��������
	@Select("SELECT document_id, server_id, document_name, extension, document_size, parent_id, file_path, marker, category_id, procenter_flg, retention_period, author, updater, authorizer, file_update_time, mask_status, create_time, update_time FROM common.document_info WHERE document_id = #{document_id}" )
	public List<DocumentInfoEntPaint> selectDocFileInfo(int document_id);


} //PolicyInfoMapper
