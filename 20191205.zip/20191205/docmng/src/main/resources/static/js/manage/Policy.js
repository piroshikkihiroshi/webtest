//グローバル変数
deleteCheckFlag = 0;
editCheckFlag = 0;
upCheckFlag = 0;
downCheckFlag = 0;
listAddBtnCheckFlag = 0;
addBtnCheckFlag = 0;
addListCount = 0;

addListMode = false; // 新規作成ボタンで行が追加された状態 : true / デフォルト : false
editMode = false; // 編集ボタンで行が追加された状態 : true / デフォルト : false;
DISABLE_TRUE = 0;
DISABLE_FALSE = 1;

var isPost = false;
var addValues = {};
var changedValues = {};
var deleteDBNo = [];

// 現在のURL
var hostUrl = location.protocol + '//' + location.host + location.pathname;

//アラートメッセージ
var policyNullMessage = "ポリシー名を入力後再度ボタンを押下してください。";
var blackReasonNullMessage = "黒塗り対処理由を入力後再度ボタンを押下してください。";
var deleteAddOrEditListMessage = "選択した行は現在編集中または、追加中のため削除できません。";
var selectedNotClickEditMessage = "行の選択を行った後「編集ボタン」を押下してください。";
var selectedNotClickDeleteMessage = "行の選択を行った後「削除ボタン」を押下してください。"
var selectedNotClickChangeUpMessage = "行の選択を行った後「順位▲ボタン」を押下してください。"
var selectedNotClickChangeDownMessage = "行の選択を行った後「順位▼ボタン」を押下してください。";
var addReflectSettingCheckMessage = "変更した内容を反映しますか。";
var addReflectSettingMessage = "変更が反映されました。";
var addReflectSettingFailureMessage = "設定反映に失敗しました。";
var cancelSelectedMessage = "変更内容を破棄してもよろしいでしょうか。";
var notUserRoleOrLoginOutMessage = "ログインを行っていない、または管理者ではありません。";

/**
 * 動作関数
 * 読み込み時、ボタン制御等を行う。
 * @memberOf  policy
 */
$(function () {

  /**
 * 再読み込み時動作関数
 * 画面が変更、または閉じられる時に動作する。
 * @memberOf  policy
 * @param {value} isPost POST送信フラグ
 */
  $(window).on("beforeunload", function (e) {
    // POST送信フラグが「true」の場合、ダイアログを表示しない
    if (isPost) {
      return;
    } else {
      return true;
    }
  });

  //Cookieを確認し、管理者権限またはログインしているかチェックを行う
  $(window).ready(function (e) {
    // ドメイン情報取得
    DomainCookie.initDomainCookie('[[${DomainInfo}]]');

    var userRole = DomainCookie.getUserRole();

    // ログインしてない場合
    if (userRole === null) {
      alert(notUserRoleOrLoginOutMessage);
      window.close();
    }

    //管理者権限か確認を行う
    if (userRole === "Administrators") {
      showUserName();
      userRoleFlag = true;
    }

    //管理者権限、またはログインしていなかった場合画面を閉じる
    if (userRoleFlag !== true) {
      alert(notUserRoleOrLoginOutMessage);
      window.close();
    }
  })

  /**
 * 一覧表読み完了後動作関数
 * 一覧表の読み込みが完了後、一覧表の数が0だった場合ボタンをdisabledに変更を行う。
 * @memberOf  policy
 * @param {value} editCheck 編集ボタン確認フラグ
 * @param {value} deleteCheck 削除ボタン確認フラグ
 * @param {value} upCheck 順位▲ボタン確認フラグ
 * @param {value} downCheck 順位▼ボタン確認フラグ
 */
  $('.scrollBody').ready(function (e) {

    if (document.getElementById('main_scroll').childElementCount == 0) {
      //「編集ボタン」をdisableに変更する
      switchEditBtnDisabled(DISABLE_TRUE);
      //「削除ボタン」をdisableに変更する
      switchDeleteBtnDisabled(DISABLE_TRUE);
      //「順位▲ボタン」をdisableに変更する
      switchUpBtnDisabled(DISABLE_TRUE);
      //「順位▼ボタン」をdisableに変更する
      switchDownBtnDisabled(DISABLE_TRUE);
    }
  });

  /**
 * 一覧表押下時動作関数
 * 表をクリック時に動作し、クリックを行った時に選択した行の色が変更する。
 * @memberOf  policy
 */
  $('.scrollBody').mousedown(function (e) {
    //表の項目以外をクリック時には色を付けない
    if (e.target.id != "main_scroll") {
      //テキストボックスに'selected'が挿入されてしまうため、判定しない
      if (e.target.className == "textbox" || e.target.className == "tr l"
        || e.target.className.match("EditTable") || e.target.className.match("AddListTable")) {
        return;
      }
      if (e.target.nodeName == "SPAN") {
        if (e.target.parentElement.parentElement.id == 'selected') {
          document.getElementById('selected').removeAttribute("id");
          return true;
        } else {
          if (document.getElementById('selected') == null) {
            e.target.parentElement.parentElement.setAttribute('id', 'selected');
          }
          document.getElementById('selected').removeAttribute("id");
          e.target.parentElement.parentElement.setAttribute('id', 'selected');
          return true;
        }
      }
      //一項目のみclick可能とする
      if (e.target.parentElement.id == 'selected') {
        document.getElementById('selected').removeAttribute("id");
      } else {
        if (document.getElementById('selected') == null) {
          e.target.parentElement.setAttribute('id', 'selected');
        }
        document.getElementById('selected').removeAttribute("id");
        e.target.parentElement.setAttribute('id', 'selected');
      }
    } else if (e.target.id == "main_scroll") {
      return false;
    }

  });
});

//新規作成ボタン押下時に動作し、一覧表の最下部に追加する
function addList() {

  //自動順位項番結果を取得する
  var objAutoRowNo = document.getElementById("main_scroll").childElementCount;
  strAutoRowNo = '' + objAutoRowNo;

  //最大順位取得の取得をする
  var objChildrenCountPoint = objAutoRowNo - 1;
  strChildrenCountPoint = objAutoRowNo + 1 + "";


  console.log("objAutoRowNo : " + objAutoRowNo);
  //黒塗りポリシーが存在しない場合新規追加
  if (objAutoRowNo == 0) {
    //新規作成する欄を作成する
    createAddListData();
    //「設定反映ボタン」をdisableに変更する
    switchAddBtnBtnDisabled(DISABLE_TRUE);
    //「編集ボタン」をdisableに変更する
    switchEditBtnDisabled(DISABLE_TRUE);
    //「新規作成ボタン」を活性化状態にする
    switchListAddBtnDisabled(DISABLE_FALSE);
    // 行追加状態にする
    addListMode = true;
  }  //
  // 行追加状態ではないならば最終行に行追加
  else if (!addListMode) {
    //編集行を、最終行に変更する
    if (document.getElementById('selected') != null) {
      document.getElementById('selected').removeAttribute("id");
    }
    //新規作成する欄を作成する
    createAddListData();
    //「設定反映ボタン」をdisableに変更する
    switchAddBtnBtnDisabled(DISABLE_TRUE);
    //「編集ボタン」をdisableに変更する
    switchEditBtnDisabled(DISABLE_TRUE);
    //「新規作成ボタン」を活性化状態にする
    switchListAddBtnDisabled(DISABLE_FALSE);
    addListMode = true;
  }
  // 行追加状態ならテキストボックス化解除
  else if (addListMode) {
    //現在新規作成中の順位を取得する
    var objRowNo = document.getElementById("main_scroll").childElementCount;
    strRowNo = '' + objRowNo;

    //入力されているテキストボックス内容を取得する
    var objNewPolicyNameText = document.getElementById("newPolicyName").value;
    var objNewBlackReasonText = document.getElementById("newBlackReason").value;

    //入力チェックの確認する
    if (objNewPolicyNameText == "") {
      alert(policyNullMessage);
      return false;
    } else if (objNewBlackReasonText == "") {
      alert(blackReasonNullMessage);
      return false;
    }

    //連想配列の作成する
    addValues[addListCount] = {
      ["policyNumber"]: strRowNo,
      ["policyName"]: objNewPolicyNameText,
      ["policyReason"]: objNewBlackReasonText
    };
    addListCount++;

    //テキストボックス化を解除する
    document.getElementById("newPolicyName").outerHTML = objNewPolicyNameText;
    document.getElementById("newBlackReason").outerHTML = objNewBlackReasonText;
    //非アクティブ化状態に移行するため、クラスの削除する
    document.getElementsByClassName("AddListTable")[0].classList.remove("AddListTable");

    //「設定反映ボタン」をenableに変更する
    switchAddBtnBtnDisabled(DISABLE_FALSE);
    //「編集ボタン」をenableに変更する
    switchEditBtnDisabled(DISABLE_FALSE);
    //「削除ボタン」をenableに変更する
    switchDeleteBtnDisabled(DISABLE_FALSE);
    //「削除ボタン」をenableに変更する
    switchUpBtnDisabled(DISABLE_FALSE);
    //「削除ボタン」をenableに変更する
    switchDownBtnDisabled(DISABLE_FALSE);
    // 行追加状態解除
    addListMode = false;
    return;
  }
}
/**
 * 黒塗りポリシー設定行を追加する
 */
function createAddListData() {
  //新規作成する欄を作成する
  var ul = $('<ul id="selected"  class="tr l AddListTable"></ul>');
  var strPolicyNumber = $('<li class="' + addListCount + '" style="display: none;"></li>');
  var strDisplayRanktd = $('<li class="w40"></li>');
  var strPolicyNametd = $('<li class="w220" ></li>');
  var strCreateTimetd = $('<li class="w160" ></li>');
  var strCreateUserNametd = $('<li class="w180 text_align_left" ></li>');
  var strBlackReasontd = $('<li class="w280" ></li>');
  var strBlackPointKeywordtd = $('<li class="wAutoA B text_align_left"></li>');

  //表に取得した値を挿入する
  $(".scrollBody").append(ul);
  ul.append(strPolicyNumber).append(strDisplayRanktd).
    append(strPolicyNametd).append(strCreateTimetd).
    append(strCreateUserNametd).append(strBlackReasontd).
    append(strBlackPointKeywordtd);

  strPolicyNumber.html("");
  strDisplayRanktd.html(strChildrenCountPoint);
  strPolicyNametd.html("<input type='text' id='newPolicyName' class='textbox' size='10' value=" + "" + "></imput>");
  //APサーバ設定時の時刻のため、表示を行わないようにする
  strCreateTimetd.html("");
  //現在ログインしているユーザー名を取得し、ここに入れるようにする
  strCreateUserNametd.html("");
  strBlackReasontd.html("<input type='text' id='newBlackReason' class='textbox' size='10' value=" + "" + " ></imput>");
  //対象キーワードは後々設定されるため、記載は行わないようにする
  strBlackPointKeywordtd.html("");
  // 幅再調整
  fillDomWidth();
}


//編集ボタン押下時に動作し、選択した項目内容を変更する
function editPolicy() {
  //非編集状態の場合
  if (!editMode) {
    // リストが選択されている場合
    if (document.getElementById('selected') != null) {
      //編集がアクティブ状態のため、クラス付与する
      $('#main_scroll').eq(0).addClass('EditMode');
      $('#selected').eq(0).addClass('EditTable');

      //選択行の一つ目の要素の子要素を取得
      var getSelectedChildren = $('#selected').eq(0).children();

      //選択行のポリシー名を取得する
      var strPolicyText = getSelectedChildren[2].valueOf().textContent;
      //選択行の黒塗り対処理由を取得する
      var strPolicyReasonText = getSelectedChildren[5].valueOf().textContent;

      //選択行のポリシー名をTextBox化する
      getSelectedChildren[2].innerHTML = "<input type='text' size='10' id='changePolicyName' class='textbox' value=" + strPolicyText + " ></imput>";
      //選択行の黒塗り対処理由をTextBox化する
      getSelectedChildren[5].innerHTML = "<input type='text' size='10' id='changeBlackReason' class='textbox' value=" + strPolicyReasonText + " ></imput>";

      //「設定反映ボタン」をdisableに変更する
      switchAddBtnBtnDisabled(DISABLE_TRUE);

      //「新規作成ボタン」をdisableに変更する
      switchListAddBtnDisabled(DISABLE_TRUE);

      //「編集ボタン」を活性化状態にする
      switchEditBtnDisabled(DISABLE_FALSE);

      // 編集状態にする
      editMode = true;

      //リストが選択されていない場合falseを返却する
    } else {
      alert(selectedNotClickEditMessage);
      return false;
    }
    //編集状態かつ編集中の場合動作する
  } else if (editMode) {

    //追加時のリスト番号値取得する
    var strChangeRow = $(".EditTable>li[style='display: none;']").text();

    //現在新規作成中の順位を取得する
    var strRanktdNumber = document.getElementsByClassName("EditTable")[0].children[1].outerText

    //addValuesのリスト番号を取得する
    var strAddChangeRow = document.getElementsByClassName("EditTable")[0].children[0].className;

    //表示されている値の登録する
    var strTextBoxPolicyName = document.getElementById("changePolicyName").value;
    var strTextBoxBlackReason = document.getElementById("changeBlackReason").value;

    //入力チェックの確認する
    if (strTextBoxPolicyName == "") {
      alert(policyNullMessage);
      return false;
    } else if (strTextBoxBlackReason == "") {
      alert(blackReasonNullMessage);
      return false;
    }

    // 連想配列作成・追加する
    if (addValues[strAddChangeRow]) {
      addValues[strAddChangeRow]["policyName"] = strTextBoxPolicyName;
      addValues[strAddChangeRow]["policyReason"] = strTextBoxBlackReason;
      if (changedValues[strChangeRow]) {
        changedValues[strChangeRow]["policyName"] = strTextBoxPolicyName;
        changedValues[strChangeRow]["policyReason"] = strTextBoxBlackReason;
        changedValues[strChangeRow]["policyId"] = strChangeRow;
      }
    } else {
      if (!changedValues[strChangeRow]) {
        changedValues[strChangeRow] = {
          ["policyId"]: strChangeRow,
          ["policyNumber"]: strRanktdNumber,
          ["policyName"]: strTextBoxPolicyName,
          ["policyReason"]: strTextBoxBlackReason
        };
      } else {
        changedValues[strChangeRow]["policyName"] = strTextBoxPolicyName;
        changedValues[strChangeRow]["policyReason"] = strTextBoxBlackReason;
        changedValues[strChangeRow]["policyId"] = strChangeRow;
      }
    }

    //テキストボックス化を解除する
    document.getElementById("changePolicyName").outerHTML = strTextBoxPolicyName;
    document.getElementById("changeBlackReason").outerHTML = strTextBoxBlackReason;

    //非アクティブ化状態に移行するため、クラスの削除する
    document.getElementById('main_scroll').classList.remove("EditMode");
    document.getElementsByClassName("EditTable")[0].classList.remove("EditTable");

    //「設定反映ボタン」をenableに変更する
    switchAddBtnBtnDisabled(DISABLE_FALSE);

    //「新規作成ボタン」をenableに変更する
    switchListAddBtnDisabled(DISABLE_FALSE);

    //「編集ボタン」を非活性化状態にする
    document.getElementById("editBtn").classList.toggle("on");

    // 非編集状態にする
    editMode = false;

    return;
  }
}

//削除ボタン押下時に動作し、選択した行を削除する
function deleteRow() {

  //選択した行があるか判定する
  if (document.getElementById('selected') != null) {

    var selectedRow = document.getElementById("selected");
    //選択している行が編集中の場合、アラートを表示する
    if (selectedRow.classList.contains("EditTable") !== true
      && selectedRow.classList.contains("AddListTable") !== true) {

      //ポリシーIDの値取得する
      var strDeleteRow = $("#selected>li[style='display: none;']").text();

      //新規作成で表示されているリストの場合、classからリスト番号を取得する
      var strAddChangeRow = document.getElementById("selected").children[0].className;

      //グローバル変数にポリシーIDの値を取得する
      deleteDBNo.push(strDeleteRow);

      //連想配列の削除する
      if (changedValues[strDeleteRow]) {
        delete changedValues[strDeleteRow];
        if (addValues[strAddChangeRow]) {
          delete addValues[strAddChangeRow];
        }
      } else if (addValues[strAddChangeRow]) {
        delete addValues[strAddChangeRow];
      }

      //選択した行の削除する
      $("#selected").remove();

      //ポリシーIDの付け直しをする
      policyIdUpdate();

      // 0行になった時新規ボタン以外をdisabledに
      var rowCnt = document.getElementById("main_scroll").childElementCount;
      if (rowCnt === 0) {
        //「編集ボタン」をdisableに変更する
        switchEditBtnDisabled(DISABLE_TRUE);
        //「削除ボタン」をdisableに変更する
        switchDeleteBtnDisabled(DISABLE_TRUE);
        //「順位▲ボタン」をdisableに変更する
        switchUpBtnDisabled(DISABLE_TRUE);
        //「順位▼ボタン」をdisableに変更する
        switchDownBtnDisabled(DISABLE_TRUE);
      }

    } else {
      alert(deleteAddOrEditListMessage);
    }
  } else {
    alert(selectedNotClickDeleteMessage);
    return false;
  }
}

//順位▲ボタン押下時に動作し、選択した行の順位を1つ上げる
function changeRankUp() {

  //選択した行があるか判定する
  if (document.getElementById('selected') != null) {
    // tbody要素に指定したIDを取得し、変数「tbody」に代入する
    var tbody = document.getElementById('main_scroll');
    // objのノードを取得し、変数「tr」に代入する
    var ul = document.getElementById("selected");

    // 指定している行が最終行の場合動作しない
    if (ul.previousElementSibling != null) {
      //最上位順位以外の場合動作する
      if (ul.children[1].outerText !== '1') {
        //「ul」を直後の兄弟ノードの上に挿入する
        tbody.insertBefore(ul, ul.previousElementSibling);
      }
      //ポリシーIDの付け直しをする
      policyIdUpdate();
    } else {
      return false;
    }
  } else {
    alert(selectedNotClickChangeUpMessage);
    return false;
  }
};

//順位▼ボタン押下時に動作し、選択した行の順位を1つ下げる
function changeRankDown() {

  //選択した行があるか判定する
  if (document.getElementById('selected') != null) {
    // tbody要素に指定したIDを取得し、変数「tbody」に代入する
    var tbody = document.getElementById('main_scroll');
    // objのノードを取得し、変数「tr」に代入する
    var ul = document.getElementById("selected");
    // 最大順位の取得する
    var strMaxRanked = '' + tbody.childElementCount;

    // 指定している行が最終行の場合動作しない
    if (ul.nextElementSibling != null) {
      //最下位順位以外動作する
      if (ul.children[1].outerText !== strMaxRanked) {
        // 「tr」を直後の兄弟ノードの上に挿入する
        tbody.insertBefore(ul.nextElementSibling, ul);
      }
      //ポリシーIDの付け直しをする
      policyIdUpdate();
    } else {
      return false;
    }
  } else {
    alert(selectedNotClickChangeDownMessage);
    return false;
  }
};

/**
 * 削除、行の上下移動の再にポリシーIDを振りなおす
 */
function policyIdUpdate() {
  //ポリシーIDの付け直しをする
  var strAutoRowNo = document.getElementById("main_scroll").childElementCount;
  //変更箇所の表示順位の変更に伴い変更箇所のフラグ判定する
  var changeValuesFlag = "false";
  for (var i = 0; i < strAutoRowNo; i++) {
    //選択した行に非表示要素があるかの判断する
    let hiddenKey = $(".scrollBody ul").eq(i).children("li[style='display: none;']").text();
    if (hiddenKey != "") {
      if ($('.scrollBody ul').eq(i).children().eq(1)[0].innerText !== "" + (i + 1)) {
        $('.scrollBody ul').eq(i).children().eq(1).text("" + (i + 1));
        changeValuesFlag = "true";
      }
      // 編集済み項目がある場合連想配列の作成・修正する
      if (changedValues[hiddenKey]) {
        // 受け渡し用の配列の順位を変更する
        changedValues[hiddenKey]['policyNumber'] = i + 1;
      } else if (addValues[hiddenKey]) {
        // 受け渡し用の配列の順位を変更する
        addValues[hiddenKey]['policyNumber'] = i + 1;
      } else if (changeValuesFlag === "true") {
        //変更した行の順位を変更する
        changedValues[hiddenKey] = { ["policyNumber"]: "" + (i + 1), ["policyId"]: hiddenKey };
        changeValuesFlag = "false";
      }
    } else {
      //選択行の行番号を取得する
      var strAddRow = $(".scrollBody ul").eq(i)[0].children[0].className;

      if (addValues[strAddRow]) {
        // 受け渡し用の配列の順位を変更する
        addValues[strAddRow]['policyNumber'] = i + 1;
      }
      $('.scrollBody ul').eq(i).children().eq(1).text("" + (i + 1));
    }
  }
}

//キャンセルボタン押下時に動作しダイアログを表示する
function policyCancel() {
  blCan = confirm(cancelSelectedMessage);
  console.log(blCan);
  if (blCan) {
    window.close();
  } else {
    return;
  }
}


//設定反映ボタン押下時に動作し、DBに設定反映する
function postItem() {

  //変更を行うか確認を取る内容をアラート表示する
  blCanPost = confirm(addReflectSettingCheckMessage);
  if (blCanPost) {

    var jsonObj = new Object();

    // 削除項目のIDをデータ受け渡し用タグに格納する
    jsonObj.deleteRow = deleteDBNo;


    // 編集項目の値をデータ受け渡し用タグに格納する
    var postChangeValues = [];
    for (var cv in changedValues) {
      console.log(changedValues[cv]);
      postChangeValues.push(changedValues[cv]);
    }
    jsonObj.changedValues = postChangeValues;

    // 追加項目の値をデータ受け渡し用タグに格納する
    var postAddValues = [];
    // リクエストパラメータに合うように変更する
    for (var av in addValues) {
      console.log(addValues[av]);
      postAddValues.push(addValues[av]);
    }
    jsonObj.addValues = postAddValues;
    console.log(jsonObj);
    //POST
    $.ajax({
      url: hostUrl + "/policy_reflect",
      type: "POST",
      contentType: "application/json",
      data: JSON.stringify(jsonObj),
      // ajax通信成功時の処理をする
    }).done(function (data) {
      let successOrFailure = "";
      console.log(data);
      // 画面を更新する
      isPost = true;
      alert(addReflectSettingMessage);
      location.reload();
      // 更新フラグをON
      // ajax通信失敗時の処理をする
    }).fail(function (xhr, textStatus, errorThrown) {
      //alert(xhr.responseText + "\r\n設定反映に失敗しました。");
      alert(addReflectSettingFailureMessage);
      // 成功でも失敗でも通信終了時に必要な処理があれば追加記載する
    }).always(function () {
    });
  } else {
    return;
  }
}

//設定反映ボタンの「活性」「非活性」を判定する
function isAdd() {
  if (addBtnCheckFlag == 0) {
    $("#addBtn").prop("disabled", true);
    return true;
  }
  $("#addBtn").prop("disabled", false);
  return false;
}

//設定反映ボタンの「活性」「非活性」を判定する
function isListAdd() {
  if (listAddBtnCheckFlag == 0) {
    $("#listAddBtn").prop("disabled", true);
    return true;
  }
  $("#listAddBtn").prop("disabled", false);
  return false;
}

//編集ボタンの「活性」「非活性」を判定する
function isEdit() {
  if (editCheckFlag == 0) {
    $("#editBtn").prop("disabled", true);
    return true;
  }
  $("#editBtn").prop("disabled", false);
  return false;
}

//削除ボタンの「活性」「非活性」を判定する
function isDelete() {
  if (deleteCheckFlag == 0) {
    $("#deleteBtn").prop("disabled", true);
    return true;
  }
  $("#deleteBtn").prop("disabled", false);
  return false;
}

//順位▲ボタンの「活性」「非活性」を判定する
function isUp() {
  if (upCheckFlag == 0) {
    $("#upBtn").prop("disabled", true);
    return true;
  }
  $("#upBtn").prop("disabled", false);
  return false;
}

//順位▼ボタンの「活性」「非活性」を判定する
function isDown() {
  if (downCheckFlag == 0) {
    $("#downBtn").prop("disabled", true);
    return true;
  }
  $("#downBtn").prop("disabled", false);
  return false;
}


//新規作成ボタンの「活性」「非活性」を判定する
function switchListAddBtnDisabled(flag) {
  listAddBtnCheckFlag = flag;
  isListAdd()
}

//設定反映ボタンのdisabled/enable(disabled:0/enable:1)を設定する
function switchAddBtnBtnDisabled(flag) {
  addBtnCheckFlag = flag;
  isAdd();
}

//編集ボタンのdisabled/enable(disabled:0/enable:1)を設定する
function switchEditBtnDisabled(flag) {
  editCheckFlag = flag;
  isEdit();
}

//削除ボタンのdisabled/enable(disabled:0/enable:1)を設定する
function switchDeleteBtnDisabled(flag) {
  deleteCheckFlag = flag;
  isDelete();
}

//順位▲ボタンのdisabled/enable(disabled:0/enable:1)を設定する
function switchUpBtnDisabled(flag) {
  upCheckFlag = flag;
  isUp();
}

//順位▼ボタンのdisabled/enable(disabled:0/enable:1)を設定する
function switchDownBtnDisabled(flag) {
  downCheckFlag = flag;
  isDown();
}
