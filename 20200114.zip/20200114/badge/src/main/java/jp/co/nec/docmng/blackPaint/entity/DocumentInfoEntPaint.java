package jp.co.nec.docmng.blackPaint.entity;

import java.math.BigDecimal;
import java.util.Date;

public class DocumentInfoEntPaint {

	public int getDocumentId() {
        return document_id;
    }
	public void setDocumentId(Integer documentId) {
        this.document_id = documentId;
    }
	public String getDocumentContents() {
        return document_contents;
    }
	public void setDocumentContents(String documentContents) {
        this.document_contents = documentContents;
    }
	public byte[] getHtmlZipData() {
        return html_zip_data;
    }
	public void setHtmlZipData(byte[] htmlZipData) {
        this.html_zip_data = htmlZipData;
    }
	public int getServerId() {
        return server_id;
    }
	public void setServerId(Integer serverId) {
        this.server_id = serverId;
    }
	public String getDocumentName() {
	        return document_name;
	}
	public void setDocumentName(String documentName) {
        this.document_name = documentName;
    }
	public String getExtension() {
        return extension;
    }
	public void setExtension(String extension) {
        this.extension = extension == null ? null : extension.trim();
    }
	public BigDecimal getDocumentSize() {
        return document_size;
    }
	public void setDocumentSize(BigDecimal documentSize) {
        this.document_size = documentSize;
    }
	public int getParentId() {
        return parent_id;
    }
	public void setParentId(Integer parentId) {
        this.parent_id = parentId;
    }
	public String getFilePath() {
        return file_path;
    }
	public void setFilePath(String filePath) {
        this.file_path = filePath == null ? null : filePath.trim();
    }
	public String getMarker() {
        return marker;
    }
	public void setMarker(String marker) {
        this.marker = marker == null ? null : marker.trim();
    }
	public int getCategoryId() {
        return category_id;
    }
	public void setCategoryId(Integer categoryId) {
        this.category_id = categoryId;
    }
	public Boolean getProcenterFlg() {
        return procenter_flg;
    }
	public void setProcenterFlg(Boolean procenterFlg) {
        this.procenter_flg = procenterFlg;
    }
	public Date getRetentionPeriod() {
        return retention_period;
    }
	public void setRetentionPeriod(Date retentionPeriod) {
        this.retention_period = retentionPeriod;
    }
	public String getAuthor() {
        return author;
    }
	public void setAuthor(String author) {
        this.author = author;
    }
	public String getUpdater() {
        return updater;
    }
	public void setUpdater(String updater) {
        this.updater = updater;
    }
	public String getAuthorizer() {
        return authorizer;
    }
	public void setAuthorizer(String authorizer) {
        this.authorizer = authorizer;
    }
	public Date getFileUpdateTime() {
        return file_update_time;
    }
	public void setFileUpdateTime(Date fileUpdateTime) {
        this.file_update_time = fileUpdateTime;
    }
	public int getMaskStatus() {
        return mask_status;
    }
	public void setMaskStatus(Integer maskStatus) {
        this.mask_status = maskStatus;
    }
	public Date getCreateTime() {
        return create_time;
    }
	public void setCreateTime(Date createTime) {
        this.create_time = createTime;
    }
	public Date getUpdateTime() {
        return update_time;
    }
	public void setUpdateTime(Date updateTime) {
        this.update_time = updateTime;
    }

	public int getNodeId() {
		return node_id;
	}
	public void setNodeId(int node_id) {
		this.node_id = node_id;
	}
	public int getProcenterParentId() {
		return procenter_parent_id;
	}
	public void setProcenterParentId(int procenter_parent_id) {
		this.procenter_parent_id = procenter_parent_id;
	}


	private int document_id;
	private String document_contents;
	private byte[] html_zip_data;
	private int server_id;
	private String document_name;
	private String extension;
	private BigDecimal document_size;
	private int parent_id;
	private String file_path;
	private String marker;
	private int category_id;
	private Boolean procenter_flg;
	private Date retention_period;
	private String author;
	private String updater;
	private String authorizer;
	private Date file_update_time;
	private int mask_status;
	private Date create_time;
	private Date update_time;
	private int node_id;
	private int procenter_parent_id;


}
