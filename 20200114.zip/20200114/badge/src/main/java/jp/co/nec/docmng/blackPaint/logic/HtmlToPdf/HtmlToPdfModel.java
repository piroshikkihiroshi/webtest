package jp.co.nec.docmng.blackPaint.logic.HtmlToPdf;





import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aspose.html.HTMLDocument;
import com.aspose.html.rendering.HtmlRenderer;
import com.aspose.html.rendering.pdf.PdfDevice;





public class HtmlToPdfModel {

	/**
	 * strHtml_iからPDFを作成する
	 * @param strHtml_i
	 * @param strPath_i 相対パスを絶対パスに変更する必要があるのでimgが格納されているDirを指定
	 * @param strPdfOutPath_i pdf出力先のファイル名を含めたフルパス
	 * @return String
	 * @throws FileNotFoundException
	 * @modify 20191216 InputStreamで読み込んでから処理するように変更
	 */
	static Logger objLog = LoggerFactory.getLogger(HtmlToPdfModel.class);

	public synchronized String convertHtmlToPdf(String strPath_i,String strPdfOutPath_i) {

		//※※※※※※動かなかったらこちらを使う/※※※※※※

		InputStream fileStream=null;
		try {
			fileStream = new FileInputStream(strPath_i);
		} catch (FileNotFoundException e1) {
			objLog.error( "file："+strPath_i+"がありません", e1 );
			return null;
		}
		HTMLDocument htmlDocument = new HTMLDocument(fileStream,strPath_i);
		HtmlRenderer renderer = new HtmlRenderer();
		FileOutputStream objOs = null;
		PdfDevice objPdfDevice=null;
		try {
			objOs = new FileOutputStream(strPdfOutPath_i, true);
		} catch (FileNotFoundException e1) {
			objLog.error( "file："+strPdfOutPath_i+"がありません", e1 );
			return null;
		}
		objPdfDevice = new PdfDevice(objOs);


		try {
			renderer.render(objPdfDevice, htmlDocument);
		} catch (Exception e) {
			objLog.error( "pdf作成時にエラーが発生しました", e );
			return null;
		} finally {
			if (fileStream != null) {
				try {
					fileStream.close();
					fileStream = null;
				}
				catch (IOException e) {
					objLog.error( "ストリームのクローズに失敗", e );
				}
			} //if
			if (objOs != null) {
				try {
					objOs.close();
					objOs=null;
				}
				catch (IOException e) {
					objLog.error( "ストリームのクローズに失敗", e );
				}
			} //if
			if (renderer != null) {
				renderer.dispose();
				renderer = null;
			}
			if (objPdfDevice != null) {
				objPdfDevice.dispose();
				objPdfDevice = null;
			}
			if (htmlDocument != null) {
				htmlDocument.dispose();
				htmlDocument = null;
			}

			//GCを明示的によんでメモリ解放
			//System.gc();
		} //try

		return strPdfOutPath_i;

	} //convertHtmlToPdf


//	public synchronized String convertHtmlToPdf(String strPath_i,String strPdfOutPath_i){
//
//		//※※※※※※動かなかったらこちらを使う/※※※※※※
//		HTMLDocument htmlDocument = new HTMLDocument(strPath_i);
//		HtmlRenderer renderer = new HtmlRenderer();
////		PdfRenderingOptions objPdfOpt = new PdfRenderingOptions();
//		FileOutputStream objOs = null;
//		PdfDevice objPdfDevice=null;
//		try {
//			objOs = new FileOutputStream(strPdfOutPath_i, true);
//			objPdfDevice = new PdfDevice(objOs);
//		} catch (FileNotFoundException e) {
//			// TODO 自動生成された catch ブロック
//			e.printStackTrace();
//		}
//
//		renderer.render(objPdfDevice, htmlDocument);
////		objPdfOpt=null;
//		renderer=null;
//		htmlDocument=null;
//		objOs=null;
//		objPdfDevice=null;
//
//		return strPdfOutPath_i;
//
//	} //convertHtmlToPdf



} //class

