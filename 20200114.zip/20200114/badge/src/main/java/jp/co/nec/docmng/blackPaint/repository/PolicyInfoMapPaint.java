package jp.co.nec.docmng.blackPaint.repository;


import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import jp.co.nec.docmng.blackPaint.entity.PolicyInfoEntBlackPaint;


@Mapper
public interface PolicyInfoMapPaint {

    @Select("select * from admin.policy_info order by policy_number")
    List<PolicyInfoEntBlackPaint> findAll();

} //PolicyInfoMapper
