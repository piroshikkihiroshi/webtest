
editMode = false; // 編集ボタンで行が追加された状態 : true / デフォルト : false;

/**
     * 黒塗りリストの項目を選択した際、選択した行の色を変更し、備考欄を入力可能な状態にする。
     * (前提：編集ボタンがonになっていること)
     */
$(function () {
	$('.scrollBody').mousedown(function (e) {
		//表の項目以外をクリック時には色を付けない
		if (e.target.id != "main_scroll") {
			//テキストボックスに'selected'が挿入されてしまうため、判定しない
			if (e.target.id == "changeRemarksText" || e.target.className == "tr l hover" || e.target.className == "0 tr l"
				|| e.target.className.match("EditTable") || e.target.className.match("AddListTable")) {
				return;
			}
			if (e.target.nodeName == "SPAN") {
				if (e.target.classList.contains('selected') == true) {
					$('li').removeClass('selected');
					$('ul').removeClass('selected');
					return true;
				} else {
					listClickAddClass(e);
					$('li').removeClass('selected');
					$('ul').removeClass('selected');
					listClickAddClass(e);
					return true;
				}
			}
			//一項目のみclick可能とする
			if (e.target.classList.contains('selected') == true) {
				$('li').removeClass('selected');
				$('ul').removeClass('selected');
			} else {
				listClickAddClass(e);
				$('li').removeClass('selected');
				$('ul').removeClass('selected');
				listClickAddClass(e);
			}
		} else if (e.target.id == "main_scroll") {
			return false;
		}

	});

	/**
     * 編集ボタン押下時、編集ボタンの色を変更する。
     * (項目を選択していた場合、選択を取り消し、備考欄を入力不可にする)
     */
	function listClickAddClass(e) {
		for (let index = 0; index < e.target.parentElement.childElementCount; index++) {
			e.target.parentElement.children[index].classList.add("selected");
		}
		e.target.parentElement.classList.add("selected");
	}
});


/**
 * 編集ボタン押下時、編集ボタンの色を変更する。
 * (項目を選択していた場合、選択を取り消し、備考欄を入力不可にする)
 */
function editColumn() {

	//非編集状態の場合
	if (!editMode) {
		// リストが選択されている場合
		if (document.getElementsByClassName('selected')[0] !== undefined) {
			//編集がアクティブ状態のため、クラス付与する
			$('#main_scroll').eq(0).addClass('EditMode');
			$('ul.selected').eq(0).addClass('EditTable');

			//選択行のポリシー名を取得する
			var strRemarksText = $('.EditTable').eq(0).children().eq(5)[0].outerText;
			var windowTextBox = window.screen.width - 1040;

			//選択行のポリシー名をTextBox化する
			$('.EditTable').eq(0).children().eq(5)[0].innerHTML = "<textarea id='changeRemarksText' style='width:" + windowTextBox + "px;height:14px;' class='wAutoA' rows='10' maxLength='128'>" + strRemarksText + "</textarea>";

			//「編集ボタン」を活性化状態に変更する
			document.getElementById("HENSHU").classList.toggle("on");

			// 編集状態にする
			editMode = true;
		}
	//編集状態の場合動作する
	} else if (editMode) {

		//表示されている値の登録する
		var strTextBoxRemarksText = document.getElementById("changeRemarksText").value;

		//テキストボックス化を解除する
		document.getElementById("changeRemarksText").outerHTML = strTextBoxRemarksText;

		//非アクティブ化状態に移行するため、クラスの削除する
		document.getElementById('main_scroll').classList.remove("EditMode");
		document.getElementsByClassName("EditTable")[0].classList.remove("EditTable");


		//「編集ボタン」を非活性化状態にする
		document.getElementById("HENSHU").classList.toggle("on");

		// 非編集状態にする
		editMode = false;

		return;
	}
}



/**
 * 黒塗り文書作成画面を表示する
 */
function cancelList() {


	var blRet = confirm("「黒塗りリスト表示画面」で編集した内容を破棄して、「黒塗り文書作成画面」に遷移してもよろしいでしょうか。");

	if (blRet) {

        var strJson = glStrJson; //バッファしておいた元のjson
        var objForm = document.createElement('form');
        var objReq = document.createElement('input');
        var objReq2 = document.createElement('input');
        var objReq3 = document.createElement('input');


        objReq.type = 'hidden'; //入力フォームが表示されないように
        objReq.name = 'documentId';
        objReq.value = gldocumentId;

        objReq2.type = 'hidden'; //入力フォームが表示されないように
        objReq2.name = 'status';
        objReq2.value = "2"; //備考を読み込むため確定フラグ

        objReq3.type = 'hidden'; // 入力フォームが表示されないように
        objReq3.name = 'blackPaintListJson';
        objReq3.value = strJson; // 備考を含んだjson


        objForm.appendChild(objReq);
        objForm.appendChild(objReq2);
        objForm.appendChild(objReq3);

        objForm.method = 'POST';
        objForm.action = "MaskHtmlCnt";

        document.body.appendChild(objForm);
        //POST送信フラグを「true」に設定
        isPost = true;
        objForm.submit();
	} //if


} //function

/**
 * 黒塗り文書作成画面を表示する
 */
function confirmList() {

	// var itemCom=""; //備考欄の配列
	var itemCom = []; // 備考欄の配列
	var element = document.getElementById("HENSHU");
	var elementCom = document.getElementsByClassName("textArea");

	if (element.classList.contains("on")) {
		alert("「編集」ボタンをクリックしてから確定を行ってください。");
		return;
	} else {

		// for (let i = 0; i < elementCom.length; i++) {
		// 	var couStr = 0;
		// 	var str = elementCom[i].value;
		// 	for (let i = 0; i < str.length; i++) {
		// 		var chr = str.charCodeAt(i);
		// 		if ((chr >= 0x00 && chr < 0x81) || (chr === 0xf8f0)
		// 				|| (chr >= 0xff61 && chr < 0xffa0)
		// 				|| (chr >= 0xf8f1 && chr < 0xf8f4)) {
		// 			// 半角文字の場合は1を加算
		// 			couStr += 1;
		// 		} else {
		// 			// それ以外の文字の場合は2を加算
		// 			couStr += 2;
		// 		}
		// 	}

		// 	if (couStr > 126) {
		// 		alert("備考欄の文字数がオーバーしています。");
		// 		return;
		// 	}
		// } // for

		var blRet = confirm("「黒塗りリスト表示画面」で編集した内容を確定して、「黒塗り文書作成画面」に遷移してもよろしいでしょうか。");

		if (blRet) {

			for (let i = 0; i < elementCom.length; i++) {
				itemCom[i] = elementCom[i].outerText;
			} // for
			// glblackPaintListに格納
			glblackPaintList.Remarks = itemCom;
			var strJson = JSON.stringify(glblackPaintList);

			var objForm = document.createElement('form');
			var objReq = document.createElement('input');
			var objReq2 = document.createElement('input');
			var objReq3 = document.createElement('input');

			objReq.type = 'hidden'; // 入力フォームが表示されないように
			objReq.name = 'documentId';
			objReq.value = gldocumentId;

			objReq2.type = 'hidden'; // 入力フォームが表示されないように
			objReq2.name = 'status';
			objReq2.value = "2"; // 確定フラグ

			objReq3.type = 'hidden'; // 入力フォームが表示されないように
			objReq3.name = 'blackPaintListJson';
			objReq3.value = strJson; // 備考を含んだjson

			objForm.appendChild(objReq);
			objForm.appendChild(objReq2);
			objForm.appendChild(objReq3);

			// objForm.method = 'GET';
			objForm.method = 'POST';
			objForm.action = "MaskHtmlCnt";

			document.body.appendChild(objForm);
			// POST送信フラグを「true」に設定
			isPost = true;
			objForm.submit();

		} // if

	}// if


} //function

"use strict"
class ToolTip {
	constructor(items) {
		this.items = Array.from(items)
		console.log(this.items)
		this.items.map(item => {
			new ToolTipItem(item)
		})
	}
}
class ToolTipItem {
	constructor(dom) {
		// 初期化
		this.rootDom = dom;
		this.dom = document.createElement("div")
		let rect = this.rootDom.getBoundingClientRect();
		// dom生成
		this.dom.innerText = this.rootDom.innerText;
		this.dom.style.position = "absolute";
		this.dom.style.background = "#ffc";
		this.dom.style.padding = "5px 15px";
		this.dom.style.borderRadius = "3px";
		this.dom.style.boxShadow = "0 8px 8px  rgba(0,0,0,0.2)";
		this.dom.style.transitionDuration = "0.2s";
		this.dom.style.top = (rect.top + window.pageYOffset + 15) + "px";
		this.dom.style.left = (rect.left + window.pageXOffset - 150) + "px";
		this.dom.style.opacity = 0;
		//
		this.rootHovering = false;
		this.domHovering = false;
		this.showing = false;
		this.rootDom.addEventListener("mouseover", this.show.bind(this), true)
		this.dom.addEventListener("mouseout", this.hide.bind(this))
		this.dom.addEventListener("click", event => event.stopImmediatePropagation(), true)
		document.body.addEventListener("click", this.hide.bind(this))
	}
	show() {
		this.showing = true;
		document.body.appendChild(this.dom)
		setTimeout(() => {
			this.dom.style.opacity = 1;
		}, 100);
	}
	hide() {
		this.dom.style.opacity = 0;
		setTimeout(() => {
			try {
				document.body.removeChild(this.dom)
			} catch (error) {

			}
		}, 100);
	}
	domHover() {
		this.show()
		this.domHovering = true;
		console.log(this)
	}
	domMouseOut() {
		this.domHovering = false;
		this.hide()
		console.log(this)
	}
	rootHover() {
		this.show()
		this.rootHovering = true;
		console.log(this)
	}
	rootMouseOut() {
		this.rootHovering = false;
		this.hide()
		console.log(this)
	}
}
