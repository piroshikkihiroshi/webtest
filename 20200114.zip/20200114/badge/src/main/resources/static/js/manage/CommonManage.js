/**
 * @fileOverview 管理機能共通スクリプト
 * @desc 機能名：管理機能
 * @desc 画面名：管理画面共通
 */


function beforeOpen(){
    try {
        if ((window.opener) && (Object.keys(window.opener).length)) {
            if (window.opener.SearchMain && typeof window.opener.SearchMain.beforeChildOpen === 'function') {
                window.opener.SearchMain.beforeChildOpen();
            } //if
        } //if
    } catch (error) {
        console.log(error);
    } //try
} //function


function afterClose() {
    try {
        if((window.opener) && (Object.keys(window.opener).length)){
            if(window.opener.SearchMain && typeof window.opener.SearchMain.afterChildClose === 'function'){
                window.opener.SearchMain.afterChildClose();
            } //if
        } //if
    } catch (error) {
        console.log(error);
    } //try
}// function
