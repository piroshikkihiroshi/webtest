/**
 * @fileOverview 黒塗りポリシー設定画面（管理者用）用スクリプト
 * @desc 機能名：管理機能
 * @desc 画面名：黒塗りポリシー設定画面
 */

/**
 * 削除ボタン有効状態の定数
 * @memberOf Policy
 * @constant {Number} deleteCheckFlag
*/
deleteCheckFlag = 1;

/**
 * 編集ボタン有効状態の定数
 * @memberOf Policy
 * @constant {Number} editCheckFlag
*/
editCheckFlag = 1;

/**
 * ボタン無効状態の定数
 * @memberOf Policy
 * @constant {Number} upCheckFlag
*/
upCheckFlag = 1;

/**
 * ボタン有効状態の定数
 * @memberOf Policy
 * @constant {Number} downCheckFlag
*/
downCheckFlag = 1;

/**
 * 追加サーバ情報のボタンの有効状態の定数
 * @memberOf Policy
 * @constant {Number} listAddBtnCheckFlag
*/
listAddBtnCheckFlag = 1;

/**
 * 追加したボタンの無効状態の定数
 * @memberOf Policy
 * @constant {Number} addBtnCheckFlag
*/
addBtnCheckFlag = 0;

/**
 * 追加したサーバ情報のカウントの無効状態の定数
 * @memberOf Policy
 * @constant {Number} addListCount
*/
addListCount = 0;

addListMode = false; // 新規作成ボタンで行が追加された状態 : true / デフォルト : false
editMode = false; // 編集ボタンで行が追加された状態 : true / デフォルト : false;

/**
 * ボタン無効状態の定数
 * @memberOf SearchServer
 * @constant {Number} DISABLE_TRUE
*/
DISABLE_TRUE = 0;

/**
 * ボタン有効状態の定数
 * @memberOf SearchServer
 * @constant {Number} DISABLE_FALSE
*/
DISABLE_FALSE = 1;


/**
 * サーバへのリクエストが成功(true)／失敗(false)を保持する変数
 * @memberOf SearchServer
 * @type {Number} isPost
 * @default
 */
var isPost = false;

/**
 * キャンセルボタンが押下されたかを保持する変数
 * @memberOf SearchServer
 * @type {Number} isCancel
 * @default
 */
var isCancel = false;

/**
 * 値を追加する変数
 * @memberOf SearchServer
 * @type {Number} addValues
 * @default
 */
var addValues = {};

/**
 * 値の変換を保持する変数
 * @memberOf SearchServer
 * @type {Number} changedValues
 * @default
 */
var changedValues = {};

/**
 * DBNoを削除する変数
 * @memberOf SearchServer
 * @type {Number} deleteDBNo
 * @default
 */
var deleteDBNo = [];


/**
 * 変数
 * @memberOf SearchServer
 * @type {Number} hostUrl
 * @default
 */
// 現在のURL
var hostUrl = location.protocol + '//' + location.host + location.pathname;

//アラートメッセージ

/**
 * 変数
 * @memberOf SearchServer
 * @type {Number} policyNullMessage
 * @default
 */
var policyNullMessage = "ポリシー名を入力後再度ボタンを押下してください。";
var samePolicyNameMessage = "既に設定されているポリシー名のため、登録することができません。";
var blackReasonNullMessage = "黒塗り対処理由を入力後再度ボタンを押下してください。";
var addModeEditClickMessage = "現在新規作成中のため編集は行えません。";
var editModeAddClickMessage = "現在編集中のため新規作成は行えません。";
var deleteEditListMessage = "選択した行は現在編集中のため削除できません。";
var selectedNotClickEditMessage = "行の選択を行った後「編集ボタン」を押下してください。";
var selectedNotClickDeleteMessage = "行の選択を行った後「削除ボタン」を押下してください。"
var selectedNotClickChangeUpMessage = "行の選択を行った後「順位▲ボタン」を押下してください。"
var selectedNotClickChangeDownMessage = "行の選択を行った後「順位▼ボタン」を押下してください。";
var addReflectSettingMessage = "変更が反映されました。";
var addReflectSettingFailureMessage = "設定反映に失敗しました。";
var cancelSelectedMessage = "変更内容を破棄してもよろしいでしょうか。";
var notUserRoleOrLoginOutMessage = "ログインを行っていない、または管理者ではありません。";

/**
 * 動作関数
 * 読み込み時、ボタン制御等を行う。
 * @memberOf  policy
 */
$(function () {

    //Cookieを確認し、管理者権限またはログインしているかチェックを行う
    // ドメイン情報取得
    DomainCookie.initDomainCookie('[[${DomainInfo}]]');
    var userRole = DomainCookie.getUserRole();
    userRoleFlag = false;

    // ログインしてない場合
    if (userRole === null) {
      alert(notUserRoleOrLoginOutMessage);

      //「新規作成ボタン」を非活性化状態にする
      listAddBtnCheckFlag = DISABLE_TRUE;
      //「編集ボタン」を非活性化状態にする
      editCheckFlag = DISABLE_TRUE;
      //「削除ボタン」を非活性化状態にする
      deleteCheckFlag = DISABLE_TRUE;
      //「順位▲ボタン」を非活性化状態にする
      upCheckFlag = DISABLE_TRUE;
      //「順位▼ボタン」を非活性化状態にする
      downCheckFlag = DISABLE_TRUE;
      //「設定反映ボタン」を非活性化状態にする
      addBtnCheckFlag = DISABLE_TRUE;
      //「キャンセルボタン」を非活性化状態にする
      $("#cancelBtn").prop("disabled", true);
    }

    //管理者権限か確認を行う
    if (userRole === "Administrators") {
      showUserName();
      userRoleFlag = true;
    }

    //管理者権限、またはログインしていなかった場合画面を閉じる
    if (userRoleFlag !== true) {
      alert(notUserRoleOrLoginOutMessage);

      //「新規作成ボタン」を非活性化状態にする
      listAddBtnCheckFlag = DISABLE_TRUE;
      //「編集ボタン」を非活性化状態にする
      editCheckFlag = DISABLE_TRUE;
      //「削除ボタン」を非活性化状態にする
      deleteCheckFlag = DISABLE_TRUE;
      //「順位▲ボタン」を非活性化状態にする
      upCheckFlag = DISABLE_TRUE;
      //「順位▼ボタン」を非活性化状態にする
      downCheckFlag = DISABLE_TRUE;
      //「設定反映ボタン」を非活性化状態にする
      addBtnCheckFlag = DISABLE_TRUE;
      //「キャンセルボタン」を非活性化状態にする
      $("#cancelBtn").prop("disabled", true);
    }

    //NAS様opener対応(beforeOpen())
    beforeOpen();

    // ボタンの表示状態更新
    btnAllCheck();

  /**
 * 再読み込み時動作関数
 * 画面が変更、または閉じられる時に動作する。
 * @memberOf  policy
 * @param {value} isPost POST送信フラグ
 */
  $(window).on("beforeunload", function (e) {
    // NAS様opener対応(afterClose())
    afterClose();
    // POST送信フラグが「true」の場合、ダイアログを表示しない
    if (isPost || isCancel) {
      return;
    } else {
      return true;
    }
  });

  /**
 * 一覧表読み完了後動作関数
 * 一覧表の読み込みが完了後、一覧表の数が0だった場合ボタンをdisabledに変更を行う。
 * @memberOf  policy
 * @param {value} editCheck 編集ボタン確認フラグ
 * @param {value} deleteCheck 削除ボタン確認フラグ
 * @param {value} upCheck 順位▲ボタン確認フラグ
 * @param {value} downCheck 順位▼ボタン確認フラグ
 */
  $('.scrollBody').ready(function (e) {

    if (document.getElementById('main_scroll').childElementCount == 0) {
      //「編集ボタン」を非活性化状態にする
      editCheckFlag = DISABLE_TRUE;
      //「削除ボタン」を非活性化状態にする
      deleteCheckFlag = DISABLE_TRUE;
      //「順位▲ボタン」を非活性化状態にする
      upCheckFlag = DISABLE_TRUE;
      //「順位▼ボタン」を非活性化状態にする
      downCheckFlag = DISABLE_TRUE;
      //「設定反映ボタン」を非活性化状態にする
      addBtnCheckFlag = DISABLE_TRUE;
      // ボタンの表示状態更新
      btnAllCheck();
    }
  });

  /**
 * 一覧表押下時動作関数
 * 表をクリック時に動作し、クリックを行った時に選択した行の色が変更する。
 * @memberOf  policy
 */
  $('.scrollBody').mousedown(function (e) {
    //表の項目以外をクリック時には色を付けない
    if (e.target.id != "main_scroll") {
      //テキストボックスに'selected'が挿入されてしまうため、判定しない
      if (e.target.className == "textbox" || e.target.className == "tr l" || e.target.className == "0 tr l"
        || e.target.className.match("EditTable") || e.target.className.match("AddListTable")) {
        return;
      }
      if (e.target.nodeName == "SPAN") {
        if (e.target.parentElement.parentElement.id == 'selected') {
          document.getElementById('selected').removeAttribute("id");
          return true;
        } else {
          if (document.getElementById('selected') == null) {
            e.target.parentElement.parentElement.setAttribute('id', 'selected');
          }
          document.getElementById('selected').removeAttribute("id");
          e.target.parentElement.parentElement.setAttribute('id', 'selected');
          return true;
        }
      }
      //一項目のみclick可能とする
      if (e.target.parentElement.id == 'selected') {
        document.getElementById('selected').removeAttribute("id");
      } else {
        if (document.getElementById('selected') == null) {
          e.target.parentElement.setAttribute('id', 'selected');
        }
        document.getElementById('selected').removeAttribute("id");
        e.target.parentElement.setAttribute('id', 'selected');
      }
    } else if (e.target.id == "main_scroll") {
      return false;
    }

  });
});

/**
 * @memberOf  policy
 * @param {value} addBtnCheckFlag 設定反映ボタン確認フラグ
 * @param {value} editCheckFlag 編集ボタン確認フラグ
 * @param {value} deleteCheckFlag 削除ボタンボタン確認フラグ
 */
//新規作成ボタン押下時に動作し、一覧表の最下部に追加する
function addList() {
  // 編集中の場合
  if (editMode) {
    alert(editModeAddClickMessage);
    return;
  }

  //自動順位項番結果を取得する
  var objAutoRowNo = document.getElementById("main_scroll").childElementCount;
  strAutoRowNo = '' + objAutoRowNo;

  //最大順位取得の取得をする
  var objChildrenCountPoint = objAutoRowNo - 1;
  strChildrenCountPoint = objAutoRowNo + 1 + "";

  //黒塗りポリシーが存在しない場合新規追加
  if (objAutoRowNo == 0) {
    //新規作成する欄を作成する
    createAddListData();
    //「設定反映ボタン」を非活性化状態にする
    addBtnCheckFlag = DISABLE_TRUE;
    //「編集ボタン」を非活性化状態にする
    editCheckFlag = DISABLE_TRUE;
    //「削除ボタン」を非活性化状態にする
    //    deleteCheckFlag = DISABLE_TRUE;
    // ボタンの表示状態更新
    btnAllCheck();
    // 行追加状態にする
    addListMode = true;
    //ラベル名を修正する
    document.getElementById("listAddBtn").value = "追加";
    document.getElementById("listAddBtn").classList.toggle("on");

    mainDom = document.querySelector(".table.LIST");
    trs = mainDom.querySelectorAll("ul")
    lineAndColumns = Array.from(trs).map(item => {
      return Array.from(item.querySelectorAll("li"))
    })
    //resizableGrid.setParam(mainDom, lineAndColumns);
    new ResizableGrid(mainDom, lineAndColumns, true);


    alignHeight = new AlignHeight(
      Array.from(document.querySelectorAll("#main_scroll ul"))
    )
  }  //
  // 行追加状態ではないならば最終行に行追加
  else if (!addListMode) {
    //編集行を、最終行に変更する
    if (document.getElementById('selected') != null) {
      document.getElementById('selected').removeAttribute("id");
    }
    //新規作成する欄を作成する
    createAddListData();
    //「設定反映ボタン」を非活性化状態にする
    addBtnCheckFlag = DISABLE_TRUE;
    //「編集ボタン」を非活性化状態にする
    editCheckFlag = DISABLE_TRUE;
    //「順位▲ボタン」を非活性化状態にする
    upCheckFlag = DISABLE_TRUE;
    //「順位▼ボタン」を非活性化状態にする
    downCheckFlag = DISABLE_TRUE;
    //「削除ボタン」を非活性化状態にする
    //    deleteCheckFlag = DISABLE_TRUE;
    // ボタンの表示状態更新
    btnAllCheck();
    addListMode = true;
    //ラベル名を修正する
    document.getElementById("listAddBtn").value = "追加";
    document.getElementById("listAddBtn").classList.toggle("on");

    var delDiv = document.getElementsByClassName("table LIST");
    while (delDiv[0].children[2]) {
        delDiv[0].removeChild(delDiv[0].children[2]);
    }

    mainDom = document.querySelector(".table.LIST");
    trs = mainDom.querySelectorAll("ul")
    lineAndColumns = Array.from(trs).map(item => {
      return Array.from(item.querySelectorAll("li"))
    })
    //resizableGrid.setParam(mainDom, lineAndColumns);
    new ResizableGrid(mainDom, lineAndColumns, true);


    alignHeight = new AlignHeight(
      Array.from(document.querySelectorAll("#main_scroll ul"))
    )
  }
  // 行追加状態ならテキストボックス化解除
  else if (addListMode) {
    //現在新規作成中の順位を取得する
    var objRowNo = document.getElementById("main_scroll").childElementCount;
    strRowNo = '' + objRowNo;

    //入力されているテキストボックス内容を取得する
    var objNewPolicyNameText = document.getElementById("newPolicyName").value;
    var objNewBlackReasonText = document.getElementById("newBlackReason").value;

    //入力チェックの確認する
    if (objNewPolicyNameText == "") {
      alert(policyNullMessage);
      return false;
    } else if (objNewBlackReasonText == "") {
      alert(blackReasonNullMessage);
      return false;
    }

    //同一ポリシー名が登録されていないか確認する
    for (let i = 1; i < document.getElementById('main_scroll').childElementCount + 1; i++) {
      var tmp = document.getElementById('main_scroll').children[i - 1].children[2].innerText;
      if (objNewPolicyNameText == tmp) {
        alert(samePolicyNameMessage);
        return false;
      }
    }


    //連想配列の作成する
    addValues[addListCount] = {
      ["policyNumber"]: strRowNo,
      ["policyName"]: objNewPolicyNameText,
      ["policyReason"]: objNewBlackReasonText
    };
    addListCount++;

    //テキストボックス化を解除する
    document.getElementById("newPolicyName").outerHTML = objNewPolicyNameText;
    document.getElementById("newBlackReason").outerHTML = objNewBlackReasonText;
    //非アクティブ化状態に移行するため、クラスの削除する
    document.getElementsByClassName("AddListTable")[0].classList.remove("AddListTable");

    //「設定反映ボタン」を活性化状態にする
    addBtnCheckFlag = DISABLE_FALSE;
    //「編集ボタン」を活性化状態にする
    editCheckFlag = DISABLE_FALSE;
    //「削除ボタン」を活性化状態にする
    deleteCheckFlag = DISABLE_FALSE;
    //「▲ボタン」を活性化状態にする
    upCheckFlag = DISABLE_FALSE;
    //「▼ボタン」を活性化状態にする
    downCheckFlag = DISABLE_FALSE;
    // ボタンの表示状態更新
    btnAllCheck();
    // 行追加状態解除
    addListMode = false;
    //ラベル名を修正する
    document.getElementById("listAddBtn").value = "新規作成";
    document.getElementById("listAddBtn").classList.toggle("on");



    return;
  }
}
/**
 * 黒塗りポリシー設定行を追加する
 */
function createAddListData() {

  var userName = $("#USER_NAME")[0].innerText.replace("ユーザー名：", "");
  var listHeader = document.getElementById("listHeader");
  var listHeaderStyle = [];

  for (let index = 1; index < listHeader.childElementCount; index++) {
    listHeaderStyle[index] = listHeader.children[index].style.width;
  }
  //新規作成する欄を作成する
  var ul = $('<ul id="selected"  class="tr l AddListTable"></ul>');
  var strPolicyNumber = $('<li class="' + addListCount + '" style="display: none;"></li>');
  var strDisplayRanktd = $('<li style="width:'+ listHeaderStyle[1] +'";></li>');
  var strPolicyNametd = $('<li style="width:'+ listHeaderStyle[2] +'";></li>');
  var strCreateTimetd = $('<li style="width:'+ listHeaderStyle[3] +'";></li>');
  var strCreateUserNametd = $('<li style="width:'+ listHeaderStyle[4] +'";></li>');
  var strBlackReasontd = $('<li style="width:'+ listHeaderStyle[5] +'";></li>');
  var strBlackPointKeywordtd = $('<li class="wAutoA" style="width:'+ listHeaderStyle[6] +'";></li>');
  var objListHeaderStyleNotpx = listHeaderStyle[2].replace("px","") - 20;
  var strListHeaderStyle= objListHeaderStyleNotpx + "px"
  var objListHeaderStyleNotpxReasontd = listHeaderStyle[5].replace("px","") - 20;
  var strListHeaderStyleReasontd= objListHeaderStyleNotpxReasontd + "px"

  //表に取得した値を挿入する
  $(".scrollBody").append(ul);
  ul.append(strPolicyNumber).append(strDisplayRanktd).
    append(strPolicyNametd).append(strCreateTimetd).
    append(strCreateUserNametd).append(strBlackReasontd).
    append(strBlackPointKeywordtd);

  strPolicyNumber.html("");
  strDisplayRanktd.html(strChildrenCountPoint);
  strPolicyNametd.html("<textarea id='newPolicyName' class='textbox' style='width:95%; height:65%'; maxlength='32'></textarea>");
  //APサーバ設定時の時刻のため、表示を行わないようにする
  strCreateTimetd.html("");
  //現在ログインしているユーザー名を取得し、ここに入れるようにする
  strCreateUserNametd.html(userName);
  strBlackReasontd.html("<textarea id='newBlackReason' style='width:95%; height:65%'; class='textbox' maxlength='64'></textarea>");
  //対象キーワードは後々設定されるため、記載は行わないようにする
  strBlackPointKeywordtd.html("");
  // 幅再調整
  fillDomWidth();
}


//編集ボタン押下時に動作し、選択した項目内容を変更する
function editPolicy() {
  // 追加中の場合
  if (addListMode) {
    alert(addModeEditClickMessage);
    return;
  }

  //非編集状態の場合
  if (!editMode) {
    // リストが選択されている場合
    if (document.getElementById('selected') != null) {
      //編集がアクティブ状態のため、クラス付与する
      $('#main_scroll').eq(0).addClass('EditMode');
      $('#selected').eq(0).addClass('EditTable');

      //選択行の一つ目の要素の子要素を取得
      var getSelectedChildren = $('#selected').eq(0).children();
      //選択行のポリシー名を取得する
      var strPolicyText = getSelectedChildren[2].valueOf().textContent;
      //選択行の黒塗り対処理由を取得する
      var strPolicyReasonText = getSelectedChildren[5].valueOf().textContent;

      //選択行のポリシー名をTextBox化する
      getSelectedChildren[2].innerHTML = "<textarea id='changePolicyName' class='textbox' style='width:95%; height:75% ' maxLength='32'>" + strPolicyText + "</textarea>";
      //選択行の黒塗り対処理由をTextBox化する
      getSelectedChildren[5].innerHTML = "<textarea id='changeBlackReason' class='textbox' style='width:95%; height:75%' maxLength='64'>" + strPolicyReasonText + "</textarea>";

      //「設定反映ボタン」を非活性化状態にする
      addBtnCheckFlag = DISABLE_TRUE;
      //「新規作成ボタン」を非活性化状態にする
      listAddBtnCheckFlag = DISABLE_TRUE;
      //      //「削除ボタン」を非活性化状態にする
      //      deleteCheckFlag = DISABLE_TRUE;

      // ボタンの表示状態更新
      btnAllCheck();

      //「編集ボタン」を活性化状態に変更する
      document.getElementById("editBtn").classList.toggle("on");
      //document.getElementById("editBtn").value = "編集完了";

      // 編集状態にする
      editMode = true;

      //リストが選択されていない場合falseを返却する
    } else {
      alert(selectedNotClickEditMessage);
      return false;
    }
    //編集状態の場合動作する
  } else if (editMode) {

    //追加時のリスト番号値取得する
    var strChangeRow = document.getElementsByClassName("EditTable")[0].children[0].outerText;

    //現在新規作成中の順位を取得する
    var strRanktdNumber = document.getElementsByClassName("EditTable")[0].children[1].outerText

    //addValuesのリスト番号を取得する
    var strAddChangeRow = document.getElementsByClassName("EditTable")[0].children[0].className;

    //表示されている値の登録する
    var strTextBoxPolicyName = document.getElementById("changePolicyName").value;
    var strTextBoxBlackReason = document.getElementById("changeBlackReason").value;

    //入力チェックの確認する
    if (strTextBoxPolicyName == "") {
      alert(policyNullMessage);
      return false;
    } else if (strTextBoxBlackReason == "") {
      alert(blackReasonNullMessage);
      return false;
    }

    //同一ポリシー名が登録されていないか確認する
    for (let i = 1; i < document.getElementById('main_scroll').childElementCount + 1; i++) {
      var tmp = document.getElementById('main_scroll').children[i - 1].children[2].innerText;
      var row = document.getElementById('main_scroll').children[i - 1].children[0].innerText;
      // 選択行は対象外とする
      if (strChangeRow === row) {
        continue;
      }
      if (strTextBoxPolicyName === tmp) {
        alert(samePolicyNameMessage);
        return false;
      }
    }

    // 連想配列作成・追加する
    if (addValues[strAddChangeRow]) {
      addValues[strAddChangeRow]["policyName"] = strTextBoxPolicyName;
      addValues[strAddChangeRow]["policyReason"] = strTextBoxBlackReason;
      if (changedValues[strChangeRow]) {
        changedValues[strChangeRow]["policyName"] = strTextBoxPolicyName;
        changedValues[strChangeRow]["policyReason"] = strTextBoxBlackReason;
        changedValues[strChangeRow]["policyId"] = strChangeRow;
      }
    } else {
      if (!changedValues[strChangeRow]) {
        changedValues[strChangeRow] = {
          ["policyId"]: strChangeRow,
          ["policyNumber"]: strRanktdNumber,
          ["policyName"]: strTextBoxPolicyName,
          ["policyReason"]: strTextBoxBlackReason
        };
      } else {
        changedValues[strChangeRow]["policyName"] = strTextBoxPolicyName;
        changedValues[strChangeRow]["policyReason"] = strTextBoxBlackReason;
        changedValues[strChangeRow]["policyId"] = strChangeRow;
      }
    }

    //テキストボックス化を解除する
    document.getElementById("changePolicyName").outerHTML = strTextBoxPolicyName;
    document.getElementById("changeBlackReason").outerHTML = strTextBoxBlackReason;

    //非アクティブ化状態に移行するため、クラスの削除する
    document.getElementById('main_scroll').classList.remove("EditMode");
    document.getElementsByClassName("EditTable")[0].classList.remove("EditTable");

    //「設定反映ボタン」を非活性化状態にする
    addBtnCheckFlag = DISABLE_FALSE;
    //「新規作成ボタン」を非活性化状態にする
    listAddBtnCheckFlag = DISABLE_FALSE;
    //「削除ボタン」を非活性化状態にする
    deleteCheckFlag = DISABLE_FALSE;

    //「編集ボタン」を活性化状態にする
    document.getElementById("editBtn").classList.toggle("on");
    //document.getElementById("editBtn").value = "編集";

    // ボタンの表示状態更新
    btnAllCheck();

    // 非編集状態にする
    editMode = false;

    return;
  }
}

//削除ボタン押下時に動作し、選択した行を削除する
function deleteRow() {

  //選択した行があるか判定する
  if (document.getElementById('selected') != null) {

    var selectedRow = document.getElementById("selected");
    //選択している行が編集中の場合、アラートを表示する
    if (selectedRow.classList.contains("EditTable") !== true
      && selectedRow.classList.contains("AddListTable") !== true) {

      //ポリシーIDの値取得する
      var strDeleteRow = document.getElementById("selected").children[0].outerText;

      //新規作成で表示されているリストの場合、classからリスト番号を取得する
      var strAddChangeRow = document.getElementById("selected").children[0].className;

      //グローバル変数にポリシーIDの値を取得する
      deleteDBNo.push(strDeleteRow);

      //連想配列の削除する
      if (changedValues[strDeleteRow]) {
        delete changedValues[strDeleteRow];
        if (addValues[strAddChangeRow]) {
          delete addValues[strAddChangeRow];
        }
      } else if (addValues[strAddChangeRow]) {
        delete addValues[strAddChangeRow];
      }

      //選択した行の削除する
      $("#selected").remove();

      //ポリシーIDの付け直しをする
      policyIdUpdate();

      // 0行になった時新規ボタン以外をdisabledに
      var rowCnt = document.getElementById("main_scroll").childElementCount;
      if (rowCnt === 0) {
        //「編集ボタン」を非活性化状態にする
        editCheckFlag = DISABLE_TRUE;
        //「削除ボタン」を非活性化状態にする
        deleteCheckFlag = DISABLE_TRUE;
        //「順位▲ボタン」を非活性化状態にする
        upCheckFlag = DISABLE_TRUE;
        //「順位▼ボタン」を非活性化状態にする
        downCheckFlag = DISABLE_TRUE;
      }
      // ボタンの表示状態更新
      btnAllCheck();

    } else if (selectedRow.classList.contains("AddListTable") === true) {

      //選択した行の削除する
      $("#selected").remove();

      //ポリシーIDの付け直しをする
      policyIdUpdate();

      // 0行になった時新規ボタン以外をdisabledに
      var rowCnt = document.getElementById("main_scroll").childElementCount;

      addListMode = false;
      //「編集ボタン」を活性化状態にする
      editCheckFlag = DISABLE_FALSE;
      //「▲ボタン」を活性化状態にする
      upCheckFlag = DISABLE_FALSE;
      //「▼ボタン」を活性化状態にする
      downCheckFlag = DISABLE_FALSE;

      if (rowCnt === 0) {
        //「編集ボタン」を非活性化状態にする
        editCheckFlag = DISABLE_TRUE;
        //「削除ボタン」を非活性化状態にする
        deleteCheckFlag = DISABLE_TRUE;
        //「順位▲ボタン」を非活性化状態にする
        upCheckFlag = DISABLE_TRUE;
        //「順位▼ボタン」を非活性化状態にする
        downCheckFlag = DISABLE_TRUE;
      }
      // ボタンの表示状態更新
      btnAllCheck();
      //ラベル名を修正する
      document.getElementById("listAddBtn").value = "新規作成";
      document.getElementById("listAddBtn").classList.toggle("on");

    } else {
      alert(deleteEditListMessage);
    }
  } else {
    alert(selectedNotClickDeleteMessage);
    return false;
  }
}

//順位▲ボタン押下時に動作し、選択した行の順位を1つ上げる
function changeRankUp() {

  //選択した行があるか判定する
  if (document.getElementById('selected') != null) {
    // tbody要素に指定したIDを取得し、変数「tbody」に代入する
    var tbody = document.getElementById('main_scroll');
    // objのノードを取得し、変数「tr」に代入する
    var ul = document.getElementById("selected");

    // 指定している行が最終行の場合動作しない
    if (ul.previousElementSibling != null) {
      //最上位順位以外の場合動作する
      if (ul.children[1].outerText !== '1') {
        //「ul」を直後の兄弟ノードの上に挿入する
        tbody.insertBefore(ul, ul.previousElementSibling);
      }
      //ポリシーIDの付け直しをする
      policyIdUpdate();
    } else {
      return false;
    }
  } else {
    alert(selectedNotClickChangeUpMessage);
    return false;
  }
};

//順位▼ボタン押下時に動作し、選択した行の順位を1つ下げる
function changeRankDown() {

  //選択した行があるか判定する
  if (document.getElementById('selected') != null) {
    // tbody要素に指定したIDを取得し、変数「tbody」に代入する
    var tbody = document.getElementById('main_scroll');
    // objのノードを取得し、変数「tr」に代入する
    var ul = document.getElementById("selected");
    // 最大順位の取得する
    var strMaxRanked = '' + tbody.childElementCount;

    // 指定している行が最終行の場合動作しない
    if (ul.nextElementSibling != null) {
      //最下位順位以外動作する
      if (ul.children[1].outerText !== strMaxRanked) {
        // 「tr」を直後の兄弟ノードの上に挿入する
        tbody.insertBefore(ul.nextElementSibling, ul);
      }
      //ポリシーIDの付け直しをする
      policyIdUpdate();
    } else {
      return false;
    }
  } else {
    alert(selectedNotClickChangeDownMessage);
    return false;
  }
};

/**
 * 削除、行の上下移動の再にポリシーIDを振りなおす
 */
function policyIdUpdate() {
  //ポリシーIDの付け直しをする
  var strAutoRowNo = document.getElementById("main_scroll").childElementCount;
  //変更箇所の表示順位の変更に伴い変更箇所のフラグ判定する
  var changeValuesFlag = "false";
  for (var i = 0; i < strAutoRowNo; i++) {
    //選択した行に非表示要素があるかの判断する
    let hiddenKey = $(".scrollBody ul").eq(i).children().eq(0)[0].innerText;
      if ($('.scrollBody ul').eq(i).children().eq(1)[0].innerText !== "" + (i + 1)) {
        $('.scrollBody ul').eq(i).children().eq(1).text("" + (i + 1));
        changeValuesFlag = "true";
      }
      // 編集済み項目がある場合連想配列の作成・修正する
      if (changedValues[hiddenKey]) {
        // 受け渡し用の配列の順位を変更する
        changedValues[hiddenKey]['policyNumber'] = i + 1;
      } else if (addValues[hiddenKey]) {
        // 受け渡し用の配列の順位を変更する
        addValues[hiddenKey]['policyNumber'] = i + 1;
      } else if (changeValuesFlag === "true") {
        //変更した行の順位を変更する
        changedValues[hiddenKey] = { ["policyNumber"]: "" + (i + 1), ["policyId"]: hiddenKey };
        changeValuesFlag = "false";
      }
  }
  //最後にボタンの状態を更新する
  btnAllCheck();

}

//キャンセルボタン押下時に動作しダイアログを表示する
function policyCancel() {
  blCan = confirm(cancelSelectedMessage);
  console.log(blCan);
  if (blCan) {
    isCancel = true;
    afterClose();
    window.close();
  } else {
    return;
  }
}


//設定反映ボタン押下時に動作し、DBに設定反映する
function postItem() {
    var jsonObj = new Object();

    // 削除項目のIDをデータ受け渡し用変数に格納
    jsonObj.deleteRow = deleteDBNo;

    // 編集項目の値をデータ受け渡しし用変数に格納
    var postChangeValues = [];
    for (var cv in changedValues) {
      console.log(changedValues[cv]);
      postChangeValues.push(changedValues[cv]);
    }
    jsonObj.changedValues = postChangeValues;

    // 追加項目の値をデータ受け渡しし用変数に格納
    var postAddValues = [];
    // リクエストパラメータに合うように変更する
    for (var av in addValues) {
      console.log(addValues[av]);
      postAddValues.push(addValues[av]);
    }
    jsonObj.addValues = postAddValues;
    // ユーザ名の追加
    var userName = $("#USER_NAME")[0].innerText.replace("ユーザー名：", "");
    jsonObj.policyAuthor = userName;
    console.log(jsonObj);
    //POST
    $.ajax({
      url: hostUrl + "/policy_reflect",
      type: "POST",
      contentType: "application/json",
      data: JSON.stringify(jsonObj),
      // ajax通信成功時の処理をする
    }).done(function (data) {
      let successOrFailure = "";
      console.log(data);
      // 画面を更新する
      isPost = true;
      alert(addReflectSettingMessage);
      location.reload();
      // 更新フラグをON
      // ajax通信失敗時の処理をする
    }).fail(function (xhr, textStatus, errorThrown) {
      //alert(xhr.responseText + "\r\n設定反映に失敗しました。");
      alert(addReflectSettingFailureMessage);
      // 成功でも失敗でも通信終了時に必要な処理があれば追加記載する
    }).always(function () {
    });
}


/**
 * 全てのボタンの「活性」・「非活性」を判定する
 */
function btnAllCheck() {
  // 追加／編集／削除のデータが無い場合
  if (!Object.keys(addValues).length && !Object.keys(changedValues).length && !deleteDBNo.length) {
    console.log("更新情報なし");
    // 設定反映ボタンを非活性状態にする
    addBtnCheckFlag = DISABLE_TRUE;
  } else {
    console.log("更新情報あり");
    // 設定反映ボタンを活性状態にする
    addBtnCheckFlag = DISABLE_FALSE;
  }// if
  isAdd();
  isListAdd();
  isEdit();
  isDelete();
  isUp();
  isDown();
}
//設定反映ボタンの「活性」「非活性」を判定する
function isAdd() {
  if (addBtnCheckFlag == 0) {
    $("#addBtn").prop("disabled", true);
    return true;
  }
  $("#addBtn").prop("disabled", false);
  return false;
}

//新規作成ボタンの「活性」「非活性」を判定する
function isListAdd() {
  if (listAddBtnCheckFlag == 0) {
    $("#listAddBtn").prop("disabled", true);
    return true;
  }
  $("#listAddBtn").prop("disabled", false);
  return false;
}

//編集ボタンの「活性」「非活性」を判定する
function isEdit() {
  if (editCheckFlag == 0) {
    $("#editBtn").prop("disabled", true);
    return true;
  }
  $("#editBtn").prop("disabled", false);
  return false;
}

//削除ボタンの「活性」「非活性」を判定する
function isDelete() {
  if (deleteCheckFlag == 0) {
    $("#deleteBtn").prop("disabled", true);
    return true;
  }
  $("#deleteBtn").prop("disabled", false);
  return false;
}

//順位▲ボタンの「活性」「非活性」を判定する
function isUp() {
  if (upCheckFlag == 0) {
    $("#upBtn").prop("disabled", true);
    return true;
  }
  $("#upBtn").prop("disabled", false);
  return false;
}

//順位▼ボタンの「活性」「非活性」を判定する
function isDown() {
  if (downCheckFlag == 0) {
    $("#downBtn").prop("disabled", true);
    return true;
  }
  $("#downBtn").prop("disabled", false);
  return false;
}

