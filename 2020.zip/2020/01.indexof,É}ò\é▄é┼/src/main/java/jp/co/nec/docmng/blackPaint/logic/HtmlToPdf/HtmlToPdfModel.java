package jp.co.nec.docmng.blackPaint.logic.HtmlToPdf;





import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aspose.html.HTMLDocument;
import com.aspose.html.rendering.HtmlRenderer;
import com.aspose.html.rendering.pdf.PdfDevice;





public class HtmlToPdfModel {

	/**
	 * strHtml_iからPDFを作成する
	 * @param strHtml_i
	 * @param strPath_i 相対パスを絶対パスに変更する必要があるのでimgが格納されているDirを指定
	 * @param strPdfOutPath_i pdf出力先のファイル名を含めたフルパス
	 * @return Throwable 正常終了ならnull
	 * @modify 20191216 InputStreamで読み込んでから処理するように変更
	 */
	static Logger objLog = LoggerFactory.getLogger(HtmlToPdfModel.class);

	public synchronized Throwable convertHtmlToPdf(String strPath_i,String strPdfOutPath_i)  {

		//※※※※※※動かなかったらこちらを使う/※※※※※※

		InputStream fileStream=null;
		Throwable objRet=null;
		try {
			fileStream = new FileInputStream(strPath_i);
		} catch (Exception e1) {
			objLog.error( "file："+strPath_i+"がありません", e1 );
			objRet = e1;
			return objRet;
		} //try


		HTMLDocument htmlDocument = new HTMLDocument(fileStream,strPath_i);
		HtmlRenderer renderer = new HtmlRenderer();
		FileOutputStream objOs = null;
		PdfDevice objPdfDevice=null;
		try {
			objOs = new FileOutputStream(strPdfOutPath_i, true);
		} catch (FileNotFoundException e1) {
			objLog.error( "file："+strPdfOutPath_i+"がありません", e1 );
			objRet = e1;
			return objRet;
		} //try
		objPdfDevice = new PdfDevice(objOs);

		try {
			renderer.render(objPdfDevice, htmlDocument);
			renderer.dispose();
			fileStream.close();
		} catch (Exception e) {
			objLog.error( "pdf作成時にエラーが発生しました", e );
			objRet=e;
		} finally {
			renderer=null;
			htmlDocument=null;
			objOs=null;
			objPdfDevice=null;
			//GCを明示的によんでメモリ解放
			System.gc();
		} //try
		return objRet;



	} //convertHtmlToPdf





//	/**
//	 * strHtml_iからPDFを作成する
//	 * @param strHtml_i
//	 * @param strPath_i 相対パスを絶対パスに変更する必要があるのでimgが格納されているDirを指定
//	 * @param strPdfOutPath_i pdf出力先のファイル名を含めたフルパス
//	 * @return ErrObject 正常終了ならnull
//	 * @modify 20191216 InputStreamで読み込んでから処理するように変更
//	 */
//	static Logger objLog = LoggerFactory.getLogger(HtmlToPdfModel.class);
//
//	public synchronized Object convertHtmlToPdf(String strPath_i,String strPdfOutPath_i) {
//
//		//※※※※※※動かなかったらこちらを使う/※※※※※※
//
//		InputStream fileStream=null;
//		Object objRet=null;
//		try {
//			fileStream = new FileInputStream(strPath_i);
//		} catch (Exception e1) {
//			objLog.error( "file："+strPath_i+"がありません", e1 );
//			return e1;
//		} //try
//
//
//		HTMLDocument htmlDocument = new HTMLDocument(fileStream,strPath_i);
//		HtmlRenderer renderer = new HtmlRenderer();
//		FileOutputStream objOs = null;
//		PdfDevice objPdfDevice=null;
//		try {
//			objOs = new FileOutputStream(strPdfOutPath_i, true);
//		} catch (FileNotFoundException e1) {
//			objLog.error( "file："+strPdfOutPath_i+"がありません", e1 );
//		}
//		objPdfDevice = new PdfDevice(objOs);
//
//		try {
//			renderer.render(objPdfDevice, htmlDocument);
//			fileStream.close();
//		} catch (Exception e) {
//			objLog.error( "pdf作成時にエラーが発生しました", e );
//			objRet=e;
//		} finally {
//			//GCを明示的によんでメモリ解放
//			System.gc();
//		} //try
//
//		renderer=null;
//		htmlDocument=null;
//		objOs=null;
//		objPdfDevice=null;
//
//		return objRet;
//
//	} //convertHtmlToPdf


//	public synchronized String convertHtmlToPdf(String strPath_i,String strPdfOutPath_i){
//
//		//※※※※※※動かなかったらこちらを使う/※※※※※※
//		HTMLDocument htmlDocument = new HTMLDocument(strPath_i);
//		HtmlRenderer renderer = new HtmlRenderer();
////		PdfRenderingOptions objPdfOpt = new PdfRenderingOptions();
//		FileOutputStream objOs = null;
//		PdfDevice objPdfDevice=null;
//		try {
//			objOs = new FileOutputStream(strPdfOutPath_i, true);
//			objPdfDevice = new PdfDevice(objOs);
//		} catch (FileNotFoundException e) {
//			// TODO 自動生成された catch ブロック
//			e.printStackTrace();
//		}
//
//		renderer.render(objPdfDevice, htmlDocument);
////		objPdfOpt=null;
//		renderer=null;
//		htmlDocument=null;
//		objOs=null;
//		objPdfDevice=null;
//
//		return strPdfOutPath_i;
//
//	} //convertHtmlToPdf



} //class

