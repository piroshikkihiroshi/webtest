package jp.co.nec.docmng.manage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.manage.entity.TmpTeacherPolicyList;
import jp.co.nec.docmng.manage.util.map.TmpTeacherPolicyListMapManage;

@Service
public class TmpTeacherPolicyService {

    @Autowired
    private TmpTeacherPolicyListMapManage tmpTeacherPolicyListMapper;

    @Transactional
    public List<TmpTeacherPolicyList> findAll(){
        List<TmpTeacherPolicyList> entityList = tmpTeacherPolicyListMapper.findAll();
        return entityList;
    }

    @Transactional
    public void deleteAll(){
        tmpTeacherPolicyListMapper.deleteAll();
    }

    @Transactional
    public void insert(TmpTeacherPolicyList tmpTeacherPolicyList){
        tmpTeacherPolicyListMapper.insertTmpPolicy(tmpTeacherPolicyList);
    }

    @Transactional
    public void updateOther(TmpTeacherPolicyList tmpTeacherPolicyList){
        tmpTeacherPolicyListMapper.updateOther(tmpTeacherPolicyList);
    }

    public List<TmpTeacherPolicyList> findPolicyId(Integer policyId) {
        List<TmpTeacherPolicyList> list = tmpTeacherPolicyListMapper.findPolicyId(policyId);
        return list;
    }


}
