package jp.co.nec.docmng.blackPaint.repository;


import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import jp.co.nec.docmng.blackPaint.entity.DocumentInfoEntPaint;


@Mapper
public interface DocumentMapPaint {


	@Select("SELECT * FROM common.document_info WHERE document_id = #{document_id}")
	public List<DocumentInfoEntPaint> selectDocInfo(int document_id);


	@Select("SELECT document_id, server_id, document_name, extension, document_size, parent_id, file_path, marker, category_id, procenter_flg, retention_period, author, updater, authorizer, file_update_time, mask_status, create_time, update_time FROM common.document_info WHERE document_id = #{document_id}" )
	public List<DocumentInfoEntPaint> selectDocFileInfo(int document_id);

	@Update("UPDATE common.document_info SET category_id=#{category_id} , retention_period=#{retention_period} , update_time=#{update_time} WHERE document_id = #{document_id}" )
	public void updateDocFileInfo(int document_id,int category_id,Date retention_period,Date update_time);


} //PolicyInfoMapper
