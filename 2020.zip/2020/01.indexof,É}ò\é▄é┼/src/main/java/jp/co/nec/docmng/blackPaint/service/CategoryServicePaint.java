package jp.co.nec.docmng.blackPaint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.blackPaint.entity.CategoryEntPaint;
import jp.co.nec.docmng.blackPaint.repository.CategoryMapPaint;


@Service
public class CategoryServicePaint {
	 @Autowired
	 private  CategoryMapPaint objCategoryMapper;
	 @Transactional
	 public List<CategoryEntPaint> findAll() {
	  // 全件
	  return objCategoryMapper.findAll();
	 } //findAll
} //PolicyInfoServicePaint
