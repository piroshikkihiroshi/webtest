/**
 * 名称：SaveProvMaskCnt.java
 * 機能名：保存画面のControlを行う。
 * 概要：保存画面のControlを行う。
 */

package jp.co.nec.docmng.blackPaint.controller;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.ResourceBundle;
import java.util.UUID;

import javax.servlet.ServletContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jp.co.nec.docmng.blackPaint.entity.DocumentInfoEntPaint;
import jp.co.nec.docmng.blackPaint.logic.HtmlToPdf.HtmlToPdfModel;
import jp.co.nec.docmng.blackPaint.logic.dirFile.DirCnt;
import jp.co.nec.docmng.blackPaint.logic.dirFile.FileCnt;
import jp.co.nec.docmng.blackPaint.logic.maskHtml.MaskHtmlModel;
import jp.co.nec.docmng.blackPaint.service.DocInfoService;


/**
 * 保存画面のControlを行う。
 */

@Controller
public class SaveProvMaskCnt {

	/**
	 * context サーブレットのRealPathを取得する
	 * objLog log出力に使用する
	 * PAGE_CLASS ページを判定するHTMLClass。ページをSplitするのに使用する
	 * ARR_HEAD ファイル名、フォルダ名を判定するために使用する
	 */
	@Autowired
	ServletContext context;
	@Autowired DocInfoService docInfoService;

    @Autowired
    private ResourceLoader resourceLoader;


	static Logger objLog = LoggerFactory.getLogger(SaveProvMaskCnt.class);

	static String PAGE_CLASS = "awdiv awpage"; //splitするページのHTMLClass
	static String[] ARR_HEAD = {"mask_","red_"}; //ファイル名、フォルダ名のヘッダー配列

	/**
	 * 保存画面初期表示メソッド
	 * 保存画面初期表示の処理をする。
	 * @param strTmpDir_i 黒塗り編集画面で処理したHTMLが格納されたTMPディレクトリ名。
	 * @param strRedHtml_i 黒塗り編集候補HTMLのouterHTML。
	 * @param strMaskHtml_i 黒塗り編集HTMLのouterHTML。
	 * @param strListJson_i 黒塗りリスト情報JSON。
	 * @param strTmpDir_i オリジナルwordファイル名。
	 * @throws Exception
	 */
	@PostMapping("/SaveProvMaskCnt")
	public synchronized String getblackPaintInfo(
//			@CookieValue(value = "strTmpDirName") String strTmpDir_i,
			@RequestParam("tmpDir") String strTmpDir_i,
			@RequestParam("strRedHtml") String strRedHtml_i,
			@RequestParam("strMaskHtml") String strMaskHtml_i,
			@RequestParam("listJson") String strListJson_i,
			@RequestParam("strFileName") String strFileName_i,
			@RequestParam("documentId") String documentId,
			@RequestParam("strFilePath") String strFilePath,
			@CookieValue(value = "user_id", required = false) String UserId,
			@CookieValue(value = "user_name", required = false) String UserName,
			Model model) throws Exception{

		if (UserId==null) UserId="";
		if (UserName==null) UserName="";

		if (!strListJson_i.equals("")) {
			objLog.info("json："+strListJson_i);
		} //if

		objLog.info("UserId:"+UserId);
		objLog.info("UserName:"+UserName);

		//モデル初期化
		FileCnt objFileCnt = new FileCnt();
		DirCnt objDirCls = new DirCnt();
		HtmlToPdfModel objPdfCls = new HtmlToPdfModel();
		MaskHtmlModel objHtmllCls = new MaskHtmlModel();

		objLog.info("作業フォルダ：" + strTmpDir_i);

		//メンバ変数初期化
		Document objDoc=null;
		String strBasePath =""; //黒塗り作成時の作業フォルダ
		String strHead=""; //ファイル名、フォルダ名のヘッダー
		String strFileOutDir=""; //PDF出力フォルダ
		String strHtmlDir=""; //黒塗り作成時HTMLに対するimg,css等が入っているフォルダ
		String strRealPath = context.getRealPath("/");
		String strOrgFileName = strFileName_i; //オリジナルwordファイル名
		String strRelativePath = ""; //iFrameに表示するための相対パス
		int intPages = 0; //PDFページ枚数
//		String strTmpUuid=""; //tempファイルタイムスタンプ
//		strTmpUuid=String.valueOf(System.currentTimeMillis());
		String strTmpUuid = UUID.randomUUID().toString() ;
		//拡張子無しファイル名取得
		String strFileWithoutExtension = objFileCnt.getNameWithoutExtension(strOrgFileName);

		int sizeRedPdf = 0; //黒塗り候補文書PDFのファイルサイズの合計
		int sizeMaskPdf = 0; //黒塗り文書PDFのファイルサイズの合計
		int sizeMaskListPdf = 0; //黒塗り文書リストPDFのファイルサイズ

		String strSizeRedPdf = ""; //黒塗り候補文書PDFのファイルサイズの合計
		String strSizeMaskPdf = ""; //黒塗り文書PDFのファイルサイズの合計
		String strSizeMaskListPdf = ""; //黒塗り文書リストPDFのファイルサイズ

		strBasePath=strRealPath + strTmpDir_i ;
		//黒塗りリスト(ファイルサイズ測る用)作成
        //******resources配下コピーしておく(controllerでないとできない)
		objLog.info("resouce配下dir作成");
        String strMakeAllDir = strRealPath + strTmpDir_i+"resources/static/css/blackPaint/";
        FileUtils.forceMkdir(new File(strMakeAllDir));
        strMakeAllDir = strRealPath + strTmpDir_i+"resources/templates/blackPaint";
        FileUtils.forceMkdir(new File(strMakeAllDir));

        strMakeAllDir = strRealPath + strTmpDir_i+"resources/static/css/images/";
        FileUtils.forceMkdir(new File(strMakeAllDir));

		String strResouceOutPath = strRealPath + strTmpDir_i+"resources";
		String strResoucePath = "/static/main/resources/";
		//デプロイ時にコピーできないため修正
		org.springframework.core.io.Resource resource =null;

//		String[] arrCopyCss = {"/templates/blackPaint/MaskListPrevTemplate.html","/static/css/blackPaint/common.css","/static/css/blackPaint/style.css","/static/css/blackPaint/03.list.css"
//				,"/static/css/images/l_file_node.gif","/static/css/images/l_file_word.gif","/static/css/images/logo_s.png"};
		String[] arrCopyCss = {"/templates/blackPaint/MaskListPrevTemplate.html","/static/css/blackPaint/common.css","/static/css/blackPaint/style.css","/static/css/blackPaint/03.list.css"
				,"/static/css/images/l_file_node.gif","/static/css/images/l_file_word.gif","/static/css/images/logo_s.png","/static/css/blackPaint/style.css","/static/css/blackPaint/mask.css"};

		for (int i = 0; i < arrCopyCss.length; i++) {
			synchronized (this) {
				String strCssPath = arrCopyCss[i];
				resource = resourceLoader.getResource("classpath:" + strCssPath);
				objLog.info(strCssPath +"存在判定：判定："+ resource.exists());
				InputStream objIs = resource.getInputStream();
				byte[] arrByte = null;
				arrByte = IOUtils.toByteArray(objIs);
				FileOutputStream objOutSr = null;
				objOutSr=new FileOutputStream(strBasePath + "resources" + strCssPath);
				objOutSr.write(arrByte);//出力（dataのbyte列をファイルに書き込む）
				objOutSr.close();//閉じる(fosを使ったファイル操作を終えた時に実行)
			} //synchronized
		} //for

		objLog.info("ファイル、イメージ配備完了");

		//DocumentIDでdocument_infoから情報を取得
		List<DocumentInfoEntPaint> listDoc=null;
		listDoc =docInfoService.selectDocInfo(Integer.parseInt(documentId));
		strFilePath = listDoc.get(0).getFilePath();

		String strListOutDir = strBasePath+strHead+"listAll/";
		String strListAllPath = objHtmllCls.makeBrackPaint("["+strListJson_i+"]",UserName,strListOutDir,strRealPath,strFileWithoutExtension,strFilePath,strOrgFileName);
		//pdf化 sizeの取得
		String strListAll="";
		String strListPdfPath="";
		String strChkHtml="";

		objLog.info("strListOutDir：" + strListOutDir);
		File maskListfile = null;
		FileInputStream maskListfis =null;
		Throwable objErr = null;

		//pdf出力失敗時に複数回試行する
		int intRetry = 3;
		int intAct=1;
		boolean blSuccess = false;

//		try {
			strListPdfPath =strListOutDir+"MaskListPrev.pdf";

			objLog.info("strListPdfPath：" + strListPdfPath);
			//pdf出力失敗時に複数回試行する
			intRetry = 3;
			intAct=1;
			blSuccess = false;

			//pdf出力失敗時に複数回試行する
			while (!blSuccess) {
				//試行回数を超えたらExceptionを投げる
				if ( (!blSuccess) && (intAct>intRetry)) {
					objLog.error("黒塗りリストPDF作成試行回数を超えてエラーが発生しました。" + intAct + "回目", objErr);
					throw new Exception(objErr);
				} //if
				objErr = objPdfCls.convertHtmlToPdf(strListAllPath,strListPdfPath);
				if (objErr!=null) {
					objLog.error("黒塗りリストPDF作成時化時エラー発生：(PDF作成時)" + intAct + "回目", objErr);
					Thread.sleep(1000);
				} else {
					blSuccess=true;
				} //if
				intAct++;

			} //while


			maskListfile = new File(strListPdfPath);
			sizeMaskListPdf += maskListfile.length();
			maskListfis = new FileInputStream(maskListfile);
//			maskListfis.close();
//			maskListfile=null;

//		} catch (Exception e) {
//			objLog.error("err message", e);
//			objLog.error("黒塗りリストPDF化時エラー発生：(PDF作成後)", e);
//		} finally {
			//maskListfis.close();
			//maskListfile=null;
			//GCを明示的によんでメモリ解放
			//System.gc();

			//NES修正箇所
			if (maskListfis != null) {
				maskListfis.close();
			} // if
			maskListfile=null;
			//GCを明示的によんでメモリ解放
			//System.gc();
			//NES修正箇所
//		} //try

		objLog.info("黒塗り・黒塗り候補PDF化処理開始");

		//黒塗り候補PDFの作成 黒塗りPDFの作成
		for (int intIndex = 0; intIndex < ARR_HEAD.length; intIndex++) {
			strHead=ARR_HEAD[intIndex];
			strBasePath=strRealPath + strTmpDir_i ;
			PrintWriter objPw=null;
			File objHtmlPath=null;
			File objTgtHtmlPath=null;
//			try {

				String strGetHtml = "";
				String strOutHtml = "";
				synchronized (this) {

					//出力フォルダ作成
					strFileOutDir=strBasePath+strHead+strTmpUuid+"split"+"/";
					Path objSrcPath = Paths.get(strBasePath);
					Path objTgtPath = Paths.get(strFileOutDir);
					Files.copy(objSrcPath, objTgtPath);

					//html群をコピー
					strHtmlDir=strBasePath+strFileWithoutExtension+"/";
					objHtmlPath = new File(strHtmlDir);
					objTgtHtmlPath = new File(strFileOutDir+strFileWithoutExtension);
					FileUtils.copyDirectory(objHtmlPath, objTgtHtmlPath);

					//動的templateを作成
					if (listDoc.get(0).getExtension().equals("txt")) {
						strOutHtml+="<!DOCTYPE html> <html> <head> <meta http-equiv='Content-Type' content='text/html; charset=utf-8' /> <title>";
						strOutHtml+=strFileWithoutExtension;
						strOutHtml+="</title> </head> <body>";
						strOutHtml+=" <link rel='stylesheet' type='text/css' href='";
						strOutHtml+="../resources/static/css/blackPaint/mask.css' media='all' /> </head> <body>";
					}else { //word

						strOutHtml+="<!DOCTYPE html> <html> <head> <meta http-equiv='Content-Type' content='text/html; charset=utf-8' /> <title>";
						strOutHtml+=strFileWithoutExtension;
						strOutHtml+="</title> <link rel='stylesheet' type='text/css' href='";
						strOutHtml+=strFileWithoutExtension;
						strOutHtml+="/styles.css' media='all' /> ";
						strOutHtml+=" <link rel='stylesheet' type='text/css' href='";
						strOutHtml+=strFileWithoutExtension;
						strOutHtml+="/mask.css' media='all' /> </head> <body>";

					} //if

					//PDF作成処理
					if(strHead.equals("mask_")) {
						strGetHtml = strMaskHtml_i;
					}else {
						strGetHtml = strRedHtml_i;
					} //if

				} //synchronized

				objDoc = Jsoup.parse(strGetHtml);
				Elements elmCls= objDoc.getElementsByClass(PAGE_CLASS);
				int intSize=elmCls.size();

//				for (int i = 0; i < elmCls.size(); i++) {
				for (int i = 0; i < intSize; i++) {

					//一度オブジェクトを開放してから処理を行う
					objDoc = Jsoup.parse(strGetHtml);
					elmCls= objDoc.getElementsByClass(PAGE_CLASS);

					String strOutPath ="";
					//html out
					objLog.info( strHead.substring(0,strHead.length()-1) + (i+1)+"枚目html出力開始");

					Element elmTgt = elmCls.get(i);
					//txtの場合フォントサイズを変更してhtmlとpdfの出力をあわせる
					if (listDoc.get(0).getExtension().equals("txt")) {
//							elmTgt.getElementsByClass("awdiv awpage").get(0).attr("style","awdiv awpage' style='word-break: break-all;padding:5px;font-size: 12px; line-height: 1.9; width:98%; text-align: justify; height:581pt;font-family: \"VL Gothic\";'>");
//							elmTgt.getElementsByClass("awdiv awpage").get(0).attr("style","awdiv awpage' style='word-break: break-all;padding:5px;font-size: 12px; line-height: 1.9; text-align: justify; width:595.3pt; height:841.9pt;font-family: \"VL Gothic\";'>");
						elmTgt.getElementsByClass("awdiv awpage").get(0).attr("style","awdiv awpage' style='word-break: break-all;padding:5px;font-size: 12px; line-height: 1.9; text-align: justify; width:580.3pt; height:841.9pt;font-family: \"VL Gothic\";'>");
					} //if
					String strGetOuterHtml = elmTgt.outerHtml();
					if (listDoc.get(0).getExtension().equals("txt")) {
						//jsopがspanに改行 スペースを加えるので除去
						strGetOuterHtml = strGetOuterHtml.replaceAll("(<span.*)\n", "$1");
						strGetOuterHtml = strGetOuterHtml.replace(" <span", "<span");
						strGetOuterHtml = strGetOuterHtml.replaceAll("\n", "");

					} //if

					strOutPath = strFileOutDir+strHead+ (i + 1) + ".html";
					//html out
					String strRepHtml=strOutHtml;
					strRepHtml+=strGetOuterHtml;
					strRepHtml+="</body> </html>";

					objPw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(
						       new FileOutputStream(strOutPath, true),"utf-8")));
					objPw.println(strRepHtml);
					objPw.close();

					//html end
					objLog.info( strHead.substring(0,strHead.length()-1)+ (i+1)+"枚目html出力完了");

					//pdfout
					objLog.info(strHead.substring(0,strHead.length()-1) + (i + 1) +"枚目pdf出力開始");
					String strOutPdfPath = strFileOutDir+strHead+ (i + 1) + ".pdf";

					//pdf出力失敗時に複数回試行する
					intRetry = 3;
					intAct=1;
					blSuccess = false;

					try {
						//pdf出力失敗時に複数回試行する
						while (!blSuccess) {
							//試行回数を超えたらExceptionを投げる
							if ( (!blSuccess) && (intAct>intRetry)) {
								objLog.error("PDF作成試行回数を超えてエラーが発生しました。" + intAct + "回目", objErr);
								throw new Exception(objErr);
							} //if
							objErr = objPdfCls.convertHtmlToPdf(strOutPath,strOutPdfPath);
							if (objErr!=null) {
								objLog.error("黒塗りPDF作成時化時エラー発生：(PDF作成時)" + intAct + "回目", objErr);
								Thread.sleep(1000);
							} else {
								blSuccess=true;
							} //if
							intAct++;

						} //while

						if(strHead.equals("mask_")) {
							File maskfile = new File(strOutPdfPath);
							sizeMaskPdf += maskfile.length();
							//FileInputStream maskfis = new FileInputStream(maskfile);
							//maskfis.close();
							//maskfile=null;

							//NES修正箇所
							// Todo: FileInputStreamを作成して即廃棄意味ある？
							//FileInputStream maskfis = new FileInputStream(maskfile);
							//maskfis.close();
							//maskfile=null;
							//NES修正箇所

						}else {
							File redfile = new File(strOutPdfPath);
							sizeRedPdf += redfile.length();
							//FileInputStream redfis = new FileInputStream(redfile);
							//redfis.close();
							//redfile=null;

							//NES修正箇所
							// Todo: FileInputStreamを作成して即廃棄意味ある？
							//FileInputStream redfis = new FileInputStream(redfile);
							//redfis.close();
							//redfile=null;
							//NES修正箇所

						} //if

						objLog.info(strHead.substring(0,strHead.length()-1) + (i + 1) +"枚目pdf出力完了");
					} catch (Exception e) {
						objLog.info("※※※※"+strHead.substring(0,strHead.length()-1) + (i + 1) +"枚目pdf出力時Errorが発生");
						throw new Exception(strHead.substring(0,strHead.length()-1) + (i + 1) +"枚目pdf出力時Errorが発生", e);
					} //try

					//GCを明示的によんでメモリ解放
					//NES修正箇所
					//System.gc();
					//NES修正箇所

				} //for

				//クライアントにわたす情報格納
				intPages = elmCls.size();
				strRelativePath="/"+strTmpDir_i+strHead+"split"+"/"+strHead;
				objLog.info(strHead.substring(0,strHead.length()-1)+ "のpdf出力処理すべて完了");

//			} catch (IOException e) {
//				objLog.error("err message", e);
//			} finally {
				objPw=null;
				objHtmlPath=null;
				objTgtHtmlPath=null;
				//GCを明示的によんでメモリ解放
				//NES修正箇所
				//System.gc();
				//NES修正箇所
//			} //try

		} //for

		//ファイルサイズを三桁区切りで表示
		strSizeRedPdf = String.format("%,d", sizeRedPdf/1000); //黒塗り候補文書PDFのファイルサイズの合計
		strSizeMaskPdf = String.format("%,d", sizeMaskPdf/1000); //黒塗り文書PDFのファイルサイズの合計
		strSizeMaskListPdf = String.format("%,d", sizeMaskListPdf/1000); //黒塗り文書リストPDFのファイルサイズ

		//格納情報(今回のPoCのみ
		ResourceBundle objRb = ResourceBundle.getBundle("config/procenter");
		String strSaveDir = objRb.getString("save_directory");


		model.addAttribute("strTmpDir", strTmpDir_i); //親作業directory
		model.addAttribute("strListJson", strListJson_i); //黒塗りリスト情報
		model.addAttribute("strFileName", strFileName_i); //オリジナルファイルネーム
		model.addAttribute("strTmpTimeStamp", strTmpUuid); //今回の作業derectory
		model.addAttribute("intPages",  String.valueOf(intPages)); //PDFページ数 documentId
		model.addAttribute("documentId", documentId); //親作業directory
		model.addAttribute("strFilePath", strFilePath); //オリジナルファイルパス


		model.addAttribute("sizeRedPdf",  strSizeRedPdf); //黒塗り候補文書PDFのファイルサイズの合計 (KB)
		model.addAttribute("sizeMaskPdf", strSizeMaskPdf); //黒塗り文書PDFのファイルサイズの合計 (KB)
		model.addAttribute("sizeMaskListPdf", strSizeMaskListPdf); //黒塗り文書リストPDFのファイルサイズ (KB)
		model.addAttribute("strSaveDir", strSaveDir);


	return "blackPaint/MaskProvSave";
} //getView1

	/**
	 * エラー画面遷移(黒塗り処理)
	 */
	@ExceptionHandler(Exception.class)
	public String handleException(
			Exception e,
			HttpServletRequest request,
			HttpServletResponse response,
			Model model
			){

		//GCを明示的によんでメモリ解放
		//NES修正箇所
		//System.gc();
		//NES修正箇所


		//モデル初期化
		DirCnt objDirCls = new DirCnt();
		Cookie cookie[] = request.getCookies();
		String strTmpDir_i = "";
		if (cookie != null){
			for (int i = 0 ; i < cookie.length ; i++){
				if (cookie[i].getName().equals("strTmpDirName")){
					strTmpDir_i = cookie[i].getValue();
				} //if
			} //for
		} //if

		//作業ディレクトリかたずけ
		if(strTmpDir_i.equals(""))  {
			objLog.info("作業ディレクトリの取得が失敗しました");
		}else {
			try {
				//作業ディレクトリ,ファイルかたづけ
				objDirCls.DelDirctory(context.getRealPath("/") + strTmpDir_i);
				objLog.info("作業ディレクトリ削除完了");
			} catch (Exception e1) {
				objLog.info("作業ディレクトリ削除失敗");
			} //try

		} //if


		response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		objLog.error("Error occurred.", e);
		StringWriter objSw = new StringWriter();
		PrintWriter objPw = new PrintWriter(objSw);
		e.printStackTrace(objPw);
		objPw.flush();
		String strError = objSw.toString();
		try {
			//objSw.close();
			//objPw.close();

			//NES修正箇所
			if (objSw != null) {
				objSw.close();
			}
			if (objPw != null) {
				objPw.close();
			}
			//NES修正箇所

		} catch (IOException e1) {

			//NES修正箇所
			objLog.error("objSw or objPw closing.：", e1);
			//NES修正箇所
			e1.printStackTrace();
		} //try

		model.addAttribute("errorMessage", e.getMessage() + "\r\n" + "StackTrace" + "\r\n" + strError) ;

		return "blackPaint/Fail";
	} //method

} //MaskHtmlCnt
