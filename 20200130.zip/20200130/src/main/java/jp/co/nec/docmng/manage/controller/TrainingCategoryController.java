/**
 * 名称：TrainingCategoryControllerファイル
 * 機能名：教師データ登録（分類）コントローラー
 * 概要：教師データ登録（分類）の制御を実施する
 */
package jp.co.nec.docmng.manage.controller;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import jp.co.nec.docmng.library.asposeToHtml.service.WordToHtml;
import jp.co.nec.docmng.manage.entity.CategoryInfo;
import jp.co.nec.docmng.manage.entity.CategoryInfoForm;
import jp.co.nec.docmng.manage.entity.CategoryInfoReflectForm;
import jp.co.nec.docmng.manage.entity.CategoryInfoReflectForm.AddValues;
import jp.co.nec.docmng.manage.entity.CategoryInfoReflectForm.ChangedValues;
import jp.co.nec.docmng.manage.entity.TmpTeacherCategoryList;
import jp.co.nec.docmng.manage.entity.TmpTeacherCategoryListReqForm;
import jp.co.nec.docmng.manage.service.CategoryInfoService;
import jp.co.nec.docmng.manage.service.TmpTeacherCategoryService;

/**
 * 教師データ（分類）のリクエストを制御する
 */
@Controller
@RequestMapping("/manage/training_category")
public class TrainingCategoryController {

    /** ロガー */
    private static Logger objLog = LoggerFactory.getLogger(TrainingCategoryController.class);

    @Autowired
    CategoryInfoService categoryInfoService;

    @Autowired
    TmpTeacherCategoryService tmpTeacherCategoryService;

    WordToHtml wordToHtml = new WordToHtml();

    /** その他カテゴリのcategoryId番号 */
    static Integer OTHER_ID = 0;

    /** 成功応答値 */
    static final String SUCCESS = "sucsess";
    /** 失敗応答値 */
    static final String ERROR = "error";

    /** Wordファイル拡張子 */
    static String[] TOHTML_EXTENSION_LIST = {".doc" , ".docx" , ".docm"};

    /** 作成されるHTMLの出力先 */
    static String STR_HTML_DIR_PATH = "src/main/resources/";

    /** 作成されるHTMLから取り出されるヘッダ文字列 */
    static String REPRACE_HTML = "Created with an evaluation copy of Aspose.Words. "
            + "To discover the full versions of our APIs please visit: "
            + "https://products.aspose.com/words/Evaluation Only. "
            + "Created with Aspose.Words. Copyright 2003-2019 Aspose Pty Ltd.";

    /** CSVファイルの出力先 */
    static String CSVFILE_PATH = "src/main/resources/";

    /** その他のカテゴリリスト */
    static Integer OTHER_CATEGORYID = 0;
    /** その他のカテゴリ名 */
    static String OTHER_CATEGORYNAME = "その他";
    /** その他のカテゴリリスト */
    static Integer OTHER_CATEGORYSORTID = 0;

    /**
     * <p>教師データ登録（分類）初期表示処理</p>
     * 処理内容：教師データ登録（分類）を表示用データを取得し表示する。
     * @param model 引渡しパラメータ用モデル
     * @return 教師データ登録（分類）画面URL
     */
    @GetMapping
    public String getTrainingCategory(Model model) {
        objLog.info("getTrainingCategory request start");

        // 分類一覧取得
        List<CategoryInfo> categoryInfos = categoryInfoService.findAll();

        // 教師データ分類一覧取得
        List<TmpTeacherCategoryList> teacherCategoryLists = tmpTeacherCategoryService.findAll();

        // 表示用に分類名を付与する
        for (int i = 0; i < teacherCategoryLists.size(); i++) {
            for (int j = 0; j < categoryInfos.size() ; j++) {
                if (categoryInfos.get(j).getCategoryId() == teacherCategoryLists.get(i).getCategoryId()) {
                    teacherCategoryLists.get(i).setCategoryName(categoryInfos.get(j).getCategoryName());
                    break;
                }
                teacherCategoryLists.get(i).setCategoryName("その他");
            }
        }

        // カテゴリ：その他を応答データには含めない
        if (!Objects.isNull(categoryInfos) && categoryInfos.size() != 0) {
            for (int i = 0; i < categoryInfos.size(); i++) {
                if (Objects.equals(categoryInfos.get(i).getCategoryId() , 0 )
                        && Objects.equals(categoryInfos.get(i).getCategoryName(), "その他")) {
                    categoryInfos.remove(i);
                }
            }
            // ポリシー一覧が取得できなかった場合
        }

        // レスポンス情報セット
        model.addAttribute("categoryInfo", categoryInfos);
        model.addAttribute("teacherCategoryList", teacherCategoryLists);
        objLog.trace("categoryInfos:{}", categoryInfos);
        objLog.trace("teacherCategoryLists:{}", teacherCategoryLists);
        objLog.info("getTrainingCategory request end (success)");
        return "manage/trainingCategory";
    }

    /**
     * <p>ファイル一覧取得メソッド</p>
     * 処理内容：リクエストのファイルパスからファイル一覧を取得し呼出し元へ返す
     * @param form ファイルパス
     * @return ファイル一覧
     * @throws Exception 想定外エラー
     */
    @PostMapping("/read_file")
    @ResponseBody
    public ArrayList<String> outputFile(@RequestBody CategoryInfoForm form) throws Exception {

        objLog.info("outputFile request start");
        // リクエストデータ存在チェック
        if (Objects.isNull(form)) {
            objLog.trace("form:{}", form);
            objLog.info("request data not found");
            objLog.info("teacherCategoryReflect request end (error)");
            return null;
        }

        objLog.info("form : {} ", form);

        String directoryPass = form.getDirectoryPass();

        //Fileクラスのオブジェクトを生成する
        File dir = new File(directoryPass);

        //listFilesメソッドを使用して一覧を取得する
        File[] dirList = dir.listFiles();

        //指定した拡張子のファイルを格納する
        ArrayList<String> fileList = new ArrayList<>();

        if(dirList != null) {
            for(int i=0; i<dirList.length; i++) {
                //ファイルの場合
                if(dirList[i].isFile()) {
                    System.out.println("ファイルです : " + dirList[i].toString());
                    fileList.add(dirList[i].toString());
                }
                //ディレクトリの場合
                else if(dirList[i].isDirectory()) {
                    System.out.println("ディレクトリです : " + dirList[i].toString());
                }
            }
        } else {
            System.out.println("指定した配下にはファイル、またはディレクトリが存在しません");
        }

        objLog.info("outputFile request end (success)");
        return fileList;
    }

    /**
     * <p>分類一覧更新メソッド</p>
     * 処理内容：
     * <ol>
     *   <li>画面上で削除した分類一覧と紐づくDBの項目を削除する。</li>
     *   <li>画面上で編集した分類一覧と紐づくDBの項目を更新する。</li>
     *   <li>画面上で追加した分類一覧と紐づくDBの項目を追加する。</li>
     * </ol>
     * @param form 追加・編集・削除した分類データ
     * @return ResponseEntity&lt;String&gt; 更新結果
     * @throws Exception 更新に失敗した場合
     */
    @PostMapping("/category_reflect")
    @ResponseBody
    public ResponseEntity<String> categoryReflect(@RequestBody CategoryInfoReflectForm form) throws Exception {

        objLog.info("categoryReflect request start");
        // 存在チェック
        if (Objects.isNull(form)) {
            objLog.trace("form:{}", form);
            objLog.info("request data not found");
            objLog.info("categoryReflect request end (error)");
            return null;
        }
        objLog.info("form : {} ", form);

        CategoryInfo categoryInfo = new CategoryInfo();
        System.out.println("設定反映ボタン");
        List<AddValues> addValues = form.getAddValues();
        List<ChangedValues> changeValues = form.getChangedValues();
        List<Integer> deleteRow = form.getDeleteRow();
        Timestamp sysdate = Timestamp.valueOf(LocalDateTime.now());

        try {
            // 追加データがある場合
            if (!Objects.isNull(addValues)) {
                for (AddValues value : addValues) {
                    // 更新データセット
                    categoryInfo.setCategoryAuthor(value.getCategoryAuthor());
                    categoryInfo.setCategoryName(value.getCategoryName());
                    categoryInfo.setCreateTime(sysdate);
                    categoryInfo.setUpdateTime(sysdate);
                    // 更新
                    categoryInfoService.insert(categoryInfo);
                }
            }

            // 編集データがある場合
            if (!Objects.isNull(changeValues)) {
                for (ChangedValues value : changeValues) {
                    // 更新データセット
                    categoryInfo.setCategoryId(value.getCategoryId());
                    categoryInfo.setCategoryName(value.getCategoryName());
                    categoryInfo.setUpdateTime(sysdate);
                    // 更新
                    categoryInfoService.update(categoryInfo);
                }
            }

            // 削除データがある場合
            if (!Objects.isNull(deleteRow)) {
                for (Integer value : deleteRow) {
                    List<TmpTeacherCategoryList> updateTmpTeacherCategoryList = tmpTeacherCategoryService.findCategoryId(value);
                    for (TmpTeacherCategoryList list : updateTmpTeacherCategoryList) {
                        System.out.println(list.getUserId());
                        System.out.println(list.getSortId());
                        System.out.println(list.getFilePath());
                        list.setCategoryId(OTHER_ID);
                        tmpTeacherCategoryService.updateCategoryId(list);
                    }
                    // 更新
                    categoryInfoService.delete(value);
                }
            }
        } catch (Exception e) {
            objLog.error("addValues:{}\r\nchangeValues:{}\r\ndeleteRow:{}", addValues, changeValues,deleteRow);
            objLog.error("error message", e);
            objLog.info("categoryReflect request end (error)");
            e.printStackTrace();
            return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
        }
        objLog.info("categoryReflect request end (success)");
        return new ResponseEntity<String>(HttpStatus.OK);
    }

    /**
     * <p>教師データ一覧更新メソッド</p>
     * 処理内容：
     * <ol>
     *   <li>画面上で削除した登録データ一覧と紐づくDBの項目を削除する。</li>
     *   <li>画面上で編集した分類一覧と紐づくDBの項目を更新する。</li>
     *   <li>画面上で追加した分類一覧と紐づくDBの項目を追加する。</li>
     * </ol>
     * @param form 追加・編集・削除した分類データ
     * @return ResponseEntity&lt;String&gt; 更新結果
     * @throws Exception 更新に失敗した場合
     */
    @PostMapping(value = "/teacher_category_reflect", produces="text/plain; charset=UTF-8")
    @ResponseBody
    public ResponseEntity<String> teacherCategoryReflect (@RequestBody TmpTeacherCategoryListReqForm form) throws Exception {

        objLog.info("teacherCategoryReflect request start");
        // 存在チェック
        if (Objects.isNull(form)) {
            objLog.trace("form:{}", form);
            objLog.info("request data not found");
            objLog.info("TeacherCategoryReflect request end (error)");
            return null;
        }
        objLog.info("form : {} ", form);

        List<TmpTeacherCategoryList> tmpTeacherCategoryList = form.getTmpTeacherCategoryList();
        String savePath = form.getSavePath();
        Timestamp sysdate = Timestamp.valueOf(LocalDateTime.now());
        File saveDrectory = new File(savePath);
        if (!saveDrectory.exists()) {
            String err = "保存先のフォルダ" + savePath + "は存在しません。";
            objLog.info("{} correct answer directoryPath path directory not found ", savePath);
            objLog.info("teacherCategoryReflect request end (error)");
            return new ResponseEntity<String>(err, HttpStatus.BAD_REQUEST);
        }

        List<String> csvDataList = new ArrayList<>();

        for (int cnt = 0 ; cnt < tmpTeacherCategoryList.size() ; cnt++) {
            TmpTeacherCategoryList list = tmpTeacherCategoryList.get(cnt);
            String filePath = list.getFilePath();
            File file = new File(filePath);
            if (!file.exists()) {
                String err = "指定のファイル" + filePath + "は存在しません。";
                objLog.info("{} file not found ", filePath);
                objLog.info("teacherCategoryReflect request end (error)");
                return new ResponseEntity<String>(err, HttpStatus.BAD_REQUEST);
            }
            System.out.println (STR_HTML_DIR_PATH);
            try {
                String csvData = createCsvData(file);
                csvDataList.add(cnt + "," + csvData + "," + list.getCategoryId());
            } catch (Exception e) {
                e.printStackTrace();
                String err = "CSVファイル作成中に失敗しました。";
                objLog.info("csv file creating error ");
                objLog.trace("csvDataList:{}", csvDataList);
                objLog.info("teacherCategoryReflect request end (error)");
                return new ResponseEntity<String>(err, HttpStatus.BAD_REQUEST);
            }
            System.out.println(csvDataList);
        }
        // CSVファイル作成
        try {
            // TODO:CSVファイル名
            String fileName = sysdate.toString().replace(":", "").replace("-", "").replace("/", "").replace(" ", "").replace(".", "") + ".csv";
            // CSVファイル作成
            Files.createFile(Paths.get(CSVFILE_PATH, fileName));
            // CSVファイル書込
            Files.write(Paths.get(CSVFILE_PATH, fileName), csvDataList,
                Charset.forName(StandardCharsets.UTF_8.toString()),
                StandardOpenOption.TRUNCATE_EXISTING);
            // 分類にその他が登録されているか確認
            List<CategoryInfo> categoryInfoOther = categoryInfoService.findOther(OTHER_CATEGORYID, OTHER_CATEGORYNAME);
            if (categoryInfoOther.size() == 0) {
                //分類にその他が無い場合0、その他をはじめに登録する
                CategoryInfo other = new CategoryInfo();
                other.setCategoryId(OTHER_CATEGORYID);
                other.setCategoryName(OTHER_CATEGORYNAME);
                other.setCategoryAuthor(form.getUserName());
                other.setCreateTime(sysdate);
                other.setUpdateTime(sysdate);
                categoryInfoService.insertOther(other);
            }
            // DB反映処理（全削除）
            tmpTeacherCategoryService.deleteAll();

            for (TmpTeacherCategoryList addlist : tmpTeacherCategoryList) {
                // DB反映処理（登録処理）
                tmpTeacherCategoryService.insert(addlist);
            }
        } catch (Exception e) {
            objLog.info("teacherCategoryReflect request end (error)");
            e.printStackTrace();
            return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
        }
        objLog.info("teacherCategoryReflect request end (success)");
        return new ResponseEntity<String>(HttpStatus.OK);
    }
    /**
     * <p>教師データ（分類）のCSVに登録する本文部分生成</p>
     * 処理内容：リクエストされた教師データファイルから本文を取り出す。
     * @param file 教師データファイル
     * @return CSVに登録する本文
     * @throws Exception 教師データから本文取り出しに失敗した場合
     */
    private String createCsvData(File file) throws Exception {
        objLog.trace("file:{}", file);

        String strDirPath = file.getAbsolutePath().replace(file.getName(), "");
        String strOrgFileName = file.getName();
        String strHtmlDirPath = STR_HTML_DIR_PATH;

        boolean officeFileFlag = false;
        String tmpWord = "";
        for (String ex : TOHTML_EXTENSION_LIST) {
            // Officceソフトの場合
            if (strOrgFileName.contains(ex)) {
                officeFileFlag = true;
            }
        }
        if (officeFileFlag) {
            try {
                tmpWord = wordToHtml.wordToHtml(strDirPath, strOrgFileName, strHtmlDirPath);
            }catch (Exception e) {
                objLog.error("strDirPath:{}\r\nstrDirPath:{}\r\nstrDirPath:{}", strDirPath, strOrgFileName, strHtmlDirPath);
                objLog.error("error message", e);
                e.printStackTrace();
                throw e;
            }
        } else {
            tmpWord = textReadFile(file);
        }
        return tmpWord;
    }

    /**
     * <p>テキストファイルから本文を抜き出す</p>
     * 処理内容：テキスト形式のファイルから本文をString形式で取り出し返す。
     * @param file 教師データ（分類）ファイル
     * @return 本文
     * @throws IOException
     */
    private String textReadFile(File file) throws IOException {
        objLog.trace("file:{}", file);
        StringBuffer output = new StringBuffer();
        FileSystem fs = FileSystems.getDefault();
        Path path = fs.getPath(file.getAbsolutePath());
        List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
        for (String text : lines) {
            output.append(text);
        }
        return output.toString();
    }
}
