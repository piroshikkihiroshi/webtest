/**
 * 名称：CategoryInfoForm.java
 * 機能名：
 * 概要：
 */


package jp.co.nec.docmng.manage.entity;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonInclude;

//@Data
/**
 *
 *@return
 */
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class CategoryInfoForm {
    public String getDirectoryPass() {
		return directoryPass;
	}


    /**
     *
     *@param directoryPass
     */
	public void setDirectoryPass(String directoryPass) {
		this.directoryPass = directoryPass;
	}
	@NotBlank(message = "必須項目です。")
    private String directoryPass;
}
