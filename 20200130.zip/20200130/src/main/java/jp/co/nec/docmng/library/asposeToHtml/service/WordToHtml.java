/**
 * 名称：WordToHtml.java
 * 機能名：
 * 概要：
 */


package jp.co.nec.docmng.library.asposeToHtml.service;

import jp.co.nec.docmng.library.asposeToHtml.repository.MaskHtmlMode;

/**
 * Hello world!
 *
 */
public class WordToHtml {
	public String wordToHtml(String strDirPath, String strOrgFileName, String strHtmlDirPath) throws Exception {

		MaskHtmlMode objMakeHtmlCls = new MaskHtmlMode();
		AsposeWordModel objAspCls = new AsposeWordModel();

		String strOuterHtml = ""; //asposeの出力したOuterHTML
		String strCompresHtml=""; //正規表現をかけるために圧縮したOuterHTML
		String strInnerText =""; //strInnerText

        //htmlを作成する。
        objAspCls.wordToHtml(strDirPath, strOrgFileName, strHtmlDirPath);

        String strHtmlName = strOrgFileName.replace(".doc", "").replace(".docx", "").replace(".docm", "") + ".html";

        //***innherHtmlを取得する
        strOuterHtml = objMakeHtmlCls.readAll(strHtmlDirPath + "\\" + strHtmlName);

		//圧縮されたBodyを取得
        strCompresHtml = objMakeHtmlCls.getBodyCompress(strOuterHtml);

		//全文検索エンジンに渡す用の文字列(innerText)を取得する
        strInnerText = objMakeHtmlCls.getIllegalText(strCompresHtml);

        return strInnerText;

	} //main

} //class
