/**
 * 名称：SearchServerInfoService.java
 * 機能名：
 * 概要：
 */


package jp.co.nec.docmng.manage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.manage.entity.SearchServerInfoEntity;
import jp.co.nec.docmng.manage.util.map.SearchServerInfoMapManage;

@Service
public class SearchServerInfoService {

    @Autowired
    private SearchServerInfoMapManage searchServerInfoMapper;

    @Transactional
    public SearchServerInfoEntity findOneService(String server_id_i) {
        // １件検索実行
        return searchServerInfoMapper.findOneMapper(server_id_i);
    }

    @Transactional
    public List<SearchServerInfoEntity> findAll(){
        List<SearchServerInfoEntity> entityList = searchServerInfoMapper.findAll();
        return entityList;
    }

    @Transactional
    public List<Integer> selectServerId(){
        List<Integer> serverIdList = searchServerInfoMapper.selectServerId();
        return serverIdList;
    }

    @Transactional
    public void insert(SearchServerInfoEntity searchServerInfo) {
        searchServerInfoMapper.insert(searchServerInfo);
    }

    @Transactional
    public void update(SearchServerInfoEntity searchServerInfo) {
        searchServerInfoMapper.update(searchServerInfo);
    }

    @Transactional
    public void deleteById(Integer id){
        searchServerInfoMapper.deleteById(id);
    }

}
