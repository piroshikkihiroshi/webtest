/**
 * 名称：AsposeWordModel.java
 * 機能名：
 * 概要：
 */


package jp.co.nec.docmng.library.asposeToHtml.service;

import com.aspose.words.Document;
import com.aspose.words.HtmlFixedPageHorizontalAlignment;
import com.aspose.words.HtmlFixedSaveOptions;

/**
 * AsposeライブラリのWordを操作するクラス
 * @author uedatats
 *
 */
public class AsposeWordModel {

	static String PAGE_CLS = "awpage";

	/**
	 * strDilPath_iのパスにstrOrgFileNameからhtmlを作成する
	 * @param strDirPath
	 * @param strOrgFileName
	 * @param strHtmlName
	 * @return ページカウント
	 * @throws Exception
	 */
	protected int wordToHtml(String strDirPath, String strOrgFileName, String strHtmlDirPath) throws Exception {
		// 変換対象のファイルの読み込み
		Document objDoc;
		int intPageCnt = 0;
		String strHtmlName = "";

		// ASPOSEのライセンスの設定
//		com.aspose.words.License license = new com.aspose.words.License();
//		license.setLicense(new java.io.FileInputStream("C:/user/aspose.Total.Java.lic"));

		// 保存するHTMLファイルの追加オプションの設定(HTMLの枠組みの作成)
		HtmlFixedSaveOptions htmlFixedSaveOptions = new HtmlFixedSaveOptions();
		htmlFixedSaveOptions.setPageHorizontalAlignment(HtmlFixedPageHorizontalAlignment.CENTER);

		objDoc = new Document(strDirPath + "\\" + strOrgFileName);
		intPageCnt = objDoc.getPageCount() - 1;

		strHtmlName = strOrgFileName.replace(".doc", "").replace(".docx", "").replace(".docm", "") + ".html";

		objDoc.save(strHtmlDirPath + "\\" + strHtmlName, htmlFixedSaveOptions);

		return intPageCnt;
	} //wordToHtml

} //class
