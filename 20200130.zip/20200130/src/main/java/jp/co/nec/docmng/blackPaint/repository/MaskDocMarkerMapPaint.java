/**
 * 名称：MaskDocMarkerMapPaint.java
 * 機能名：黒塗り処理黒塗り文書黒塗り箇所保存情報連携
 * 概要：黒塗り処理にて使用する黒塗り文書黒塗り箇所保存情報への連携用レポジトリ
 */

package jp.co.nec.docmng.blackPaint.repository;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import jp.co.nec.docmng.blackPaint.entity.MaskDocMarkerEntBlackPaint;

/**
 * 黒塗り処理黒塗り文書黒塗り箇所保存情報連携
 */
@Mapper
public interface MaskDocMarkerMapPaint {

	/**
	 * データ登録処理
	 * @param objEnt 登録内容を格納したentity
	 */
    @Insert("INSERT INTO common.mask_document_marker(document_id,  marker_start_cd, marker_end_cd, marker_policy, marker_remarks, create_time) VALUES ( #{document_id}, #{marker_start_cd}, #{marker_end_cd}, #{marker_policy}, #{marker_remarks}, #{create_time})")
    public void insertMaskDocMarker(MaskDocMarkerEntBlackPaint objEnt);

	/**
	 * ドキュメントID指定による取得
	 * @param document_id 取得条件となるドキュメントID
	 * @return 取得したデータのリスト
	 */
    @Select("SELECT marker_id, document_id, marker_start_cd, marker_end_cd, marker_policy, marker_remarks, create_time, update_time FROM common.mask_document_marker WHERE document_id = #{document_id} ORDER BY marker_id")
    public List<MaskDocMarkerEntBlackPaint> selectMaskDocMarker(Integer document_id);

	/**
	 * ドキュメントID指定による削除処理
	 * @param document_id 削除条件となるドキュメントID
	 */
    @Delete("DELETE FROM common.mask_document_marker WHERE document_id = #{document_id}")
    public void deleteMarkerDoc(Integer document_id);

	/**
	 * 黒塗り箇所ポリシーの更新処理
	 * @param objEnt2 更新条件を格納したentity
	 */
    @Update("UPDATE common.mask_document_marker set marker_policy = #{marker_policy} WHERE document_id = #{document_id}")
    public void updateMarkerDoc(MaskDocMarkerEntBlackPaint objEnt2);

	/**
	 * 黒塗り箇所ポリシーID指定による取得
	 * @param marker_policy 取得条件となる黒塗り箇所ポリシーID
	 * @return 取得したデータのリスト
	 */
    @Select("SELECT marker_id, document_id, marker_start_cd, marker_end_cd, marker_policy, marker_remarks, create_time, update_time FROM common.mask_document_marker WHERE marker_policy = #{marker_policy} ORDER BY marker_id")
    public  List<MaskDocMarkerEntBlackPaint> findMakerPolicyId(Integer marker_policy);

} //interface
