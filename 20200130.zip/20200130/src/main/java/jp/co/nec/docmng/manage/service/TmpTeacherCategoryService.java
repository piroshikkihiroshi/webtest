/**
 * ���́FTmpTeacherCategoryService.java
 * �@�\���F
 * �T�v�F
 */


package jp.co.nec.docmng.manage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.manage.entity.TmpTeacherCategoryList;
import jp.co.nec.docmng.manage.util.map.TmpTeacherCategoryListMapManage;

@Service
public class TmpTeacherCategoryService {

    @Autowired
    private TmpTeacherCategoryListMapManage tmpTeacherCategoryListMapper;

    @Transactional
    public List<TmpTeacherCategoryList> findAll(){
        List<TmpTeacherCategoryList> entityList = tmpTeacherCategoryListMapper.findAll();
        return entityList;
    }

    @Transactional
    public List<TmpTeacherCategoryList> findCategoryId(Integer categoryId){
        List<TmpTeacherCategoryList> entityList = tmpTeacherCategoryListMapper.findCategoryId(categoryId);
        return entityList;
    }

    @Transactional
    public void updateCategoryId(TmpTeacherCategoryList tmpTeacherCategoryList){
        tmpTeacherCategoryListMapper.updateCategoryId(tmpTeacherCategoryList);
    }

    @Transactional
    public void insert(TmpTeacherCategoryList tmpTeacherCategoryList) {
        tmpTeacherCategoryListMapper.insertReflect(tmpTeacherCategoryList);
    }

    @Transactional
    public void deleteAll() {
        tmpTeacherCategoryListMapper.deleteAll();
    }

}
