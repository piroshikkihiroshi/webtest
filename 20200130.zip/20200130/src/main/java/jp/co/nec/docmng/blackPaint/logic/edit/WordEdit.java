/**
 * 名称：WordEdit.java
 * 機能名：
 * 概要：
 */


package jp.co.nec.docmng.blackPaint.logic.edit;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletContext;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.zeroturnaround.zip.ZipUtil;

import jp.co.nec.docmng.blackPaint.controller.MaskHtmlCnt;
import jp.co.nec.docmng.blackPaint.entity.DocumentInfoEntPaint;
import jp.co.nec.docmng.blackPaint.logic.Aspose.AsposeWordModel;
import jp.co.nec.docmng.blackPaint.logic.dirFile.DirCnt;
import jp.co.nec.docmng.blackPaint.logic.dirFile.FileCnt;
import jp.co.nec.docmng.blackPaint.logic.maskHtml.HtmlStructure;
import jp.co.nec.docmng.blackPaint.logic.maskHtml.MaskHtmlModel;
import jp.co.nec.docmng.blackPaint.service.DocInfoServicePaint;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocMarkerServicePaint;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocumentServicePaint;
import jp.co.nec.docmng.library.blackprintextract.entity.BlackPrintPlace;
import jp.co.nec.docmng.library.blackprintextract.service.BlackPrintExtract;

public class WordEdit {
    static Logger objLog = LoggerFactory.getLogger(MaskHtmlCnt.class);

    @Autowired
    ServletContext context;
    @Autowired
    DocInfoServicePaint docInfoService;

    @Autowired
    TmpMaskDocMarkerServicePaint tmpMaskDocTmpMarkerService;

    @Autowired
    TmpMaskDocumentServicePaint tmpMaskDocumentService;

    HashMap<String, String> hashMap = new HashMap<String, String>();

    /**
     * 黒塗り文書作成画面初期表示メソッド
     * 画面初期表示の処理をする。
     * @param documentId 文書を一意に特定するID
     * @param status 空文字: 初期処理 1: 再開 2: 黒塗りリスト確定
     * @param blackPaintListJson 空文字: 初期処理、再開 値あり：備考のjson
     * @param listDoc
     * @param strTmpDir
     * @param resourceLoader
     * @return
     */
    public HashMap<String,String> wordEditMain(
            List<DocumentInfoEntPaint> listDoc,
            String strTmpDir,
            ResourceLoader resourceLoader,
            String status //空文字: 初期処理 1: 再開 2: 黒塗りリスト確定

            ) {

        int documentId = listDoc.get(0).getDocumentId();


        String aiData = ""; //aiが返すデータ

        String strHeight = "785"; //word A4の時 他は未考慮
//        int insPageLen = 1942; //txtのページの長さ(1行54文字、36行想定)-2
		int insPageLen = 1888; //txtのページの長さ(1行54文字、35行想定)-2 //マスク箇所のbadge対応の為marginをいれ1行減らした

        FileCnt objFileCnt = new FileCnt();
        AsposeWordModel objAspCls = new AsposeWordModel();
        MaskHtmlModel  objMaskCls = new MaskHtmlModel();
        DirCnt objDirCls = new DirCnt();



        String strHtmlName = documentId + ".html"; //作成html名
        String strHtmlPath = strTmpDir + documentId + ".html"; //作成htmlパス

        String strStyle = ""; //CSSを作成する
        strStyle+="<style>";
        strStyle+=".tagRed{";
        strStyle+="    color: rgb(233, 84, 84);";
        strStyle+="    display: inline-grid;";
        strStyle+="    overflow: hidden;";
//        strStyle+="    background-color: #ffff7b;";
        strStyle+="}";
        strStyle+=".tagRng{";
        strStyle+="    color: rgb(233, 87, 51);";
        strStyle+="    background-color: rgba(159, 192, 230, 0.884);";
        strStyle+="}";
        strStyle+=".tagMsk{";
        strStyle+="    color: black;";
        strStyle+="    display: inline-grid;";
        strStyle+="    overflow: hidden;";

//            strStyle+="    font-size: 10.5pt;";
            strStyle+="    background-color: black;";


        strStyle+="}";
        strStyle+=".awpage {";
        strStyle+="    position: relative;";
        strStyle+="    border: none;";
        strStyle+="    margin: 0px;";
        strStyle+="}";
        strStyle+=".redimg{";
        strStyle+="    -webkit-filter: sepia(100%)  hue-rotate(300deg); ";
        strStyle+="    -moz-filter: sepia(100%)  hue-rotate(300deg);";
        strStyle+="    -o-filter: sepia(100%)  hue-rotate(300deg);";
        strStyle+="    -ms-filter: sepia(100%)  hue-rotate(300deg);";
        strStyle+="    filter: sepia(100%)  hue-rotate(300deg);";

        strStyle+="}";

        //badge対応
        strStyle+=".redNumber {";
        strStyle+="	   position: absolute;";
        strStyle+="	   z-index: 1000;";
        strStyle+="	   padding: 5px;";
        strStyle+="    font-size: 10.5px;";
        strStyle+="	   background-color: #fff;";
        strStyle+="	   background-clip: padding-box;";
        strStyle+="	   border: 1px solid rgba(0,0,0,.2);";
        strStyle+="	   border-radius: 10rem;";

        strStyle+="    font-family: \"VL Gothic\";";
        strStyle+="    color: black;";
        strStyle+="    font-style: normal;";
        strStyle+="}";
        strStyle+=" .redNumber:hover {";
        strStyle+="    opacity: 0.0;";
        strStyle+="}";
        strStyle+=" .redHidden {";
        strStyle+="  visibility: hidden;";
        strStyle+="}";
        strStyle+=".mskNumber {";
        strStyle+="	    display: none;";
        strStyle+="}";


        strStyle+="</style>";

        FileWriter objFile=null;
        String[] arrMask=null;
        String[] arrRed=null;

        //全文検索モックデータ コロン区切りでペアは+区切り intpos,そこからつづく,intpos,そこからつづく
        String strTestData = aiData;
        String strAllHtml = "";
        String strOrgBody = "";
        String strNotTagBody = "";
        String strRepBody = "";
        String strMaskHtml= "";
        String strRedHtml = "";
        int intPageCnt = 0;

        String strOrgFilePath = listDoc.get(0).getDocumentName();
        //一度RealPathへファイルをコピーする
        String strFileName = strOrgFilePath.substring(strOrgFilePath.lastIndexOf("\\") + 1,strOrgFilePath.length());
        String strFileWithoutExtension = objFileCnt.getNameWithoutExtension(strFileName);


        objLog.info("txt処理開始");
        try {
            byte[] arrHtmlZip=null;
            arrHtmlZip = listDoc.get(0).getHtmlZipData();
            //file出力
            //出力フォルダ作成
            String strFileOutDir=strTmpDir;
            String strZipPath = strFileOutDir + "mask.zip";

            Path objZipPath = Paths.get(strZipPath);


            try {

                objDirCls.makeDirWithCheck(strFileOutDir);
                //zipファイル出力
                Files.write(objZipPath, arrHtmlZip);
                //unzipする
                ZipUtil.unpack(new File(strZipPath), new File(strFileOutDir));

                //作業ファイルかたづけ
                File fileZip = new File(strZipPath);
                fileZip.delete();



                // 20200115　ファイル名をdocumentIdに変更した対応
            //変更前ファイル名
             File bfFile = new File(strFileOutDir+strFileWithoutExtension+".html");
             //変更後のファイル名
             File afFile = new File(strFileOutDir+documentId+".html");
             bfFile.renameTo(afFile);

            //変更前ファイル名
             File bfDir = new File(strFileOutDir+"/"+strFileWithoutExtension);
             //変更後のファイル名
             File afDir = new File(strFileOutDir+"/"+documentId);
             bfDir.renameTo(afDir);

                objLog.info("HTML群取得完了");

            } catch (IOException e1) {
                objLog.error( "err message", e1 );
                e1.printStackTrace();


            } //try
        }catch (Exception e) {
                objLog.error( "err message", e );
                e.printStackTrace();
            } //try

            try {
                //tmpDir作成
                //対象HTMLを取得する
                strAllHtml = objMaskCls.readAll(strHtmlPath);

                // 20200115　ファイル名をdocumentIdに変更した対応
                strAllHtml = strAllHtml.replace("href=\""+strFileWithoutExtension+"/", "href=\""+documentId+"/");
                strAllHtml = strAllHtml.replace("src=\""+strFileWithoutExtension+"/", "src=\""+documentId+"/");
                //20200128 //svg用追加
                strAllHtml = strAllHtml.replace("data=\""+strFileWithoutExtension+"/", "data=\""+documentId+"/");

                //圧縮されたBodyを取得
//				strOrgBody = objMaskCls.getBodyCompress(strAllHtml);

                //全文検索エンジンに渡す用の文字列を取得する
//				strNotTagBody=listDoc.get(0).getDocumentContents();

//				※※※※※※※検索エンジンに送ったと想定※※※※※※※

                //AIdata スタブ
                BlackPrintExtract objAiCls  = new BlackPrintExtract();
//				if (status.equals("")) { //初期処理時のみ
                    //aiDatalist
                    List<BlackPrintPlace> listAi = null;
                    try {
                        listAi = objAiCls.extractBlackPrintPlace(documentId);
                        BlackPrintPlace tmpPrintPlace = null;
                        aiData = "";
                        for (int i = 0; i < listAi.size(); i++) {
                            tmpPrintPlace = listAi.get(i);
                            aiData+=tmpPrintPlace.start + ":" + tmpPrintPlace.end + ":" + tmpPrintPlace.policyID + "+";
                        } //for
                        aiData = aiData.substring(0,aiData.length()-1);
                    } catch (Exception e2) {
                        aiData="";
                        objLog.info("AIデータ取得処理でエラーが発生したため、取得したHTMLをそのまま表示");
                        objLog.error( "err message", e2 );
                        e2.printStackTrace();
                    } //try
//				} //if

                if(aiData==null) {
                    aiData="";
                } //if

                //debug
//				aiData="206:230:1";
//				aiData="106:192:1+238:242:1";
//				aiData="106:192:1+238:239:1+240:242:1";
                //spring boot
//				aiData="106:193:2+241:249:2+357:383:2+420:424:2+530:3051:2+3160:3197:2+3387:3393:2+3575:3589:2+4074:4128:2+4130:4139:2+4176:4181:2+4183:4189:2+4243:4249:2+4364:4373:2+4567:4604:2+4944:4953:2+5160:5201:2+5425:5470:2+5499:5508:2+5667:5714:2+5897:6038:2";

                objLog.info("aiData="+aiData);

                if(!aiData.equals("")) {

                    //全文検索から戻ってきた値をhashへ成型
                    HashMap<Integer, String> hashRepPos = objMaskCls.makePosHash(aiData);
                    objMaskCls.makePosHash(aiData);

                    objLog.info("makePosHash完了");

                    //bodyの構造体hashを取得
//					HashMap<Integer, HtmlStructure> hashBodyStructure = objMaskCls.getBodyStructure(strOrgBody);
                    HashMap<Integer, HtmlStructure> hashBodyStructure = objMaskCls.getBodyStructure(strAllHtml);

                    //全文検索エンジンに返した結果を置換してbodyを入れ替えた文字列を取得(黒塗り)
                    arrMask=objMaskCls.bodyReplace(hashRepPos, hashBodyStructure,1);
                    strRepBody = arrMask[0];


                    //htmlのbodyの中身を入れ替え、置換HTMLを作成する
//					strMaskHtml = objMaskCls.makeBody(strAllHtml,strRepBody);
                    strMaskHtml = strRepBody;

                    //スタイルシートPath埋め込み
                    strMaskHtml = objMaskCls.insertStyle(strMaskHtml,strStyle);

                    //全文検索エンジンに返した結果を置換してbodyを入れ替えた文字列を取得(赤文字)
                    arrRed=objMaskCls.bodyReplace(hashRepPos, hashBodyStructure,2);
                    strRepBody=arrRed[0];
                    //htmlのbodyの中身を入れ替え、置換HTMLを作成する
//					strRedHtml = objMaskCls.makeBody(strAllHtml,strRepBody);
                    strRedHtml = strRepBody;

                    //スタイルシートPath埋め込み
                    strRedHtml = objMaskCls.insertStyle(strRedHtml,strStyle);
                }else { //aidataなし
                    objLog.info("aiDataが無いため、サーバでの黒塗り処理は行いません。");
                    strMaskHtml=strAllHtml;
                    strRedHtml=strAllHtml;
                    //スタイルシートPath埋め込み
                    strMaskHtml = objMaskCls.insertStyle(strMaskHtml,strStyle);
                    //スタイルシートPath埋め込み
                    strRedHtml = objMaskCls.insertStyle(strRedHtml,strStyle);
                } //if

                synchronized (this) {
                    //css,黒塗り画像ファイル配備 ※deploy時にエラーになるためresourceLoaderで取得
                    String strCssPath = "/static/css/blackPaint/mask.css";
                    String strImgPath = "/static/css/images/m";
                    //deploy後に動かないので修正
                    objLog.info("ファイル、イメージ配備開始");
                    Resource resource =null;
                    resource = resourceLoader.getResource("classpath:" + strCssPath);
                    objLog.info(strCssPath +"存在判定："+ resource.exists());

                    InputStream objIs = resource.getInputStream();
                    byte[] arrByte = null;
    //				arrByte=objIs.readAllBytes();
                    arrByte = IOUtils.toByteArray(objIs);
                    FileOutputStream objOutSr = null;
                    objOutSr=new FileOutputStream(strTmpDir + "/" + documentId+ "/mask.css");
                    objOutSr.write(arrByte);//出力（dataのbyte列をファイルに書き込む）
                    objOutSr.close();//閉じる(fosを使ったファイル操作を終えた時に実行)

                    resource = resourceLoader.getResource("classpath:" + strImgPath);
                    objLog.info(strCssPath +"存在判定："+ resource.exists());
                    objIs = resource.getInputStream();
                    arrByte = IOUtils.toByteArray(objIs);

                    objOutSr=new FileOutputStream(strTmpDir + "/" + documentId+ "/m");

                    objOutSr.write(arrByte);//出力（dataのbyte列をファイルに書き込む）
                    objOutSr.close();//閉じる(fosを使ったファイル操作を終えた時に実行)


    //				FileUtils.copyFile(resource.getFile(), objTgtImgFile);
                    objLog.info("ファイル、イメージ配備完了");

                    String strMaskOutPath = strTmpDir + "mask_" + strHtmlName;
                    String strRedOutPath = strTmpDir + "red_" + strHtmlName;

                    objLog.info("html出力開始");
                    //htmlを出力する(黒塗り)
                    if (objFileCnt.writeFile(strMaskOutPath, strMaskHtml)) {
                        objLog.info("maskHTML完了");
                    } else {
                        objLog.error("maskHTML生成失敗");
                    }
                    //htmlを出力する(赤文字)
                    if (objFileCnt.writeFile(strRedOutPath, strRedHtml)) {
                        objLog.info("赤文字HTML完了");
                    } else {
                        objLog.error("赤文字HTML生成失敗");
                    }
                } //synchronized

                synchronized (this) {
                    //ページカウント取得
                    intPageCnt = objAspCls.aspPageGet(strMaskHtml);
                    hashMap.put("strPageCnt", intPageCnt+"");
                } //synchronized

            } catch (Exception e) {
                objLog.error("err message", e);
                e.printStackTrace();
            } //try


        return hashMap;





    } // method

} // class
