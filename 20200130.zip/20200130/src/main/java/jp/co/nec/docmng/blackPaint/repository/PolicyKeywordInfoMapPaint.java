/**
 * 名称：PolicyKeywordInfoMapPaint.java
 * 機能名：黒塗り処理黒塗りポリシーキーワード情報連携
 * 概要：黒塗り処理にて使用する黒塗りポリシーキーワード情報への連携用レポジトリ
 */

package jp.co.nec.docmng.blackPaint.repository;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

import jp.co.nec.docmng.blackPaint.entity.PolicyKeywordInfoBlackPaint;

/**
 * 黒塗り処理黒塗りポリシーキーワード情報連携
 */
@Mapper
public interface PolicyKeywordInfoMapPaint {

	/**
	 * データ登録処理
	 * @param objEnt 登録内容を格納したentity
	 */
	@Insert("INSERT INTO admin.policy_keyword_info( policy_id, policy_keyword, create_time, update_time) VALUES ( #{policy_id}, #{policy_keyword}, #{create_time}, #{update_time})")
    public void insertPolicyKeyword(PolicyKeywordInfoBlackPaint objEnt);

} //interface
