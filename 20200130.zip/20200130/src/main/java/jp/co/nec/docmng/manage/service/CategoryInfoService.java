/**
 * ���́FCategoryInfoService.java
 * �@�\���F
 * �T�v�F
 */


package jp.co.nec.docmng.manage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.manage.entity.CategoryInfo;
import jp.co.nec.docmng.manage.util.map.CategoryInfoMapManage;

@Service
public class CategoryInfoService {

    @Autowired
    private CategoryInfoMapManage categoryInfoMapper;

    @Transactional
    public List<CategoryInfo> findAll(){
        List<CategoryInfo> entityList = categoryInfoMapper.findAll();
        return entityList;
    }

    @Transactional
    public List<CategoryInfo> findOther(Integer categoryId, String categoryName){
        List<CategoryInfo> entityList = categoryInfoMapper.findOther(categoryId, categoryName);
        return entityList;
    }

    @Transactional
    public void insert(CategoryInfo categoryInfo) {
        categoryInfoMapper.insertCategoryList(categoryInfo);
    }

    @Transactional
    public void insertOther(CategoryInfo categoryInfo) {
        categoryInfoMapper.insertOther(categoryInfo);
    }

    @Transactional
    public void delete(Integer deleteRow) {
        categoryInfoMapper.deleteCategoryList(deleteRow);
    }

    @Transactional
    public void update(CategoryInfo categoryInfo) {
        categoryInfoMapper.updateCategoryList(categoryInfo);

    }
}
