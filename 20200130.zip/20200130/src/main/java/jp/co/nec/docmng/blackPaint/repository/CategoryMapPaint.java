/**
 * 名称：CategoryMapPaint.java
 * 機能名：黒塗り処理カテゴリー情報連携
 * 概要：黒塗り処理にて使用するカテゴリー情報への連携用レポジトリ
 */

package jp.co.nec.docmng.blackPaint.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import jp.co.nec.docmng.blackPaint.entity.CategoryEntPaint;

/**
 * 黒塗り処理カテゴリー情報連携
 */
@Mapper
public interface CategoryMapPaint {

	/**
	 * 全件取得
	 */
    @Select("select * from admin.category_info order by category_id")
    List<CategoryEntPaint> findAll();

} //PolicyInfoMapper
