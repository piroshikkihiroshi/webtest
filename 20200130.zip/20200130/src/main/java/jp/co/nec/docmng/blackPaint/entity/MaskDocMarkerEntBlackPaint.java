/**
 * 名称：MaskDocMarkerEntBlackPaint.java
 * 機能名：黒塗り処理黒塗り文書黒塗り箇所保存情報entity
 * 概要：黒塗り処理で使用する黒塗り文書黒塗り箇所保存情報entity
 */

package jp.co.nec.docmng.blackPaint.entity;
import java.sql.Timestamp;

/**
 * 黒塗り処理黒塗り文書黒塗り箇所保存情報entity
 */
public class MaskDocMarkerEntBlackPaint {

	public Integer getDocumentId() {
		return document_id;
	}
	public void setDocumentId(Integer document_id) {
		this.document_id = document_id;
	}
	public String getMarkerStartCd() {
		return marker_start_cd;
	}
	public void setMarkerStartCd(String marker_start_cd) {
		this.marker_start_cd = marker_start_cd;
	}
	public String getMarkerEndCd() {
		return marker_end_cd;
	}
	public void setMarkerEndCd(String marker_end_cd) {
		this.marker_end_cd = marker_end_cd;
	}
	public Integer getMarkerPolicy() {
		return marker_policy;
	}
	public void setMarkerPolicy(Integer marker_policy) {
		this.marker_policy = marker_policy;
	}
	public String getMarkerRemarks() {
		return marker_remarks;
	}
	public void setMarkerRemarks(String marker_remarks) {
		this.marker_remarks = marker_remarks;
	}
	public Timestamp getCreateTime() {
		return create_time;
	}
	public void setCreateTime(Timestamp create_time) {
		this.create_time = create_time;
	}
	public Timestamp getUpdateTime() {
		return update_time;
	}
	public void setUpdateTime(Timestamp update_time) {
		this.update_time = update_time;
	}

	/**
	 * 文書ID
	 */
	private Integer document_id;

	/**
	 * 黒塗り先頭コード
	 */
	private String marker_start_cd;

	/**
	 * 黒塗り終了コード
	 */
	private String marker_end_cd;

	/**
	 * 黒塗り箇所ポリシーID
	 */
	private Integer marker_policy;

	/**
	 * 黒塗り箇所備考
	 */
	private String marker_remarks;

	/**
	 * 作成日時
	 */
	private Timestamp create_time;

	/**
	 * 更新日時
	 */
	private Timestamp update_time;

}
