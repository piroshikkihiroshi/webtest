/**
 * 名称：PolicyInfoControllerファイル
 * 機能名：黒塗りポリシー設定画面コントローラー
 * 概要：黒塗りポリシー設定画面の制御を実施する
 */
package jp.co.nec.docmng.manage.controller;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

//import jp.co.nec.docmng.blackPaint.service.MaskDocMarkerService;
//import jp.co.nec.docmng.blackPaint.service.TmpMaskDocTmpMarkerService;
import jp.co.nec.docmng.manage.entity.PolicyInfoEntity;
import jp.co.nec.docmng.manage.entity.PolicyInfoReflectForm;
import jp.co.nec.docmng.manage.entity.PolicyInfoReflectForm.AddValues;
import jp.co.nec.docmng.manage.entity.PolicyInfoReflectForm.ChangedValues;
import jp.co.nec.docmng.manage.entity.PolicyKeywordInfo;
import jp.co.nec.docmng.manage.entity.TmpTeacherPolicyList;
import jp.co.nec.docmng.manage.service.PolicyInfoService;
import jp.co.nec.docmng.manage.service.PolicyKeywordInfoService;
import jp.co.nec.docmng.manage.service.TmpTeacherPolicyService;

/**
 * 黒塗りポリシー設定画面のリクエストを制御する
 */
@Controller
@RequestMapping("/manage/policy")
public class PolicyInfoController {

    /** ロガー */
    private static Logger objLog = LoggerFactory.getLogger(PolicyInfoController.class);

    /**
     * 該当キーワードの表示上限個数
     */
    private static final int DISPLAY_LIMIT_PIECE = 3;

    /**
     * 非表示対象ポリシー名1
     */
    private static final String DISPLAY_NON_POLICY1 = "その他ポリシー";
    /**
     * 非表示対象ポリシー名2
     */
    private static final String DISPLAY_NON_POLICY2 = "図・表";

    /**
     * 管理者権限
     */
    private static final String USER_ROLE_TYPE = "Administrators";

    /** OTHER_ID */
    private static final Integer OTHER_ID = 0;

    @Autowired
    PolicyInfoService policyInfoService;
    @Autowired
    PolicyKeywordInfoService policyKeywordInfoService;
    @Autowired
    TmpTeacherPolicyService tmpTeacherPolicyService;
//    @Autowired
//    MaskDocMarkerService maskDocMarkerService;
//    @Autowired
//    TmpMaskDocTmpMarkerService tmpMaskDocTmpMarkerService;

    /**
     * <p>黒塗りポリシー設定画面初期表示メソッド</p>
     * 処理内容：黒塗りポリシー初期表示に必要なデータを取得し表示する。
     * @param model モデル
	 * @param request HTTPリクエスト
     * @return 検索対象サーバ設定画面のURL
     */
    @GetMapping
    public String getPolicyInfo(
            Model model,
            HttpServletRequest request
            ) {
        //クッキー情報を取得する
        System.out.println("");
        System.out.println(request.getHeader("Cookie"));
        int userAuth = 0;

        //管理者権限の文字列が検出されなかった場合
        if(request.getHeader("Cookie") == null){
            userAuth = 1;

            objLog.info("getPolicyInfo request end (failed)");
            model.addAttribute("userAuth", userAuth);
            return "manage/policy";
        }

        //ログインしているユーザーの権限を確認する
        String userRoleString = "\"userRole\":\"";
        int openUserRolePoint = request.getHeader("Cookie").indexOf(userRoleString);
        int openUserRoleEndPoint = request.getHeader("Cookie").indexOf(USER_ROLE_TYPE,openUserRolePoint) + USER_ROLE_TYPE.length();
        System.out.println(openUserRolePoint);
        System.out.println(openUserRoleEndPoint);

        //管理者権限の文字列が検出されなかった場合
        if(openUserRoleEndPoint == 13){
            userAuth = 1;

            objLog.info("getPolicyInfo request end (failed)");
            model.addAttribute("userAuth", userAuth);
            return "manage/policy";
        }

        String openUserRole = request.getHeader("Cookie").substring(openUserRolePoint+userRoleString.length(),openUserRoleEndPoint);
        System.out.println(openUserRole);

        objLog.info("getPolicyInfo request start");
        // 全件取得
        List<PolicyInfoEntity> policyInfoEntities = policyInfoService.findAll();
        List<PolicyKeywordInfo> policyKeywordInfos = policyKeywordInfoService.findAll();

        // 50文字を超える対象黒塗りポリシー該当キーワードの51文字目以降を省略する
        int keywordCnt = 0;
        int tmpPolicyId = -1;
        for (int i = 0; i < policyKeywordInfos.size(); i++) {

            // 前要素のポリシーIDと今回のポリシーIDを比較し同じ時カウンターを+1
            if (tmpPolicyId == policyKeywordInfos.get(i).getPolicyId()) {
                keywordCnt++;
                // 前回のポリシーIDと変化があった時初期化
            } else {
                // カウンター初期化
                keywordCnt = 0;
            }
            // ビュー側で表示切替が難しいためコントローラで同一ポリシーのキーワード4個目以降を非表示とするフラグを設定
            if (DISPLAY_LIMIT_PIECE <= keywordCnt) {
                policyKeywordInfos.get(i).setViewFlag(false);
            }
            // ポリシーID保持
            tmpPolicyId = policyKeywordInfos.get(i).getPolicyId();
        }

        // 図・表およびその他ポリシーを削除（リストの後ろから削除）
        for (int i = policyInfoEntities.size() - 1 ; i >= 0 ; i--) {
            PolicyInfoEntity pe = policyInfoEntities.get(i);
            if (Objects.equals(pe.getPolicyName(), DISPLAY_NON_POLICY1)) {
                policyInfoEntities.remove(i);
            } else
            // 図・表
            if (Objects.equals(pe.getPolicyName(), DISPLAY_NON_POLICY2)) {
                policyInfoEntities.remove(i);
            }
        }

        // レスポンス情報セット
        model.addAttribute("policyInfo", policyInfoEntities);
        model.addAttribute("policyKeywordInfos", policyKeywordInfos);
        objLog.trace("policyInfoEntities:{}", policyInfoEntities);
        objLog.trace("policyInfoEntities:{}", policyInfoEntities);
        objLog.info("getPolicyInfo request end (success)");
        return "manage/policy";
    }

    /**
     * <p>黒塗りポリシー設定画面設定反映処理メソッド</p>
     * 処理内容：
     * <ol>
     *   <li>画面上で削除した項目と紐づくDBの項目を削除する。</li>
     *   <li>画面上で編集した項目と紐づくDBの項目を更新する。</li>
     *   <li>画面上で追加した項目と紐づくDBの項目を追加する。</li>
     * </ol>
     * @param form 画面上の編集項目
     * <ol>
     *   <li>deleteRows 画面上で削除した項目のポリシーID</li>
     *   <li>changedValue 画面上で編集した項目</li>
     *   <li>addValue 画面上で追加した項目</li>
     * </ol>
     * @return ResponseEntity&lt;String&gt; 更新結果
     * @throws Exception 想定外エラー
     */
    @RequestMapping("/policy_reflect")
    @ResponseBody
    public ResponseEntity<String> policyReflect(
            @RequestBody PolicyInfoReflectForm form) throws Exception {

        objLog.info("policyReflect request start");
        // 存在チェック
        if (Objects.isNull(form)) {
            objLog.trace("form:{}", form);
            objLog.info("request data not found");
            objLog.info("TeacherCategoryReflect request end (error)");
            return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
        }
        objLog.info("form : {} ", form);

        List<AddValues> addValues = form.getAddValues();
        List<ChangedValues> changeValues = form.getChangedValues();
        List<Integer> deleteRow = form.getDeleteRow();
        String policyAuthor = form.getPolicyAuthor();
        System.out.println("設定反映ボタン");
        try {
            // システム日付を取得する
            Timestamp sysdate = Timestamp.valueOf(LocalDateTime.now());
            // 追加データがある場合
            if (!Objects.isNull(addValues)) {
                for (AddValues value : addValues) {
                    PolicyInfoEntity addPolicyInfo = new PolicyInfoEntity();
                    addPolicyInfo.setPolicyName(value.getPolicyName());
                    addPolicyInfo.setPolicyNumber(value.getPolicyNumber());
                    addPolicyInfo.setPolicyReason(value.getPolicyReason());
                    addPolicyInfo.setPolicyAuthor(policyAuthor);
                    addPolicyInfo.setCreateTime(sysdate);
                    addPolicyInfo.setUpdateTime(sysdate);
                    // DBに反映
                    objLog.trace("add policy [{}]", addPolicyInfo);
                    policyInfoService.insert(addPolicyInfo);
                }
            }

            // 編集データがある場合
            if (!Objects.isNull(changeValues)) {
                for (ChangedValues value : changeValues) {
                    PolicyInfoEntity changePolicyInfo = new PolicyInfoEntity();
                    // 更新データセット
                    changePolicyInfo.setPolicyId(value.getPolicyId());
                    changePolicyInfo.setPolicyName(value.getPolicyName());
                    changePolicyInfo.setPolicyNumber(value.getPolicyNumber());
                    changePolicyInfo.setPolicyReason(value.getPolicyReason());
                    changePolicyInfo.setUpdateTime(sysdate);
                    System.out.printf("[%s]の更新処理実施\r\n", value.getPolicyId());
                    objLog.trace("cange policy [{}]", changePolicyInfo);
                    policyInfoService.update(changePolicyInfo);
                }
            }


            // 削除項目
            if (!Objects.isNull(deleteRow)) {
                for (Integer value : deleteRow) {
                    // 教師データ（黒塗りポリシー）の外部キーとして削除項目が存在するときにその他を設定する
                    List<TmpTeacherPolicyList> updateTmpTeacherPolicyList = tmpTeacherPolicyService.findPolicyId(value);
                    for (TmpTeacherPolicyList list : updateTmpTeacherPolicyList) {
                        // 削除するポリシーIDの項目をその他にする
                        list.setPolicyId(OTHER_ID);
                        // DB更新
                        tmpTeacherPolicyService.updateOther(list);
                    }
//                    // 黒塗り箇所保存テーブルの外部キーとして削除項目が存在するときにその他を設定する
//                    List<MaskDocMarkerEntBlackPaint> maskDocMarkerEntBlackPaintList = maskDocMarkerService.findMakerPolicyId(value);
//                    for (MaskDocMarkerEntBlackPaint list : maskDocMarkerEntBlackPaintList) {
//                        // 削除するポリシーIDの項目をその他にする
//                        list.setMarkerPolicy(OTHER_ID);
//                        // DB更新
//                        maskDocMarkerService.updateMarkerDoc(list);
//                    }
//                    // 黒塗り箇所保存テーブルの外部キーとして削除項目が存在するときにその他を設定する
//                    List<TmpMaskDocMarkerEntBlackPaint> tmpMaskDocMarkerEntBlackPaintList = tmpMaskDocTmpMarkerService.findMakerPolicyId(value);
//                    for (TmpMaskDocMarkerEntBlackPaint list : tmpMaskDocMarkerEntBlackPaintList) {
//                        // 削除するポリシーIDの項目をその他にする
//                        list.setMarkerPolicy(OTHER_ID);
//                        // DB更新
//                        tmpMaskDocTmpMarkerService.updateTmpMarkerDoc(list);
//                    }
                    objLog.trace("delete policy id [{}]", value);
                    // 対応キーワード削除
                    policyKeywordInfoService.deleteKeyWord(value);
                    // ポリシー一覧から削除
                    policyInfoService.deleteById(value);
                }
            }
        } catch (Exception e) {
            objLog.error("addValues:{}\r\nchangeValues:{}\r\ndeleteRow:{}", addValues, changeValues,deleteRow);
            objLog.error("error message", e);
            objLog.info("policyReflect request end (error)");
            e.printStackTrace();
            // エラー応答を返す
            return new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
        objLog.info("policyReflect request end (success)");
        // 成功応答を返す
        return new ResponseEntity<String>(HttpStatus.OK);
    }
}
