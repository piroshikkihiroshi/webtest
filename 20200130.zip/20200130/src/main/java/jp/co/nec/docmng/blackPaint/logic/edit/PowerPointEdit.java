package jp.co.nec.docmng.blackPaint.logic.edit;

public class PowerPointEdit {
	
} // class
