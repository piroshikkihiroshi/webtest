/**
 * ���́FPolicyInfoService.java
 * �@�\���F
 * �T�v�F
 */


package jp.co.nec.docmng.manage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.manage.entity.PolicyInfoEntity;
import jp.co.nec.docmng.manage.util.map.PolicyInfoMapManage;

@Service
public class PolicyInfoService {

    @Autowired
    private PolicyInfoMapManage policyMapper;

    @Transactional
    public List<PolicyInfoEntity> findAll(){
        List<PolicyInfoEntity> entityList = policyMapper.findAll();
        return entityList;
    }

    @Transactional
    public void insert(PolicyInfoEntity policyInfo) {
        policyMapper.insert(policyInfo);
    }

    @Transactional
    public void update(PolicyInfoEntity policyInfo) {
        policyMapper.update(policyInfo);
    }

    @Transactional
    public void deleteById(Integer id){
        policyMapper.deleteById(id);
    }

}
