/**
 * 名称：UserIdSet.java
 * 機能名：
 * 概要：
 */


package jp.co.nec.docmng.blackPaint.util.api;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class UserIdSet {


	/**
	 * ユーザーIDをセットする
	 * @param userId
	 * @param response
	 * @return String 成否文字列
	 */
	@GetMapping("/rest/useidset")
	public String setUserId(@RequestParam("userId") String userId,
			HttpServletResponse response) {

		try {
			if(userId.equals("")) userId="0001";

			Cookie cookie = new Cookie("user_id", userId);
		    cookie.setMaxAge(60*3600);
		    cookie.setPath("/");
			response.addCookie(cookie);
			return "success";
		} catch (Exception e) {
			return "fail";
		} //try


	} //method


	/**
	 * ユーザーネームをセットする
	 * @param userName
	 * @param response
	 * @return String 成否文字列
	 */
	@GetMapping("/rest/usernameset")
	public String setUserName(@RequestParam("userName") String userName,
			HttpServletResponse response) {

		try {
			if(userName.equals("")) userName="テスト太郎";

			Cookie cookie = new Cookie("user_name", userName);
		    cookie.setMaxAge(60*3600);
		    cookie.setPath("/");
			response.addCookie(cookie);
			return "success";
		} catch (Exception e) {
			return "fail";
		} //try


	} //method


} //PolicyGet
