/**
 * 名称：PolicyInfoReflectForm.java
 * 機能名：
 * 概要：
 */


package jp.co.nec.docmng.manage.entity;

import java.util.List;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonInclude;




//@Data
/**
 * @param addValues
 * @param changedValues
 * @param deleteRow
 * @param policyAuthor
 * @return
 */
@JsonInclude
public class PolicyInfoReflectForm {
    private List<AddValues> addValues;
    private List<ChangedValues> changedValues;
    private List<Integer> deleteRow;
    private String policyAuthor;

    public List<AddValues> getAddValues() {
        return addValues;
    }
    public void setAddValues(List<AddValues> addValues) {
        this.addValues = addValues;
    }
    public List<ChangedValues> getChangedValues() {
        return changedValues;
    }
    public void setChangedValues(List<ChangedValues> changedValues) {
        this.changedValues = changedValues;
    }
    public List<Integer> getDeleteRow() {
        return deleteRow;
    }
    public void setDeleteRow(List<Integer> deleteRow) {
        this.deleteRow = deleteRow;
    }
    public String getPolicyAuthor() {
        return policyAuthor;
    }
    public void setPolicyAuthor(String policyAuthor) {
        this.policyAuthor = policyAuthor;
    }

    /**
     * @param policyName
     * @param policyNumber
     * @param policyReason
     * @return
     */

    public static class AddValues {
        @NotBlank(message = "必須項目です。")
        private String policyName;
        @NotBlank(message = "必須項目です。")
        private Integer policyNumber;
        @NotBlank(message = "必須項目です。")
        private String policyReason;

        public String getPolicyName() {
            return policyName;
        }
        public void setPolicyName(String policyName) {
            this.policyName = policyName;
        }
        public Integer getPolicyNumber() {
            return policyNumber;
        }
        public void setPolicyNumber(Integer policyNumber) {
            this.policyNumber = policyNumber;
        }
        public String getPolicyReason() {
            return policyReason;
        }
        public void setPolicyReason(String policyReason) {
            this.policyReason = policyReason;
        }
    }

    /**
     * @param policyId
     * @param policyNumber
     * @param policyReason
     * @param policyName
     * @return
     */

    public static class ChangedValues {
        @NotBlank(message = "必須項目です。")
        private Integer policyId;
        @NotBlank(message = "必須項目です。")
        private String policyName;
        @NotBlank(message = "必須項目です。")
        private Integer policyNumber;
        @NotBlank(message = "必須項目です。")
        private String policyReason;

        public Integer getPolicyId() {
            return policyId;
        }
        public void setPolicyId(Integer policyId) {
            this.policyId = policyId;
        }
        public String getPolicyName() {
            return policyName;
        }
        public void setPolicyName(String policyName) {
            this.policyName = policyName;
        }
        public Integer getPolicyNumber() {
            return policyNumber;
        }
        public void setPolicyNumber(Integer policyNumber) {
            this.policyNumber = policyNumber;
        }
        public String getPolicyReason() {
            return policyReason;
        }
        public void setPolicyReason(String policyReason) {
            this.policyReason = policyReason;
        }
    }

}


