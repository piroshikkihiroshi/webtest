/**
 * 名称：Return.java
 * 機能名：PROCENTER Return管理
 * 機能:PROCENTERのReturn管理
 */

package jp.co.nec.docmng.blackPaint.entity.procenter;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * PROCENTER Return管理
 */
public class Return {

	/**
	 * セッションID
	 */
	private String sessionID;

	/**
	 * ユーザID
	 */
	private String userID;

	/**
	 * ロケール
	 */
	private String locale;

	/**
	 * クライアントコード
	 */
	private String clientCode;

	/**
	 * サーバエイジェント
	 */
	private String serverAddress;

	/**
	 * ユーザエイジェント
	 */
	private String userAgent;

	@JsonProperty("sessionId")
	public String getSessionID() {
		return sessionID;
	}

	@JsonProperty("sessionId")
	public void setSessionID(String value) {
		this.sessionID = value;
	}

	@JsonProperty("userId")
	public String getUserID() {
		return userID;
	}

	@JsonProperty("userId")
	public void setUserID(String value) {
		this.userID = value;
	}

	@JsonProperty("locale")
	public String getLocale() {
		return locale;
	}

	@JsonProperty("locale")
	public void setLocale(String value) {
		this.locale = value;
	}

	@JsonProperty("clientCode")
	public String getClientCode() {
		return clientCode;
	}

	@JsonProperty("clientCode")
	public void setClientCode(String value) {
		this.clientCode = value;
	}

	@JsonProperty("serverAddress")
	public String getServerAddress() {
		return serverAddress;
	}

	@JsonProperty("serverAddress")
	public void setServerAddress(String value) {
		this.serverAddress = value;
	}

	@JsonProperty("userAgent")
	public String getUserAgent() {
		return userAgent;
	}

	@JsonProperty("userAgent")
	public void setUserAgent(String value) {
		this.userAgent = value;
	}
}
