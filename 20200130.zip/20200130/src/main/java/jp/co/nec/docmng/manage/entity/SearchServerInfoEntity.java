/**
 * ���́FSearchServerInfoEntity.java
 * �@�\���F
 * �T�v�F
 */


package jp.co.nec.docmng.manage.entity;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonFormat;



/**
 *
 * @param serverId
 * @param serverName
 * @param displayName
 * @param loginUserName
 * @param loginPassword
 * @param directoryPath
 * @param createTime
 * @param updateTime
 * @return
 */
//@Data
public class SearchServerInfoEntity {
    public Integer getServerId() {
		return serverId;
	}
	public void setServerId(Integer serverId) {
		this.serverId = serverId;
	}
	public String getServerName() {
		return serverName;
	}
	public void setServerName(String serverName) {
		this.serverName = serverName;
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public String getLoginUserName() {
		return loginUserName;
	}
	public void setLoginUserName(String loginUserName) {
		this.loginUserName = loginUserName;
	}
	public String getLoginPassword() {
		return loginPassword;
	}
	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}
	public String getDirectoryPath() {
		return directoryPath;
	}
	public void setDirectoryPath(String directoryPath) {
		this.directoryPath = directoryPath;
	}
	public Timestamp getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Timestamp createTime) {
		this.createTime = createTime;
	}
	public Timestamp getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Timestamp updateTime) {
		this.updateTime = updateTime;
	}
	private Integer serverId;
    private String serverName;
    private String displayName;
    private String loginUserName;
    private String loginPassword;
    private String directoryPath;
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss.SSS", timezone = "Asia/Tokyo")
    private Timestamp createTime;
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss.SSS", timezone = "Asia/Tokyo")
    private Timestamp updateTime;
}
