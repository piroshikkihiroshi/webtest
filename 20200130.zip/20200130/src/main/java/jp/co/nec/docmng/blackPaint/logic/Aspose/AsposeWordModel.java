/**
 * 名称：AsposeWordMode.java
 * 機能名：AsposeライブラリWord操作クラス
 * 概要：AsposeライブラリのWordを操作するクラス
 */

package jp.co.nec.docmng.blackPaint.logic.Aspose;

import org.jsoup.Jsoup;
import org.jsoup.select.Elements;

/**
 * AsposeライブラリのWordを操作するクラス
 */
public class AsposeWordModel {

	static String PAGE_CLASS = "awdiv awpage";

	/**
	 * html文字列からasposeで分割したページ数を返す
	 * @param strHtml_i 対象HTML
	 * @return ページ数
	 */
	public int aspPageGet(String strHtml_i) {
		int intRet = 0;
		org.jsoup.nodes.Document objDoc = Jsoup.parse(strHtml_i);
		Elements elmCls= objDoc.getElementsByClass(PAGE_CLASS);
		intRet = elmCls.size();
		elmCls = null;

		return intRet;
	} //aspPageGet

} //class
