/**
 * 名称：DocumentInfoEntPaint.java
 * 機能名：黒塗り処理文書情報entity
 * 概要：黒塗り処理で使用する文書情報entity
 */

package jp.co.nec.docmng.blackPaint.entity;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 黒塗り処理文書情報entity
 */
public class DocumentInfoEntPaint {

	public int getDocumentId() {
        return document_id;
    }
	public void setDocumentId(Integer documentId) {
        this.document_id = documentId;
    }
	public String getDocumentContents() {
        return document_contents;
    }
	public void setDocumentContents(String documentContents) {
        this.document_contents = documentContents;
    }
	public byte[] getHtmlZipData() {
        return html_zip_data;
    }
	public void setHtmlZipData(byte[] htmlZipData) {
        this.html_zip_data = htmlZipData;
    }
	public int getServerId() {
        return server_id;
    }
	public void setServerId(Integer serverId) {
        this.server_id = serverId;
    }
	public String getDocumentName() {
	        return document_name;
	}
	public void setDocumentName(String documentName) {
        this.document_name = documentName;
    }
	public String getExtension() {
        return extension;
    }
	public void setExtension(String extension) {
        this.extension = extension == null ? null : extension.trim();
    }
	public BigDecimal getDocumentSize() {
        return document_size;
    }
	public void setDocumentSize(BigDecimal documentSize) {
        this.document_size = documentSize;
    }
	public int getParentId() {
        return parent_id;
    }
	public void setParentId(Integer parentId) {
        this.parent_id = parentId;
    }
	public String getFilePath() {
        return file_path;
    }
	public void setFilePath(String filePath) {
        this.file_path = filePath == null ? null : filePath.trim();
    }
	public String getMarker() {
        return marker;
    }
	public void setMarker(String marker) {
        this.marker = marker == null ? null : marker.trim();
    }
	public int getCategoryId() {
        return category_id;
    }
	public void setCategoryId(Integer categoryId) {
        this.category_id = categoryId;
    }
	public Boolean getProcenterFlg() {
        return procenter_flg;
    }
	public void setProcenterFlg(Boolean procenterFlg) {
        this.procenter_flg = procenterFlg;
    }
	public Date getRetentionPeriod() {
        return retention_period;
    }
	public void setRetentionPeriod(Date retentionPeriod) {
        this.retention_period = retentionPeriod;
    }
	public String getAuthor() {
        return author;
    }
	public void setAuthor(String author) {
        this.author = author;
    }
	public String getUpdater() {
        return updater;
    }
	public void setUpdater(String updater) {
        this.updater = updater;
    }
	public String getAuthorizer() {
        return authorizer;
    }
	public void setAuthorizer(String authorizer) {
        this.authorizer = authorizer;
    }
	public Date getFileUpdateTime() {
        return file_update_time;
    }
	public void setFileUpdateTime(Date fileUpdateTime) {
        this.file_update_time = fileUpdateTime;
    }
	public int getMaskStatus() {
        return mask_status;
    }
	public void setMaskStatus(Integer maskStatus) {
        this.mask_status = maskStatus;
    }
	public Date getCreateTime() {
        return create_time;
    }
	public void setCreateTime(Date createTime) {
        this.create_time = createTime;
    }
	public Date getUpdateTime() {
        return update_time;
    }
	public void setUpdateTime(Date updateTime) {
        this.update_time = updateTime;
    }

	public int getNodeId() {
		return node_id;
	}
	public void setNodeId(int node_id) {
		this.node_id = node_id;
	}
	public int getProcenterParentId() {
		return procenter_parent_id;
	}
	public void setProcenterParentId(int procenter_parent_id) {
		this.procenter_parent_id = procenter_parent_id;
	}

	/**
	 * 文書ID
	 */
	private int document_id;

	/**
	 * 全文検索用text
	 */
	private String document_contents;

	/**
	 * HTML群(zip圧縮)
	 */
	private byte[] html_zip_data;

	/**
	 * サーバID
	 */
	private int server_id;

	/**
	 * 文書名
	 */
	private String document_name;

	/**
	 * 拡張子
	 */
	private String extension;

	/**
	 * 文書サイズ
	 */
	private BigDecimal document_size;

	/**
	 * 親ディレクトリID
	 */
	private int parent_id;

	/**
	 * パス
	 */
	private String file_path;

	/**
	 * 黒塗り箇所
	 */
	private String marker;

	/**
	 * 分類軸ID
	 */
	private int category_id;

	/**
	 * PROCENTERフラグ
	 */
	private Boolean procenter_flg;

	/**
	 * 保存期間
	 */
	private Date retention_period;

	/**
	 * 文書作成者
	 */
	private String author;

	/**
	 * 文章更新者
	 */
	private String updater;

	/**
	 * 文書承認者
	 */
	private String authorizer;

	/**
	 * 文書更新日時
	 */
	private Date file_update_time;

	/**
	 * 黒塗り状態
	 */
	private int mask_status;

	/**
	 * 作成日時
	 */
	private Date create_time;

	/**
	 * 更新日時
	 */
	private Date update_time;

	/**
	 * ノードID
	 */
	private int node_id;

	/**
	 * PROCENTER親ディレクトリID
	 */
	private int procenter_parent_id;

}
