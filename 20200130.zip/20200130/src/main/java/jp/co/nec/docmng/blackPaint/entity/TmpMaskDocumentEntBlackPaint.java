/**
 * 名称：TmpMaskDocumentEntBlackPaint.java
 * 機能名：黒塗り処理黒塗り文書一時保存情報entity
 * 機能:黒塗り処理で使用する黒塗り文書一時保存情報entity
 */

package jp.co.nec.docmng.blackPaint.entity;
import java.sql.Timestamp;

/**
 * 黒塗り処理黒塗り文書一時保存情報entity
 */
public class TmpMaskDocumentEntBlackPaint {

	public Integer getDocumentId() {
		return document_id;
	}
	public void setDocumentId(Integer document_id) {
		this.document_id = document_id;
	}
	public String getUserId() {
		return user_id;
	}
	public void setUserId(String user_id) {
		this.user_id = user_id;
	}
	public byte[] getHtmlZipData() {
		return html_zip_data;
	}
	public void setHtmlZipData(byte[] html_zip_data) {
		this.html_zip_data = html_zip_data;
	}
	public Timestamp getCreateTime() {
		return create_time;
	}
	public void setCreateTime(Timestamp create_time) {
		this.create_time = create_time;
	}
	public Timestamp getUpdateTime() {
		return update_time;
	}
	public void setUpdateTime(Timestamp update_time) {
		this.update_time = update_time;
	}

	/**
	 * 文書ID
	 */
	private Integer document_id;

	/**
	 * ユーザID
	 */
	private String user_id ;

	/**
	 * HTML群(zip圧縮)
	 */
	private byte[] html_zip_data ;

	/**
	 * 作成日時
	 */
	private Timestamp create_time ;

	/**
	 * 更新日時
	 */
	private Timestamp update_time ;
}
