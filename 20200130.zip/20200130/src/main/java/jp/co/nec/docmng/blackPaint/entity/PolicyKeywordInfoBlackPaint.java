/**
 * 名称：PolicyKeywordInfoBlackPaint.java
 * 機能名：黒塗り処理黒塗りポリシーキーワード情報entity
 * 機能:黒塗り処理で使用する文書情報entity
 */

package jp.co.nec.docmng.blackPaint.entity;

import java.util.Date;

/**
 * 黒塗り処理黒塗りポリシーキーワード情報entity
 */
public class PolicyKeywordInfoBlackPaint {

    public Integer getPolicyId() {
		return policy_id;
	}
	public void setPolicyId(Integer policy_id) {
		this.policy_id = policy_id;
	}
	public String getPolicyKeyword() {
		return policy_keyword;
	}
	public void setPolicyKeyword(String policy_keyword) {
		this.policy_keyword = policy_keyword;
	}
	public Date getCreateTime() {
		return create_time;
	}
	public void setCreateTime(Date create_time) {
		this.create_time = create_time;
	}
	public Date getUpdateTime() {
		return update_time;
	}
	public void setUpdateTime(Date update_time) {
		this.update_time = update_time;
	}

	/**
	 * ポリシーID
	 */
	private Integer policy_id;

	/**
	 * キーワードID
	 */
    private String policy_keyword;

	/**
	 * 作成日時
	 */
    private Date create_time;

	/**
	 * 文書ID
	 */
    private Date update_time;

}