/**
 * 名称：TmpMaskDocumentService.java
 * 機能名：黒塗り処理黒塗り文書一時保存情報連携
 * 概要：黒塗り処理にて使用する黒塗り文書黒塗り箇所一時保存情報への連携用サービス
 */

package jp.co.nec.docmng.blackPaint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.blackPaint.entity.TmpMaskDocumentEntBlackPaint;
import jp.co.nec.docmng.blackPaint.repository.TmpMaskDocumentMapPaint;

/**
 * 黒塗り処理黒塗り文書一時保存情報連携
 */
@Service
public class TmpMaskDocumentServicePaint {
	@Autowired
	private TmpMaskDocumentMapPaint tmpMaskDocumentMapPaint;

	/**
	 * ドキュメントID、ユーザID指定による取得
	 * @param document_id 取得条件となるドキュメントID
	 * @param user_id 取得条件となるユーザID
	 * @return 取得したデータのリスト
	 */
	@Transactional
	public List<TmpMaskDocumentEntBlackPaint> getTmpHtmlZip(Integer document_id,String user_id){
		return tmpMaskDocumentMapPaint.getTmpHtmlZip(document_id, user_id);
	} //getTmpHtmlZip

	/**
	 * ドキュメントID、ユーザID指定によるデータ存在確認
	 * @param document_id 取得条件となるドキュメントID
	 * @param user_id 取得条件となるユーザID
	 * @return 取得したデータのリスト
	 */
	@Transactional
	public List<TmpMaskDocumentEntBlackPaint> listTmpDoc(Integer document_id,String user_id) {
		return tmpMaskDocumentMapPaint.isTmpDoc(document_id, user_id);
	} //findOneService

	/**
	 * データ登録処理
	 * @param TmpMaskDocumentEnt 登録内容を格納したentity
	 */
	@Transactional
	public void insertTmpMaskDocument(TmpMaskDocumentEntBlackPaint TmpMaskDocumentEnt) {
		tmpMaskDocumentMapPaint.insertTmpMaskDocument(TmpMaskDocumentEnt);
	} //insertTmpMaskDocument

	/**
	 * ドキュメントID、ユーザID指定による削除処理
	 * @param document_id 削除条件となるドキュメントID
	 * @param user_id 削除条件となるユーザID
	 */
	@Transactional
    public void deleteTmpDoc(Integer document_id,String user_id) {
		tmpMaskDocumentMapPaint.deleteTmpDoc(document_id, user_id);
	} //deleteTmpDoc

} //PolicyInfoServiceApi
