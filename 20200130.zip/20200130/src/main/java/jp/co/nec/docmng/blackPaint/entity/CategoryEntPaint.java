/**
 * 名称：CategoryEntPaint.java
 * 機能名：黒塗り処理カテゴリー情報entity
 * 概要：黒塗り処理で使用するカテゴリー情報entity
 */

package jp.co.nec.docmng.blackPaint.entity;

import lombok.Data;

/**
 * 黒塗り処理カテゴリー情報entity
 */
@Data
public class CategoryEntPaint {

	/**
	 * 分類軸ID
	 */
	private int category_id;

	/**
	 * 分類軸名
	 */
	private String category_name;

	/**
	 * 分類軸作成者
	 */
	private String category_author;

}
