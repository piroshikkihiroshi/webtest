package jp.co.nec.docmng.manage.entity;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class PolicyInfoEntity {

    private Integer policyId;
    private Integer policyNumber;
    private String policyName;
    private String policyAuthor;
    private String policyReason;
    private String policyKeyword;
    private String policyRemarks;
    private Timestamp createTime;
    private Timestamp updateTime;
    // 表示・非表示切替用フラグ
    private Boolean viewFlag = true;

    public Integer getPolicyNumber() {
        return policyNumber;
    }
    public void setPolicyNumber(Integer policyNumber) {
        this.policyNumber = policyNumber;
    }
    public Integer getPolicyId() {
        return policyId;
    }
    public void setPolicyId(Integer policyId) {
        this.policyId = policyId;
    }
    public String getPolicyName() {
        return policyName;
    }
    public void setPolicyName(String policyName) {
        this.policyName = policyName;
    }
    public String getPolicyReason() {
        return policyReason;
    }
    public void setPolicyReason(String policyReason) {
        this.policyReason = policyReason;
    }
    public String getPolicyKeyword() {
        return policyKeyword;
    }
    public void setPolicyKeyword(String policyKeyword) {
        this.policyKeyword = policyKeyword;
    }
    public String getPolicyRemarks() {
        return policyRemarks;
    }
    public void setPolicyRemarks(String policyRemarks) {
        this.policyRemarks = policyRemarks;
    }
    public String getPolicyAuthor() {
        return policyAuthor;
    }
    public void setPolicyAuthor(String policyAuthor) {
        this.policyAuthor = policyAuthor;
    }
    public Timestamp getCreateTime() {
        return createTime;
    }
    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }
    public Timestamp getUpdateTime() {
        return updateTime;
    }
    public void setUpdateTime(Timestamp updateTime) {
        this.updateTime = updateTime;
    }
    public boolean getViewFlag() {
        return viewFlag;
    }
    public void setViewFlag(boolean viewFlag) {
        this.viewFlag = viewFlag;
    }
}
