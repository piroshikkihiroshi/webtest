package jp.co.nec.docmng.blackPaint.repository;


import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import jp.co.nec.docmng.blackPaint.entity.CategoryEntPaint;


@Mapper
public interface CategoryMapPaint {

    @Select("select * from admin.category_info order by category_id")
    List<CategoryEntPaint> findAll();

} //PolicyInfoMapper
