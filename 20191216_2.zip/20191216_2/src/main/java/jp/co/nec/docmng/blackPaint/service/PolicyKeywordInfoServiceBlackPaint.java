package jp.co.nec.docmng.blackPaint.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.blackPaint.entity.PolicyKeywordInfoBlackPaint;
import jp.co.nec.docmng.blackPaint.repository.PolicyKeywordInfoMapPaint;

@Service
public class PolicyKeywordInfoServiceBlackPaint {
	@Autowired
	private PolicyKeywordInfoMapPaint policyKeywordInfoMapPaint;

	//table mask_document_marker

	@Transactional
	public void insertPolicyKeyword(PolicyKeywordInfoBlackPaint objEnt) {
		policyKeywordInfoMapPaint.insertPolicyKeyword(objEnt);
	} //method





} //PolicyInfoServiceApi
