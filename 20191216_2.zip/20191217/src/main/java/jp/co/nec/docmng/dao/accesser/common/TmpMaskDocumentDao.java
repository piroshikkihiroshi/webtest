package jp.co.nec.docmng.dao.accesser.common;

import java.io.Reader;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nec.docmng.dao.entity.common.TmpMaskDocument;
import jp.co.nec.docmng.dao.entity.common.TmpMaskDocumentExample;
import jp.co.nec.docmng.dao.mapper.common.TmpMaskDocumentMapper;

/**
 * TmpMaskDocumentDao
 * 黒塗り文書一時保存テーブルの全件を取得する。
 */
public class TmpMaskDocumentDao {

	/**
	 * 黒塗り文書一時保存テーブルの情報を表示する。
	 * @return List<TmpMaskDocument> tempMaskDocumentList 黒塗り文書一時保存テーブルの情報リストを取得する。
	 * @throws Exception テーブル情報を取得できない場合
	 */
	
	public List<TmpMaskDocument> getTempMaskDocumentAll() {
		
		List<TmpMaskDocument> tempMaskDocumentList = null ;
		
		try (Reader readerConfig = Resources.getResourceAsReader("mybatis-config.xml");) {

			// 読み込んだ設定ファイルからSqlSessionFactoryを生成する
			SqlSessionFactory sqlFactory = new SqlSessionFactoryBuilder().build(readerConfig);

			// SQLセッションを取得する
			try (SqlSession sqlSession = sqlFactory.openSession()) {

				// 黒塗り文書一時保存テーブルのMapperを取得する
				TmpMaskDocumentMapper tempMaskDocumentMapper = sqlSession.getMapper(TmpMaskDocumentMapper.class);

				// 黒塗り文書一時保存テーブルの条件検索用クラスを生成する
				TmpMaskDocumentExample tempMaskDocumentExample = new TmpMaskDocumentExample();

				tempMaskDocumentExample.setOrderByClause("document_id,user_id");

				// 上記の条件でテーブルを検索する
				tempMaskDocumentList = tempMaskDocumentMapper.selectByExample(tempMaskDocumentExample);

			}
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
		return tempMaskDocumentList;
	} 

} 
