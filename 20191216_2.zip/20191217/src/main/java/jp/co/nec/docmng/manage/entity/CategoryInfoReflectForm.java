package jp.co.nec.docmng.manage.entity;

import java.util.List;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonInclude;

//@Data
@JsonInclude
public class CategoryInfoReflectForm {
    private List<AddValues> addValues;
    private List<ChangedValues> changedValues;
    private List<Integer> deleteRow;

    public List<AddValues> getAddValues() {
        return addValues;
    }
    public void setAddValues(List<AddValues> addValues) {
        this.addValues = addValues;
    }
    public List<ChangedValues> getChangedValues() {
        return changedValues;
    }
    public void setChangedValues(List<ChangedValues> changedValues) {
        this.changedValues = changedValues;
    }
    public List<Integer> getDeleteRow() {
        return deleteRow;
    }
    public void setDeleteRow(List<Integer> deleteRow) {
        this.deleteRow = deleteRow;
    }

    public static class AddValues {
        @NotBlank(message = "必須項目です。")
        private String categoryName;
        @NotBlank(message = "必須項目です。")
        private String categoryAuthor;

        public String getCategoryName() {
            return categoryName;
        }
        public void setCategoryName(String categoryName) {
            this.categoryName = categoryName;
        }
        public String getCategoryAuthor() {
            return categoryAuthor;
        }
        public void setCategoryAuthor(String categoryAuthor) {
            this.categoryAuthor = categoryAuthor;
        }
    }
    public static class ChangedValues {
        @NotBlank(message = "必須項目です。")
        private Integer categoryId;
        @NotBlank(message = "必須項目です。")
        private String categoryName;

        public Integer getCategoryId() {
            return categoryId;
        }
        public void setCategoryId(Integer categoryId) {
            this.categoryId = categoryId;
        }
        public String getCategoryName() {
            return categoryName;
        }
        public void setCategoryName(String categoryName) {
            this.categoryName = categoryName;
        }


    }

}


