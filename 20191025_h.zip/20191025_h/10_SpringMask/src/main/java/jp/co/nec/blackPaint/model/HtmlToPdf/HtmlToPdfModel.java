package jp.co.nec.blackPaint.model.HtmlToPdf;

import java.nio.file.Path;
import java.nio.file.Paths;

import io.woo.htmltopdf.HtmlToPdf;
import io.woo.htmltopdf.HtmlToPdfObject;

public class HtmlToPdfModel {
	/**
	 * strHtml_iからPDFを作成する
	 * @param strHtml_i
	 * @param strPath_i 相対パスを絶対パスに変更する必要があるのでimgが格納されているDirを指定
	 * @param strPdfOutPath_i pdf出力先のファイル名を含めたフルパス
	 */
	public void convertHtmlToPdf(String strHtml_i,String strPath_i,String strPdfOutPath_i){

		Path objPath = Paths.get(strPath_i);
		String strDirFile =  objPath.toUri().toString();;
//		String strDirFile = strPath_i.replace("C:/", "file:///");
		strHtml_i = strHtml_i.replace("src=\"", "src=\""+ strDirFile +"/");
		strHtml_i = strHtml_i.replace("href='", "href='"+ strDirFile +"/");
		// HTMLをPDFファイルに変更する
		HtmlToPdf.create().object(HtmlToPdfObject.forHtml(strHtml_i)).convert(strPdfOutPath_i);

	} //convertHtmlToPdf
} //class
