package _JsoupTest.JsoupTest;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Collectors;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;



//asposeをawpageクラス(ページ単位)で分割する
public class JsoupTest_bk_20191023 {
	static String PAGE_CLASS = "awpage";
	static String REP_MARK = "repMark";

	public static void main(String[] args) {
        Document objDoc;
        String strTgt = "//yoks3104/Project/NES_文書管理システム/99_tmp/上田/aspProto/test_WordHTML.html";
        String strTemplate = "//yoks3104/Project/NES_文書管理システム/99_tmp/上田/aspProto/tamplate.html";

		FileWriter file;
		PrintWriter pw;
		try {

			JsoupTest_bk_20191023 objMe = new JsoupTest_bk_20191023();
			String strGetHtml = objMe.readAll(strTgt);

			objDoc = Jsoup.parse(strGetHtml);
			Elements elmCls= objDoc.getElementsByClass(PAGE_CLASS);

			for (int i = 0; i < elmCls.size(); i++) {
				Element elmTgt = elmCls.get(i);
				String strGetOuterHtml = elmTgt.outerHtml();
				String strOutPath = strTemplate + i + ".html";
	            //html replace
	            String strRepHtml = objMe.readAll(strTemplate);
	            strRepHtml =strRepHtml.replace(REP_MARK, strGetOuterHtml);

				file = new FileWriter(strOutPath);
				pw = new PrintWriter(new BufferedWriter(file));
				pw.println(strRepHtml);
				pw.close();

			} //for

			System.out.println("end");


		} catch (IOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		} //try


	} //main

	/**
	 * strpath_iで指定したファイルを改行付きですべて読み込む
	 * @param strpath_i
	 * @return 読み込んだ文字列
	 * @throws IOException
	 */
	public String readAll(final String strpath_i) throws IOException {
		return Files.lines(Paths.get(strpath_i), Charset.forName("UTF-8"))
				.collect(Collectors.joining(System.getProperty("line.separator")));

	} //readAll


}
