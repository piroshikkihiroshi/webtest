package _JsoupTest.JsoupTest;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Collectors;

import org.apache.commons.io.FileUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import io.woo.htmltopdf.HtmlToPdf;
import io.woo.htmltopdf.HtmlToPdfObject;



//asposeをawpageクラス(ページ単位)で分割する(テンプレートなし)
public class JsoupTest {
	static String PAGE_CLASS = "awdiv awpage";
	static String REP_MARK = "repMark";

	public static void main(String[] args) {
        Document objDoc;
//        String strTgt = "C:/temp/splitTest/red_SpringBoot.html";
        String strTgt = "red_SpringBoot.html";
        String strOutTmpPath="C:/temp/splitTest/";
        String strBasePath = "C:/temp/splitTest/red_SpringBoot.html";
        String strHead="";
        String strFileOutDir="";
        String strHtmlDir="";
        String strHtmlOutDir="";
        strHead="red_";

		FileWriter objFile=null;
		PrintWriter objPw=null;
		try {

			JsoupTest objMe = new JsoupTest();
			//拡張子無しファイル名取得
			String strFileWithoutExtension = objMe.getNameWithoutExtension(strTgt);

			String strGetHtml = objMe.readAll(strBasePath);

			strFileWithoutExtension = strFileWithoutExtension.replace(strHead, ""); //識別文字消込

			//出力フォルダ作成
			strFileOutDir=strOutTmpPath+"/"+strHead+strFileWithoutExtension+"/";
            Path objSrcPath = Paths.get(strHtmlDir);
            Path objTgtPath = Paths.get(strFileOutDir);

            Files.copy(objSrcPath, objTgtPath);

			//html群のpath取得
			strHtmlDir = strOutTmpPath + strFileWithoutExtension;

			//html群をコピー
			strHtmlOutDir=strOutTmpPath+strHead+strFileWithoutExtension+"/"+strFileWithoutExtension+"/";
			File objHtmlPath = new File(strHtmlDir);
			File objTgtHtmlPath = new File(strHtmlOutDir);
            FileUtils.copyDirectory(objHtmlPath, objTgtHtmlPath);


			String strOutHtml = "";
			strOutHtml+="<!DOCTYPE html> <html> <head> <meta http-equiv='Content-Type' content='text/html; charset=utf-8' /> <title>";
			strOutHtml+=strFileWithoutExtension;
			strOutHtml+="</title> <link rel='stylesheet' type='text/css' href='";
			strOutHtml+=strFileWithoutExtension;
			strOutHtml+="/styles.css' media='all' /> ";
			strOutHtml+=" <link rel='stylesheet' type='text/css' href='";
			strOutHtml+=strFileWithoutExtension;
			strOutHtml+="/mask.css' media='all' /> </head> <body>";



			objDoc = Jsoup.parse(strGetHtml);
			Elements elmCls= objDoc.getElementsByClass(PAGE_CLASS);

			for (int i = 0; i < elmCls.size(); i++) {
				Element elmTgt = elmCls.get(i);
				String strGetOuterHtml = elmTgt.outerHtml();
				String strOutPath = strOutTmpPath+strHead+strFileWithoutExtension+"/"+ i + ".html";
	            //html out
				String strRepHtml=strOutHtml;
				strRepHtml+=strGetOuterHtml;
				strRepHtml+="</body> </html>";

				objFile = new FileWriter(strOutPath);
				objPw = new PrintWriter(new BufferedWriter(objFile));
				objPw.println(strRepHtml);
				objPw.close();

				//pdfout
				String strOutPdfPath = strOutTmpPath+strHead+strFileWithoutExtension+"/"+ i + ".pdf";
				objMe.convertHtmlToPdf(strRepHtml,strOutTmpPath+strHead+strFileWithoutExtension,strOutPdfPath);


			} //for




			System.out.println("end");


		} catch (IOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		} //try


	} //main

	/**
	 * strpath_iで指定したファイルを改行付きですべて読み込む
	 * @param strpath_i
	 * @return 読み込んだ文字列
	 * @throws IOException
	 */
	public String readAll(final String strpath_i) throws IOException {
		return Files.lines(Paths.get(strpath_i), Charset.forName("UTF-8"))
				.collect(Collectors.joining(System.getProperty("line.separator")));

	} //readAll


	/**
	 * File名から拡張子を抜いたファイル名を取得する。
	 * @param String strFileName_i ファイルのフルパス
	 * @return String 取得文字列
	 */
	synchronized public String getNameWithoutExtension(String strFileName_i) {
		int index = strFileName_i.lastIndexOf('.');
		if (index != -1) {
			return strFileName_i.substring(0, index);
		}
		return strFileName_i;
	} //getNameWithoutExtension

	/**
	 * strHtml_iからPDFを作成する
	 * @param strHtml_i
	 * @param strPath_i 相対パスを絶対パスに変更する必要があるのでimgが格納されているDirを指定
	 * @param strPdfOutPath_i pdf出力先のファイル名を含めたフルパス
	 */
	public void convertHtmlToPdf(String strHtml_i,String strPath_i,String strPdfOutPath_i){

		Path objPath = Paths.get(strPath_i);
		String strDirFile =  objPath.toUri().toString();;
//		String strDirFile = strPath_i.replace("C:/", "file:///");
		strHtml_i = strHtml_i.replace("src=\"", "src=\""+ strDirFile +"/");
		strHtml_i = strHtml_i.replace("href='", "href='"+ strDirFile +"/");
		// HTMLをPDFファイルに変更する
		HtmlToPdf.create().object(HtmlToPdfObject.forHtml(strHtml_i)).convert(strPdfOutPath_i);

	} //convertHtmlToPdf


}
