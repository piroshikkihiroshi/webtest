<?php
  require_once './vendor/autoload.php';
  use Microsoft\Graph\Graph;
  use Microsoft\Graph\Model;
  $accessToken = NULL;
   
  $provider = new \League\OAuth2\Client\Provider\GenericProvider([
    'clientId'                => '19add8fc-8d22-4571-9157-91cc6154cc42',
    'clientSecret'            => 'ricsSNTZX+hwaKQ80659(]$',
    'redirectUri'             => 'https://localhost/OAuth2/index.php',
    'urlAuthorize'            => 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize',
    'urlAccessToken'          => 'https://login.microsoftonline.com/common/oauth2/v2.0/token',
    'urlResourceOwnerDetails' => '',
    'scopes'                  => 'user.read'
  ]);
   
  //アクセストークン取得
  if($_SERVER['REQUEST_METHOD'] === 'GET' && !isset($_GET['code']) && !isset($_GET['error'])){
    $authorizationUrl = $provider->getAuthorizationUrl();
    header('Location: ' . $authorizationUrl);
    exit();
  }elseif($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['code'])){
    try{
      $accessTokenObj = $provider->getAccessToken('authorization_code', [
        'code' => $_GET['code']
      ]);
      $accessToken = $accessTokenObj->getToken();
    }catch(League\OAuth2\Client\Provider\Exception\IdentityProviderException $e){
      printf('Error:', $e->getMessage());
    }
  }
   
  //Graph API呼び出し
  if($accessToken){
    $graph = new Graph();
    $graph->setAccessToken($accessToken);
     
    $user = $graph->createRequest('GET', '/me')
              ->setReturnType(Model\User::class)
              ->execute();
    echo 'Hello, ' . $user->getDisplayName();
  }
  