package jp.co.nec.docmng.blackPaint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.blackPaint.entity.TmpMaskDocumentEntBlackPaint;
import jp.co.nec.docmng.blackPaint.repository.TmpMaskDocumentMapPaint;

@Service
public class TmpMaskDocumentService {
	@Autowired
	private TmpMaskDocumentMapPaint tmpMaskDocumentMapPaint;

	//table tmp_mask_document

	@Transactional
	public List<TmpMaskDocumentEntBlackPaint> getTmpHtmlZip(Integer document_id,String user_id){
		return tmpMaskDocumentMapPaint.getTmpHtmlZip(document_id, user_id);

	} //method


	@Transactional
	public List<TmpMaskDocumentEntBlackPaint> listTmpDoc(Integer document_id,String user_id) {
		return tmpMaskDocumentMapPaint.isTmpDoc(document_id, user_id);
	} //findOneService

	@Transactional
	public void insertTmpMaskDocument(TmpMaskDocumentEntBlackPaint TmpMaskDocumentEnt) {
		tmpMaskDocumentMapPaint.insertTmpMaskDocument(TmpMaskDocumentEnt);
	} //insertTmpMaskDocument

	@Transactional
    public void deleteTmpDoc(Integer document_id,String user_id) {
		tmpMaskDocumentMapPaint.deleteTmpDoc(document_id, user_id);
	} //deleteTmpDoc


} //PolicyInfoServiceApi
