package com.example.demo.model.entity;

import lombok.Data;

//ポイント：@Data
@Data
public class View3entity {

	private String user_id;
	private String password;
	private String user_name;

} //class
