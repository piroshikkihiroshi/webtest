package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.model.entity.View3entity;
import com.example.demo.model.service.View3service;

@Controller
public class View3Controller {

	@Autowired
	private View3service objview3Service;

	@GetMapping("/view3")
	public String getView1() {
		return "view3";
	} //getView1

	@PostMapping("/view3Response/findone")
	public String postDbRequest(@RequestParam("userid") String strUserId_i, Model model) {
		// １件検索
		View3entity objview3ent = objview3Service.findOneService(strUserId_i);
		// 検索結果をModelに登録
		model.addAttribute("user_id", objview3ent.getUser_id());
		//	model.addAttribute("user_password", objview3ent.getPassword()); //passwordは送らない
		model.addAttribute("user_name", objview3ent.getUser_name());
		// helloResponseDB.htmlに画面遷移
		return "view3Response/findone";
	} //postDbRequest

	@PostMapping("/view3Response/findall")
	public String findAll(Model model) {
		// 全件検索
		List<View3entity> listView3ent = objview3Service.findAllService();
		// 検索結果をModelに登録
		model.addAttribute("users", listView3ent);
		return "view3Response/findall";
	} //postDbRequest


} //class
