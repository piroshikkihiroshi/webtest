package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class View1Controller {

	@GetMapping("/view1")
	public String getView1() {
		return "view1";
	} //getView1
	// ポイント１：@PostMapping
	// ポイント２：@RequestParam
	@PostMapping("/view1")
	public String postRequest(@RequestParam("postvalue1") String strValue_i, Model model) {
		// ポイント３：model.addAttribute
		// 画面から受け取った文字列をModelに登録
		String strRet = strValue_i + "response";
		model.addAttribute("response", strRet);
		// helloResponse.htmlに画面遷移
		return "view1Response";
	} //postRequest

} //class
