package com.example.demo.model.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.example.demo.model.entity.View3entity;

@Mapper
public interface View3rmapper {
    @Select("select * from user_info")
    List<View3entity> findAllMapper();

    @Select("select * from user_info where user_id = #{user_id}")
    View3entity findOneMapper(String strId_i);

    @Insert("insert into user_info (user_id, password, user_name) values (#{user_id}, #{password}, #{user_name})")
    @Options(useGeneratedKeys = true)
    void save(View3entity user_info);

    @Update("update user_info set user_name = #{user_name}  where user_id = #{user_id}")
    void update(View3entity user_info);

    @Delete("delete from user_info where user_id = #{user_id}")
    void delete(String strId_i);


} //class
