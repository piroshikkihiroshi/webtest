package com.example.demo.model.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.entity.View2entity;
import com.example.demo.model.repository.View2repository;

//ポイント：@Service
@Service
public class View2service {

	@Autowired
	private View2repository objView2repo;

	public View2entity findOneService(String user_id_i) {
		// １件検索実行
		Map<String, Object> map = objView2repo.findOneRepo(user_id_i);
		// Mapから値を取得
		String strUserId = (String) map.get("user_id");
		String strUserPass = (String) map.get("password");
		String strUserName = (String) map.get("user_name");
		// Employeeクラスに値をセット
		View2entity objView2Entity = new View2entity();
		objView2Entity.setUser_id(strUserId);
		objView2Entity.setPassword(strUserPass);
		objView2Entity.setUser_name(strUserName);
		return objView2Entity;
	} //findOneService
}//class
