package com.example.demo.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.entity.View3entity;
import com.example.demo.model.mapper.View3rmapper;

@Service
public class View3service {

	@Autowired
	private View3rmapper objView3mapper;

	//ポイント：@Transactional
	@Transactional
	public View3entity findOneService(String user_id_i) {
		// １件検索実行
		return objView3mapper.findOneMapper(user_id_i);
	} //findOneService

    @Transactional
    public List<View3entity> findAllService() {
        return objView3mapper.findAllMapper();
    } //findAllService


}//class
