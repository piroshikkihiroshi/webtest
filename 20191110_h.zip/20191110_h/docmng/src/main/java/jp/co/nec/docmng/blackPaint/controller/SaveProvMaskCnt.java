/**
 * 名称：SaveProvMaskCnt.java
 * 機能名：保存画面のControlを行う。
 * 概要：保存画面のControlを行う。
 */

package jp.co.nec.docmng.blackPaint.controller;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.ServletContext;

import org.apache.commons.io.FileUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jp.co.nec.docmng.blackPaint.logic.HtmlToPdf.HtmlToPdfModel;
import jp.co.nec.docmng.blackPaint.logic.dirFile.FileCnt;
import jp.co.nec.docmng.blackPaint.logic.maskHtml.MaskHtmlModel;

/**
 * 保存画面のControlを行う。
 */

@Controller
public class SaveProvMaskCnt {

	/**
	 * context サーブレットのRealPathを取得する
	 * objLog log出力に使用する
	 * PAGE_CLASS ページを判定するHTMLClass。ページをSplitするのに使用する
	 * ARR_HEAD ファイル名、フォルダ名を判定するために使用する
	 */
	@Autowired
	ServletContext context;
	static Logger objLog = LoggerFactory.getLogger(SaveProvMaskCnt.class);

	static String PAGE_CLASS = "awdiv awpage"; //splitするページのHTMLClass
	static String[] ARR_HEAD = {"mask_","red_"}; //ファイル名、フォルダ名のヘッダー配列

	/**
	 * 保存画面初期表示メソッド
	 * 保存画面初期表示の処理をする。
	 * @param strTmpDir_i 黒塗り編集画面で処理したHTMLが格納されたTMPディレクトリ名。
	 * @param strRedHtml_i 黒塗り編集候補HTMLのouterHTML。
	 * @param strMaskHtml_i 黒塗り編集HTMLのouterHTML。
	 * @param strListJson_i 黒塗りリスト情報JSON。
	 * @param strTmpDir_i オリジナルwordファイル名。
	 */
	@PostMapping("/SaveProvMaskCnt")
	public String getblackPaintInfo(
			@RequestParam("tmpDir") String strTmpDir_i,
			@RequestParam("strRedHtml") String strRedHtml_i,
			@RequestParam("strMaskHtml") String strMaskHtml_i,
			@RequestParam("listJson") String strListJson_i,
			@RequestParam("strFileName") String strFileName_i,
			@RequestParam("documentId") String documentId,
			@CookieValue(value = "user_id", required = false) String UserId,
			Model model) {

		//モデル初期化
		FileCnt objFileCnt = new FileCnt();
		HtmlToPdfModel objPdfCls = new HtmlToPdfModel();
		MaskHtmlModel objHtmllCls = new MaskHtmlModel();

		//メンバ変数初期化
		Document objDoc=null;
		String strBasePath =""; //黒塗り作成時の作業フォルダ
		String strHead=""; //ファイル名、フォルダ名のヘッダー
		String strFileOutDir=""; //PDF出力フォルダ
		String strHtmlDir=""; //黒塗り作成時HTMLに対するimg,css等が入っているフォルダ
		String strRealPath = context.getRealPath("/");
		String strOrgFileName = strFileName_i; //オリジナルwordファイル名
		String strRelativePath = ""; //iFrameに表示するための相対パス
		int intPages = 0; //PDFページ枚数
		String strTmpTimeStamp=""; //tempファイルタイムスタンプ
		strTmpTimeStamp=String.valueOf(System.currentTimeMillis());
		//拡張子無しファイル名取得
		String strFileWithoutExtension = objFileCnt.getNameWithoutExtension(strOrgFileName);

		int sizeRedPdf = 0; //黒塗り候補文書PDFのファイルサイズの合計
		int sizeMaskPdf = 0; //黒塗り文書PDFのファイルサイズの合計

		//黒塗りリスト(ファイルサイズ測る用)作成
		objHtmllCls.makeBrackPaint("["+strListJson_i+"]",UserId,strBasePath+strHead+strTmpTimeStamp+"listAll"+"/",strRealPath);


		//黒塗り候補PDFの作成 黒塗りPDFの作成
		for (int intIndex = 0; intIndex < ARR_HEAD.length; intIndex++) {
			strHead=ARR_HEAD[intIndex];
			strBasePath=strRealPath + strTmpDir_i ;
			FileWriter objFile=null;
			PrintWriter objPw=null;
			try {

				String strGetHtml = "";

				//出力フォルダ作成
				strFileOutDir=strBasePath+strHead+strTmpTimeStamp+"split"+"/";
				Path objSrcPath = Paths.get(strBasePath);
				Path objTgtPath = Paths.get(strFileOutDir);
				Files.copy(objSrcPath, objTgtPath);

				//html群をコピー
				strHtmlDir=strBasePath+strFileWithoutExtension+"/";
				File objHtmlPath = new File(strHtmlDir);
				File objTgtHtmlPath = new File(strFileOutDir+strFileWithoutExtension);
				FileUtils.copyDirectory(objHtmlPath, objTgtHtmlPath);

				//動的templateを作成
				String strOutHtml = "";
				strOutHtml+="<!DOCTYPE html> <html> <head> <meta http-equiv='Content-Type' content='text/html; charset=utf-8' /> <title>";
				strOutHtml+=strFileWithoutExtension;
				strOutHtml+="</title> <link rel='stylesheet' type='text/css' href='";
				strOutHtml+=strFileWithoutExtension;
				strOutHtml+="/styles.css' media='all' /> ";
				strOutHtml+=" <link rel='stylesheet' type='text/css' href='";
				strOutHtml+=strFileWithoutExtension;
				strOutHtml+="/mask.css' media='all' /> </head> <body>";

				//PDF作成処理
				if(strHead.equals("mask_")) {
					strGetHtml = strMaskHtml_i;
				}else {
					strGetHtml = strRedHtml_i;
				} //if


				objDoc = Jsoup.parse(strGetHtml);
				Elements elmCls= objDoc.getElementsByClass(PAGE_CLASS);

				for (int i = 0; i < elmCls.size(); i++) {
					Element elmTgt = elmCls.get(i);
					String strGetOuterHtml = elmTgt.outerHtml();
					String strOutPath = strFileOutDir+strHead+ (i + 1) + ".html";
					//html out
					String strRepHtml=strOutHtml;
					strRepHtml+=strGetOuterHtml;
					strRepHtml+="</body> </html>";

					objFile = new FileWriter(strOutPath);
					objPw = new PrintWriter(new BufferedWriter(objFile));
					objPw.println(strRepHtml);
					objPw.close();

					//pdfout
					String strOutPdfPath = strFileOutDir+strHead+ (i + 1) + ".pdf";
					String strChkHtml = objPdfCls.convertHtmlToPdf(strRepHtml,strFileOutDir,strOutPdfPath);

					if(strHead.equals("mask_")) {
						File maskfile = new File(strOutPdfPath);
						sizeMaskPdf += maskfile.length();
						FileInputStream maskfis = new FileInputStream(maskfile);
						maskfis.close();

					}else {
						File redfile = new File(strOutPdfPath);
						sizeRedPdf += redfile.length();
						FileInputStream redfis = new FileInputStream(redfile);
						redfis.close();
					} //if


					objLog.info(strHead.substring(0,strHead.length()-1) + (i + 1) +"枚目pdf出力完了");

				} //for

				//クライアントにわたす情報格納
				intPages = elmCls.size();
				strRelativePath="/"+strTmpDir_i+strHead+"split"+"/"+strHead;
				objLog.info(strHead.substring(0,strHead.length()-1)+ "のpdf出力すべて完了");


			} catch (IOException e) {
				// TODO 自動生成された catch ブロック
				e.printStackTrace();
			} //try

		} //for

		model.addAttribute("strTmpDir", strTmpDir_i); //親作業directory
		model.addAttribute("strListJson", strListJson_i); //黒塗りリスト情報
		model.addAttribute("strFileName", strFileName_i); //オリジナルファイルネーム
		model.addAttribute("strTmpTimeStamp", strTmpTimeStamp); //今回の作業derectory
		model.addAttribute("intPages",  String.valueOf(intPages)); //PDFページ数 documentId
		model.addAttribute("documentId", documentId); //親作業directory

		model.addAttribute("sizeRedPdf",  sizeRedPdf/1000); //黒塗り候補文書PDFのファイルサイズの合計 (KB)
		model.addAttribute("sizeMaskPdf", sizeMaskPdf/1000); //黒塗り文書PDFのファイルサイズの合計 (KB)

	return "blackPaint/MaskProvSave";
} //getView1



} //MaskHtmlCnt
