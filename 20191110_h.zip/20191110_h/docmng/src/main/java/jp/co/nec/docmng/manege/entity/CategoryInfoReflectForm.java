package jp.co.nec.docmng.manege.entity;

import java.util.List;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonInclude;

//@Data
@JsonInclude
public class CategoryInfoReflectForm {
    private List<AddValues> addValues;
    private List<ChangedValues> changedValues;
    private List<Integer> deleteRow;

    public List<AddValues> getAddValues() {
        return addValues;
    }
    public void setAddValues(List<AddValues> addValues) {
        this.addValues = addValues;
    }
    public List<ChangedValues> getChangedValues() {
        return changedValues;
    }
    public void setChangedValues(List<ChangedValues> changedValues) {
        this.changedValues = changedValues;
    }
    public List<Integer> getDeleteRow() {
        return deleteRow;
    }
    public void setDeleteRow(List<Integer> deleteRow) {
        this.deleteRow = deleteRow;
    }

    public static class AddValues {
        @NotBlank(message = "必須項目です。")
        private String category_name;
        @NotBlank(message = "必須項目です。")
        private String category_author;

        public String getCategory_name() {
            return category_name;
        }
        public void setCategory_name(String category_name) {
            this.category_name = category_name;
        }
        public String getCategory_author() {
            return category_author;
        }
        public void setCategory_author(String category_author) {
            this.category_author = category_author;
        }
    }
    public static class ChangedValues {
        @NotBlank(message = "必須項目です。")
        private Integer category_id;
        @NotBlank(message = "必須項目です。")
        private String category_name;

        public Integer getCategory_id() {
            return category_id;
        }

        public void setCategory_id(Integer category_id) {
            this.category_id = category_id;
        }

        public String getCategory_name() {
            return category_name;
        }

        public void setCategory_name(String category_name) {
            this.category_name = category_name;
        }
    }

}


