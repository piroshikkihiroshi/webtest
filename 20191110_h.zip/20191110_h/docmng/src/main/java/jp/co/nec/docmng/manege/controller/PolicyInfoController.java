package jp.co.nec.docmng.manege.controller;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.thymeleaf.util.StringUtils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.manege.entity.PolicyInfoEntity;
import jp.co.nec.docmng.manege.entity.PolicyKeywordInfo;
import jp.co.nec.docmng.manege.entity.SearchServerInfoEntity;
import jp.co.nec.docmng.manege.service.PolicyInfoService;
import jp.co.nec.docmng.manege.service.PolicyKeywordInfoService;
@Controller
@RequestMapping("/manege/policy")
public class PolicyInfoController {
    /**
     * 該当キーワードの表示上限文字数
     */
    private static final int DISPLAY_LIMIT_NUM = 50;

    //要らないかも？
    /**
     * 設定反映ステータス：成功
     */
    private static final String SUCCESS = "success";

    /**
     * 設定反映ステータス：失敗
     */
    private static final String FAILURE = "failure";
    /**
     * 設定反映ステータス格納用変数
     */
    private String saveStatus = null;

    @Autowired
    PolicyInfoService policyInfoService;
    @Autowired
    PolicyKeywordInfoService policyKeywordInfoService;

    /**
     * <p>黒塗りポリシー設定画面GET処理</p>
     * 処理内容：<br>
     * <ol>
     *   <li>黒塗りポリシー設定画面をGETする</li>
     * </ol>
     * @param form 検索対象追加用フォーム
     * @param model モデル
     * @return 検索対象サーバ設定画面のURL
     */
    @GetMapping
    public String getPolicyInfo(Model model) {

        // 全件取得
        List<PolicyInfoEntity> policyInfoEntities = policyInfoService.findAll();
        List<PolicyKeywordInfo> policyKeywordInfos = policyKeywordInfoService.findAll();

        // 50文字を超える対象黒塗りポリシー該当キーワードの51文字目以降を省略する
        for (int i = 0; i < policyKeywordInfos.size(); i++) {
            // 該当キーワードを取得する
            String keyword = policyKeywordInfos.get(i).getPolicyKeyword();

            // 該当キーワードが50文字を超える場合
            if (DISPLAY_LIMIT_NUM < keyword.length()) {
                // 51文字目以降を切り取る
                String cutStr = StringUtils.substring(keyword, 0, DISPLAY_LIMIT_NUM);
                // エンティティにセットしなおす
                policyKeywordInfos.get(i).setPolicyKeyword(cutStr + "...");
            }
        }

        model.addAttribute("policyInfo", policyInfoEntities);
        model.addAttribute("policyKeywordInfos", policyKeywordInfos);
        return "manege/policy";
    }

  //TODO 例外時の処理、ログ出力
    /**
     * <p>設定反映処理</p>
     * 処理内容：<br>
     * <ol>
     *   <li>画面上で削除した項目と紐づくDBの項目を削除する</li>
     *   <li>画面上で編集した項目と紐づくDBの項目を更新する</li>
     *   <li>画面上で追加した項目と紐づくDBの項目を追加する</li>
     * </ol>
     * @param changedValue 画面上で編集した項目の値
     * @param deleteRows 画面上で削除した項目のサーバID
     * @param addValue
     * @return リロード
     */
    @PostMapping(params = "save")
    public String save(@RequestParam("changedValue") String changedValue, @RequestParam("deleteRow") List<Integer> deleteRows,
            @RequestParam("addValue") String addValue) {

    	System.out.println(changedValue);
    	System.out.println(deleteRows);
    	System.out.println(addValue);

        try {

            // システム日付を取得する
            Timestamp sysdate = Timestamp.valueOf(LocalDateTime.now());

            ObjectMapper mapper = new ObjectMapper();

            // 追加項目
            // Json文字列をツリーとして扱う
            JsonNode addRoot = mapper.readTree(addValue);

            Iterator<String> addFieldNames = addRoot.fieldNames();

            while (addFieldNames.hasNext()) {
                // キー取得
                String fieldName = addFieldNames.next();
                System.out.println(fieldName);

                JsonNode jn = addRoot.get(fieldName);

                // 取得したオブジェクトをエンティティにマッピングする
                PolicyInfoEntity addPolicyInfo = mapper.readValue(jn.toString(), PolicyInfoEntity.class);
                // システム日付を設定する
                addPolicyInfo.setCreateTime(sysdate);

                policyInfoService.insert(addPolicyInfo);

            }

            // 編集項目
            // Json文字列をツリーとして扱う
            JsonNode editRoot = mapper.readTree(changedValue);

            Iterator<String> editFieldNames = editRoot.fieldNames();

            while (editFieldNames.hasNext()) {

                // キーを取得する
                String fieldName = editFieldNames.next();

                JsonNode jn = editRoot.get(fieldName);

                // 取得したオブジェクトをエンティティにマッピングする
                PolicyInfoEntity editPolicyInfo = mapper.readValue(jn.toString(), PolicyInfoEntity.class);
                // キーを設定
                editPolicyInfo.setPolicyId(Integer.valueOf(fieldName));
                // システム日付を設定する
                editPolicyInfo.setUpdateTime(sysdate);

                policyInfoService.update(editPolicyInfo);
            }

            // 削除項目
            if (!CollectionUtils.isEmpty(deleteRows)) {

                for (int i = 0; i < deleteRows.size(); i++) {
                	policyInfoService.deleteById(deleteRows.get(i));
                }
            }

            saveStatus = SUCCESS;

        } catch (Exception e) {
            e.printStackTrace();

            //TODO エラーログ出力

            saveStatus = FAILURE;

        }
        return "redirect:policy";

    }

}
