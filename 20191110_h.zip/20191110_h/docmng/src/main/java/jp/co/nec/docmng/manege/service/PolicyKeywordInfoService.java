package jp.co.nec.docmng.manege.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.manege.entity.PolicyKeywordInfo;
import jp.co.nec.docmng.manege.util.map.PolicyKeywordInfoMapManege;

@Service
public class PolicyKeywordInfoService {

    @Autowired
    private PolicyKeywordInfoMapManege policyKeywordMapper;

    @Transactional
    public List<PolicyKeywordInfo> findAll(){
        List<PolicyKeywordInfo> entityList = policyKeywordMapper.findAll();
        return entityList;
    }

}
