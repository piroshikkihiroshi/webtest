package jp.co.nec.docmng.manege.controller;

import java.io.File;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import jp.co.nec.docmng.manege.entity.CategoryInfo;
import jp.co.nec.docmng.manege.entity.CategoryInfoForm;
import jp.co.nec.docmng.manege.entity.CategoryInfoReflectForm;
import jp.co.nec.docmng.manege.entity.CategoryInfoReflectForm.AddValues;
import jp.co.nec.docmng.manege.entity.CategoryInfoReflectForm.ChangedValues;
import jp.co.nec.docmng.manege.entity.TmpTeacherCategoryList;
import jp.co.nec.docmng.manege.service.CategoryInfoService;
import jp.co.nec.docmng.manege.service.TmpTeacherCategoryService;

@Controller
@RequestMapping("/manege/training_category")
public class TrainingCategoryController {

    @Autowired
    CategoryInfoService categoryInfoService;

    @Autowired
    TmpTeacherCategoryService tmpTeacherCategoryService;

    /** OTHER_ID */
    static Integer OTHER_ID = 0;

    /** 成功応答値 */
    static final String SUCCESS = "sucsess";
    /** 失敗応答値 */
    static final String ERROR = "error";

    @GetMapping
    public String getTrainingCategory(Model model) {
        // 全件取得
        System.out.println("教師データ（分類）登録画面表示（GET）");
        List<CategoryInfo> categoryInfos = categoryInfoService.findAll();
        model.addAttribute("categoryInfo", categoryInfos);

        List<TmpTeacherCategoryList> teacherCategoryLists = tmpTeacherCategoryService.findAll();
        model.addAttribute("teacherCategoryList", teacherCategoryLists);

        for (int i = 0; i < teacherCategoryLists.size(); i++) {
            for (int j = 0; j < categoryInfos.size() ; j++) {
                if (categoryInfos.get(j).getCategoryId() == teacherCategoryLists.get(i).getCategoryId()) {
                    teacherCategoryLists.get(i).setCategoryName(categoryInfos.get(j).getCategoryName());
                    break;
                }
                teacherCategoryLists.get(i).setCategoryName("その他");
            }
        }

        System.out.println(categoryInfos);
        System.out.println(teacherCategoryLists);

//        model.addAttribute("");

        return "manege/training_category";
    }

    @PostMapping("/read_file")
    @ResponseBody
    public ArrayList<String> outputFile(@RequestBody CategoryInfoForm form) throws Exception {

        String directoryPass = form.getDirectoryPass();

        //Fileクラスのオブジェクトを生成する
        File dir = new File(directoryPass);

        //listFilesメソッドを使用して一覧を取得する
        File[] dirList = dir.listFiles();

        //指定した拡張子のファイルを格納する
        ArrayList<String> fileList = new ArrayList<>();

        if(dirList != null) {

            for(int i=0; i<dirList.length; i++) {

                //ファイルの場合
                if(dirList[i].isFile()) {
                    System.out.println("ファイルです : " + dirList[i].toString());
                    fileList.add(dirList[i].toString());
                }
                //ディレクトリの場合
                else if(dirList[i].isDirectory()) {
                    System.out.println("ディレクトリです : " + dirList[i].toString());
                }
            }
        } else {
            System.out.println("指定した配下にはファイル、またはディレクトリが存在しません");
        }

        return fileList;
    }

    @PostMapping("/category_reflect")
    @ResponseBody
    public String categoryReflect(@RequestBody CategoryInfoReflectForm form) throws Exception {

        CategoryInfo categoryInfo = new CategoryInfo();
        System.out.println("設定反映ボタン");
        List<AddValues> addValues = form.getAddValues();
        List<ChangedValues> changeValues = form.getChangedValues();
        List<Integer> deleteRow = form.getDeleteRow();
        Timestamp sysdate = Timestamp.valueOf(LocalDateTime.now());

        try {
            // 追加データがある場合
            if (!Objects.isNull(addValues)) {
                for (AddValues value : addValues) {
                    // 更新データセット
                    categoryInfo.setCategoryAuthor(value.getCategory_author());
                    categoryInfo.setCategoryName(value.getCategory_name());
                    categoryInfo.setCreateTime(sysdate);
                    categoryInfo.setUpdateTime(sysdate);
                    // 更新
                    categoryInfoService.insert(categoryInfo);
                }
            }

            // 編集データがある場合
            if (!Objects.isNull(changeValues)) {
                for (ChangedValues value : changeValues) {
                    // 更新データセット
                    categoryInfo.setCategoryId(value.getCategory_id());
                    categoryInfo.setCategoryName(value.getCategory_name());
                    categoryInfo.setCreateTime(sysdate);
                    categoryInfo.setUpdateTime(sysdate);
                    // 更新
                    categoryInfoService.update(categoryInfo);
                }
            }

            // 削除データがある場合
            if (!Objects.isNull(deleteRow)) {
                for (Integer value : deleteRow) {
                    List<TmpTeacherCategoryList> updateTmpTeacherCategoryList = tmpTeacherCategoryService.findCategoryId(value);
                    for (TmpTeacherCategoryList list : updateTmpTeacherCategoryList) {
                        System.out.println(list.getUserId());
                        System.out.println(list.getSortId());
                        System.out.println(list.getFilePath());
                        list.setCategoryId(OTHER_ID);
                        tmpTeacherCategoryService.updateCategoryId(list);
                    }
                    // 更新
                    categoryInfoService.delete(value);
                }
            }
        } catch (Exception e) {
            return ERROR;
        }
        return SUCCESS;
    }
}
