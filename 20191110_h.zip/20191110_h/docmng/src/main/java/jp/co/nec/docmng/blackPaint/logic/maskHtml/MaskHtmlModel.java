package jp.co.nec.docmng.blackPaint.logic.maskHtml;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.blackPaint.logic.dirFile.DirCnt;
import jp.co.nec.docmng.blackPaint.logic.dirFile.FileCnt;


public class MaskHtmlModel {
	static String MASK_MSG = "■";
	static int STATE_MASK = 1;
	static int STATE_RED = 2;
	static int ID_COUNT=1000000;
	static String POS_INIT = "INIT";
	static String POS_NORMAL = "NORMAL";
	static String POS_END = "END";


	//黒塗りにもspanがあったほうが制御しやすいため追加
	//idを付与する仕様へ変更
//	static String MASK_BF = "<span class='tagMsk'>";
	static String MASK_BF = "<span class='tagMsk' id='msk";
	static String MASK_BF_INIT= "<span class='tagMsk tagMskInit' id='msk";
	static String MASK_BF_END= "<span class='tagMsk tagMskEnd' id='msk";
	static String MASK_AF = "</span>";

//	static String RED_BF = "<span class='tagRed'>";
	static String RED_BF = "<span class='tagRed' id='red";
	static String RED_BF_INIT= "<span class='tagRed tagRedInit' id='red";
	static String RED_BF_END= "<span class='tagRed tagRedEnd' id='red";
	static String RED_AF = "</span>";

	static Logger objLog = LoggerFactory.getLogger(MaskHtmlModel.class);

	/**
	 * 全文検索エンジンに返した結果を置換してbodyを入れ替え、または赤文字変換した文字列を取得
	 * @param hashRepPos_i AIから帰ってきた黒塗り対象情報をハッシュで格納したもの key：マスク箇所 value連続したポジションのステータス:ポリシーID
	 * @param hashBodyStructure_i HTMLのchar毎の情報を格納するクラスを格納したhash key：HTMLのindex : val HTMLのchar(index)毎の情報を格納するクラス
	 * @param intStatus_i 置換ステータス :マスク 2:赤文字
	 * @return String配列 0　置換したBody文字列 1　黒塗り先頭ID:黒塗り終了ID:policyID構成 複数ある場合は+でセパレート
	 */
	public String[] bodyReplace(
			HashMap<Integer, String> hashRepPos_i,
			HashMap<Integer, HtmlStructure> hashBodyStructure_i,
			int intStatus_i) {
		String[] arrRet=new String[2];
		String strIdMaker="";
		String strRepBody = "";
		String strActPolicys = "";
		int intStatus = 0;
		int intNotTagPos = 0;
		int intIdCnt = ID_COUNT;
		for (int i = 1; i < hashBodyStructure_i.size() + 1; i++) {
			HtmlStructure objHtmlStructure = hashBodyStructure_i.get(i);
			intStatus=objHtmlStructure.intStatus;
			intNotTagPos=objHtmlStructure.intNotTagPos;
			if (intStatus==1) { //通常文字の場合
				if (hashRepPos_i.containsKey(intNotTagPos)) { //置換対象
					if (intStatus_i == 1) {
						strActPolicys=hashRepPos_i.get(intNotTagPos);
						String[] arrActPolicys = strActPolicys.split(":");
						if (arrActPolicys[0].equals(POS_INIT)) {
							strRepBody+=MASK_BF_INIT+intIdCnt + "' >" +MASK_MSG+MASK_AF; //マスク
							strIdMaker +="msk" + intIdCnt+":";
						}else if (arrActPolicys[0].equals(POS_NORMAL)) {
							strRepBody+=MASK_BF+intIdCnt + "' >" +MASK_MSG+MASK_AF; //マスク
						} else {
							strRepBody+=MASK_BF_END+intIdCnt + "' >" +MASK_MSG+MASK_AF; //マスク
							strIdMaker +=(":msk" + intIdCnt)+":"+arrActPolicys[1] + "+";
						} //if

//						strRepBody+=MASK_BF+intIdCnt + "' >" +MASK_MSG+MASK_AF; //マスク
						intIdCnt++;
					}else {
						strActPolicys=hashRepPos_i.get(intNotTagPos);
						String[] arrActPolicys = strActPolicys.split(":");
						if (arrActPolicys[0].equals(POS_INIT)) {
							strRepBody+=RED_BF_INIT +intIdCnt + "'>" + objHtmlStructure.strTgt + RED_AF; //赤塗り
							strIdMaker +="red" + intIdCnt+":";
						}else if (arrActPolicys[0].equals(POS_NORMAL)) {
							strRepBody+=RED_BF +intIdCnt + "'>" + objHtmlStructure.strTgt + RED_AF; //赤塗り
						}else {
							strRepBody+=RED_BF_END +intIdCnt + "'>" + objHtmlStructure.strTgt + RED_AF; //赤塗り
							strIdMaker +=("red" + intIdCnt)+":"+arrActPolicys[1] + "+";
						} //if
//						strRepBody+=RED_BF +intIdCnt + "' >" + objHtmlStructure.strTgt + RED_AF; //赤塗り
						intIdCnt++;
					} //if

				}else {
					strRepBody+=objHtmlStructure.strTgt;
				} //if
			}else { //その他の場合そのまま出力する
				strRepBody+=objHtmlStructure.strTgt;
			} //if
		} //for

		if(!strIdMaker.equals("")) {
			strIdMaker = strIdMaker.substring(0,strIdMaker.length()-1);
		} //if
		arrRet[0]=strRepBody;
		arrRet[1]=strIdMaker;
		return arrRet;
//		return strRepBody;
	} //bodyReplace



	/**
	 * bodyの構造体hashを取得
	 * @param strOrgBody_i
	 * @return HtmlStructureのハッシュ
	 */
	public HashMap<Integer, HtmlStructure> getBodyStructure(
			String strOrgBody_i) {
		String strTgtVal = strOrgBody_i;

		HashMap<Integer, HtmlStructure> hashRetStructure = new HashMap<Integer, HtmlStructure>();
		List <Integer> listLastNotTagPos = new ArrayList<Integer>(); //intNotTagPosを格納していく
		String strRegrep = "(<\\/?[^>]+>)|([^<]+)"; //タグとタグを除いた値をグループで取得する
		Pattern objPattern = Pattern.compile(strRegrep);
		Matcher objMatch = objPattern.matcher(strTgtVal);
		String strCurrentKwd = ""; //現在ヒットしている単語
		int intCurrentPos = 0;
		while(objMatch.find()){
			strCurrentKwd = objMatch.group(2);

			if (strCurrentKwd == null) { //タグの処理
				strCurrentKwd = objMatch.group(1);
				searchAnalysis(hashRetStructure,listLastNotTagPos,strCurrentKwd,intCurrentPos,2);
			}else if (strCurrentKwd.equals(" ")) { //半角スペース処理
				searchAnalysis(hashRetStructure,listLastNotTagPos,strCurrentKwd,intCurrentPos,0);
				continue; //半角スペースはスキップ
			} else { //通常文字
				searchAnalysis(hashRetStructure,listLastNotTagPos,strCurrentKwd,intCurrentPos,1);
			} //if

			intCurrentPos = hashRetStructure.size();
		}  //while

		return hashRetStructure;
	} //getBodyStructure


	/**
	* 検索結果からbodyの構造体hashを作成する
	* @param HashMap<Integer, HtmlStructure> hashRetStructure_i 参照渡しのハッシュ
	* HtmlStructureはHTMLのchar毎の情報を格納するクラス
	* HashMap<Integer, HtmlStructure> の形で格納し、keyは置換対象外文字やtagを含んだポジション(<div>タグ等を含む)を格納する
	* @param strCurrentKwd_i 現在正規表現でヒットしている文字列
	* @param intCurrentPos_i タグを含めた現在のposition
	* @param intStatus_i 0：置換対象外(半角文字等) 1：対象 2：tag
	*/
	public void searchAnalysis(
			HashMap<Integer, HtmlStructure> hashRetStructure_i,
			List <Integer> listLastNotTagPos_i ,
			String strCurrentKwd_i,
			int intCurrentPos_i,
			int intStatus_i) {
		int intCntPos = hashRetStructure_i.size();
		int intNotTagPos = 0;
		HtmlStructure objHtmlStructure =null;
		String[] arrTmp = strCurrentKwd_i.split("");
		String strTgt="";

		if(listLastNotTagPos_i.size() !=0) { //tag抜き文字の最終を取得する
			intNotTagPos = listLastNotTagPos_i.get(listLastNotTagPos_i.size() - 1);
		} //if

		for (int i = 0; i < arrTmp.length; i++) {
			objHtmlStructure = new HtmlStructure();
			strTgt = arrTmp[i];
			objHtmlStructure.strTgt=strTgt;
			objHtmlStructure.intStatus=intStatus_i;
			if(intStatus_i==1) { //通常文字はintNotTagPosをカウント
				intNotTagPos++;
				objHtmlStructure.intNotTagPos = intNotTagPos;
			} //if
			hashRetStructure_i.put(intCntPos + (i + 1),objHtmlStructure);
		} //for

		if(intStatus_i==1) { //通常時はtag抜き文字の最終を格納
			listLastNotTagPos_i.add(intNotTagPos);
		} //if

	} //searchAnalysis



	/**
	 * タグを削除する
	 * @param strText_i タグを削除したい文字列
	 * @return タグ無し連結文字列
	 */
	public String getNoTabText(String strText_i) {
		String strRet = strText_i;
		//tagを全て除去
		String strPattern = "<(\"[^\"]*\"|'[^']*'|[^'\">])*>";
		strRet = strRet.replaceAll(strPattern, "");

		return strRet;
	} //getNoTabText



	/**
	 * htmlのbodyの中身を入れ替え、置換HTMLを作成する
	 * @param strAllHtml_i
	 * @param strRepBody_i
	 * @return 置換処理を行ったHTMLString
	 */
	public String makeBody(String strAllHtml_i, String strRepBody_i) {
		String strRet = strAllHtml_i;
		//改行を削除
		strRet = strRet.replaceAll("\r\n", " ");
		//tag以外で必要以外の半角スペース削除
		strRet.replaceAll("\\s+\\s", " ");

		String strPattern = "\\<body\\>.+\\</body\\>";

		//Bodyを入れ替え
		strRet = strRet.replaceFirst(strPattern, strRepBody_i);
		return strRet;
	} //getBody

	/**
	 * スタイルシートのパスを埋め込む
	 * @param strAllHtml_i
	 * @param strRepBody_i
	 * @return 置換処理を行ったHTMLString
	 */
	public String insertStyle(String strAllHtml_i, String strStyleSheet_i) {
		String strRet = strAllHtml_i;
		String strTgt = strStyleSheet_i;
		//debug jqueyも入れる
//		strTgt += " <script src='//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js'></script> ";
//		String strPattern = "</head>";
		String strPattern = "<body>";

		//Bodyを入れ替え
//		strRet = strRet.replaceFirst(strPattern, " " + strTgt+ " " + strPattern);
		strRet = strRet.replaceFirst(strPattern, " " + strPattern + " " + strTgt );

		//debug bodyのズームも理れる
//		strTgt += " <body style='zoom: 0.7;'>";
//		strPattern = "<body>";
//		strRet = strRet.replaceFirst(strPattern,strTgt);
		return strRet;
	} //getBody


	/**
	 * strpath_iで指定したファイルを改行付きですべて読み込む
	 * @param strpath_i
	 * @return 読み込んだ文字列
	 * @throws IOException
	 */
	public String readAll(final String strpath_i) throws IOException {
		return Files.lines(Paths.get(strpath_i), Charset.forName("UTF-8"))
				.collect(Collectors.joining(System.getProperty("line.separator")));

	} //readAll

	/**
	 * strHtml_i(htmlString)のBodyを正規表現で抜き出す(改行 必要以外の半角スペース削除)
	 * @param strHtml_i
	 * @return 抜き出したBody
	 */
	public String getBodyCompress(String strHtml_i) {
		String strRet = strHtml_i;

		//改行を削除
		strRet = strRet.replaceAll("\r\n", "");

		//2つ以上の半角スペースを一つにまとめる
		strRet = strRet.replaceAll("\\s+", " ");

		String strPattern = "\\<body\\>.+\\</body\\>";
		Pattern objPattern = Pattern.compile(strPattern);
		Matcher objMatch = objPattern.matcher(strRet);
		boolean blRet = objMatch.find();
		strRet = objMatch.group();

		return strRet;
	} //getBody

	/**
	 * 全文検索エンジンに渡す用の文字列を取得する
	 * @param strBody_i HTML文字列からBody要素だけを抜き出したもの
	 * @return タグ無し連結文字列
	 */
	public String getIllegalText(String strBody_i) {
		String strRet = strBody_i;
		//tagを全て除去
		String strPattern = "<(\"[^\"]*\"|'[^']*'|[^'\">])*>";
		strRet = strRet.replaceAll(strPattern, "");
		//trim
		strRet = strRet.trim();

		//半角スペース記号置換
		//		strPattern="&#xa0;";
		//		strRet = strRet.replace(strPattern, " ");

		return strRet;
	} //getIllegalText



	/**
	 * 全文検索から戻ってきた値をkeyで当てはまったハッシュをすべて変換するよう成型する
	 * ※来るデータはカンマ区切りで「startポジション,startポジションから〇〇文字」を想定
	 * @param strTextSrh_i 全文検索から帰ってきた文字列
	 * @return 成型したハッシュ key：マスク箇所 value連続したポジションのステータス:ポリシーID
	 * 　　　　　　　　　　　　　　　　　　　　　　　 ※連続したポジションのステータス→INIT NORMAL END
	 */
	public HashMap<Integer, String> makePosHash(String strTextSrh_i) {
		HashMap<Integer, String> hashRet = new HashMap<Integer, String>();

		//ペアは意識しないので+は:に置換
		strTextSrh_i = strTextSrh_i.replaceAll("\\+", ":");
		String[] arrTgt = strTextSrh_i.split(":");
//		String[] arrTgt = strTextSrh_i.split(",");

		for (int i = 0; i < arrTgt.length; i++) {
			Integer intTmp = Integer.parseInt(arrTgt[i]);
//			if (i % 2 == 0) { //偶数ならkeyを作成
			if (i % 3 == 0) { //ポリシー対応で3の倍数ならキーとする
				if (intTmp <= 0) { //※1文字目からカウントするので
					String strErrMtg = "文字は1文字目からカウントします。置換対象文字位置「" + intTmp + "」";
					throw new IllegalArgumentException(strErrMtg);
				} //if
				Integer intEnd = Integer.parseInt(arrTgt[i + 1]) + (intTmp - 1);
				Integer intPolicy = Integer.parseInt(arrTgt[i + 2]); //policy
				String strPosState = POS_INIT;
				for (int j = intTmp; j <= intEnd; j++) {
//					hashRet.put(j, 0);
					if (j==intTmp) { //policy対応
						strPosState=POS_INIT;
					}else if(j==intEnd) {
						strPosState=POS_END;
					}else {
						strPosState=POS_NORMAL;
					} //if
					hashRet.put(j, strPosState+":"+intPolicy);
				} //for

			} //if

		} //for

		return hashRet;

	} //makePosHash



	/**
	 * 黒塗りリストの保存用データを作成する
	 * @param strJson 黒塗りリストに必要なデータ
	 * @param strName 名前はクッキーなので引数
	 * @param strFileOutDir 出力フォルダ
	 */
	public void makeBrackPaint(String strJson,
			String strName,
			String strFileOutDir,
			String strRealPath) {

		//モデル初期化
		FileCnt objFileCnt = new FileCnt();
		DirCnt objDirCls = new DirCnt();

		//メンバ変数初期化
		String strTmpDir = ""; //黒塗り編集画面で処理したHTMLが格納されたTMPディレクトリ名。
		String strRedHtml = ""; //黒塗り編集候補HTMLのouterHTML。
		String strMaskHtml = ""; //黒塗り編集HTMLのouterHTML。
		String strFileName = ""; //オリジナルwordファイル名。
		int intDocumentId = -1; //documentId
		String strListJson = ""; //黒塗りリストの情報のjson

		String strBasePath = ""; //黒塗り作成時の作業フォルダ
		String strHead = ""; //ファイル名、フォルダ名のヘッダー
		String strHtmlDir = ""; //黒塗り作成時HTMLに対するimg,css等が入っているフォルダ
		String strTmpTimeStamp = ""; //tempファイルタイムスタンプ

		String updateTime =""; //更新日時
		String retentionPeriod=""; //保存期間
		String[] arrPrint = null; //印刷範囲のインデックス true：印刷 false 印刷無し
		String[] arrMaskPaths = null; //黒塗りpdfパス
		String[] arrRedPaths = null; //黒塗り候補pdfパス

		//以下黒塗りリスト配列
		String[] keywords=null;
		String[] pages=null;
		String[] policyNames=null;
		String[] Reasons=null;
		String[] Remarks=null;

		//以下黒塗りリスト配列
		String[] glArrBfIds = null;
		String[] glArrAfIds = null;
		String[] glArrPolicys = null;

		byte[] byteZip = null; //zipにした際のbyte配列
		File objZipFile = null;



		//POSTされたjsonをパースする
		ObjectMapper objMapper = new ObjectMapper();
		List<Map<String, String[]>> objTmpList = null;
		TypeReference<List<Map<String, String[]>>> objType = new TypeReference<List<Map<String, String[]>>>() {
		};
		try {
			objTmpList = objMapper.readValue(strJson, objType);
		} catch (JsonParseException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} catch (JsonMappingException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} catch (IOException e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} //try

		HashMap<String, String[]> objMap = (HashMap<String, String[]>) objTmpList.get(0);

		Object objTmp = null;
		for (String strKey : objMap.keySet()) {
			switch (strKey) {
			case "tmpDir":
				strTmpDir = objMap.get(strKey)[0];
				break;
			case "strFileName":
				strFileName = objMap.get(strKey)[0];
				break;
			case "updateTime":
				updateTime = objMap.get(strKey)[0];
				break;
			case "retentionPeriod":
				retentionPeriod = objMap.get(strKey)[0];
				break;
			case "documentId":
				intDocumentId = Integer.parseInt(objMap.get(strKey)[0]);
				break;
			case "arrPrint":
				arrPrint = (String[]) objMap.get(strKey);
				break;
			case "arrMaskPaths":
				arrMaskPaths = (String[]) objMap.get(strKey);
				break;
			case "arrRedPaths":
				arrRedPaths = (String[]) objMap.get(strKey);
				break;
				//*******以下黒塗りリスト用
			case "keywords":
				keywords = (String[]) objMap.get(strKey);
				break;
			case "pages":
				pages = (String[]) objMap.get(strKey);
				break;
			case "policyNames":
				policyNames = (String[]) objMap.get(strKey);
				break;
			case "Reasons":
				Reasons = (String[]) objMap.get(strKey);
				break;
			case "Remarks":
				Remarks = (String[]) objMap.get(strKey);
				break;
			case "glArrBfIds":
				glArrBfIds = (String[]) objMap.get(strKey);
				break;
			case "glArrAfIds":
				glArrAfIds = (String[]) objMap.get(strKey);
				break;
			case "glArrPolicys":
				glArrPolicys = (String[]) objMap.get(strKey);
				break;
			default:
				break;
			}//switch

		} //for

		//拡張子無しファイル名取得
		String strFileWithoutExtension = objFileCnt.getNameWithoutExtension(strFileName);

//		//出力フォルダ作成
		try {
			//面倒だからresouces配下もってくる
			objDirCls.makeDirWithCheck(strFileOutDir);
			//MaskListView.htmlをコピー
			String strListHtmlPath = "src/main/resources/templates/blackPaint/MaskListView.html";
			Path objListPath =Paths.get(strListHtmlPath);
			Path objTgtPath = Paths.get(strFileOutDir);
			Files.copy(objListPath, objTgtPath);
			//MaskListView.htmlをPDFように加工していく
			String strOrgHtml = objFileCnt.readAll(strListHtmlPath);
			String strRepHtml = strOrgHtml.replace("ユーザ名：<span></span>", "ユーザ名：<span>"+strName+"</span>");
			strRepHtml = strRepHtml.replaceAll("th:src=\"@{", "");



		} catch (Exception e1) {
			objLog.error("err message", e1);
			e1.printStackTrace();
		} //tyr


	} //method


} //class
