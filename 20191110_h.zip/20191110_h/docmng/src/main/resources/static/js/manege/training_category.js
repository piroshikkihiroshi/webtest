$(function () {

    /**
     * 画面が変更または閉じれる時に動作
     * ダイアログを表示する
     * messageboxで表示を行いたいが、検知の限界が存在する為「beforeunload」を使用する
     * 参考サイト：https://teratail.com/questions/51831
    **/
    $(window).on("beforeunload", function (e) {
        // POST送信フラグが「true」の場合、ダイアログを表示しない
        if (isPost) {
            return;
        } else {
            return true;
        }
    });

    /**
     * ×ボタン押下後に動作
     * 選択した行を削除する
     **/
    $('.DeleteRowTrainingPolicy').on('click', function (e) {
        //選択した行にIDを付与
        e.target.parentElement.setAttribute('id', 'selected');
        //選択した行の削除
        $("#selected").remove();
    });

    /**
     * ×ボタン押下後に動作
     * 動的に生成された選択した行を削除する
     **/
    $(document).on('click', '.NewDeleteRowTrainingPolicy', function (e) {
        //選択した行にIDを付与
        e.target.parentElement.setAttribute('id', 'selected');
        //選択した行の削除
        $("#selected").remove();
    });

    /**
     * 表をクリック時に動作
     * クリックを行った時に選択した行の色が変更される
    **/
    $('#main_scroll_L').mousedown(function (e) {
        //表の項目以外をクリック時には色を付けない
        if (e.target.id != "main_scroll_L") {
            if (e.target.className == "tr") {
                return false;
            } else if (e.target.tagName == "INPUT") {
                return true;
            }// if
            //一項目のみclick可能とする
            if (e.target.parentElement.id == 'selected') {
                document.getElementById('selected').removeAttribute("id");
            } else {
                if (document.getElementById('selected') == null) {
                    e.target.parentElement.setAttribute('id', 'selected');
                }// if
                document.getElementById('selected').removeAttribute("id");
                e.target.parentElement.setAttribute('id', 'selected');
            }// if
        } else if (e.target.id == "main_scroll_L") {
            return false;
        }// if

    });// function


    // Ajax通信テスト ボタンクリック
    $("#outputFileButton").click(function () {
        var strAddFilePassText = $('#addDirectoryPass').val();

        //未入力チェック
        if (strAddFilePassText == "") {
            alert('『フォルダパス』が未入力です。');
            return false;
        }// if

        // コントローラに渡すjsonオブジェクトを作成する
        var jsonObj = new Object();
        jsonObj.directoryPass = strAddFilePassText;

        $.ajax({
            url: "/manege/training_category/read_file",
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify(jsonObj),
            dataType: "json"
            // ajax通信成功時の処理
        }).done(function (data, textStatus, jqXHR) {
            let successOrFailure = "";
            var successCount = 0;
            if (data.length !== 0) {
                for (let i = 0; i < data.length; i++) {
                    for (let index = 0; index < document.getElementById("main_scroll_R").children.length; index++) {
                        var listFile = document.getElementById("main_scroll_R").children[index].children[2].outerText;
                        if (listFile !== data[i]) {
                            successCount++;
                        }
                    }
                    if (document.getElementById("main_scroll_R").children.length === successCount) {

                        //最上位行のプルダウンメニュー内容を取得
                        var strPullDownMenuList = document.getElementById("main_scroll_R").children[0].children[1].innerHTML;

                        //最上位行のstyleを取得
                        var strFilePassStyle = document.getElementById("main_scroll_R").children[0].children[2].style.cssText;

                        // 追加されていないファイルパスを追加する
                        var tr = $('<ul class="tr"></tr>');
                        var strDeleteButton = $('<li class="w40 bt_batsu NewDeleteRowTrainingPolicy"></li>');
                        var strCategoryId = $('<li style="display: none"></li>');
                        var strCategoryList = $('<li class="w100 menu dropdown_arrow_right" style="position: relative;"></li>');
                        var strFilePass = $('<li class="wAutoA B text_align_left" style="' + strFilePassStyle + '"></li>');

                        //表に取得した値を挿入する
                        $("#main_scroll_R").append(tr);
                        tr.append(strDeleteButton).append(strCategoryId).append(strCategoryList).append(strFilePass);
                        strDeleteButton.html("");
                        strCategoryList.html(strPullDownMenuList);
                        strFilePass.html(data[i]);
                    }
                    successCount = 0;
                }
                alert('ファイルパスを出力が完了いたしました。');
            } else if (data.length === 0) {
                alert('入力したディレクトリが存在しないか、配下にファイルが存在しませんでした。');
            }
            console.log(jqXHR.status);
            // ajax通信失敗時の処理
        }).fail(function (jqXHR, textStatus, errorThrown) {
            console.log(jqXHR.status);
            // 成功でも失敗でも通信終了時に必要な処理があれば
        }).always(function () {
        });

        console.log(jsonObj);

    });

});// function

/**
 * ⇒ボタン押下時に動作
 * 分類一覧表を表示し、「⇐」ボタンを表示する
**/
function FadeInOut() {
    if (document.getElementById("categoryTable").style.cssText !== "display: none;") {
        //分類一覧表の非表示
        $('#categoryTable').fadeOut(375);
    } else {
        //分類一覧表の表示
        $('#categoryTable').fadeIn(375);
    }// if
}// function


//グローバル変数
var addValues =[];

var addListCount = 0;

/**
 * 追加ボタン押下時に動作
 * 一覧表の最下部に追加する
**/
function AddList() {

    //現在の最大行取得
    var objAutoRowNo = document.getElementById("main_scroll_L").children.length - 1;
    strAutoRowNo = '' + objAutoRowNo;

    //非編集状態かつ編集中ではない場合
    if (document.getElementsByClassName('EditMode').length == 0 && document.getElementsByClassName("EditTable").length == 0) {

        //最終行が新規作成テキストボックスか確認を行う
        var t = document.getElementById("main_scroll_L")
        var t2 = $("#main_scroll_L")
        console.log(document.getElementById("main_scroll_L").children[objAutoRowNo].classList[2]);
        if (document.getElementById("main_scroll_L").children[objAutoRowNo].classList[2] !== "addListTable") {
            //編集行を、最終行に変更を行う
            if (document.getElementById('selected') !== null) {
                document.getElementById('selected').removeAttribute("id");
            }// if

            //新規作成する欄を作成
            var tr = $('<ul id="selected" class="tr ' + addListCount + '"></ul>');
            var strCategoryName = $('<li class="w160"></li>');

            //表に取得した値を挿入する
            $('#main_scroll_L').append(tr);
            tr.append(strCategoryName);
            strCategoryName.html("<input size='17' type='text' id='newCategoryName' class='textBox' value=" + "" + " ></imput>");
            $('#selected').eq(0).addClass('addListTable');

        } else if (document.getElementById("main_scroll_L").children[objAutoRowNo].classList[2] === "addListTable") {
            //入力されているテキストボックス内容を取得
            var strNewCategoryNameText = document.getElementById("newCategoryName").value;
            //入力チェック
            if (strNewCategoryNameText == "") {
                alert("分類軸名を入力後再度ボタンを押下してください");
                return false;
            }// if

            //入力された値がすでに一覧に存在するかチェック
            for (let index = 0; index < objAutoRowNo; index++) {
              var doc = document.getElementById("main_scroll_L").children[index];
              //var strListContent = document.getElementById("main_scroll_L").children[index].children[1].textContent;
              // 既存行なら[1] 追加行なら[0]からチェック対象を参照
              var strListContent = doc.children[1] ? doc.children[1].textContent : doc.children[0].textContent;
              if (strListContent === strNewCategoryNameText) {
                    alert("既に一覧に登録されているため、追加できません");
                    return false;
                }// if
            }// for

            //連想配列の作成
            var userName = $("#USER_NAME")[0].children[0].textContent;
            var addLen = addValues.length;
            addValues[addListCount] = { ["category_name"]: strNewCategoryNameText, ["category_author"]: userName };//現在ログインしているユーザー名を取得する
            addListCount++;
            console.log(addValues);
            //テキストボックス化を解除する
            document.getElementById("newCategoryName").outerHTML = strNewCategoryNameText;

            //非アクティブ化状態に移行するため、クラスの削除
            document.getElementsByClassName("addListTable")[0].classList.remove("addListTable");

            return;
        }// if
        //編集状態かつ編集中の場合
    } else if (document.getElementsByClassName('EditMode').length > 0 && document.getElementsByClassName("EditTable").length > 0) {
        alert("現在編集中のため追加は行えません");
        return false;
    }// if
}// function

//グローバル変数
var changedValues = [];
var beforeCategoryName = "";
/**
   * 編集ボタン押下時に動作
   * 選択した項目内容を変更する
  **/
function Edit() {
    //現在新規作成中の場合アラートを表示する
    if (document.getElementsByClassName('addListTable').length == 0) {
        //非編集状態かつ編集中ではない場合
        if (document.getElementsByClassName('EditMode').length == 0 && document.getElementsByClassName("EditTable").length == 0) {
            if (document.getElementById('selected') !== null) {
                if (document.getElementById('selected').length != 0) {
                    //編集がアクティブ状態のため、クラス付与
                    $('#main_scroll_L').eq(0).addClass('EditMode');
                    $('#selected').eq(0).addClass('EditTable');

                    //分類軸ID取得
                    var strChangeRow = $("#selected>li[style='display: none;']").text();

                    //新規追加行チェック
                    if (strChangeRow === "") {
                        //選択行の分類軸名を取得
                        var strCategoryNameText = $('#selected').eq(0).children()[0].valueOf().textContent;
                        console.log(strCategoryNameText);
                        //更新前の追加した分類名を保持
                        beforeCategoryName = strCategoryNameText;
                        //選択行の分類軸名をTextBox化
                        $('#selected').eq(0).children()[0].innerHTML = "<input size='17' type='text' id='changeCategoryName' class='textBox' value=" + strCategoryNameText + " ></imput>";
                    } else {
                        //選択行の分類軸名を取得
                        var strCategoryNameText = $('#selected').eq(0).children()[1].valueOf().textContent;
                        //選択行の分類軸名をTextBox化
                        $('#selected').eq(0).children()[1].innerHTML = "<input size='17' type='text' id='changeCategoryName' class='changeTextBox' value=" + strCategoryNameText + " ></imput>";
                    }// if
                }// if
            } else {
                alert("行を選択後編集ボタンを押下して下さい");
            }// if
            //編集状態かつ編集中の場合
        } else if (document.getElementsByClassName('EditMode').length > 0 && document.getElementsByClassName("EditTable").length > 0) {

            //分類軸ID取得
            var strChangeRow = $(".EditTable>li[style='display: none;']").text();
            //DBで表示されているリストの場合、classからリスト番号を取得
            var strAddChangeRow = document.getElementsByClassName("EditTable")[0].classList[0];
            //表示されている値の登録
            var strTextBoxCategoryName = document.getElementById("changeCategoryName").value;
            //現在の最大行取得
            var objAutoRowNo = document.getElementById("main_scroll_L").childElementCount - 1;
            console.log(strChangeRow);

            //入力された値がすでに一覧に存在するかチェック
            if (document.getElementsByClassName("changeTextBox").length > 0) {
              //入力された値がすでに一覧に存在するかチェック
              for (let index = 0; index < objAutoRowNo; index++) {
                var doc = document.getElementById("main_scroll_L").children[index];
                // 既存行なら[1] 追加行なら[0]からチェック対象を参照
                var strListContent = doc.children[1] ? doc.children[1].textContent : doc.children[0].textContent;
                if (strListContent === strTextBoxCategoryName) {
                      alert("既に一覧に登録されているため、編集が確定できません");
                      return false;
                  }// if
              }// for
            } else {
              //入力された値がすでに一覧に存在するかチェック
              for (let index = 0; index < objAutoRowNo; index++) {
                var doc = document.getElementById("main_scroll_L").children[index];
                // 既存行なら[1] 追加行なら[0]からチェック対象を参照
                var strListContent = doc.children[1] ? doc.children[1].textContent : doc.children[0].textContent;
                if (strListContent === strTextBoxCategoryName) {
                      alert("既に一覧に登録されているため、編集が確定加できません");
                      return false;
                  }// if
              }// for
            }// if

            // 連想配列作成・追加
//            if (addValues[strAddChangeRow]) {
//                addValues[strAddChangeRow]["category_name"] = strTextBoxCategoryName;
//                if (changedValues[strChangeRow]) {
//                    changedValues[strChangeRow]["category_name"] = strTextBoxCategoryName;
//                }// if
//            } else {
//                if (!changedValues[strChangeRow]) {
//                    changedValues[strChangeRow] = { ["category_name"]: strTextBoxCategoryName };
//                } else {
//                    changedValues[strChangeRow]["category_name"] = strTextBoxCategoryName;
//                }// if
//            }// if
            var len = changedValues.length;
            // リクエスト用配列作成・追加
            var changeFlag = false;
            // 更新前の追加した分類名がある場合、連想配列は追加に対して修正を行う
            if (beforeCategoryName) {
              for (var cnt = 0 ; cnt < addValues.length ; cnt++) {
                // 編集前の分類名でAddValuesを検索
                if (addValues[cnt]["category_name"] === beforeCategoryName) {
                  // 編集した内容で更新
                  addValues[cnt]["category_name"] = strTextBoxCategoryName;
                }
              }
            // 既存の分類名を編集した場合
            } else {
                for (var cnt = 0 ; cnt < len ; cnt++) {
                    if (changedValues[cnt]["category_id"] == strChangeRow) {
                    changedValues[cnt]["category_name"] = strTextBoxCategoryName;
                    changeFlag = true;
                    }//if
                }//for
                if (!changeFlag) {
                  var changedValue = {};
                    changedValue["category_id"] = strChangeRow;
                    changedValue["category_name"] = strTextBoxCategoryName;
                    changedValues[len] = changedValue;
                }
            }
            //テキストボックス化を解除する
            document.getElementById("changeCategoryName").outerHTML = strTextBoxCategoryName;

            //非アクティブ化状態に移行するため、クラスの削除
            document.getElementById('main_scroll_L').classList.remove("EditMode");
            document.getElementsByClassName("EditTable")[0].classList.remove("EditTable");

            return;
        }// if
    } else if (document.getElementsByClassName('addListTable').length > 0) {
        alert("現在新規作成中のため編集は行えません");
        return false;
    }// if
}// function

/**
 * 削除ボタン押下時に動作
 * 選択した行を削除する
**/
//グローバル変数
//DBデータの削除した項番
var deleteDBNo = [];

//行の削除を行う
function DeleteRow() {
    //行を選択していない場合、アラートを表示
    if (document.getElementById('selected') !== null) {
        //選択している行が編集中の場合、アラートを表示
        if (document.getElementById("selected").classList.contains("EditTable") !== true && document.getElementById("selected").classList.contains("AddTable") !== true) {
            //分類軸ID取得
            var strDeleteRow = $("#selected>li[style='display: none;']").text();
            console.log(strDeleteRow);
            //新規作成で表示されているリストの場合、classからリスト番号を取得
            var strAddDeleteRow = $("#selected")[0].textContent;
            // グローバル変数に値を設定するのは既存行の時のみ
            if (strDeleteRow) {
                console.log(changedValues);
                //グローバル変数に分類軸IDの値を設定する
                deleteDBNo.push(strDeleteRow);
                //連想配列の削除を行う
                for (var cnt = 0 ; cnt < changedValues.length ; cnt++) {
                    if (changedValues[cnt]["category_id"] == strDeleteRow) {
                        changedValues.splice(cnt, 1);
                    }
                }
            // 新規作成行の場合
            } else {
                console.log(addValues);
                for (var cnt = 0 ; cnt < addValues.length ; cnt++) {
                    if (addValues[cnt]["category_name"] == strAddDeleteRow) {
                        addValues.splice(cnt, 1);
                    }
                }
            }
//            if (changedValues[strDeleteRow]) {
//                delete changedValues[strDeleteRow];
//                if (addValues[strAddChangeRow]) {
//                    delete addValues[strAddChangeRow];
//                }// if
//            } else if (addValues[strAddChangeRow]) {
//                delete addValues[strAddChangeRow];
//            }// if

            //選択した行の削除
            $("#selected").remove();

        } else {
            alert("選択した行は現在編集中または、追加中のため削除できません。");
        }//if
    } else {
        alert("行を選択後、ボタンを押下してください");
    }// if
}// function

/**
 * キャンセルボタン押下時に動作
 * ダイアログを表示する
**/
function Cancel() {
    blCan = confirm("変更内容を破棄してもよろしいでしょうか。");
    if (blCan) {
        window.close();
    } else {
        return;
    }// if
}// function

/**
 * クリアボタン押下時に動作
 * ダイアログを表示する
**/
function Clear() {
    blCan = confirm("分類一覧設定と登録データ一覧の変更内容を破棄してもよろしいでしょうか。");
    if (blCan) {
        location.reload();
    } else {
        return;
    }// if
}// function

/**
 * 設定反映ボタン押下時に動作
 * 編集したカテゴリ一覧を登録処理する
 */
function Reflect() {
  var categoryList = $("#main_scroll_L")

  if (!Object.keys(addValues).length && !Object.keys(changedValues).length && !deleteDBNo.length) {
    alert("分類一覧は編集されていません。");
    return;
  }// if
  var jsonObj = new Object();

  if (Object.keys(addValues).length) {
    jsonObj.addValues = addValues;
  }
  if (Object.keys(changedValues).length) {
    jsonObj.changedValues = changedValues;
  }
  if (deleteDBNo.length) {
    jsonObj.deleteRow = deleteDBNo;
  }

  $.ajax({
    url: "/manege/training_category/category_reflect",
    type: "POST",
    contentType: "application/json",
    data: JSON.stringify(jsonObj),
    dataType: "json"
    // ajax通信成功時の処理
    }).done(function (data, textStatus, jqXHR) {
        let successOrFailure = "";
        console.log(jqXHR.status);
        // ajax通信失敗時の処理
    }).fail(function (jqXHR, textStatus, errorThrown) {
        alert("分類一覧の更新処理に失敗しました");
        console.log(jqXHR.status);
        // 成功でも失敗でも通信終了時に必要な処理があれば
    }).always(function () {
});
}