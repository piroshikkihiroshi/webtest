$(function () {

  /**
   * 画面が変更または閉じれる時に動作
   * ダイアログを表示する
   * messageboxで表示を行いたいが、検知の限界が存在する為「beforeunload」を使用する
   * 参考サイト：https://teratail.com/questions/51831
  **/
  $(window).on("beforeunload", function (e) {
    // POST送信フラグが「true」の場合、ダイアログを表示しない
    if (isPost) {
      return;
    } else {
      return true;
    }
  });

  /**
   * ×ボタン押下後に動作
   * 選択した行を削除する
   **/
  $('.DeleteRowTrainingPolicy').on('click', function (e) {
    //選択した行にIDを付与
    e.target.parentElement.setAttribute('id', 'selected');
    //選択した行の削除
    $("#selected").remove();
  });

  /**
   * ×ボタン押下後に動作
   * 動的に生成された選択した行を削除する
   **/
  $(document).on('click', '.NewDeleteRowTrainingPolicy', function (e) {
    //選択した行にIDを付与
    e.target.parentElement.setAttribute('id', 'selected');
    //選択した行の削除
    $("#selected").remove();

  });
});// function

/**
 * 出力ボタン押下時に動作
 * 一覧表に行の新規追加を行う
**/
function AddListData() {
  //現在の行数を取得
  var objAutoRowNo = document.getElementById("main_scroll_R").children.length + 1;
  strAutoRowNo = '' + objAutoRowNo;

  var successCount = 0;
  //テキストボックス内の文字列取得
  var strAddFilePassListText = document.getElementById("addFilePassList").value;

  //最上位行のプルダウンメニュー内容を取得
  var strPullDownMenuList = document.getElementsByClassName("menu")[0].innerHTML;

  //最上位行のstyleを取得
  var strFilePassStyle = document.getElementById("main_scroll_R").children[0].children[2].style.cssText;

  if (strAddFilePassListText !== "") {
    for (let index = 0; index < document.getElementById("main_scroll_R").children.length; index++) {
      var listFile = document.getElementById("main_scroll_R").children[index].children[2].outerText;
      if (listFile !== strAddFilePassListText) {
        successCount++;
      }
    }
    if (document.getElementById("main_scroll_R").children.length === successCount) {
      //新規作成する欄を作成
      var ul = $('<ul class="tr"></ul>');
      var strDeleteButton = $('<li class="w40 bt_batsu NewDeleteRowTrainingPolicy"></li>');
      var strPolicyPullDown = $('<li class="w100 menu dropdown_arrow_right" style="position: relative;"></li>');
      var strFilePassList = $('<li class="wAutoA B text_align_left" style="' + strFilePassStyle + '"></li>');

      //表に取得した値を挿入する
      $(".scrollBody").append(ul);
      ul.append(strDeleteButton).append(strPolicyPullDown).append(strFilePassList);
      strDeleteButton.html('');
      strPolicyPullDown.html(strPullDownMenuList);
      strFilePassList.html(strAddFilePassListText);

      //一覧追加用テキストボックスを空にする
      document.getElementById("addFilePassList").value = "";
    } else {
      alert("入力したディレクトリパスは既に設定済みです");
    }
  } else {
    alert("ディレクトリパスを入力後、再度ボタンを押下してください");
  }
}// function

/**
 * キャンセルボタン押下時に動作
 * ダイアログを表示する
**/
function Cancel() {
  blCan = confirm("変更内容を破棄してもよろしいでしょうか。");
  if (blCan) {
    window.close();
    sessionStorage.clear();
  } else {
    return;
  }// if
}// function
/**
 * 登録ボタン押下時に動作
 * コントローラーへDB更新データをPOSTする
 */
function postItem() {

  // TODO:入力チェック

  var savePath = $('#saveRegistrationList')[0].value;
  console.log(savePath);

  // TODO:保存先パスの入力チェック
  if (!savePath) {
    alert("保存先パスが入力されていません");
    return;
  }

  var test = $('.scrollBody')[0].children;
  //データ送信用
  var postData = {}
  // 送信データ列部
  var teacherPolicyList = [];
  for (let i = 0; i < test.length; i++) {
    // ポリシーID
    var policyData = {};
    var policyId = test[i].children[1].outerText;
    var path = test[i].children[2].textContent;
    // ユーザ名
    policyData['userId'] = 'user1';
    // ソードID
    policyData['sortId'] = i;
    // ポリシーID
    policyData['policyId'] = policyId;
    // 格納先パス
    policyData['directoryPath'] = path;
    teacherPolicyList[i] = policyData;
  }
  //送信データ生成
  postData['teacher_policy_list'] = teacherPolicyList;
  postData['savePath'] = savePath
  $("input[name='saveValue']").attr('value', JSON.stringify(postData));
  //POSTする前にisPostフラグをtrueにする
  isPost = true;
  //コントローラーへ更新データ送信
  $('form').submit();
}