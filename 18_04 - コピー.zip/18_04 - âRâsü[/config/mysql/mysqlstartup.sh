#!/bin/bash
service mysql start
mysql -u root -e "CREATE USER test@ IDENTIFIED BY 'Passw0rd'"
mysqladmin -u root password 'Passw0rd'
