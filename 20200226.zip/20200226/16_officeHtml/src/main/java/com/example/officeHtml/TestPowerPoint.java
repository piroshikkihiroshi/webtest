package com.example.officeHtml;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;
import org.zeroturnaround.zip.ZipUtil;

import com.aspose.pdf.Document;
import com.aspose.pdf.HtmlSaveOptions;
import com.aspose.pdf.LettersPositioningMethods;
import com.aspose.slides.FontData;
import com.aspose.slides.IParagraph;
import com.aspose.slides.IPortion;
import com.aspose.slides.IPortionFormatEffectiveData;
import com.aspose.slides.ISlide;
import com.aspose.slides.ISlideCollection;
import com.aspose.slides.ITextFrame;
import com.aspose.slides.Presentation;
import com.aspose.slides.SaveFormat;
import com.aspose.slides.SlideUtil;

/**
 * aspose変換ppt→html→pdfの変換テスト
 *
 */
public class TestPowerPoint {
	static Logger objLog = Logger.getLogger(TestPowerPoint.class);

	public static void main(String[] args) {
		try {
			tester();
		} catch (Exception e) {
			e.printStackTrace();
		} // try
	} // main

	public static void tester() throws Exception {

		//documentIdの指定
		int intDocumentId = 20;

		// ※※※※※svgタグができてしまい、pdf化時に落ちてしまうため、ppt→pdf→html→pdfの変換とする※※※※※

		//		String strDir = "/home/ueda/デスクトップ/PPT/";
		String strDir = "C:/Users/Public/Documents/test/PPT/";
		objLog.info("対象Directory：" + strDir);
		String strDirRet = strDir + "result/";
		objLog.info("対象Directory：" + strDir);
		objLog.info("結果格納Directory：" + strDirRet);
		makeDirWithCheck(strDirRet);

		//result保持用
		String strTmpDirRet = strDirRet;

		// Fileクラスのオブジェクトを生成する
		File dir = new File(strDir);

		// listFilesメソッドを使用して一覧を取得する
		File[] list = dir.listFiles();
		String dstHtmlFile = "";
		String dstPdfFile = "";
		String strFileName = "";

		String strRetFile = "ppt_" + String.valueOf(System.currentTimeMillis()) + ".csv";
		StringBuilder objSb = new StringBuilder(); // 結果格納用
		String strTmpRet = "";

		objLog.info("test start:" + String.valueOf(System.currentTimeMillis()));

		// headerを格納
		objSb.append("No,File名,HTML変換,SVG,PDF変換\r\n");
		int intCnt = 0;
		for (int i = 0; i < list.length; i++) {
			if (!list[i].isFile())
				continue;
			strFileName = list[i].getName();
			String strExtension = strFileName.substring(strFileName.lastIndexOf(".") + 1, strFileName.length());
			if (strExtension.equals("ppt") || strExtension.equals("pptx") || strExtension.equals("pptm")) {
				intCnt++;

				//変更必要
				strTmpDirRet = strDirRet;
				strDirRet += strFileName.substring(0, strFileName.lastIndexOf(".")) + "/";
				makeDirWithCheck(strDirRet);

				strTmpRet = intCnt + "," + strFileName + ",";
				dstHtmlFile = strFileName.substring(0, strFileName.lastIndexOf(".")) + ".html";

				// 一度PDF変換をかませる
				String dstPdfTmp = strFileName.substring(0, strFileName.lastIndexOf(".")) + "_tmp.pdf";
				String dstPptTmp = strFileName.substring(0, strFileName.lastIndexOf(".")) + "_tmp.pptx";
				dstPdfFile = strFileName.substring(0, strFileName.lastIndexOf(".")) + ".pdf";

				/* PPT→HTML convert start */
				objLog.info("対象ファイル：" + strFileName);
				objLog.info("PPT→PDF convert start");

				// PowerPointファイルの読み込み
				Presentation presentation = new Presentation(strDir + strFileName);
				try {

					// 図形の処理
					ISlideCollection iSlideCollection = presentation.getSlides();
					for (int j = 0; j < iSlideCollection.size(); j++) {
						ISlide iSlide = iSlideCollection.get_Item(j);
						ITextFrame[] textFramesSlideOne = SlideUtil.getAllTextBoxes(iSlideCollection.get_Item(j));

						// Loop through the Array of TextFrames
						for (int k = 0; k < textFramesSlideOne.length; k++) {
							//							textFramesSlideOne[0].getParagraphs().get_Item(0).getParagraphFormat().getDefaultPortionFormat().getFontHeight();
							// Loop through paragraphs in current TextFrame
							for (IParagraph para : textFramesSlideOne[k].getParagraphs()) {
								// Loop through portions in the current Paragraph
								for (IPortion port : para.getPortions()) {

									if (Float.isNaN(port.getPortionFormat().getFontHeight())) {
										IPortionFormatEffectiveData formateffect = port.createPortionFormatEffective();
										float height = formateffect.getFontHeight();
										port.getPortionFormat().setFontHeight((float) (height * 0.7));
									} else {
										float height = port.getPortionFormat().getFontHeight();
										port.getPortionFormat().setFontHeight((float) (height * 0.7));
									}

									port.getPortionFormat().setEastAsianFont(new FontData("VL PGothic"));
									port.getPortionFormat().setLatinFont(new FontData("VL PGothic"));

								} //for

							} //for

						} //for

					} // for
						// PowerPointのHTML変換
					presentation.save(strDirRet + dstPptTmp, SaveFormat.Pptx);
					if (presentation != null)
						presentation.dispose();

					Presentation presentation2 = new Presentation(strDirRet + dstPptTmp);

					// PowerPointのHTML変換
					presentation2.save(strDirRet + dstPdfTmp, SaveFormat.Pdf);
					if (presentation2 != null)
						presentation2.dispose();

					objLog.info("PPT→PDF convert OK");
				} catch (Exception e) {
					objLog.error("PPT→PDF convertでエラー発生");
					strTmpRet += "×,-,-,\r\n";
					objSb.append(strTmpRet);
					continue;
				} // try

				objLog.info("PPT→PDF convert end");

				objLog.info("PDF→HTML convert start");

				// PowerPointファイルの読み込み

				try {
					Document pdf = new Document(strDirRet + dstPdfTmp);

					HtmlSaveOptions newOptions = new HtmlSaveOptions();
					// SaveOption設定
					newOptions.LettersPositioningMethod = LettersPositioningMethods.UseEmUnitsAndCompensationOfRoundingErrorsInCss;
					newOptions.FontSavingMode = HtmlSaveOptions.FontSavingModes.AlwaysSaveAsEOT;

					String strOs = System.getProperty("os.name").toLowerCase();
					if (strOs.indexOf("windows") >= 0) {
						newOptions.setDefaultFontName("MS Gothic");
					} else {
						newOptions.setDefaultFontName("VL Gothic");
					} // if

					pdf.save(strDirRet + dstHtmlFile, newOptions);
					objLog.info("PDF→HTML convert OK");
				} catch (Exception e) {
					objLog.error("PDF→HTML convertでエラー発生");
					strTmpRet += "×,-,-,\r\n";
					objSb.append(strTmpRet);
					continue;
				} // try
				if (presentation != null)
					presentation.dispose();

				strTmpRet += "○,";

				objLog.info("PDF→HTML convert end");

				// style.cssを整形する
				objLog.info("style.css Shape Start");
				shapeStyleCss(strDirRet + strFileName.substring(0, strFileName.lastIndexOf(".")) + "_files/style.css");
				objLog.info("style.css Shape End");

				// shape html
				shapeTgtHtml(strDirRet + dstHtmlFile);

				//DBinsert
				Statement stmt = null;
				ResultSet objRs = null;
				//DB設定読み込み
				try {
					ResourceBundle objRb = null;
					objRb = ResourceBundle.getBundle("config/setting");
					String strUrl = objRb.getString("url");
					String strUsername = objRb.getString("username");
					String strPassword = objRb.getString("password");
					String strDriverClassName = objRb.getString("driverClassName");

					// クラスのロード
					Class.forName(strDriverClassName);

					// コネクションの取得
					Connection conn = DriverManager.getConnection(strUrl, strUsername, strPassword);

					// zipに固める
					String strZipOut = strDirRet + "mask.zip";
					ZipUtil.pack(new File(strDirRet), new File(strZipOut));

					// zipをbyte配列にする
					byte[] byteZip = null;
					File objZipFile = null;
					objZipFile = new File(strZipOut);
					byteZip = Files.readAllBytes(objZipFile.toPath());

					//query exec
					String sql = "";


					PreparedStatement pstmt = null;
					Date date = new Date(0, 0, 0);
					//存在確認
					sql = "SELECT COUNT(document_id) cnt FROM common.document_info WHERE document_id=" + (intDocumentId+intCnt);
					objRs = stmt.executeQuery(sql);
					objRs.next();

					if (objRs.getInt("cnt") == 1) { //delete →insert
						System.out.println("document_id" + intDocumentId + "が存在するのでDelete→Insert");
						sql = "DELETE FROM common.document_info WHERE document_id=" + (intDocumentId+intCnt);
						stmt.executeUpdate(sql);
						sql = "DELETE FROM common.document_info_internal WHERE document_id=" + (intDocumentId+intCnt);
						stmt.executeUpdate(sql);
					} //if

					sql = "INSERT INTO common.document_info(document_id, document_contents, html_zip_data, server_id , document_name, extension, document_size  , parent_id , file_path, marker , category_id , procenter_flg , procenter_parent_id , node_id , retention_period , author , updater , authorizer , file_update_time , mask_status , create_time , update_time) VALUES (  ? ,1,? , 1,? , ?  , 0 , 0 , ?, null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 , null , null);";
					pstmt = conn.prepareStatement(sql);
					pstmt.setInt(1, (intDocumentId+intCnt));
					pstmt.setBytes(2, byteZip);
					pstmt.setString(3, "test.pptx");
					pstmt.setString(4, "pptx");
					pstmt.setString(5, strDir + strFileName);
					pstmt.executeUpdate();

					if (objRs != null)
						objRs.close();

					//存在確認
					sql = "SELECT COUNT(document_id) cnt FROM common.document_info_internal WHERE document_id="
							+ (intDocumentId+intCnt);
					objRs = stmt.executeQuery(sql);
					objRs.next();

					if (objRs.getInt("cnt") == 1) { //delete →insert
						System.out.println("document_id" + (intDocumentId+intCnt) + "が存在するのでDelete→Insert");
						sql = "DELETE FROM common.document_info WHERE document_id=" + (intDocumentId+intCnt);
						stmt.executeUpdate(sql);
						sql = "DELETE FROM common.document_info_internal WHERE document_id=" + (intDocumentId+intCnt);
						stmt.executeUpdate(sql);
					} //if

					sql = "INSERT INTO common.document_info_internal(document_id, document_contents, html_zip_data, server_id , document_name, extension, document_size  , parent_id , file_path, marker , category_id , procenter_flg , procenter_parent_id , node_id , retention_period , author , updater , authorizer , file_update_time , mask_status ,crawl_act_time,document_update_flg,document_delete_flg, create_time , update_time) VALUES (  ? ,1,? , 1,? , ?  , 0 , 2 , ?, null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 ,?,false,true, null , null);";
					pstmt = conn.prepareStatement(sql);
					pstmt.setInt(1, (intDocumentId+intCnt));
					pstmt.setBytes(2, byteZip);
					pstmt.setString(3, "test.pptx");
					pstmt.setString(4, "pptx");
					pstmt.setString(5, strDir + strFileName);
					pstmt.setDate(6, date);
					pstmt.executeUpdate();

					System.out.println("insert ok");
				} catch (Exception e) {
					System.out.println("insert ng");
					throw e;
				} finally {
					if (stmt != null) {
						stmt.close();
						stmt = null;
					}
					if (objRs != null) {
						objRs.close();
						objRs = null;
					} //if
				}

			} // if

		} // for
		File newfile = new File(strDirRet + "/" + strRetFile);
		PrintWriter filewriter = new PrintWriter(
				new BufferedWriter(new OutputStreamWriter(new FileOutputStream(newfile), "Shift-JIS")));
		filewriter.write(objSb.toString());
		filewriter.close();
		objLog.info("test end:" + String.valueOf(System.currentTimeMillis()));

	} // tester

	/**
	 * strpath_iで指定したファイルを改行なしですべて読み込む
	 *
	 * @param strpath_i
	 * @return 読み込んだ文字列
	 * @throws IOException
	 */
	public static String readAll(final String strpath_i) throws IOException {
		Path file = Paths.get(strpath_i);
		List<String> list = Files.readAllLines(file, Charset.forName("UTF-8"));
		StringBuilder objSb = new StringBuilder();
		for (int i = 0; i < list.size(); i++) {
			objSb.append(list.get(i));
		}
		file = null;
		return objSb.toString();

	} // readAll

	/**
	 * ディレクトリを作成する。
	 *
	 * @param strDirPath_i 作成ディレクトリパス
	 * @return 成否ステータス（0以外は失敗）
	 */
	public static int makeDirWithCheck(String strDirPath_i) {

		// strDirPath_iの長さが10未満なら処理しない(フェールセーフ)
		if (strDirPath_i.length() <= 10) {
			return -2;
		} // if

		objLog.info("対象フォルダ：" + strDirPath_i);

		File objTgtDir = new File(strDirPath_i);
		if (!objTgtDir.exists()) {

			if (objTgtDir.mkdir()) {
				objLog.info("フォルダの作成に成功しました");
			} else {
				objLog.info("フォルダの作成に失敗しました");
				return -1;
			} // it
		} // if
		return 0;
	} // method

	/**
	 * html shaping
	 *
	 * @param strpath_i
	 * @return 読み込んだ文字列
	 * @throws IOException
	 */
	public static String shapeTgtHtml(final String strCsspath_i) throws IOException {
		Path file = Paths.get(strCsspath_i);
		List<String> list = Files.readAllLines(file, Charset.forName("UTF-8"));
		StringBuilder objSb = new StringBuilder();
		for (int i = 0; i < list.size(); i++) {
			String strTmp = list.get(i);
			// visibility: hidden;対応
			if (strTmp.contains("visibility:hidden;")) {
				strTmp = strTmp.replaceAll("visibility:hidden;", "visibility: visible;");
			} // if
			//			if (strTmp.contains("font-weight:bold;")) {
			//				strTmp = strTmp.replaceAll("font-weight:bold;", "font-weight: normal;");
			//			} // if
			objSb.append(strTmp + "\r\n");
		} // for
		File newfile = new File(strCsspath_i);
		PrintWriter filewriter = new PrintWriter(
				new BufferedWriter(new OutputStreamWriter(new FileOutputStream(newfile), "UTF-8")));
		filewriter.write(objSb.toString());

		if (filewriter != null)
			filewriter.close();
		filewriter = null;

		return objSb.toString();

	} // readAll

	/**
	 * style.cssを整形する
	 *
	 * @param strpath_i
	 * @return 読み込んだ文字列
	 * @throws IOException
	 */
	public static String shapeStyleCss(final String strCsspath_i) throws IOException {
		Path file = Paths.get(strCsspath_i);
		List<String> list = Files.readAllLines(file, Charset.forName("UTF-8"));
		StringBuilder objSb = new StringBuilder();
		for (int i = 0; i < list.size(); i++) {
			String strTmp = list.get(i);
			if (strTmp.matches("\tfont-size: .*")) {
				float intFontSize = Float.parseFloat(strTmp.replace("font-size:", "").replace("em;", "").trim());
				intFontSize -= 0.01;
				//				intFontSize -= 0.1;
				strTmp = "	font-size: " + intFontSize + "em;";
			} else if (strTmp.matches("\tline-height: .*")) {
				float intLineHeight = Float.parseFloat(strTmp.replace("line-height:", "").replace("em;", "").trim());
				//				intLineHeight += 0.5;
				strTmp = "	line-height: " + intLineHeight + "em;";
			} else if (strTmp.matches("\tfont-family: .*")) {
				//				strTmp = "	font-family: \"VL PGothic\";";
				strTmp = "	font-family: \"VL Gothic\";";
			} // if
			objSb.append(strTmp + "\r\n");
		} // for
		File newfile = new File(strCsspath_i);
		PrintWriter filewriter = new PrintWriter(
				new BufferedWriter(new OutputStreamWriter(new FileOutputStream(newfile), "UTF-8")));
		filewriter.write(objSb.toString());

		if (filewriter != null)
			filewriter.close();

		return objSb.toString();

	} // readAll

}