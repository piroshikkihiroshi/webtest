package com.example.officeHtml;

import java.io.File;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import org.zeroturnaround.zip.ZipUtil;

import com.aspose.cells.PdfSaveOptions;
import com.aspose.cells.Workbook;
import com.aspose.pdf.Document;
import com.aspose.pdf.HtmlSaveOptions;
import com.aspose.pdf.LettersPositioningMethods;


public class TestExcel_bk_20200225 {
	public static void main(String[] args) {
		try {
			connectionTest();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * コネクションの取得
	 *
	 * @throws Exception
	 *             実行時例外
	 */
	public static void connectionTest() throws Exception {
		Connection conn = null;

		try {


			//DB設定読み込み
			ResourceBundle objRb=null;
			objRb=ResourceBundle.getBundle("config/setting");
			String strUrl=objRb.getString("url");;
			String strUsername=objRb.getString("username");;
			String strPassword=objRb.getString("password");;
			String strDriverClassName=objRb.getString("driverClassName");;

			// クラスのロード
			Class.forName(strDriverClassName);

			// コネクションの取得
			conn = DriverManager.getConnection(strUrl, strUsername, strPassword);
			// insertのテスト
			insertTest(conn);

			System.out.println("success");
		} catch (Exception e) {
			System.out.println("fail");
			throw e;
		} finally {
			if (conn != null) {
				conn.close();
			}
		}
	}

	/**
	 * データ取得テスト
	 *
	 * @param conn
	 *            コネクション
	 * @throws Exception
	 */
	public static void insertTest(Connection conn) throws Exception {
		Statement stmt = null;
		ResultSet objRs = null;
		try {

			// ステートメントの作成
			stmt = conn.createStatement();

			// srcDoc : 変換するPowerPointファイルのパス
			String srcDoc = "C:/Users/Public/Documents/test/test.xlsx";

			// dstDoc : 変換語のHTMLファイルのパス
//			String dstDoc = "C:/Users/Public/Documents/test/test01/test.html";

			String dstTmpPdf = "C:/Users/Public/Documents/test/test01/tmp_.pdf";
			String dstDoc = "C:/Users/Public/Documents/test/test01/test.html";

			/* excel→PDF convert start */
			Workbook book = new Workbook(srcDoc);
			PdfSaveOptions pdfSaveOptions = new PdfSaveOptions();
			book.save(dstTmpPdf, pdfSaveOptions);
			if (book != null)
				book.dispose();

			/* PDF→html convert start */
			try {
				Document pdf = new Document(dstTmpPdf);

				HtmlSaveOptions newOptions = new HtmlSaveOptions();
				//SaveOption設定
				newOptions.LettersPositioningMethod = LettersPositioningMethods.UseEmUnitsAndCompensationOfRoundingErrorsInCss;
				newOptions.FontSavingMode = HtmlSaveOptions.FontSavingModes.AlwaysSaveAsEOT;

				String strOs = System.getProperty("os.name").toLowerCase();
				if (strOs.indexOf("windows") >= 0) {
					newOptions.setDefaultFontName("MS Gothic");
				} else {
					newOptions.setDefaultFontName("VL Gothic");
				} //if

				pdf.save(dstDoc, newOptions);
			} catch (Exception e) {
				System.err.println(e);
			} //try


			// dstDoc : 変換語のHTMLファイルのパス
			String strFileOutDir = "C:\\Users\\Public\\Documents\\test\\test01";

			// zipに固める
			String strZipOut = "C:/Users/Public/Documents/mask01.zip";
			ZipUtil.pack(new File(strFileOutDir), new File(strZipOut));

			// zipをbyte配列にする
			byte[] byteZip = null;
			File objZipFile = null;
			objZipFile = new File(strZipOut);
			byteZip = Files.readAllBytes(objZipFile.toPath());

			//query exec
			Date date = new Date(0, 0, 0);
			String sql = "";
			int intDocumentId=5;
			PreparedStatement pstmt = null;
			//存在確認
			sql = "SELECT COUNT(document_id) cnt FROM common.document_info WHERE document_id=" + intDocumentId;
			objRs = stmt.executeQuery(sql);
			objRs.next();

			if(objRs.getInt("cnt")==1) { //delete →insert
				System.out.println("document_id"+intDocumentId+"が存在するのでDelete→Insert");
				sql = "DELETE FROM common.document_info WHERE document_id=" + intDocumentId;
				stmt.executeUpdate(sql);
			} //if
			objRs.close();

			sql = "INSERT INTO common.document_info(document_id, document_contents, html_zip_data, server_id , document_name, extension, document_size  , parent_id , file_path, marker , category_id , procenter_flg , procenter_parent_id , node_id , retention_period , author , updater , authorizer , file_update_time , mask_status , create_time , update_time) VALUES (  ? ,1,? , 1,? , ?  , 0 , 30 , ?, null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 , null , null);";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, intDocumentId);
			pstmt.setBytes(2, byteZip);
			pstmt.setString(3, "test.xlsx");
			pstmt.setString(4,"xlsx");
			pstmt.setString(5, srcDoc);
			pstmt.executeUpdate();

			sql = "SELECT COUNT(document_id) cnt FROM common.document_info_internal WHERE document_id=" + intDocumentId;
			objRs = stmt.executeQuery(sql);
			objRs.next();

			if(objRs.getInt("cnt")==1) { //delete →insert
				System.out.println("document_id"+intDocumentId+"が存在するのでDelete→Insert");
				sql = "DELETE FROM common.document_info_internal WHERE document_id=" + intDocumentId;
				stmt.executeUpdate(sql);
			} //if

			sql = "INSERT INTO common.document_info_internal(document_id, document_contents, html_zip_data, server_id , document_name, extension, document_size  , parent_id , file_path, marker , category_id , procenter_flg , procenter_parent_id , node_id , retention_period , author , updater , authorizer , file_update_time , mask_status ,crawl_act_time,document_update_flg,document_delete_flg, create_time , update_time) VALUES (  ? ,1,? , 1,? , ?  , 0 , 2 , ?, null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 ,?,false,true, null , null);";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, intDocumentId);
			pstmt.setBytes(2, byteZip);
			pstmt.setString(3, "test.pptx");
			pstmt.setString(4,"pptx");
			pstmt.setString(5, srcDoc);
			pstmt.setDate(6, date);
			pstmt.executeUpdate();

			System.out.println("InsertTest_OK");
		} catch (Exception e) {
			System.out.println("InsertTest_NG");
			System.err.println(e);
			throw e;
		} finally {
			if (stmt != null) {
				stmt.close();
				stmt = null;
			} //if
			if (objRs != null) {
				objRs.close();
				objRs = null;
			} //if
		} //try
	} //method
} //class
