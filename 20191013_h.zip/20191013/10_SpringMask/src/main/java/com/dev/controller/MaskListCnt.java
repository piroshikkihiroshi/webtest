package com.dev.controller;
import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.dev.model.Aspose.AsposeWordModel;
import com.dev.model.dirFile.DirCnt;
import com.dev.model.dirFile.FileCnt;
import com.dev.model.maskHtml.MaskHtmlModel;

@Controller
public class MaskListCnt {

	@Autowired
	ServletContext context;

	@PostMapping("/MaskListCnt")
	public String getblackTextTest(@RequestParam("editMask") String strEditMask_i,Model model) {

		FileCnt objFileCnt = new FileCnt();
		DirCnt objDilCnt = new DirCnt();
		AsposeWordModel objAspCls = new AsposeWordModel();
		MaskHtmlModel  objMaskCls = new MaskHtmlModel();





		return "maskedit/MaskListVeiw";
	} //getView1

} //MaskHtmlCnt
