//定数等
const TAG_RED = "tagRed";
const TAG_MASK = "tagMsk";

const STATE_MASK = 1;
const STATE_RED = 2;
const MASK_MSG = "■";
const MASK_BF = "<span class='tagMsk' id='msk";
const MASK_BF_INIT= "<span class='tagMsk tagMskInit' id='msk";
const MASK_BF_END= "<span class='tagMsk tagMskEnd' id='msk";
const RED_BF = "<span class='tagRed' id='red";
const RED_BF_INIT= "<span class='tagRed tagRedInit' id='red";
const RED_BF_END= "<span class='tagRed tagRedEnd' id='red";
const MASK_END_CLS="tagMskEnd";
const RED_END_CLS="tagRedEnd";
const MASK_AF = "</span>";
const RED_AF = "</span>";
const MASK_INIT_CLS="tagMskInit";
const RED_INIT_CLS="tagRedInit";

const NODE_CROSS = 1;
const SPACE_MARK = '&nbsp;';
const REG_TAG_VAL_SPLIT = "(<\\/?[^>]+>)|([^<]+)";
const NOMAL_MENU = 1;
const MASK_MENU = 2;

const ID_OFFSET = 4;
const ELEMENT_NODE_TYPE= 1;
const TEXT_NODE_TYPE= 3;
const EDIT_ABLE="btn-success"

/**
 グローバル変数 
*/
var glObjRedFlame;
var glObjRedBody;
var glObjMaskFlame;
var glObjMaskBody;
var glContextDom;

var glActContext;
//暫定で100000 余裕があればAIのマスク連番(サーバサイド処理)と合わせる
var glIdCnt = 100000;
var glActBfId="";
var glActAfId="";
var glObjRange;
var glSelectIinitId;
var glSelectEndId;
var glarrRepOrgOuter=[];
var glarrRepOuter=[];
var glarrMaskOrgOuter=[];
var glarrMaskOuter=[];
var glNewRangeFlg=false;
var glchngeRangeOrg="";
var glChngeRangeInitPos=0;
var glChngeRangeEndPos=0;

//暫定で110000 余裕があればAIのマスク連番(サーバサイド処理)と合わせる
var glMaskIdCnt = 110000;
var glRedIdCnt = 110000;


/**
* HTMLのchar毎の情報を格納するクラス
* HashMap<Integer, HtmlStructure> の形で格納し、keyは置換対象外文字やtagを含んだポジション
* (<div>タグ等を含む)を格納する
*/
class HtmlStructure {
    strTgt = ""; //対象文字
    intPage = 0; //Page
    intStatus = 0; //strTgtのステータス 0：置換対象外(半角文字等) 1：対象 2：tag
    intNotTagPos = 0; //置換対象外文字やtagを抜いたときのポジション		
} //class

/**
* strの文字列をbeforeStrをafterStrに全置換する
* @return 置換文字列
*/
function replaceAll(str, beforeStr, afterStr) {
    var reg = new RegExp(beforeStr, "g");
    return str.replace(reg, afterStr);
} //function

/**
 * 半角記号を全角スペースにする
 * @param strTgt_i
 * @return 置換後のストリング
 */
function replaceHalfSpace(strTgt_i){
    var strReplace = replaceAll(strTgt_i,SPACE_MARK,"　");
    return strReplace;
} //function

/**
* 全てのタグにIDを付与する(もともとIDある場合未考慮)
*/
function allIdPut(objTgtDom_i, strTagName_i) {
    objTgtDom_i.setAttribute("id", strTagName_i + glIdCnt);
    glIdCnt++;
    for (var index = glIdCnt; index < objTgtDom_i.childElementCount; index++) {
        var objActDom = objTgtDom_i.children[index];
        objActDom.setAttribute("id", strTagName_i + index);
        glIdCnt++;
    } // for	
    if (objTgtDom_i.childElementCount != 0) {
        for (var index = 0; index < objTgtDom_i.childElementCount; index++) {
            var objActDom = objTgtDom_i.children[index];
            allIdPut(objActDom, strTagName_i);
        } // for	
    }//if		
} //function

/**
* bodyの構造体hashを取得
* @param strOrgBody_i
* @return HtmlStructureのハッシュ
*/
function getBodyStructure(strOrgBody_i) {
    var strTgtVal = strOrgBody_i;

    var hashRetStructure = {};
    var listLastNotTagPos = []; //intNotTagPosを格納していく
    var strRegrep = REG_TAG_VAL_SPLIT; //タグとタグを除いた値をグループで取得する
    var objPattern = new RegExp(strRegrep, "g");
    var strCurrentKwd = ""; //現在ヒットしている単語
    var intCurrentPos = 0;
    var objRegRet;
    while ((objRegRet = objPattern.exec(strTgtVal)) != null) {
        strCurrentKwd = objRegRet[2];
        if (strCurrentKwd == undefined) { //タグの処理
            strCurrentKwd = objRegRet[1];
            searchAnalysis(hashRetStructure, listLastNotTagPos, strCurrentKwd, intCurrentPos, 2);
        } else if (strCurrentKwd == " " ||strCurrentKwd == "　" || strCurrentKwd == SPACE_MARK) { //スペース処理
            searchAnalysis(hashRetStructure, listLastNotTagPos, strCurrentKwd, intCurrentPos, 0);
            continue; //スペースはそのまま格納
        } else if (Boolean(strCurrentKwd.match(/^\t$|^\v$|^\n$|^\r$|^\f$/g))) { //特殊記号処理(特殊記号のみの場合のみ処理)        
            searchAnalysis(hashRetStructure, listLastNotTagPos, strCurrentKwd, intCurrentPos, 0);
            continue; //特殊記号処理はそのまま格納            
        } else { //通常文字
            searchAnalysis(hashRetStructure, listLastNotTagPos, strCurrentKwd, intCurrentPos, 1);
        } //if
        intCurrentPos = Object.keys(hashRetStructure).length;

    }  //while

    return hashRetStructure;
} //function

/**
* 検索結果からbodyの構造体hashを作成する
* @param HashMap<Integer, HtmlStructure> hashRetStructure_i 参照渡しのハッシュ
* HtmlStructureはHTMLのchar毎の情報を格納するクラス
* HashMap<Integer, HtmlStructure> の形で格納し、keyは置換対象外文字やtagを含んだポジション(<div>タグ等を含む)を格納する
* @param strCurrentKwd_i 現在正規表現でヒットしている文字列
* @param intCurrentPos_i タグを含めた現在のposition
* @param intStatus_i 0：置換対象外(半角文字等) 1：対象 2：tag
*/
function searchAnalysis(hashRetStructure_i, listLastNotTagPos_i, strCurrentKwd_i, intCurrentPos_i, intStatus_i) {
    var intCntPos = Object.keys(hashRetStructure_i).length;
    var intNotTagPos = 0;
    objHtmlStructure = null;
    var arrTmp = strCurrentKwd_i.split("");
    var strTgt = "";

    if (listLastNotTagPos_i.length != 0) { //tag抜き文字の最終を取得する
        intNotTagPos = listLastNotTagPos_i[listLastNotTagPos_i.length - 1];
    } //if

    for (var i = 0; i < arrTmp.length; i++) {
        objHtmlStructure = new HtmlStructure();
        strTgt = arrTmp[i];
        objHtmlStructure.strTgt = strTgt;
        objHtmlStructure.intStatus = intStatus_i;
        if (intStatus_i == 1) { //通常文字はintNotTagPosをカウント
            intNotTagPos++;
            objHtmlStructure.intNotTagPos = intNotTagPos;
        } //if
        hashRetStructure_i[intCntPos + (i + 1)] = objHtmlStructure;
    } //for

    if (intStatus_i == 1) { //通常時はtag抜き文字の最終を格納
        listLastNotTagPos_i.push(intNotTagPos);
    } //if
} //function

/**
 * 全文検索エンジンに返した結果を置換してbodyを入れ替え、または赤文字変換した文字列を取得
 * @param hashBodyStructure_i HTMLのchar毎の情報を格納するクラスを格納したhash key：HTMLのindex : val HTMLのchar(index)毎の情報を格納するクラス
 * @param intMaskStatus_i 置換ステータス :マスク 2:赤文字
 * @return 置換したBody文字列
 */
function bodyCharChange(hashBodyStructure_i, intMaskStatus_i) {
    var strRepBody = "";
    var intStatus = 0;
    var blFlag = true;
    var intIndCnt=Object.keys(hashBodyStructure_i).length;
    for (var i = 1; i < Object.keys(hashBodyStructure_i).length + 1; i++) {
        var objHtmlStructure = hashBodyStructure_i[i];
        intStatus = objHtmlStructure.intStatus;
        intNotTagPos = objHtmlStructure.intNotTagPos;
        if (intStatus == 1) { //通常文字の場合
            if (intMaskStatus_i == 1 && blFlag) { //初期だけ特別クラス
                strRepBody += MASK_BF_INIT + glMaskIdCnt + "'>" + MASK_MSG + MASK_AF; //マスク
                blFlag=false;
                glMaskIdCnt++;
            } else if (blFlag) { //初期だけ特別クラス
                strRepBody += RED_BF_INIT + glRedIdCnt + "'>" + objHtmlStructure.strTgt + RED_AF; //赤塗り
                blFlag=false;
                glRedIdCnt++;
            } else if (intMaskStatus_i == 1 && i==intIndCnt) { //最後も特別クラス
                strRepBody += MASK_BF_END + glMaskIdCnt + "'>" + MASK_MSG + MASK_AF; //マスク
                blFlag=false;
                glMaskIdCnt++;
            } else if (i==intIndCnt) { //最後も特別クラス
                strRepBody += RED_BF_END + glRedIdCnt + "'>" + objHtmlStructure.strTgt + RED_AF; //赤塗り
                blFlag=false;
                glRedIdCnt++;
            }else if (intMaskStatus_i == 1) {
                strRepBody += MASK_BF + glMaskIdCnt + "'>" + MASK_MSG + MASK_AF; //マスク
                glMaskIdCnt++;
            } else {
                strRepBody += RED_BF + glRedIdCnt + "'>" + objHtmlStructure.strTgt + RED_AF; //赤塗り
                glRedIdCnt++;
            } //if

        } else { //その他の場合そのまま出力する
            strRepBody += objHtmlStructure.strTgt;
        } //if
    } //for
    return strRepBody;
} //function


/**
* 引数の文字列をtagとそれ以外に分割する
*/
function splitTagArr(strTgtVal_i, arrTag_i, arrNotTag_i) {
    var strTgtVal = strTgtVal_i;
    var strRegrep = REG_TAG_VAL_SPLIT; //タグとタグを除いた値をグループで取得する
    var objPattern = new RegExp(strRegrep, "g");
    var strCurrentKwd = ""; //現在ヒットしている単語
    var objRegRet;
    while ((objRegRet = objPattern.exec(strTgtVal)) != null) {
        strCurrentKwd = objRegRet[2];
        if (strCurrentKwd == undefined) { //タグ
            strCurrentKwd = objRegRet[1];
            arrTag_i.push(strCurrentKwd);
            arrNotTag_i.push(""); //indexを合わせるために空文字を挿入
        } else { //通常文字
            arrTag_i.push("");//indexを合わせるために空文字を挿入
            arrNotTag_i.push(strCurrentKwd);
        } //if
    }  //while
} //function

/**
* 引数の文字列の最終がタグか判定する
* @return tag:true tag以外 false
*/
function isLastTag(strTgtVal_i) {
    var strTgtVal = strTgtVal_i;
    var strRegrep = REG_TAG_VAL_SPLIT; //タグとタグを除いた値をグループで取得する
    var objPattern = new RegExp(strRegrep, "g");
    var strCurrentKwd = ""; //現在ヒットしている単語
    var objRegRet;
    var blRet = false;
    while ((objRegRet = objPattern.exec(strTgtVal)) != null) {
        strCurrentKwd = objRegRet[2];
        if (strCurrentKwd == undefined) { //タグ
            blRet = true;
        } else { //通常文字
            blRet = false;
        } //if
    }  //while
    return blRet;
} //function

/**
* マスク候補IFlame内の選択指定している範囲のbodyInnerHtmlからの距離を返す
* @return 0:intInitPartPos,1:intEndPartPosの配列
*/
function getSelectionInnerPos(){

    //選択されていなかったらreturn
    if (glObjRedFlame.getSelection().toString() == "") {
        return;
    } //if

    var objSelection = glObjRedFlame.getSelection(); // 選択範囲のオブジェクト取得
    var objTgtRange = objSelection.getRangeAt(0); //rangeを取得
    var objInitDom;
    var objEndDom;
    var strInnerBody = glObjRedFlame.body.innerHTML;
    /**
    * memo Dom横断の場合のobjTgtRange.startOffset,objTgtRange.endOffsetの挙動
    *「objTgtRange.startContainer.wholeText」から何文字OffsetしたかがobjTgtRange.startOffset
    *「objTgtRange.endContainer.wholeText」から何文字OffsetしたかがobjTgtRange.endOffset
    *また、wholeTextはDOMのinnerTextと一致するのでそこから捜索する
    */

    //部分文字列の前半取得
    var objInitDom = glObjRedFlame.getElementById(glSelectIinitId)
    var objInitParentDom = glObjRedFlame.getElementById(glSelectIinitId)

    var intInitChildCnt = objInitDom.childElementCount;
    var objInitNode = objSelection.anchorNode;//Selectionのアンカーとは、選択の開始点
    var objPrevDom = objInitNode.previousSibling;
    var blChildFlg = false;
    var blChildFind = false;
    
    if (intInitChildCnt>0 && (objPrevDom!=null)) { //子要素がある場合かつ前のdomが無い
        var objTmpNode;
        var objExpectDom; //OFFSET開始位置予想dom
        blChildFlg = true;

        for (var i = 0; i < objInitDom.childNodes.length; i++) {
            objTmpNode = objInitDom.childNodes[i];
            if (objTmpNode.nodeType==TEXT_NODE_TYPE) {
                continue;
            } //if
            if (objTmpNode.getAttribute("class").indexOf(RED_END_CLS)>0) {
                objExpectDom=objTmpNode;
                //rangeのoffcet対象Domか判定
                var objChkNode=objInitDom.childNodes[i+1];
                var strChkVal=objChkNode.wholeText.substring(objTgtRange.startOffset,objChkNode.wholeText.length);
                // if(objTgtRange.toString().indexOf(strChkVal)>=0){
                if(strChkVal.indexOf(objTgtRange.toString())>=0){
                    objInitDom=objExpectDom;
                    // blChildFlg = true;
                    blChildFind=true;
                    break;
                } //if
            }//if
        } //for
    } //if
    //子がいるのに見つからなかった場合、中途半端な文字列なのでobjInitDom.childNodesの最後のDomとなる
    if (blChildFlg&&(!blChildFind)) { 
        objInitDom=objInitDom.children[objInitDom.childElementCount-1];
    } //if

    var strInitInner = objInitParentDom.innerHTML.toString();
    var strInitOuter = objInitParentDom.outerHTML.toString();
    var intChildOffcet=0;
    var intInitOutPos;
    var intInitPartPos;    
    if (blChildFlg) { //子要素がある場合
        var intChildOffcet = strInitOuter.indexOf(objInitDom.outerHTML) + objInitDom.outerHTML.length;
        strInitPart=strInitOuter.substr(intChildOffcet,strInitOuter.length);
        intInitPartPos = strInnerBody.indexOf(strInitPart) + objTgtRange.startOffset;
    }else{
        var strInitPart = strInitInner.substr(objTgtRange.startOffset, strInitInner.length);
        strInitPart = strInitOuter.substr(strInitOuter.lastIndexOf(strInitPart), strInitOuter.length); //閉じタグプラス			    
        intInitOutPos = strInnerBody.indexOf(strInitOuter);
        intInitPartPos = intInitOutPos + strInitOuter.lastIndexOf(strInitPart);        
    } //if

    //部分文字列の後半取得
    var objEndDom = glObjRedFlame.getElementById(glSelectEndId);
    var objEndParentDom = glObjRedFlame.getElementById(glSelectEndId);

    var objEndNode = objSelection.focusNode; //Selectionのフォーカスとは、選択の終了点
    var objPrevDom = objEndNode.previousSibling;
    blChildFlg = false;
    blChildFind = false;
    if (intInitChildCnt>0  && (objPrevDom!=null)){ //子要素がある場合かつ前のdomが無い
        var objTmpNode;
        var objExpectDom; //OFFSET開始位置予想dom
        blChildFlg = true;

        for (var i = 0; i < objEndDom.childNodes.length; i++) {
            objTmpNode = objEndDom.childNodes[i];
            if (objTmpNode.nodeType==TEXT_NODE_TYPE) {
                continue;
            } //if            
            if (objTmpNode.getAttribute("class").indexOf(RED_END_CLS)>0) {
                objExpectDom=objTmpNode;
                //rangeのoffcet対象Domか判定
                var objChkNode=objEndDom.childNodes[i+1];
                var strChkVal=objChkNode.wholeText.substring(objTgtRange.startOffset,objChkNode.wholeText.length);
                if(strChkVal.indexOf(objTgtRange.toString())>=0){
                    objEndDom=objExpectDom;
                    blChildFind=true;
                    break;
                } //if
            }//if
        } //for
    } //if    

    //子がいるのに見つからなかった場合、中途半端な文字列なのでobjEndDom.childNodesの最後のDomとなる
    if (blChildFlg&&(!blChildFind)) { 
        objEndDom=objEndDom.children[objEndDom.childElementCount-1];
    } //if

    var strEndInner = objEndParentDom.innerHTML.toString();
    var strEndOuter = objEndParentDom.outerHTML.toString();

    var strEndPart;
    var intEndOutPos;
    var intEndPartPos;
    intChildOffcet=0;
    if (blChildFlg) { //子要素がある場合
        var intChildOffcet = strEndOuter.indexOf(objEndDom.outerHTML) + objEndDom.outerHTML.length;
        strEndPart=strEndOuter.substr(intChildOffcet,strEndOuter.length);
        intEndPartPos = strInnerBody.indexOf(strEndPart) + objTgtRange.endOffset;        
    }else{
        strEndPart = strEndInner.substr(0, objTgtRange.endOffset);
        intEndOutPos = strInnerBody.indexOf(strEndOuter);
        intEndPartPos = intEndOutPos + strEndOuter.indexOf(strEndPart) + strEndPart.length;
    }//if    
    var arrRet=[];
    arrRet.push(intInitPartPos);
    arrRet.push(intEndPartPos);
    return arrRet;

} //function


/**
* 選択指定している範囲のマスク、マスク候補を変更する
*/
function tgtMaskChk(objEnt_i) {

    //選択されていなかったらreturn
    if (glObjRedFlame.getSelection().toString() == "") {
        return;
    } //if

    var strTgtVal = "";
    var arrPos=getSelectionInnerPos();
    var intInitPartPos = arrPos[0];
    var intEndPartPos = arrPos[1];
    var strInnerBody = glObjRedFlame.body.innerHTML;
    var strMaskInnerBody = glObjMaskFlame.body.innerHTML;

    //値を実際に取得
    strTgtVal = strInnerBody.substring(intInitPartPos, intEndPartPos);
    var strBfBody = strInnerBody.substr(0, intInitPartPos);
    var strAfBody = strInnerBody.substring(intEndPartPos, strInnerBody.length);

    //グローバルにもとの値を保持
    glarrRepOrgOuter.push(strTgtVal);

    //マスク候補処理
    var hashBodyStructure = {};
    hashBodyStructure = getBodyStructure(strTgtVal);
    var strRepVal = bodyCharChange(hashBodyStructure, STATE_RED);


    //bodyを入れ替える
    var strChangeBody = strBfBody + strRepVal + strAfBody;
    glObjRedBody.innerHTML = strChangeBody;

    //グローバルにstrRepValを保持
    glarrRepOuter.push(strRepVal);

    //マスク処理
    var strMaskInnerBody = glObjMaskFlame.body.innerHTML;
    var strMakkTgtVal=strMaskInnerBody.substring(intInitPartPos, intEndPartPos);

    //グローバルにもとの値を保持
    glarrMaskOrgOuter.push(strMakkTgtVal);

    var hashBodyMaskStructure = getBodyStructure(strMakkTgtVal);
    var strMaskRepVal = bodyCharChange(hashBodyMaskStructure, STATE_MASK);

    //bodyを入れ替える
    var strMaskBfBody = strMaskInnerBody.substr(0, intInitPartPos);
    var strMaskAfBody = strMaskInnerBody.substring(intEndPartPos, strMaskInnerBody.length);
    var strMaskChangeBody = strMaskBfBody + strMaskRepVal + strMaskAfBody;
    glObjMaskBody.innerHTML = strMaskChangeBody;

    //グローバルに保持
    glarrMaskOuter.push(strMaskChangeBody);
    contextNone();

} //function

/**
* 選択範囲を開放する
*/
function tgtMaskRelease() {
    var strBfId = glActBfId;
    var strAfId = glActAfId;
    var intIndex=0;
    //対象のインデックスを探す
    for (var i = 0; i < glarrRepOuter.length; i++) {
        var objTgt = glarrRepOuter[i];
        if(objTgt.indexOf(strBfId) >= 0){
            intIndex=i;
            break;
        } //if
    } //for

    //bodyを入れ替える(マスク候補)
    var objBfOuter = glObjRedFlame.getElementById(strBfId);
    var objAfOuter = glObjRedFlame.getElementById(strAfId);
    var strInnerBody = glObjRedFlame.body.innerHTML;
    var intInitPos = strInnerBody.indexOf(objBfOuter.outerHTML);
    var intEndPos = strInnerBody.indexOf(objAfOuter.outerHTML) + objAfOuter.outerHTML.length
    var strBfBody = strInnerBody.substr(0, intInitPos);
    var strAfBody = strInnerBody.substring(intEndPos, strInnerBody.length);
    var strChangeBody = strBfBody + glarrRepOrgOuter[intIndex] + strAfBody;
    glObjRedBody.innerHTML = strChangeBody;    


    //bodyを入れ替える(マスク)
    strBfId=strBfId.replace("red","msk");
    strAfId=strAfId.replace("red","msk");
    objBfOuter = glObjMaskFlame.getElementById(strBfId);
    objAfOuter = glObjMaskFlame.getElementById(strAfId);
    strInnerBody = glObjMaskFlame.body.innerHTML;
    intInitPos = strInnerBody.indexOf(objBfOuter.outerHTML);
    intEndPos = strInnerBody.indexOf(objAfOuter.outerHTML) + objAfOuter.outerHTML.length
    strBfBody = strInnerBody.substr(0, intInitPos);
    strAfBody = strInnerBody.substring(intEndPos, strInnerBody.length);
    strChangeBody = strBfBody + glarrMaskOrgOuter[intIndex] + strAfBody;
    glObjMaskBody.innerHTML = strChangeBody;    

    contextNone();

} //function


/**
 * 独自コンテキストメニューを閉じる
*/
function contextNone() {
    document.getElementById('contextmenu').style.display = "none";
    document.getElementById('contextmenu_red').style.display = "none";   
    
} //fanction


function mouseupAct(e) {
    glSelectEndId=e.target.id;
} //function

function mouseDownAct(e) {
    if (e.button==0) { //通常クリック時のみ発火
        glSelectIinitId=e.target.id;       
    } //if

    //範囲選択フラグが立っている時かつ右クリックかつ選択されている
    if (glNewRangeFlg&&e.button==2&&(!glObjRedFlame.getSelection().toString() == "") ) {
        blRet = confirm("新たな範囲選択場所はこちらでよろしいでしょうか？");
        if (blRet) {
            changeRangeAfter(e);
        } else{
            //もともと選択中のものをもとに戻す
            changeRangeCancel();            
            return;
        } //if     

    } //if    


    contextNone();
} //function


/**
* コンテキストメニューを開く
*/
function contextOpen(e,intStatus_i) {
    if (intStatus_i==NOMAL_MENU) {
        document.getElementById('contextmenu').style.left = e.pageX - scrollX + document.getElementById('red').offsetLeft + 35 + "px";
        document.getElementById('contextmenu').style.top = e.pageY - scrollY + document.getElementById('red').offsetTop + 43 + "px";
        document.getElementById('contextmenu').style.display = "block";        
    }else if(intStatus_i==MASK_MENU){
        document.getElementById('contextmenu_red').style.left = e.pageX - scrollX + document.getElementById('red').offsetLeft + 35 + "px";
        document.getElementById('contextmenu_red').style.top = e.pageY - scrollY + document.getElementById('red').offsetTop + 43 + "px";
        document.getElementById('contextmenu_red').style.display = "block";                
    } //if

} //fanction

/**
 * コンテキストメニュー操作
*/
function contextFunc(e) {
    glActContext=e; //context保持

    var objSelection = glObjRedFlame.getSelection(); // 選択範囲のオブジェクト取得
    var strClsChk=e.target.getAttribute("class");
    if(strClsChk==null) strClsChk="";
    if (strClsChk.indexOf(TAG_RED)>=0) { //対象クラスがTAG_REDならMASK_MENUを開く
        getRedRange(e);
        contextOpen(e,MASK_MENU);                
    }else if (objSelection != "") { //選択されていたらNOMAL_MENUを開く
        contextOpen(e,NOMAL_MENU);
    } //if



} //function


/**
 * 黒塗り候補を選択する
*/
function getRedRange(e) {
    //glarrRepOuterから選択するIDを捜索
    var strActId = e.target.id;
    var intIndex=0;
    for (var i = 0; i < glarrRepOuter.length; i++) {
        var objTgt = glarrRepOuter[i];
        if(objTgt.indexOf(strActId) >= 0){
            intIndex=i;
            break;
        } //if
    } //for
    var strBfId="red"+glarrRepOuter[intIndex].substr(RED_BF_INIT.length,glRedIdCnt.toString().length);
    var strAfId="red"+replaceAll(glarrRepOuter[intIndex].substr(glarrRepOuter[intIndex].indexOf(RED_BF_END)).replace(RED_BF_END,""),"'.*","")

    //rangeの作成
    objRange = glObjRedFlame.createRange();
    objRange.setStart(glObjRedFlame.getElementById(strBfId),0);
    objRange.setEnd(glObjRedFlame.getElementById(strAfId),glObjRedFlame.getElementById(strAfId).innerText.length);
    var objTgtSelection = glObjRedFlame.getSelection();
    glObjRedBody.focus();
    objTgtSelection.removeAllRanges();
    objTgtSelection.addRange(objRange);
    //id,rangeをグローバルに保持
    glActBfId=strBfId;
    glActAfId=strAfId;
    glObjRange = objRange;

} //function


/**
 * 範囲の変更を行う
 */
// function changeRange(){
//     var strBfId = glActBfId;
//     var strAfId = glActAfId;
    
//     //bodyをもとに戻す
//     var objBfOuter = glObjRedFlame.getElementById(strBfId);
//     var objAfOuter = glObjRedFlame.getElementById(strAfId);
//     var strInnerBody = glObjRedFlame.body.innerHTML;
//     var intInitPos = strInnerBody.indexOf(objBfOuter.outerHTML);
//     var intEndPos = strInnerBody.indexOf(objAfOuter.outerHTML) + objAfOuter.outerHTML.length
//     var strBfBody = strInnerBody.substr(0, intInitPos);
//     var strAfBody = strInnerBody.substring(intEndPos, strInnerBody.length);
//     var strOrg=strInnerBody.substring(intInitPos, intEndPos); //キャンセル時のためにがめておく
//     glchngeRangeOrg=strOrg;

//     //元の文章に戻す前のポジションを保持
//     glChngeRangeInitPos = intInitPos;
//     glChngeRangeEndPos = intEndPos;

//     //一旦元の文章に戻す
//     var strActId = intInitPos;
//     var intIndex=0;
//     for (var i = 0; i < glarrRepOuter.length; i++) {
//         var objTgt = glarrRepOuter[i];
//         if(objTgt.indexOf(strActId) >= 0){
//             intIndex=i;
//             break;
//         } //if
//     } //for

//     var strChangeBody = strBfBody + glarrRepOrgOuter + strAfBody;
//     glObjRedBody.innerHTML = strChangeBody;        

//     //もとに戻したあとのポジションも保持
//     objBfOuter = glObjRedFlame.getElementById(strBfId);
//     objAfOuter = glObjRedFlame.getElementById(strAfId);
//     strInnerBody = glObjRedFlame.body.innerHTML;
//     intInitPos = strInnerBody.indexOf(objBfOuter.outerHTML);
//     intEndPos = strInnerBody.indexOf(objAfOuter.outerHTML) + objAfOuter.outerHTML.length
//     console.log();    

//     // //クラスだけ入れ替え
//     // var strChange=replaceAll(strOrg,'Red','Rng');
//     // var strChangeBody = strBfBody + strChange + strAfBody;
//     // glObjRedBody.innerHTML = strChangeBody;    

//     alert("新たな選択範囲を選んで右クリックしてください\n※ポリシーは引き継がれます");
//     glNewRangeFlg = true;
//     contextNone();

// } //function

// 選択候補色塗りチャレンジ
/**
 * 範囲の変更を行う
 */
function changeRange(){
    var strBfId = glActBfId;
    var strAfId = glActAfId;
    
    //bodyを入れ替える(マスク候補)
    var objBfOuter = glObjRedFlame.getElementById(strBfId);
    var objAfOuter = glObjRedFlame.getElementById(strAfId);
    var strInnerBody = glObjRedFlame.body.innerHTML;
    var intInitPos = strInnerBody.indexOf(objBfOuter.outerHTML);
    var intEndPos = strInnerBody.indexOf(objAfOuter.outerHTML) + objAfOuter.outerHTML.length
    var strBfBody = strInnerBody.substr(0, intInitPos);
    var strAfBody = strInnerBody.substring(intEndPos, strInnerBody.length);
    var strOrg=strInnerBody.substring(intInitPos, intEndPos); //キャンセル時のためにがめておく
    glchngeRangeOrg=strOrg;
    glChngeRangeInitPos = intInitPos;
    glChngeRangeEndPos = intEndPos;

    var strChange=replaceAll(strOrg,'Red','Rng');
    var strChangeBody = strBfBody + strChange + strAfBody;
    glObjRedBody.innerHTML = strChangeBody;    

    alert("新たな選択範囲を選んで右クリックしてください\n※ポリシーは引き継がれます");
    glNewRangeFlg = true;
    contextNone();

} //function

/**
 * 新たな囲の変更Cancel
 */
function changeRangeCancel(){
    //もともと選択中のものを選択中に戻す
    var strInnerBody = glObjRedFlame.body.innerHTML;
    var strBfBody = strInnerBody.substr(0, glChngeRangeInitPos);
    var strAfBody = strInnerBody.substring(glChngeRangeEndPos, strInnerBody.length);
    var strChangeBody = strBfBody + glchngeRangeOrg + strAfBody;
    glObjRedBody.innerHTML = strChangeBody; 
    glNewRangeFlg = false;
    contextNone();    
} //functin

/**
 * 新たな囲の変更を行う
 */
function changeRangeAfter(e){
    var strActId = e.target.id;
    var intIndex=0;
    for (var i = 0; i < glarrRepOuter.length; i++) {
        var objTgt = glarrRepOuter[i];
        if(objTgt.indexOf(strActId) >= 0){
            intIndex=i;
            break;
        } //if
    } //for

    //選択範囲を取得
    var arrPos=getSelectionInnerPos();
    var intInitPos = arrPos[0];
    var intEndPos = arrPos[1]
    
    var strMaskInnerBody = glObjMaskFlame.body.innerHTML;    
    
    //もともと選択中のものをもとに戻す(マスク側)
    var strBfBody = strMaskInnerBody.substr(0, glChngeRangeInitPos);
    var strAfBody = strMaskInnerBody.substring(glChngeRangeEndPos, strMaskInnerBody.length);
    var strChangeBody = strBfBody + glarrRepOrgOuter[intIndex] + strAfBody;
    glObjMaskBody.innerHTML = strChangeBody;     



    //現在の選択を反映(マスク側) ・・・選択が消えてしまうから
    var strMaskBfBody = strMaskInnerBody.substr(0, intInitPos);
    var strMaskAfBody = strMaskInnerBody.substring(intEndPos, strMaskInnerBody.length);
    var strMaskOrg=strMaskInnerBody.substring(intInitPos, intEndPos);  

    var hashBodyStructure = {};
    hashBodyStructure = getBodyStructure(strMaskOrg);
    var strMaskRepVal = bodyCharChange(hashBodyStructure, STATE_MASK);
    var strMaskChangeBody = strMaskBfBody + strMaskRepVal + strMaskAfBody;
    glObjMaskBody.innerHTML = strMaskChangeBody;    




    // //現在の選択を反映(マスク側) ・・・選択が消えてしまうから
    // var strRedInnerBody = glObjRedFlame.body.innerHTML;
    // var strRedBfBody = strRedInnerBody.substr(0, intInitPartPos);
    // var strRedAfBody = strRedInnerBody.substring(intEndPartPos, strRedInnerBody.length);
    // var strRedChangeBody = strRedBfBody + strRedRepVal + strRedAfBody;
    // glObjRedBody.innerHTML = strRedChangeBody;    


    // //もともと選択中のものをもとに戻す(マスク側)
    // var strBfBody = strRedInnerBody.substr(0, glChngeRangeInitPos);
    // var strAfBody = strRedInnerBody.substring(glChngeRangeEndPos, strRedInnerBody.length);
    // var strChangeBody = strBfBody + glarrRepOrgOuter[intIndex] + strAfBody;
    // glObjRedBody.innerHTML = strChangeBody; 

    glNewRangeFlg = false;
    contextNone();

} //function

/**
 * 編集ボタン制御 classがEDIT_ABLEのときだけ編集可能
 */
function editBtnStateCng (){
    $('#editBtn').toggleClass(EDIT_ABLE);
} //function

/**
 * 編集ボタンか判定する
 */
function isEdit (){
    if ( $('#editBtn').attr('class').indexOf(EDIT_ABLE)>=0) {
        return true;
    }
    return false;
} //function

/**
 * 黒塗りリスト表示画面を表示する
 */
function maskListView(){
    var glObjMaskFlame = document.getElementById('mask');
    var strMaskHtml = glObjMaskFlame.contentWindow.document.documentElement.outerHTML;
    var objForm = document.createElement('form');
    var objReq = document.createElement('input');

    objForm.method = 'POST';
    objForm.action = "/MaskListCnt";

    objReq.type = 'hidden'; //入力フォームが表示されないように
    objReq.name = 'editMask';
    objReq.value = strMaskHtml;

    objForm.appendChild(objReq);
    document.body.appendChild(objForm);

    objForm.submit();
} //function
