/*
 * @class UITestManager
 * @param param.targetButtons
 *  ボタンのトグルを行う
 * 
 * @description
 */
'use strict'
class UITestManagerHOZON {
    constructor(param) {
        var pagerButton1 = param.pager.button1;
        var pagerButton2 = param.pager.button2;
        var pagerInput = param.pager.input;
        this.initPager(pagerButton1, pagerButton2,pagerInput);
    }
    initPager(pagerButton1, pagerButton2, pagerInput){
        pagerButton1.addEventListener("change", event => {
            if (event.target.checked) {
                pagerInput.disabled = true;
            }
        })
        pagerButton2.addEventListener("change", event => {
            if (event.target.checked){
                pagerInput.disabled = false;
            }
        })
    }
}