package jp.co.nec.docmng.blackPaint.util.api;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nec.docmng.blackPaint.logic.Aspose.AsposeWordModel;



@RestController
public class test {


	/**
	 * ユーザーIDをセットする
	 * @return String 成否文字列
	 */
	@GetMapping("/rest/test")
	public String setUserId() {
		AsposeWordModel test = new AsposeWordModel();
		test.wordToHtml("C:/Users/ueda tatsuya/Desktop/20191028_h/", "SpringBoot習得手順書.docx", "test.html");

		return "";

	} //method

} //PolicyGet
