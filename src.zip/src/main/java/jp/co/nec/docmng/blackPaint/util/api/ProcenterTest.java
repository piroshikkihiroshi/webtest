package jp.co.nec.docmng.blackPaint.util.api;

import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nec.docmng.blackPaint.entity.procenter.ProcenterEnt;
import jp.co.nec.docmng.blackPaint.logic.procenter.ProcnterWebApi;



@RestController
public class ProcenterTest {

	static Logger objLog = LoggerFactory.getLogger(ProcenterTest.class);

	@GetMapping("/rest/protest")
	public String getTest(){
		//暫定
		int intNodeId=100; //createDraftNodeにて必要だが、重複はNG どのように空いているNodeIDを取得するか不明
		String strFileOutDir = "C:/Temp/result/"; //PROCENTER/Cに保存するファイル格納DIR
		String strFileWithoutExtension = "SpringBoot習得手順書_bk_20190924";
		//暫定 end


		ProcenterEnt procenterSessionEnt = null; //PORCENTER beenクラス(session用)
		ProcenterEnt procenterEnt = null; //PORCENTER beenクラス
		String strRet = "";
		//設定ファイル取得
		ResourceBundle objRb = ResourceBundle.getBundle("config/procenter");
		String strBaseUrl = objRb.getString("procenter_url");
		String strProcenterUserId = objRb.getString("procenter_user_id");
		String strProcenterPassword = objRb.getString("procenter_user_password");
		String strJson = "";
		String strSessionInfoJson="";

		ProcnterWebApi objProCls = new ProcnterWebApi();
		//login処理
		strJson ="";
		strJson+="{";
		strJson+="    \"credentials\": {";
		strJson+="        \"userId\": \""+strProcenterUserId+"\",";
		strJson+="        \"password\": \""+strProcenterPassword+"\",";
		strJson+="        \"locale\": \"ja\"";
		strJson+="    }";
		strJson+="}";

		String strLoginUrl = strBaseUrl + "webapi/RepositoryWebAPI/login/call.rmt"; //login用url
		try {
			procenterSessionEnt = objProCls.getProCenterUrencode(strLoginUrl, strJson);
			strRet=procenterSessionEnt.getResult();
			if (strRet.equals("success")) {
				objLog.info("PROCENTER/C LOGIN OK");
			} else {
				objLog.error("PROCENTER/C LOGIN NG \r\n" + procenterSessionEnt.getException().getMessage());
				throw new Exception(procenterSessionEnt.getException().getMessage());
			} //if

		} catch (Exception e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} //try

		//session infoは使い回すのでsession infoのjsonStringを作成しておく
		strSessionInfoJson+="";
		strSessionInfoJson+="    \"sessionInfo\": {";
		strSessionInfoJson+="        \"sessionId\": \""+procenterSessionEnt.getProcenterEntReturn().getSessionID()+"\",";
		strSessionInfoJson+="        \"userId\": \""+procenterSessionEnt.getProcenterEntReturn().getUserID()+"\",";
		strSessionInfoJson+="        \"locale\": \"ja\",";
		strSessionInfoJson+="        \"clientCode\": \""+procenterSessionEnt.getProcenterEntReturn().getClientCode()+"\",";
		strSessionInfoJson+="        \"serverAddress\": \""+procenterSessionEnt.getProcenterEntReturn().getServerAddress()+"\",";
		strSessionInfoJson+="        \"userAgent\": \""+procenterSessionEnt.getProcenterEntReturn().getServerAddress()+"\""
				+ "";
		strSessionInfoJson+="    }";


		//createDraftNode処理
		strJson ="";
		strJson+="{";
		strJson+=strSessionInfoJson;
		strJson+="    ,";
		strJson+="    \"nodeId\": "+intNodeId+",";
		strJson+="    \"responseFilter\": {";
		strJson+="        \"nameList\": [";
		strJson+="            \"ID\",";
		strJson+="            \"NAME\",";
		strJson+="            \"LASTMODIFIED\",";
		strJson+="            \"REMARK\"";
		strJson+="        ]";
		strJson+="    }";
		strJson+="}";

		String strCreateDraftNodeUrl = strBaseUrl + "webapi/RepositoryWebAPI/login/call.rmt"; //criateDraftNode用url
		String strCreateNodeUrl = strBaseUrl + "webapi/RepositoryWebAPI/login/call.rmt"; //criateDraftNode用url
		try {
			procenterEnt = objProCls.getProCenterUrencode(strCreateDraftNodeUrl, strJson);
			strRet=procenterEnt.getResult();
			if (strRet.equals("success")) {
				objLog.info("PROCENTER/C CREATE DRAFT NODE OK");
			} else {
				objLog.error("PROCENTER/C CREATE DRAFT NODE NG \r\n" + procenterEnt.getException().getMessage());
				throw new Exception(procenterEnt.getException().getMessage());
			} //if

			//createNode
			//送付するファイルのリスト作成
			List<String> objSendPath = new ArrayList<String>();
			objSendPath.add(strFileOutDir + strFileWithoutExtension+"(公開用).pdf");
			objSendPath.add(strFileOutDir + strFileWithoutExtension+"(査閲用).pdf");
			objSendPath.add(strFileOutDir + strFileWithoutExtension+"(黒塗諸元).pdf");
//			procenterSessionEnt = objProCls.getProCenterMultipart("http://localhost/test/parsejson.php?XDEBUG_SESSION_START=xdebug",strSessionInfoJson,objSendPath);
//			strRet = objProCls.getProCenterMultipart("http://localhost/test/parsejson.php?XDEBUG_SESSION_START=xdebug",strSessionInfoJson,objSendPath);

		} catch (Exception e) {
			objLog.error("err message", e);
			e.printStackTrace();
		} //try


		//承認画面呼び出し

		return strRet;

	} //method



} //PolicyGet
