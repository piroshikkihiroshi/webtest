/**
　* 名称  :BlackPrintPlaceファイル
　* 機能名:黒塗り高所箇所抽出APIの出力情報の黒塗り高所箇所情報定義
　* 概要  :黒塗り高所箇所抽出APIの出力情報の黒塗り高所箇所情報定義をする。
　*/
package jp.co.nec.docmng.library.blackprintextract.entity;

import lombok.Data;

/**
* 黒塗り高所箇所抽出の出力情報の検索結果情報定義をする。
*/
@Data
public class BlackPrintPlace {
    /**
 　　　* メンバ policyIDは、黒塗り候補箇所の黒塗りポリシーIDを保持する。
 　　　*/
	public Integer policyID;
	
    /**
 　　　* メンバ start は
 　　　*黒塗高所箇所の全文中での開始位置を保持する。
 　　　*/
	public int start;
	
    /**
 　　　* メンバ end は
 　　　*黒塗高所箇所の全文中での終了位置を保持する。
 　　　*/
	public int end;
	
	public void setPolicyID(int i) {
		this.policyID = i;
	}

	public void setStart(int start2) {
		this.start = start2;		
	}

	public void setEnd(int end2) {
		this.end = end2;		
		
	}
	
	public int gettPolicyID() {
		return policyID;
	}

	public int getStart() {
		return start;		
	}

	public int getEnd() {
		return end;		
		
	}
}
