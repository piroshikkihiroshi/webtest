package jp.co.nec.docmng.blackPaint.repository;


import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import jp.co.nec.docmng.blackPaint.entity.MaskDocMarkerEntBlackPaint;


@Mapper
public interface MaskDocMarkerMapPaint {

	//table mask_document_marker

	@Insert("INSERT INTO common.mask_document_marker(document_id,  marker_start_cd, marker_end_cd, marker_policy, marker_remarks, create_time) VALUES ( #{document_id}, #{marker_start_cd}, #{marker_end_cd}, #{marker_policy}, #{marker_remarks}, #{create_time})")
    public void insertMaskDocMarker(MaskDocMarkerEntBlackPaint objEnt);

	@Select("SELECT marker_id, document_id, marker_start_cd, marker_end_cd, marker_policy, marker_remarks, create_time, update_time FROM common.mask_document_marker WHERE document_id = #{document_id} ORDER BY marker_id")
    public List<MaskDocMarkerEntBlackPaint> selectMaskDocMarker(Integer document_id);

	@Delete("DELETE FROM common.mask_document_marker WHERE document_id = #{document_id}")
    public void deleteMarkerDoc(Integer document_id);



} //interface
