package jp.co.nec.docmng.blackPaint.entity.procenter;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Return {
	private String sessionID;
	private String userID;
	private String locale;
	private String clientCode;
	private String serverAddress;
	private String userAgent;

	@JsonProperty("sessionId")
	public String getSessionID() {
		return sessionID;
	}

	@JsonProperty("sessionId")
	public void setSessionID(String value) {
		this.sessionID = value;
	}

	@JsonProperty("userId")
	public String getUserID() {
		return userID;
	}

	@JsonProperty("userId")
	public void setUserID(String value) {
		this.userID = value;
	}

	@JsonProperty("locale")
	public String getLocale() {
		return locale;
	}

	@JsonProperty("locale")
	public void setLocale(String value) {
		this.locale = value;
	}

	@JsonProperty("clientCode")
	public String getClientCode() {
		return clientCode;
	}

	@JsonProperty("clientCode")
	public void setClientCode(String value) {
		this.clientCode = value;
	}

	@JsonProperty("serverAddress")
	public String getServerAddress() {
		return serverAddress;
	}

	@JsonProperty("serverAddress")
	public void setServerAddress(String value) {
		this.serverAddress = value;
	}

	@JsonProperty("userAgent")
	public String getUserAgent() {
		return userAgent;
	}

	@JsonProperty("userAgent")
	public void setUserAgent(String value) {
		this.userAgent = value;
	}
}
