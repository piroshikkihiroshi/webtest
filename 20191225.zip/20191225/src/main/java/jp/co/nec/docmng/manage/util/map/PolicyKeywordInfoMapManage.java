package jp.co.nec.docmng.manage.util.map;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import jp.co.nec.docmng.manage.entity.PolicyKeywordInfo;

@Mapper
public interface PolicyKeywordInfoMapManage {

    @Select("select * from admin.policy_keyword_info order by policy_id asc, update_time desc")
    public List<PolicyKeywordInfo> findAll();

    @Delete("delete from admin.policy_keyword_info where policy_id = #{policyId}")
    public void deleteKeyWord(Integer policyId);

//    @Select("select * from admin.policy_keyword_info as keyword where keyword.policy_id = #{} order by keyword.keyword_id")
//    public List<PolicyKeywordInfoBlackPaint> selectByPolicyId();
}
