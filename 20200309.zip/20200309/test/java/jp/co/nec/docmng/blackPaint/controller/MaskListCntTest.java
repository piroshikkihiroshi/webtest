package jp.co.nec.docmng.blackPaint.controller;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.ui.Model;

import jp.co.nec.docmng.common.DBConnection;

@SuppressWarnings("javadoc")
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class MaskListCntTest extends SpringBootServletInitializer {

	// DBアクセス用クラス
	DBConnection dbConnection = new DBConnection();
	PreparedStatement ps = null;

	@Autowired
	HttpServletRequest request;

	@Autowired
	HttpServletResponse response;

	@Mock
	private Model model;

	@Autowired
	MaskListCnt maskListCnt;


	// DB項目の挿入

	// DB項目の挿入
	String insertDirectoryInfoInternal = "INSERT \r\n" +
			"INTO common.directory_info_internal( \r\n" +
			"  directory_id\r\n" +
			"  , server_id\r\n" +
			"  , directory_name\r\n" +
			"  , parent_id\r\n" +
			"  , directory_path\r\n" +
			"  , directory_type\r\n" +
			"  , crawl_act_time\r\n" +
			"  , directory_update_flg\r\n" +
			"  , directory_delete_flg\r\n" +
			") \r\n" +
			"VALUES ( \r\n" +
			"  0 \r\n" +
			"  , 0 \r\n" +
			"  , ''\r\n" +
			"  , 0 \r\n" +
			"  , '' \r\n" +
			"  , 0 \r\n" +
			"  , '2019/11/13 00:00:00' \r\n" +
			"  , false \r\n" +
			"  , false \r\n" +
			")";

	//DB項目の削除
	String deleteDirectoryInfoInternal = ""
			+ "DELETE "
			+ "FROM common.directory_info_internal WHERE directory_id=0";

	String insertDirectoryInfo = "INSERT \r\n" +
			"INTO common.directory_info( \r\n" +
			"  directory_id\r\n" +
			"  , server_id\r\n" +
			"  , directory_name\r\n" +
			"  , parent_id\r\n" +
			"  , directory_path\r\n" +
			"  , directory_type\r\n" +
			") \r\n" +
			"VALUES ( \r\n" +
			"  0 \r\n" +
			"  , 0 \r\n" +
			"  , ''\r\n" +
			"  , 0 \r\n" +
			"  , '' \r\n" +
			"  , 0 \r\n" +
			")";

	//DB項目の削除
	String deleteDirectoryInfo = ""
			+ "DELETE "
			+ "FROM common.directory_info WHERE directory_id=0";

	// DB項目の挿入
	String insertDocumentInfoInternal = ""
			+ "INSERT  "
			+ "INTO common.document_info_internal(  "
			+ "  document_id "
			+ "  , document_contents "
			+ "  , server_id "
			+ "  , document_name "
			+ "  , document_size "
			+ "  , parent_id "
			+ "  , file_path "
			+ "  , procenter_flg "
			+ "  , crawl_act_time "
			+ "  , document_update_flg "
			+ "  , document_delete_flg "
			+ ")  "
			+ "VALUES (  "
			+ "  ? "
			+ "  , '' "
			+ "  , 0 "
			+ "  , 'test' "
			+ "  , 0 "
			+ "  , 0 "
			+ "  , '' "
			+ "  , true "
			+ "  , '2019/11/13 00:00:00' "
			+ "  , false "
			+ "  , false "
			+ ")";

	//DB項目の削除
	String deleteDocumentInfoInternal = ""
			+ "DELETE "
			+ "FROM common.document_info_internal WHERE document_id=?";

	// DB項目の挿入
	String insertDocumentInfo = ""
			+ "INSERT  "
			+ "INTO common.document_info(  "
			+ "  document_id "
			+ "  , document_contents "
			+ "  , server_id "
			+ "  , document_name "
			+ "  , document_size "
			+ "  , parent_id "
			+ "  , file_path "
			+ "  , procenter_flg "
			+ ")  "
			+ "VALUES (  "
			+ "  ? "
			+ "  , '' "
			+ "  , 0 "
			+ "  , 'test' "
			+ "  , 0 "
			+ "  , 0 "
			+ "  , '' "
			+ "  , true "
			+ ")";

	//DB項目の削除
	String deleteDocumentInfo = ""
			+ "DELETE "
			+ "FROM common.document_info WHERE document_id=?";

	/**
	 * LinkOpen正常系
	 * @throws Exception
	 */
	@Test
	public void testMaskListCntA001() throws Exception {

		// DBとの接続を確立
		Connection connection = dbConnection.DBConnectReturn();
		try {

			//delete Sql
			ps = connection.prepareStatement(deleteDocumentInfoInternal);
			ps.setInt(1, 0);
			ps.executeUpdate();

			ps = connection.prepareStatement(deleteDocumentInfo);
			ps.setInt(1, 0);
			ps.executeUpdate();

			ps = connection.prepareStatement(deleteDirectoryInfo);
			ps.executeUpdate();

			ps = connection.prepareStatement(deleteDirectoryInfoInternal);

			//insert Sql
			ps = connection.prepareStatement(insertDirectoryInfoInternal);
			ps.executeUpdate();

			ps = connection.prepareStatement(insertDirectoryInfo);
			ps.executeUpdate();

			ps = connection.prepareStatement(insertDocumentInfoInternal);
			ps.setInt(1, 0);
			ps.executeUpdate();

			ps = connection.prepareStatement(insertDocumentInfo);
			ps.setInt(1, 0);
			ps.executeUpdate();

			String ret = maskListCnt.getblackPaintInfo("testjson", "", "", "0", 0, "", model);

			assertEquals(ret, "blackPaint/MaskListView");

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			//delete Sql
			ps = connection.prepareStatement(deleteDocumentInfoInternal);
			ps.setInt(1, 0);
			ps.executeUpdate();

			ps = connection.prepareStatement(deleteDocumentInfo);
			ps.setInt(1, 0);
			ps.executeUpdate();

			ps = connection.prepareStatement(deleteDirectoryInfo);
			ps.executeUpdate();

			ps = connection.prepareStatement(deleteDirectoryInfoInternal);

			ps.close();
			connection.close();
		} //try

	} //method

	/**
	 * LinkOpen異常系
	 * @throws Exception
	 */
	@Test
	public void testMaskListCntB001() throws Exception {

		try {
			String ret = maskListCnt.handleException(new RuntimeException("errTest"), response, model);
			assertEquals(ret, "blackPaint/Fail");

		} catch (Exception e) {
			e.printStackTrace();
		} //try

	} //method

} //class
