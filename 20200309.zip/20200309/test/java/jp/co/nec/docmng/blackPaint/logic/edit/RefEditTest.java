package jp.co.nec.docmng.blackPaint.logic.edit;

import static org.junit.Assert.*;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletContext;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.core.io.ResourceLoader;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.zeroturnaround.zip.ZipUtil;

import com.aspose.cells.PdfSaveOptions;
import com.aspose.cells.Workbook;
import com.aspose.pdf.HtmlSaveOptions;
import com.aspose.pdf.LettersPositioningMethods;
import com.aspose.slides.Presentation;
import com.aspose.slides.SaveFormat;
import com.aspose.words.Document;
import com.aspose.words.HtmlFixedPageHorizontalAlignment;
import com.aspose.words.HtmlFixedSaveOptions;

import jp.co.nec.docmng.blackPaint.entity.DocumentInfoEntPaint;
import jp.co.nec.docmng.blackPaint.service.DocInfoServicePaint;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocMarkerServicePaint;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocumentServicePaint;
import jp.co.nec.docmng.common.DBConnection;
import jp.co.nec.docmng.manage.service.PolicyInfoService;

@SuppressWarnings("javadoc")
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class RefEditTest extends SpringBootServletInitializer {

	// DBアクセス用クラス
	DBConnection dbConnection = new DBConnection();

	@Autowired
	ServletContext context;
	@Autowired
	DocInfoServicePaint docInfoService;

	@Autowired
	TmpMaskDocMarkerServicePaint tmpMaskDocTmpMarkerService;

	@Autowired
	TmpMaskDocumentServicePaint tmpMaskDocumentService;

	@Autowired
	PolicyInfoService policyInfoService;

	@Autowired
	private ResourceLoader resourceLoader;

	// DB項目の削除(初期化)
	String deleteDocumentInfo = "delete from common.document_info where document_id in (1,2,3,4,5,6,7,8,9,10);";
	String deleteDocumentInternalInfo = "delete from common.document_info_internal where document_id in (1,2,3,4,5,6,7,8,9,10);";
	String deleteTmpDocumentInfo = "delete from common.tmp_mask_document where document_id in (1,2,3,4,5,6,7,8,9,10);";
	String deleteTmpDocumentMarkerInfo = "delete from common.tmp_mask_document_marker where document_id in (1,2,3,4,5,6,7,8,9,10);";
	String deleteDirectoryInfo = "delete from common.directory_info where directory_id =1;";
	String deleteServerInfo = "delete from admin.search_server_info where server_id =1;";
	String deleteMaskDocumentInfo = "delete from common.mask_document where document_id in (1,2,3,4,5,6,7,8,9,10);";
	String deleteMaskDocumentMarkerInfo = "delete from common.mask_document_marker where document_id in (1,2,3,4,5,6,7,8,9,10);";
	String deleteDirectoryInternalInfo = "delete from common.directory_info_internal where directory_id =1;";

	// DB項目の挿入
	// サーバー情報
	String insertSearchServerInfo = "insert into admin.search_server_info"
			+ "	(server_id, server_name, display_name, login_user_name, login_password, directory_path, create_time, update_time)"
			+ "	values"
			+ "	(1, '\\\\yoks3016', 'disp999', 'user999', 'pass999', '\\\\yoks3106\\Project\\NES_文書管理システム\\99_tmp', '2019/11/13 00:00:00', '2019/11/13 00:00:00');"
			+ "";
	// ディレクトリ情報
	String insertDirectoryInfo = "insert into common.directory_info"
			+ "	(directory_id , server_id , directory_name , parent_id , directory_path,directory_type,create_time,update_time)"
			+ "	values"
			+ "	(1, 1, 'crawl_test', 1, '\\\\build1006636.swf.nec.co.jp\\crawl_test', 0, '2019/11/13 00:00:00', '2019/11/13 00:00:00');"
			+ "";

	// ディレクトリ情報
	String insertDirectoryInternalInfo = "insert into common.directory_info_internal"
			+ "	(directory_id , server_id , directory_name , parent_id , directory_path,directory_type,crawl_act_time,directory_update_flg,directory_delete_flg,create_time,update_time)"
			+ "	values"
			+ "	(1, 1, 'crawl_test', 1, '\\\\build1006636.swf.nec.co.jp\\crawl_test', 0,'2019/11/13 00:00:00',false,false, '2019/11/13 00:00:00', '2019/11/13 00:00:00');"
			+ "";

	//////////////////////////////////////////

	String insertDocDocument = "INSERT INTO common.document_info("
			+ "	document_id, document_contents, html_zip_data, server_id , document_name, extension, document_size  , parent_id , file_path, marker , category_id , procenter_flg , procenter_parent_id , node_id , retention_period , author , updater , authorizer , file_update_time , mask_status , create_time , update_time)"
			+ "	values "
			+ "	( 1 ,'テキストテスト01',?, 1,'test01.docx' , 'docx'  , 0 , 1 , '\\\\build1006636.swf.nec.co.jp\\crawl_test\\test01.docx', null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 , null , null),"
			+ "	( 2 ,'テキストテスト02',? , 1,'test02.docx' , 'docx ' , 0 , 1 , '\\\\build1006636.swf.nec.co.jp\\crawl_test\\test02.docx', null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 , null , null);";

	String insertTxtDocument = "INSERT INTO common.document_info("
			+ "	document_id, document_contents, html_zip_data, server_id , document_name, extension, document_size  , parent_id , file_path, marker , category_id , procenter_flg , procenter_parent_id , node_id , retention_period , author , updater , authorizer , file_update_time , mask_status , create_time , update_time)"
			+ "	values "
			+ "	( 3 ,'テキストテスト01',? , 1,'test01.txt' , 'txt'  , 0 , 1 , '\\\\build1006636.swf.nec.co.jp\\crawl_test\\test01.xlsx', null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 , null , null),"
			+ "	( 4 ,'テキストテスト02',? , 1,'test02.txt' , 'txt'   , 0 , 1 , '\\\\build1006636.swf.nec.co.jp\\crawl_test\\test02.xlsx', null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 , null , null);";

	String insertXlsDocument = "INSERT INTO common.document_info("
			+ "	document_id, document_contents, html_zip_data, server_id , document_name, extension, document_size  , parent_id , file_path, marker , category_id , procenter_flg , procenter_parent_id , node_id , retention_period , author , updater , authorizer , file_update_time , mask_status , create_time , update_time)"
			+ "	values "
			+ "	( 5 ,'テキストテスト01',? , 1,'test01.xlsx' , 'xlsx'  , 0 , 1 , '\\\\build1006636.swf.nec.co.jp\\crawl_test\\test01.xlsx', null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 , null , null),"
			+ "	( 6 ,'テキストテスト02',? , 1,'test02.xlsx' , 'xlsx'   , 0 , 1 , '\\\\build1006636.swf.nec.co.jp\\crawl_test\\test02.xlsx', null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 , null , null);";

	String insertPptDocument = "INSERT INTO common.document_info("
			+ "	document_id, document_contents, html_zip_data, server_id , document_name, extension, document_size  , parent_id , file_path, marker , category_id , procenter_flg , procenter_parent_id , node_id , retention_period , author , updater , authorizer , file_update_time , mask_status , create_time , update_time)"
			+ "	values "
			+ "	( 7 ,'テキストテスト01',?, 1,'test01.pptx' , 'pptx'  , 0 , 1 , '\\\\build1006636.swf.nec.co.jp\\crawl_test\\test01.pptx', null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 , null , null),"
			+ "	( 8 ,'テキストテスト02',? , 1,'test02.pptx' , 'pptx'   , 0 , 1 , '\\\\build1006636.swf.nec.co.jp\\crawl_test\\test02.pptx', null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 , null , null);";

	String insertPdfDocument = "INSERT INTO common.document_info("
			+ "	document_id, document_contents, html_zip_data, server_id , document_name, extension, document_size  , parent_id , file_path, marker , category_id , procenter_flg , procenter_parent_id , node_id , retention_period , author , updater , authorizer , file_update_time , mask_status , create_time , update_time)"
			+ "	values "
			+ "	( 9 ,'テキストテスト01',? , 1,'test01.pdf' , 'pdf'  , 0 , 1 , '\\\\build1006636.swf.nec.co.jp\\crawl_test\\test01.pdf', null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 , null , null),"
			+ "	( 10 ,'テキストテスト02',? , 1,'test02.pdf' , 'pdf'  , 0 , 1 , '\\\\build1006636.swf.nec.co.jp\\crawl_test\\test02.pdf', null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 , null , null);";

	//////////////////////////////////////////

	String insertDocDocumentInternal = "INSERT INTO common.document_info_internal("
			+ "	document_id, document_contents, html_zip_data, server_id , document_name, extension, document_size  , parent_id , file_path, marker , category_id , procenter_flg , procenter_parent_id , node_id , retention_period , author , updater , authorizer , file_update_time , mask_status ,crawl_act_time,document_update_flg,document_delete_flg, create_time , update_time)"
			+ "	values "
			+ "	( 1 ,'テキストテスト01',?, 1,'test01.docx' , 'docx'  , 0 , 1 , '\\\\build1006636.swf.nec.co.jp\\crawl_test\\test01.docx', null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 ,'2019/11/13 00:00:00',false,false, null , null),"
			+ "	( 2 ,'テキストテスト02',? , 1,'test02.docx' , 'docx ' , 0 , 1 , '\\\\build1006636.swf.nec.co.jp\\crawl_test\\test02.docx', null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 ,'2019/11/13 00:00:00',false,false, null , null);";

	String insertTxtDocumentInternal = "INSERT INTO common.document_info_internal("
			+ "	document_id, document_contents, html_zip_data, server_id , document_name, extension, document_size  , parent_id , file_path, marker , category_id , procenter_flg , procenter_parent_id , node_id , retention_period , author , updater , authorizer , file_update_time , mask_status ,crawl_act_time,document_update_flg,document_delete_flg, create_time , update_time)"
			+ "	values "
			+ "	( 3 ,'テキストテスト01',?, 1,'test01.txt' , 'txt'  , 0 , 1 , '\\\\build1006636.swf.nec.co.jp\\crawl_test\\test01.xlsx', null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 ,'2019/11/13 00:00:00',false,false, null , null),"
			+ "	( 4 ,'テキストテスト02',? , 1,'test02.txt' , 'txt ' , 0 , 1 , '\\\\build1006636.swf.nec.co.jp\\crawl_test\\test02.xlsx', null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 ,'2019/11/13 00:00:00',false,false, null , null);";

	String insertXlsDocumentInternal = "INSERT INTO common.document_info_internal("
			+ "	document_id, document_contents, html_zip_data, server_id , document_name, extension, document_size  , parent_id , file_path, marker , category_id , procenter_flg , procenter_parent_id , node_id , retention_period , author , updater , authorizer , file_update_time , mask_status ,crawl_act_time,document_update_flg,document_delete_flg, create_time , update_time)"
			+ "	values "
			+ "	( 5 ,'テキストテスト01',?, 1,'test01.xlsx' , 'xlsx'  , 0 , 1 , '\\\\build1006636.swf.nec.co.jp\\crawl_test\\test01.xlsx', null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 ,'2019/11/13 00:00:00',false,false, null , null),"
			+ "	( 6 ,'テキストテスト02',? , 1,'test02.xlsx' , 'xlsx ' , 0 , 1 , '\\\\build1006636.swf.nec.co.jp\\crawl_test\\test02.xlsx', null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 ,'2019/11/13 00:00:00',false,false, null , null);";

	String insertPptDocumentInternal = "INSERT INTO common.document_info_internal("
			+ "	document_id, document_contents, html_zip_data, server_id , document_name, extension, document_size  , parent_id , file_path, marker , category_id , procenter_flg , procenter_parent_id , node_id , retention_period , author , updater , authorizer , file_update_time , mask_status ,crawl_act_time,document_update_flg,document_delete_flg, create_time , update_time)"
			+ "	values "
			+ "	( 7 ,'テキストテスト01',?, 1,'test01.pptx' , 'pptx'  , 0 , 1 , '\\\\build1006636.swf.nec.co.jp\\crawl_test\\test01.pptx', null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 ,'2019/11/13 00:00:00',false,false, null , null),"
			+ "	( 8 ,'テキストテスト02',? , 1,'test02.pptx' , 'pptx'   , 0 , 1 , '\\\\build1006636.swf.nec.co.jp\\crawl_test\\test02.pptx', null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 ,'2019/11/13 00:00:00',false,false, null , null);";

	String insertPdfDocumentInternal = "INSERT INTO common.document_info_internal("
			+ "	document_id, document_contents, html_zip_data, server_id , document_name, extension, document_size  , parent_id , file_path, marker , category_id , procenter_flg , procenter_parent_id , node_id , retention_period , author , updater , authorizer , file_update_time , mask_status ,crawl_act_time,document_update_flg,document_delete_flg, create_time , update_time)"
			+ "	values "
			+ "	( 9 ,'テキストテスト01',? , 1,'test01.pdf' , 'pdf'  , 0 , 1 , '\\\\build1006636.swf.nec.co.jp\\crawl_test\\test01.pdf', null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 ,'2019/11/13 00:00:00',false,false, null , null),"
			+ "	( 10 ,'テキストテスト02',? , 1,'test02.pdf' , 'pdf'  , 0 , 1 , '\\\\build1006636.swf.nec.co.jp\\crawl_test\\test02.pdf', null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 ,'2019/11/13 00:00:00',false,false, null , null);";

	//////////////////////////////////////////

	String insertTmpDocDocument = "INSERT INTO common.tmp_mask_document("
			+ "	document_id, user_id, html_zip_data, create_time , update_time)" + "	values "
			+ "	( 1 ,'0001',? , null , null)," + "	( 2 ,'0001',? , null , null);";

	String insertTmpTxtDocument = "INSERT INTO common.tmp_mask_document("
			+ "	document_id, user_id, html_zip_data, create_time , update_time)" + "	values "
			+ "	( 3 ,'0001',? , null , null)," + "	( 4 ,'0001',? , null , null);";

	String insertTmpXlsDocument = "INSERT INTO common.tmp_mask_document("
			+ "	document_id, user_id, html_zip_data, create_time , update_time)" + "	values "
			+ "	( 5 ,'0001',? , null , null)," + "	( 6 ,'0001',? , null , null);";

	String insertTmpPptDocument = "INSERT INTO common.tmp_mask_document("
			+ "	document_id, user_id, html_zip_data, create_time , update_time)" + "	values "
			+ "	( 7 ,'0001',? , null , null)," + "	( 8 ,'0001',? , null , null);";

	String insertTmpPdfDocument = "INSERT INTO common.tmp_mask_document("
			+ "	document_id, user_id, html_zip_data, create_time , update_time)" + "	values "
			+ "	( 9 ,'0001',? , null , null)," + "	( 10 ,'0001',? , null , null);";

	String selectDocumentInfoDoc = "select * from common.document_info WHERE document_id =1";
	int tmpDocId = 2;

	String selectDocumentInfoTxt = "select * from common.document_info WHERE document_id =3";
	int tmpTxtId = 4;

	String selectDocumentInfoXls = "select * from common.document_info WHERE document_id =5";
	int tmpXlsId = 6;

	String selectDocumentInfoPpt = "select * from common.document_info WHERE document_id =7";
	int tmpPptId = 8;

	String selectDocumentInfoPdf = "select * from common.document_info WHERE document_id =9";
	int tmpPdfId = 10;
//
	@Test
	public void test_refEditMainDoc() {

		RefEdit instance = new RefEdit();

		// DBとの接続を確立
		dbConnection.DBConnect();

		// 削除のSQL文
		// 外部キーのあるテーブルから削除
		try {
			dbConnection.SQLExe(deleteMaskDocumentMarkerInfo);
			dbConnection.SQLExe(deleteMaskDocumentInfo);
			dbConnection.SQLExe(deleteTmpDocumentMarkerInfo);
			dbConnection.SQLExe(deleteTmpDocumentInfo);
			dbConnection.SQLExe(deleteDocumentInfo);
			dbConnection.SQLExe(deleteDocumentInternalInfo);
			dbConnection.SQLExe(deleteDirectoryInfo);
			dbConnection.SQLExe(deleteServerInfo);
			dbConnection.SQLExe(deleteDirectoryInternalInfo);

		} catch (Exception e) {
//            e.printStackTrace();
		}

		// srcDoc : 変換するPowerPointファイルのパス
		String srcDoc1 = "C:\\Users\\Public\\Documents\\test/test01.docx";

		// dstDoc : 変換語のHTMLファイルのパス
		String dstDoc1 = "C:\\Users\\Public\\Documents\\test\\test01/test01.html";

		// dstDoc : 変換語のHTMLファイルのパス
		String dstRedDoc1 = "C:\\Users\\Public\\Documents\\test\\test01/red_1.html";

		// srcDoc : 変換するPowerPointファイルのパス
		String srcDoc2 = "C:\\Users\\Public\\Documents\\test/test02.docx";

		// dstDoc : 変換語のHTMLファイルのパス
		String dstDoc2 = "C:\\Users\\Public\\Documents\\test\\test02/test02.html";

		// 保存するHTMLファイルの追加オプションの設定(HTMLの枠組みの作成)
		HtmlFixedSaveOptions htmlFixedSaveOptions = new HtmlFixedSaveOptions();
		htmlFixedSaveOptions.setPageHorizontalAlignment(HtmlFixedPageHorizontalAlignment.CENTER);
		htmlFixedSaveOptions.setExportEmbeddedSvg(false);

		// 変換対象のファイルの読み込み
		Document objDoc = null;
		try {
			objDoc = new Document(srcDoc1);
		} catch (Exception e3) {
			// TODO 自動生成された catch ブロック
			e3.printStackTrace();
		}
		try {
			objDoc.save(dstDoc1, htmlFixedSaveOptions);
			objDoc.save(dstRedDoc1, htmlFixedSaveOptions);
		} catch (Exception e2) {
			// TODO 自動生成された catch ブロック
			e2.printStackTrace();
		}

		// dstDoc : 変換語のHTMLファイルのパス
		String strFileOutDir = "C:\\Users\\Public\\Documents\\test\\test01";
		// zipに固める
		String strZipOut = "C:/Users/Public/Documents/mask01.zip";
		ZipUtil.pack(new File(strFileOutDir), new File(strZipOut));
		// zipをbyte配列にする
		byte[] byteZip1 = null;
		File objZipFile = null;
		objZipFile = new File(strZipOut);
		try {
			byteZip1 = Files.readAllBytes(objZipFile.toPath());
		} catch (IOException e1) {
			// TODO 自動生成された catch ブロック
			e1.printStackTrace();
		}

		try {
			objDoc = new Document(srcDoc2);
		} catch (Exception e3) {
			// TODO 自動生成された catch ブロック
			e3.printStackTrace();
		}
		try {
			objDoc.save(dstDoc2, htmlFixedSaveOptions);
		} catch (Exception e2) {
			// TODO 自動生成された catch ブロック
			e2.printStackTrace();
		}
		// dstDoc : 変換語のHTMLファイルのパス
		strFileOutDir = "C:\\Users\\Public\\Documents\\test\\test02";
		// zipに固める
		strZipOut = "C:/Users/Public/Documents/mask02.zip";
		ZipUtil.pack(new File(strFileOutDir), new File(strZipOut));
		// zipをbyte配列にする
		byte[] byteZip2 = null;
		objZipFile = new File(strZipOut);
		try {
			byteZip2 = Files.readAllBytes(objZipFile.toPath());
		} catch (IOException e1) {
			// TODO 自動生成された catch ブロック
			e1.printStackTrace();
		}

		// 削除のSQL文
		// 外部キーのあるテーブルから削除
		try {
			dbConnection.SQLExe(insertSearchServerInfo);
			dbConnection.SQLExe(insertDirectoryInternalInfo);
			dbConnection.SQLExe(insertDirectoryInfo);
			dbConnection.SQLExeByte(insertDocDocument, byteZip1, byteZip2);
			dbConnection.SQLExeByte(insertDocDocumentInternal, byteZip1, byteZip2);
			dbConnection.SQLExeByte(insertTmpDocDocument, byteZip1, byteZip2);
		} catch (Exception e) {
//            e.printStackTrace();
		}

		// DocumentIDでdocument_infoから情報を取得
		ResultSet resultSet = dbConnection.SelectSQLExe(selectDocumentInfoDoc);

		DocumentInfoEntPaint documentInfoEntPaint = new DocumentInfoEntPaint();
		List<DocumentInfoEntPaint> listDoc = new ArrayList<DocumentInfoEntPaint>();

		try {

			while (resultSet.next()) {
				documentInfoEntPaint.setDocumentId(Integer.parseInt(resultSet.getString("document_id")));
				documentInfoEntPaint.setDocumentContents(resultSet.getString("document_contents"));
				documentInfoEntPaint.setHtmlZipData(resultSet.getBytes("html_zip_data"));
				documentInfoEntPaint.setServerId(resultSet.getInt("server_id"));
				documentInfoEntPaint.setDocumentName(resultSet.getString("document_name"));
				documentInfoEntPaint.setExtension(resultSet.getString("extension"));
				documentInfoEntPaint.setDocumentSize(resultSet.getBigDecimal("document_size"));
				documentInfoEntPaint.setParentId(resultSet.getInt("parent_id"));
				documentInfoEntPaint.setFilePath(resultSet.getString("file_path"));
				documentInfoEntPaint.setMarker(resultSet.getString("marker"));
				documentInfoEntPaint.setCategoryId(resultSet.getInt("category_id"));
				documentInfoEntPaint.setProcenterFlg(resultSet.getBoolean("procenter_flg"));
				documentInfoEntPaint.setRetentionPeriod(resultSet.getDate("retention_period"));
				documentInfoEntPaint.setAuthor(resultSet.getString("author"));
				documentInfoEntPaint.setUpdater(resultSet.getString("updater"));
				documentInfoEntPaint.setAuthorizer(resultSet.getString("authorizer"));
				documentInfoEntPaint.setFileUpdateTime(resultSet.getDate("file_update_time"));
				documentInfoEntPaint.setMaskStatus(resultSet.getInt("mask_status"));
				documentInfoEntPaint.setCreateTime(resultSet.getDate("create_time"));
				documentInfoEntPaint.setFileUpdateTime(resultSet.getDate("update_time"));
				documentInfoEntPaint.setNodeId(resultSet.getInt("node_id"));
				documentInfoEntPaint.setProcenterParentId(resultSet.getInt("procenter_parent_id"));

				listDoc.add(0, documentInfoEntPaint);

			}
		} catch (SQLException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}

		HashMap<String, String> ret = instance.refEditMain(listDoc, "C:\\JUnitTest\\", resourceLoader, tmpDocId, "0001",
				"3", tmpMaskDocTmpMarkerService, tmpMaskDocumentService, docInfoService);

		assertEquals(ret.get("strPageCnt"), "1");
		assertEquals(ret.get("strRefHtmlName"), "2.html");
		assertEquals(ret.get("strRefFileName"), "test02.docx");
		assertEquals(ret.get("strRefPageCnt"), "1");
		assertEquals(ret.get("strHeight"), "785");

	}
//
	@Test
	public void test_refEditMainTxt() throws Exception {

		RefEdit instance = new RefEdit();

		// DBとの接続を確立
		dbConnection.DBConnect();

		// 削除のSQL文
		// 外部キーのあるテーブルから削除
		try {
			dbConnection.SQLExe(deleteMaskDocumentMarkerInfo);
			dbConnection.SQLExe(deleteMaskDocumentInfo);
			dbConnection.SQLExe(deleteTmpDocumentMarkerInfo);
			dbConnection.SQLExe(deleteTmpDocumentInfo);
			dbConnection.SQLExe(deleteDocumentInfo);
			dbConnection.SQLExe(deleteDocumentInternalInfo);
			dbConnection.SQLExe(deleteDirectoryInfo);
			dbConnection.SQLExe(deleteServerInfo);
			dbConnection.SQLExe(deleteDirectoryInternalInfo);

		} catch (Exception e) {
//        e.printStackTrace();
		}

		// dstDoc : 変換語のHTMLファイルのパス
		String dstDoc1 = "C:\\Users\\Public\\Documents\\test\\test03/test01.html";

		// dstDoc : 変換語のHTMLファイルのパス
		String dstRedDoc1 = "C:\\Users\\Public\\Documents\\test\\test03/red_3.html";

		// dstDoc : 変換語のHTMLファイルのパス
		String dstDoc2 = "C:\\Users\\Public\\Documents\\test\\test04/test02.html";


		PrintWriter stream1 = null;
		PrintWriter stream2 = null;
		PrintWriter stream3 = null;
		try {
			stream1 = new PrintWriter(new BufferedWriter(new FileWriter(new File(dstDoc1))));
			stream1.println("<html><body><div class='stl_02'>テストテキスト01</div></body></html>");
			stream2 = new PrintWriter(new BufferedWriter(new FileWriter(new File(dstRedDoc1))));
			stream2.println("<html><body><div class='stl_02'>テストテキスト01</div></body></html>");
			stream3 = new PrintWriter(new BufferedWriter(new FileWriter(new File(dstDoc2))));
			stream3.println("<html><body><div class='stl_02'>テストテキスト02</div></body></html>");

		} catch (UnsupportedEncodingException | FileNotFoundException e2) {
			// TODO 自動生成された catch ブロック
			e2.printStackTrace();
		}
		finally {
			if (stream1 != null) {
				stream1.close();
				stream1 = null;
			} //if
			if (stream2 != null) {
				stream2.close();
				stream2 = null;
			} //if
			if (stream3 != null) {
				stream3.close();
				stream3 = null;
			} //if
		} //try



		// dstDoc : 変換語のHTMLファイルのパス
		String strFileOutDir = "C:\\Users\\Public\\Documents\\test\\test03";
		// zipに固める
		String strZipOut = "C:/Users/Public/Documents/mask01.zip";
		ZipUtil.pack(new File(strFileOutDir), new File(strZipOut));
		// zipをbyte配列にする
		byte[] byteZip1 = null;
		File objZipFile = null;
		objZipFile = new File(strZipOut);
		try {
			byteZip1 = Files.readAllBytes(objZipFile.toPath());
		} catch (IOException e1) {
			// TODO 自動生成された catch ブロック
			e1.printStackTrace();
		}

		// dstDoc : 変換語のHTMLファイルのパス
		strFileOutDir = "C:\\Users\\Public\\Documents\\test\\test04";
		// zipに固める
		strZipOut = "C:/Users/Public/Documents/mask02.zip";
		ZipUtil.pack(new File(strFileOutDir), new File(strZipOut));
		// zipをbyte配列にする
		byte[] byteZip2 = null;
		objZipFile = new File(strZipOut);
		try {
			byteZip2 = Files.readAllBytes(objZipFile.toPath());
		} catch (IOException e1) {
			// TODO 自動生成された catch ブロック
			e1.printStackTrace();
		}

		// 削除のSQL文
		// 外部キーのあるテーブルから削除
		try {
			dbConnection.SQLExe(insertSearchServerInfo);
			dbConnection.SQLExe(insertDirectoryInternalInfo);
			dbConnection.SQLExe(insertDirectoryInfo);
			dbConnection.SQLExeByte(insertTxtDocument, byteZip1, byteZip2);
			dbConnection.SQLExeByte(insertTxtDocumentInternal, byteZip1, byteZip2);
			dbConnection.SQLExeByte(insertTmpTxtDocument, byteZip1, byteZip2);
		} catch (Exception e) {
//            e.printStackTrace();
		}

		// DocumentIDでdocument_infoから情報を取得
		ResultSet resultSet = dbConnection.SelectSQLExe(selectDocumentInfoTxt);

		DocumentInfoEntPaint documentInfoEntPaint = new DocumentInfoEntPaint();
		List<DocumentInfoEntPaint> listDoc = new ArrayList<DocumentInfoEntPaint>();

		try {

			while (resultSet.next()) {
				documentInfoEntPaint.setDocumentId(Integer.parseInt(resultSet.getString("document_id")));
				documentInfoEntPaint.setDocumentContents(resultSet.getString("document_contents"));
				documentInfoEntPaint.setHtmlZipData(resultSet.getBytes("html_zip_data"));
				documentInfoEntPaint.setServerId(resultSet.getInt("server_id"));
				documentInfoEntPaint.setDocumentName(resultSet.getString("document_name"));
				documentInfoEntPaint.setExtension(resultSet.getString("extension"));
				documentInfoEntPaint.setDocumentSize(resultSet.getBigDecimal("document_size"));
				documentInfoEntPaint.setParentId(resultSet.getInt("parent_id"));
				documentInfoEntPaint.setFilePath(resultSet.getString("file_path"));
				documentInfoEntPaint.setMarker(resultSet.getString("marker"));
				documentInfoEntPaint.setCategoryId(resultSet.getInt("category_id"));
				documentInfoEntPaint.setProcenterFlg(resultSet.getBoolean("procenter_flg"));
				documentInfoEntPaint.setRetentionPeriod(resultSet.getDate("retention_period"));
				documentInfoEntPaint.setAuthor(resultSet.getString("author"));
				documentInfoEntPaint.setUpdater(resultSet.getString("updater"));
				documentInfoEntPaint.setAuthorizer(resultSet.getString("authorizer"));
				documentInfoEntPaint.setFileUpdateTime(resultSet.getDate("file_update_time"));
				documentInfoEntPaint.setMaskStatus(resultSet.getInt("mask_status"));
				documentInfoEntPaint.setCreateTime(resultSet.getDate("create_time"));
				documentInfoEntPaint.setFileUpdateTime(resultSet.getDate("update_time"));
				documentInfoEntPaint.setNodeId(resultSet.getInt("node_id"));
				documentInfoEntPaint.setProcenterParentId(resultSet.getInt("procenter_parent_id"));

				listDoc.add(0, documentInfoEntPaint);

			}
		} catch (SQLException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}

		HashMap<String, String> ret = instance.refEditMain(listDoc, "C:\\JUnitTest\\", resourceLoader, tmpTxtId, "0001",
				"3", tmpMaskDocTmpMarkerService, tmpMaskDocumentService, docInfoService);

		assertEquals(ret.get("strPageCnt"), "1");
		assertEquals(ret.get("strRefHtmlName"), "4.html");
		assertEquals(ret.get("strRefFileName"), "test02.txt");
		assertEquals(ret.get("strRefPageCnt"), "1");
		assertEquals(ret.get("strHeight"), "785");

	}
//
	@Test
	public void test_refEditMainXls() {

		RefEdit instance = new RefEdit();

		// DBとの接続を確立
		dbConnection.DBConnect();

		// 削除のSQL文
		// 外部キーのあるテーブルから削除
		try {
			dbConnection.SQLExe(deleteMaskDocumentMarkerInfo);
			dbConnection.SQLExe(deleteMaskDocumentInfo);
			dbConnection.SQLExe(deleteTmpDocumentMarkerInfo);
			dbConnection.SQLExe(deleteTmpDocumentInfo);
			dbConnection.SQLExe(deleteDocumentInfo);
			dbConnection.SQLExe(deleteDocumentInternalInfo);
			dbConnection.SQLExe(deleteDirectoryInfo);
			dbConnection.SQLExe(deleteServerInfo);
			dbConnection.SQLExe(deleteDirectoryInternalInfo);

		} catch (Exception e) {
//                 e.printStackTrace();
		}

		// srcDoc : 変換するPowerPointファイルのパス
		String srcDoc1 = "C:\\Users\\Public\\Documents\\test/test01.xlsx";

		// 一度PDF変換をかませる
		String dstPdfTmp1 = "C:\\Users\\Public\\Documents\\test\\test05/test_tmp.pdf";

		// dstDoc : 変換語のHTMLファイルのパス
		String dstDoc1 = "C:\\Users\\Public\\Documents\\test\\test05/test01.html";

		// dstDoc : 変換語のHTMLファイルのパス
		String dstRedDoc1 = "C:\\Users\\Public\\Documents\\test\\test05/red_5.html";

		// srcDoc : 変換するPowerPointファイルのパス
		String srcDoc2 = "C:\\Users\\Public\\Documents\\test/test02.xlsx";

		// 一度PDF変換をかませる
		String dstPdfTmp2 = "C:\\Users\\Public\\Documents\\test\\test06/test_tmp.pdf";

		// dstDoc : 変換語のHTMLファイルのパス
		String dstDoc2 = "C:\\Users\\Public\\Documents\\test\\test06/test02.html";

		/* excel→PDF convert start */
		Workbook book = null;
		try {
			book = new Workbook(srcDoc1);
		} catch (Exception e6) {
			// TODO 自動生成された catch ブロック
			e6.printStackTrace();
		}
		PdfSaveOptions pdfSaveOptions = new PdfSaveOptions();
		try {
			book.save(dstPdfTmp1, pdfSaveOptions);
		} catch (Exception e5) {
			// TODO 自動生成された catch ブロック
			e5.printStackTrace();
		}
		if (book != null)
			book.dispose();

		/* PDF→html convert start */
		try {
			com.aspose.pdf.Document pdf = new com.aspose.pdf.Document(dstPdfTmp1);

			HtmlSaveOptions newOptions = new HtmlSaveOptions();
			// SaveOption設定
			newOptions.LettersPositioningMethod = LettersPositioningMethods.UseEmUnitsAndCompensationOfRoundingErrorsInCss;
			newOptions.FontSavingMode = HtmlSaveOptions.FontSavingModes.AlwaysSaveAsEOT;

			String strOs = System.getProperty("os.name").toLowerCase();
			if (strOs.indexOf("windows") >= 0) {
				newOptions.setDefaultFontName("MS Gothic");
			} else {
				newOptions.setDefaultFontName("VL Gothic");
			} // if

			pdf.save(dstDoc1, newOptions);

			pdf = new com.aspose.pdf.Document(dstPdfTmp1);
			pdf.save(dstRedDoc1, newOptions);
		} catch (Exception e) {
			System.err.println(e);
		} // try

		// dstDoc : 変換語のHTMLファイルのパス
		String strFileOutDir = "C:\\Users\\Public\\Documents\\test\\test05";

		// zipに固める
		String strZipOut = "C:/Users/Public/Documents/mask01.zip";
		ZipUtil.pack(new File(strFileOutDir), new File(strZipOut));

		// zipをbyte配列にする
		byte[] byteZip1 = null;
		File objZipFile = null;
		objZipFile = new File(strZipOut);
		try {
			byteZip1 = Files.readAllBytes(objZipFile.toPath());
		} catch (IOException e4) {
			// TODO 自動生成された catch ブロック
			e4.printStackTrace();
		}

		/* excel→PDF convert start */
		try {
			book = new Workbook(srcDoc2);
		} catch (Exception e3) {
			// TODO 自動生成された catch ブロック
			e3.printStackTrace();
		}
		pdfSaveOptions = new PdfSaveOptions();
		try {
			book.save(dstPdfTmp2, pdfSaveOptions);
		} catch (Exception e2) {
			// TODO 自動生成された catch ブロック
			e2.printStackTrace();
		}
		if (book != null)
			book.dispose();

		/* PDF→html convert start */
		try {
			com.aspose.pdf.Document pdf = new com.aspose.pdf.Document(dstPdfTmp2);

			HtmlSaveOptions newOptions = new HtmlSaveOptions();
			// SaveOption設定
			newOptions.LettersPositioningMethod = LettersPositioningMethods.UseEmUnitsAndCompensationOfRoundingErrorsInCss;
			newOptions.FontSavingMode = HtmlSaveOptions.FontSavingModes.AlwaysSaveAsEOT;

			String strOs = System.getProperty("os.name").toLowerCase();
			if (strOs.indexOf("windows") >= 0) {
				newOptions.setDefaultFontName("MS Gothic");
			} else {
				newOptions.setDefaultFontName("VL Gothic");
			} // if

			pdf.save(dstDoc2, newOptions);
		} catch (Exception e) {
			System.err.println(e);
		} // try

		// dstDoc : 変換語のHTMLファイルのパス
		strFileOutDir = "C:\\Users\\Public\\Documents\\test\\test06";

		// zipに固める
		strZipOut = "C:/Users/Public/Documents/mask01.zip";
		ZipUtil.pack(new File(strFileOutDir), new File(strZipOut));

		// zipをbyte配列にする
		byte[] byteZip2 = null;
		objZipFile = new File(strZipOut);
		try {
			byteZip2 = Files.readAllBytes(objZipFile.toPath());
		} catch (IOException e1) {
			// TODO 自動生成された catch ブロック
			e1.printStackTrace();
		}

		// 削除のSQL文
		// 外部キーのあるテーブルから削除
		try {
			dbConnection.SQLExe(insertSearchServerInfo);
			dbConnection.SQLExe(insertDirectoryInternalInfo);
			dbConnection.SQLExe(insertDirectoryInfo);
			dbConnection.SQLExeByte(insertXlsDocument, byteZip1, byteZip2);
			dbConnection.SQLExeByte(insertXlsDocumentInternal, byteZip1, byteZip2);
			dbConnection.SQLExeByte(insertTmpXlsDocument, byteZip1, byteZip2);
		} catch (Exception e) {
//                 e.printStackTrace();
		}

		// DocumentIDでdocument_infoから情報を取得
		ResultSet resultSet = dbConnection.SelectSQLExe(selectDocumentInfoXls);

		DocumentInfoEntPaint documentInfoEntPaint = new DocumentInfoEntPaint();
		List<DocumentInfoEntPaint> listDoc = new ArrayList<DocumentInfoEntPaint>();

		try {

			while (resultSet.next()) {
				documentInfoEntPaint.setDocumentId(Integer.parseInt(resultSet.getString("document_id")));
				documentInfoEntPaint.setDocumentContents(resultSet.getString("document_contents"));
				documentInfoEntPaint.setHtmlZipData(resultSet.getBytes("html_zip_data"));
				documentInfoEntPaint.setServerId(resultSet.getInt("server_id"));
				documentInfoEntPaint.setDocumentName(resultSet.getString("document_name"));
				documentInfoEntPaint.setExtension(resultSet.getString("extension"));
				documentInfoEntPaint.setDocumentSize(resultSet.getBigDecimal("document_size"));
				documentInfoEntPaint.setParentId(resultSet.getInt("parent_id"));
				documentInfoEntPaint.setFilePath(resultSet.getString("file_path"));
				documentInfoEntPaint.setMarker(resultSet.getString("marker"));
				documentInfoEntPaint.setCategoryId(resultSet.getInt("category_id"));
				documentInfoEntPaint.setProcenterFlg(resultSet.getBoolean("procenter_flg"));
				documentInfoEntPaint.setRetentionPeriod(resultSet.getDate("retention_period"));
				documentInfoEntPaint.setAuthor(resultSet.getString("author"));
				documentInfoEntPaint.setUpdater(resultSet.getString("updater"));
				documentInfoEntPaint.setAuthorizer(resultSet.getString("authorizer"));
				documentInfoEntPaint.setFileUpdateTime(resultSet.getDate("file_update_time"));
				documentInfoEntPaint.setMaskStatus(resultSet.getInt("mask_status"));
				documentInfoEntPaint.setCreateTime(resultSet.getDate("create_time"));
				documentInfoEntPaint.setFileUpdateTime(resultSet.getDate("update_time"));
				documentInfoEntPaint.setNodeId(resultSet.getInt("node_id"));
				documentInfoEntPaint.setProcenterParentId(resultSet.getInt("procenter_parent_id"));

				listDoc.add(0, documentInfoEntPaint);

			}
		} catch (SQLException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}

		HashMap<String, String> ret = instance.refEditMain(listDoc, "C:/JUnitTest/", resourceLoader, tmpXlsId, "0001",
				"3", tmpMaskDocTmpMarkerService, tmpMaskDocumentService, docInfoService);

		assertEquals(ret.get("strPageCnt"), "1");
		assertEquals(ret.get("strRefHtmlName"), "6.html");
		assertEquals(ret.get("strRefFileName"), "test02.xlsx");
		assertEquals(ret.get("strRefPageCnt"), "1");
		assertEquals(ret.get("strHeight"), "785");

	}
//
////
	@Test
	public void test_refEditMainPpt() {

		RefEdit instance = new RefEdit();

		// DBとの接続を確立
		dbConnection.DBConnect();

		// 削除のSQL文
		// 外部キーのあるテーブルから削除
		try {
			dbConnection.SQLExe(deleteMaskDocumentMarkerInfo);
			dbConnection.SQLExe(deleteMaskDocumentInfo);
			dbConnection.SQLExe(deleteTmpDocumentMarkerInfo);
			dbConnection.SQLExe(deleteTmpDocumentInfo);
			dbConnection.SQLExe(deleteDocumentInfo);
			dbConnection.SQLExe(deleteDocumentInternalInfo);
			dbConnection.SQLExe(deleteDirectoryInfo);
			dbConnection.SQLExe(deleteServerInfo);
			dbConnection.SQLExe(deleteDirectoryInternalInfo);

		} catch (Exception e) {
//                 e.printStackTrace();
		}

		// srcDoc : 変換するPowerPointファイルのパス
		String srcDoc1 = "C:\\Users\\Public\\Documents\\test/test01.pptx";

		// 一度PDF変換をかませる
		String dstPdfTmp1 = "C:\\Users\\Public\\Documents\\test\\test07/test_tmp.pdf";

		// dstDoc : 変換語のHTMLファイルのパス
		String dstDoc1 = "C:\\Users\\Public\\Documents\\test\\test07/test01.html";

		// dstDoc : 変換語のHTMLファイルのパス
		String dstRedDoc1 = "C:\\Users\\Public\\Documents\\test\\test07/red_7.html";

		// srcDoc : 変換するPowerPointファイルのパス
		String srcDoc2 = "C:\\Users\\Public\\Documents\\test/test02.pptx";

		// 一度PDF変換をかませる
		String dstPdfTmp2 = "C:\\Users\\Public\\Documents\\test\\test08/test_tmp.pdf";

		// dstDoc : 変換語のHTMLファイルのパス
		String dstDoc2 = "C:\\Users\\Public\\Documents\\test\\test08/test02.html";

		// PowerPointファイルの読み込み
		Presentation presentation = new Presentation(srcDoc1);

		// ppt→pdf
		presentation.save(dstPdfTmp1, SaveFormat.Pdf);

		// pdf→HTML変換
		com.aspose.pdf.Document pdf = new com.aspose.pdf.Document(dstPdfTmp1);

		HtmlSaveOptions newOptions = new HtmlSaveOptions();
		// SaveOption設定
		newOptions.LettersPositioningMethod = LettersPositioningMethods.UseEmUnitsAndCompensationOfRoundingErrorsInCss;
		newOptions.FontSavingMode = HtmlSaveOptions.FontSavingModes.AlwaysSaveAsEOT;

		String strOs = System.getProperty("os.name").toLowerCase();
		if (strOs.indexOf("windows") >= 0) {
			newOptions.setDefaultFontName("MS Gothic");
		} else {
			newOptions.setDefaultFontName("VL Gothic");
		} // if
		pdf.save(dstRedDoc1, newOptions);


		// pdf→HTML変換
		pdf = new com.aspose.pdf.Document(dstPdfTmp1);
		pdf.save(dstDoc1, newOptions);


		// dstDoc : 変換語のHTMLファイルのパス
		String strFileOutDir = "C:\\Users\\Public\\Documents\\test\\test07";

		// zipに固める
		String strZipOut = "C:/Users/Public/Documents/mask01.zip";
		ZipUtil.pack(new File(strFileOutDir), new File(strZipOut));

		// zipをbyte配列にする
		byte[] byteZip1 = null;
		File objZipFile = null;
		objZipFile = new File(strZipOut);
		try {
			byteZip1 = Files.readAllBytes(objZipFile.toPath());
		} catch (IOException e4) {
			// TODO 自動生成された catch ブロック
			e4.printStackTrace();
		}

		// PowerPointファイルの読み込み
		presentation = new Presentation(srcDoc2);

		// ppt→pdf
		presentation.save(dstPdfTmp2, SaveFormat.Pdf);

		// pdf→HTML変換
		pdf = new com.aspose.pdf.Document(dstPdfTmp2);

		pdf.save(dstDoc2, newOptions);

		// dstDoc : 変換語のHTMLファイルのパス
		strFileOutDir = "C:\\Users\\Public\\Documents\\test\\test08";

		// zipに固める
		strZipOut = "C:/Users/Public/Documents/mask01.zip";
		ZipUtil.pack(new File(strFileOutDir), new File(strZipOut));

		// zipをbyte配列にする
		byte[] byteZip2 = null;
		objZipFile = new File(strZipOut);
		try {
			byteZip2 = Files.readAllBytes(objZipFile.toPath());
		} catch (IOException e1) {
			// TODO 自動生成された catch ブロック
			e1.printStackTrace();
		}

		// 削除のSQL文
		// 外部キーのあるテーブルから削除
		try {
			dbConnection.SQLExe(insertSearchServerInfo);
			dbConnection.SQLExe(insertDirectoryInternalInfo);
			dbConnection.SQLExe(insertDirectoryInfo);
			dbConnection.SQLExeByte(insertPptDocument, byteZip1, byteZip2);
			dbConnection.SQLExeByte(insertPptDocumentInternal, byteZip1, byteZip2);
			dbConnection.SQLExeByte(insertTmpPptDocument, byteZip1, byteZip2);
		} catch (Exception e) {
//                 e.printStackTrace();
		}

	// DocumentIDでdocument_infoから情報を取得
			ResultSet resultSet = dbConnection.SelectSQLExe(selectDocumentInfoPpt);

			DocumentInfoEntPaint documentInfoEntPaint = new DocumentInfoEntPaint();
			List<DocumentInfoEntPaint> listDoc = new ArrayList<DocumentInfoEntPaint>();

			try {

				while (resultSet.next()) {
					documentInfoEntPaint.setDocumentId(Integer.parseInt(resultSet.getString("document_id")));
					documentInfoEntPaint.setDocumentContents(resultSet.getString("document_contents"));
					documentInfoEntPaint.setHtmlZipData(resultSet.getBytes("html_zip_data"));
					documentInfoEntPaint.setServerId(resultSet.getInt("server_id"));
					documentInfoEntPaint.setDocumentName(resultSet.getString("document_name"));
					documentInfoEntPaint.setExtension(resultSet.getString("extension"));
					documentInfoEntPaint.setDocumentSize(resultSet.getBigDecimal("document_size"));
					documentInfoEntPaint.setParentId(resultSet.getInt("parent_id"));
					documentInfoEntPaint.setFilePath(resultSet.getString("file_path"));
					documentInfoEntPaint.setMarker(resultSet.getString("marker"));
					documentInfoEntPaint.setCategoryId(resultSet.getInt("category_id"));
					documentInfoEntPaint.setProcenterFlg(resultSet.getBoolean("procenter_flg"));
					documentInfoEntPaint.setRetentionPeriod(resultSet.getDate("retention_period"));
					documentInfoEntPaint.setAuthor(resultSet.getString("author"));
					documentInfoEntPaint.setUpdater(resultSet.getString("updater"));
					documentInfoEntPaint.setAuthorizer(resultSet.getString("authorizer"));
					documentInfoEntPaint.setFileUpdateTime(resultSet.getDate("file_update_time"));
					documentInfoEntPaint.setMaskStatus(resultSet.getInt("mask_status"));
					documentInfoEntPaint.setCreateTime(resultSet.getDate("create_time"));
					documentInfoEntPaint.setFileUpdateTime(resultSet.getDate("update_time"));
					documentInfoEntPaint.setNodeId(resultSet.getInt("node_id"));
					documentInfoEntPaint.setProcenterParentId(resultSet.getInt("procenter_parent_id"));

					listDoc.add(0, documentInfoEntPaint);

				}
			} catch (SQLException e) {
				// TODO 自動生成された catch ブロック
				e.printStackTrace();
			}

		HashMap<String, String> ret = instance.refEditMain(listDoc, "C:/JUnitTest/", resourceLoader, tmpPptId, "0001",
				"3", tmpMaskDocTmpMarkerService, tmpMaskDocumentService, docInfoService);

		assertEquals(ret.get("strPageCnt"), "1");
		assertEquals(ret.get("strRefHtmlName"), "8.html");
		assertEquals(ret.get("strRefFileName"), "test02.pptx");
		assertEquals(ret.get("strRefPageCnt"), "1");
		assertEquals(ret.get("strHeight"), "485");

	}

//
	@Test
	public void test_refEditMainPdf() {

		RefEdit instance = new RefEdit();

		// DBとの接続を確立
		dbConnection.DBConnect();

		// 削除のSQL文
		// 外部キーのあるテーブルから削除
		try {
			dbConnection.SQLExe(deleteMaskDocumentMarkerInfo);
			dbConnection.SQLExe(deleteMaskDocumentInfo);
			dbConnection.SQLExe(deleteTmpDocumentMarkerInfo);
			dbConnection.SQLExe(deleteTmpDocumentInfo);
			dbConnection.SQLExe(deleteDocumentInfo);
			dbConnection.SQLExe(deleteDocumentInternalInfo);
			dbConnection.SQLExe(deleteDirectoryInfo);
			dbConnection.SQLExe(deleteServerInfo);
			dbConnection.SQLExe(deleteDirectoryInternalInfo);

		} catch (Exception e) {
//        e.printStackTrace();
		}

		// srcDoc : 変換するPowerPointファイルのパス
		String srcDoc1 = "C:\\Users\\Public\\Documents\\test/test01.pdf";

		// dstDoc : 変換語のHTMLファイルのパス
		String dstDoc1 = "C:\\Users\\Public\\Documents\\test\\test09/test01.html";

		// dstDoc : 変換語のHTMLファイルのパス
		String dstRedDoc1 = "C:\\Users\\Public\\Documents\\test\\test09/red_9.html";

		// srcDoc : 変換するPowerPointファイルのパス
		String srcDoc2 = "C:\\Users\\Public\\Documents\\test/test02.pdf";

		// dstDoc : 変換語のHTMLファイルのパス
		String dstDoc2 = "C:\\Users\\Public\\Documents\\test\\test10/test02.html";


		com.aspose.pdf.Document pdf = new com.aspose.pdf.Document(srcDoc1);

		HtmlSaveOptions newOptions = new HtmlSaveOptions();
		//SaveOption設定
		newOptions.LettersPositioningMethod = LettersPositioningMethods.UseEmUnitsAndCompensationOfRoundingErrorsInCss;
		newOptions.FontSavingMode = HtmlSaveOptions.FontSavingModes.SaveInAllFormats;

		pdf.save(dstDoc1, newOptions);

		// pdf→HTML変換
		pdf = new com.aspose.pdf.Document(srcDoc1);
		pdf.save(dstRedDoc1, newOptions);


		pdf = new com.aspose.pdf.Document(srcDoc2);


		pdf.save(dstDoc2, newOptions);




		// dstDoc : 変換語のHTMLファイルのパス
		String strFileOutDir1 = "C:\\Users\\Public\\Documents\\test\\test09";

		// zipに固める
		String strZipOut1 = "C:/Users/Public/Documents/mask01.zip";
		ZipUtil.pack(new File(strFileOutDir1), new File(strZipOut1));

		// zipをbyte配列にする
		byte[] byteZip1 = null;
		File objZipFile = null;
		objZipFile = new File(strZipOut1);
		try {
			byteZip1 = Files.readAllBytes(objZipFile.toPath());
		} catch (IOException e2) {
			// TODO 自動生成された catch ブロック
			e2.printStackTrace();
		}

		// dstDoc : 変換語のHTMLファイルのパス
		String strFileOutDir2 = "C:\\Users\\Public\\Documents\\test\\test10";

		// zipに固める
		String strZipOut2 = "C:/Users/Public/Documents/mask02.zip";
		ZipUtil.pack(new File(strFileOutDir2), new File(strZipOut2));

		// zipをbyte配列にする
		byte[] byteZip2 = null;
		objZipFile = new File(strZipOut2);
		try {
			byteZip2 = Files.readAllBytes(objZipFile.toPath());
		} catch (IOException e1) {
			// TODO 自動生成された catch ブロック
			e1.printStackTrace();
		}

		// 削除のSQL文
		// 外部キーのあるテーブルから削除
		try {
			dbConnection.SQLExe(insertSearchServerInfo);
			dbConnection.SQLExe(insertDirectoryInternalInfo);
			dbConnection.SQLExe(insertDirectoryInfo);
			dbConnection.SQLExeByte(insertPdfDocument, byteZip1, byteZip2);
			dbConnection.SQLExeByte(insertPdfDocumentInternal, byteZip1, byteZip2);
			dbConnection.SQLExeByte(insertTmpPdfDocument, byteZip1, byteZip2);
		} catch (Exception e) {
//        e.printStackTrace();
		}

		// DocumentIDでdocument_infoから情報を取得
		ResultSet resultSet = dbConnection.SelectSQLExe(selectDocumentInfoPdf);

		DocumentInfoEntPaint documentInfoEntPaint = new DocumentInfoEntPaint();
		List<DocumentInfoEntPaint> listDoc = new ArrayList<DocumentInfoEntPaint>();

		try {

			while (resultSet.next()) {
				documentInfoEntPaint.setDocumentId(Integer.parseInt(resultSet.getString("document_id")));
				documentInfoEntPaint.setDocumentContents(resultSet.getString("document_contents"));
				documentInfoEntPaint.setHtmlZipData(resultSet.getBytes("html_zip_data"));
				documentInfoEntPaint.setServerId(resultSet.getInt("server_id"));
				documentInfoEntPaint.setDocumentName(resultSet.getString("document_name"));
				documentInfoEntPaint.setExtension(resultSet.getString("extension"));
				documentInfoEntPaint.setDocumentSize(resultSet.getBigDecimal("document_size"));
				documentInfoEntPaint.setParentId(resultSet.getInt("parent_id"));
				documentInfoEntPaint.setFilePath(resultSet.getString("file_path"));
				documentInfoEntPaint.setMarker(resultSet.getString("marker"));
				documentInfoEntPaint.setCategoryId(resultSet.getInt("category_id"));
				documentInfoEntPaint.setProcenterFlg(resultSet.getBoolean("procenter_flg"));
				documentInfoEntPaint.setRetentionPeriod(resultSet.getDate("retention_period"));
				documentInfoEntPaint.setAuthor(resultSet.getString("author"));
				documentInfoEntPaint.setUpdater(resultSet.getString("updater"));
				documentInfoEntPaint.setAuthorizer(resultSet.getString("authorizer"));
				documentInfoEntPaint.setFileUpdateTime(resultSet.getDate("file_update_time"));
				documentInfoEntPaint.setMaskStatus(resultSet.getInt("mask_status"));
				documentInfoEntPaint.setCreateTime(resultSet.getDate("create_time"));
				documentInfoEntPaint.setFileUpdateTime(resultSet.getDate("update_time"));
				documentInfoEntPaint.setNodeId(resultSet.getInt("node_id"));
				documentInfoEntPaint.setProcenterParentId(resultSet.getInt("procenter_parent_id"));

				listDoc.add(0, documentInfoEntPaint);

			}
		} catch (SQLException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}

		HashMap<String, String> ret = instance.refEditMain(listDoc, "C:/JUnitTest/", resourceLoader, tmpPdfId, "0001",
				"3", tmpMaskDocTmpMarkerService, tmpMaskDocumentService, docInfoService);

		assertEquals(ret.get("strPageCnt"), "1");
		assertEquals(ret.get("strRefHtmlName"), "10.html");
		assertEquals(ret.get("strRefFileName"), "test02.pdf");
		assertEquals(ret.get("strRefPageCnt"), "1");
		assertEquals(ret.get("strHeight"), "785");

	}
}
