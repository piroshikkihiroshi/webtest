package jp.co.nec.docmng.common;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.junit.runner.RunWith;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@SuppressWarnings("javadoc")
@RunWith(SpringJUnit4ClassRunner.class)
public class DBConnection {
	/** DB接続インスタンス */
	Connection connection = null;

	PreparedStatement ps = null;

	DefaultResourceLoader resourceLoader;
	InputStreamReader reader;

	/**
	 * DB接続
	 */
	public void DBConnect() {
		try {
			resourceLoader = new DefaultResourceLoader();
			Resource resource = resourceLoader.getResource("classpath:/config/application.yml");
			reader = new InputStreamReader(resource.getInputStream());
			InputStream objIs = resource.getInputStream();
			byte[] arrByte = null;
			arrByte = IOUtils.toByteArray(objIs);
			String strYml = new String(arrByte);
			String url = "";
			String username = "";
			String password = "";
			String[] arrYml = strYml.split("\r\n");
			for (int i = 0; i < arrYml.length; i++) {
				String strTmp = arrYml[i];
				if (strTmp.contains("url")) {
					url = strTmp.replaceFirst("^.+url:", "").trim();
				} else if (strTmp.contains("username")) {
					username = strTmp.replaceFirst("^.+username:", "").trim();
				} else if (strTmp.contains("password")) {
					password = strTmp.replaceFirst("^.+password:", "").trim();
				} //if

			} //for

			connection = DriverManager.getConnection(
					url, // "jdbc:postgresql://<場所>:<ポート>/<データベース名>"
					username, //user
					password);
		} catch (SQLException e) {
			e.printStackTrace();
		} //password;
		catch (IOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
	}

	/**
	 * DB接続(コネクション返却)
	 */
	public Connection DBConnectReturn() {
		try {
			resourceLoader = new DefaultResourceLoader();
			Resource resource = resourceLoader.getResource("classpath:/config/application.yml");
			reader = new InputStreamReader(resource.getInputStream());
			InputStream objIs = resource.getInputStream();
			byte[] arrByte = null;
			arrByte = IOUtils.toByteArray(objIs);
			String strYml = new String(arrByte);
			String url = "";
			String username = "";
			String password = "";
			String[] arrYml = strYml.split("\r\n");
			for (int i = 0; i < arrYml.length; i++) {
				String strTmp = arrYml[i];
				if (strTmp.contains("url")) {
					url = strTmp.replaceFirst("^.+url:", "").trim();
				} else if (strTmp.contains("username")) {
					username = strTmp.replaceFirst("^.+username:", "").trim();
				} else if (strTmp.contains("password")) {
					password = strTmp.replaceFirst("^.+password:", "").trim();
				} //if

			} //for

			connection = DriverManager.getConnection(
					url, // "jdbc:postgresql://<場所>:<ポート>/<データベース名>"
					username, //user
					password);
		} catch (SQLException e) {
			e.printStackTrace();
		} //password;
		catch (IOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		} //try
		return connection;
	} //method

	/**
	 * DB切断
	 */
	public void DBClose() {
		try {
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 更新系のSQL実行
	 * @param sql
	 */
	public void SQLExe(String sql) {
		try {
			ps = connection.prepareStatement(sql);
			ps.executeUpdate();
			//            connection.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 更新系のSQL実行
	 * @param sql
	 */
	public void SQLExeByte(String sql, byte[] byteZip1, byte[] byteZip2) {
		try {
			ps = connection.prepareStatement(sql);
			ps.setBytes(1, byteZip1);
			ps.setBytes(2, byteZip2);
			ps.executeUpdate();
			//            connection.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 更新系のSQL実行
	 * @param sql
	 */
	public void SQLExeZipData(String sql, List<byte[]> zipData) {
		try {
			ps = connection.prepareStatement(sql);
			for (int i = 0; i < zipData.size(); i++) {
				byte[] data = zipData.get(i);
				ps.setBytes(i + 1, data);
			}
			ps.executeUpdate();
			//            connection.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 検索系のSQL実行
	 * @param sql
	 * @return ResultSet 検索結果
	 */
	public ResultSet SelectSQLExe(String sql) {
		ResultSet resultSet = null;
		try {
			Statement st = connection.createStatement();
			resultSet = st.executeQuery(sql);
			ResultSetMetaData rsmd = resultSet.getMetaData();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return resultSet;
	}
}
