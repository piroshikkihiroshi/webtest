package jp.co.nec.docmng.manage.controller;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.Cookie;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.common.DBConnection;
import jp.co.nec.docmng.manage.entity.SearchServerInfoEntity;
import jp.co.nec.docmng.manage.entity.SearchServerInfoForm;
import jp.co.nec.docmng.manage.entity.SearchServerInfoSaveFrom;
import jp.co.nec.docmng.manage.entity.SearchServerInfoSaveFrom.AddValues;
import jp.co.nec.docmng.manage.entity.SearchServerInfoSaveFrom.ChangedValues;

@SuppressWarnings("javadoc")
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class SearchServerInfoControllerTest {

    DBConnection dbConnection = new DBConnection();

    private MockMvc mockMvc;

    @Autowired
    SearchServerInfoController target;

    @Before
    public void setup() {
        mockMvc = MockMvcBuilders.standaloneSetup(target).build();
    }

    /**
     * 設定反映ステータス：成功
     */
    private static final String SUCCESS = "success";

    /**
     * 設定反映ステータス：失敗
     */
    private static final String FAILURE = "failure";

    // private static final String ERR_1219 = "1219";

    String insertSearchServerInfo = "insert into admin.search_server_info" +
            "	(server_id, server_name, display_name, login_user_name, login_password, directory_path, create_time, update_time)" +
            "	values" +
            "	(996, '\\\\yoks3016', 'disp996', 'user996', 'pass996', '\\\\yoks3106\\Project\\NES_文書管理システム\\99_tmp\\岩淵\\test\\server', '2019/11/13 00:00:00', '2019/11/13 00:00:00')," +
            "	(997, '\\\\yoks3016', 'disp997', 'user997', 'pass997', '\\\\yoks3106\\Project\\NES_文書管理システム\\99_tmp\\岩淵\\test\\server', '2019/11/13 00:00:00', '2019/11/13 00:00:00')," +
            "	(998, '\\\\yoks3016', 'disp998', 'user998', 'pass998', '\\\\yoks3106\\Project\\NES_文書管理システム\\99_tmp\\岩淵\\test\\server', '2019/11/13 00:00:00', '2019/11/13 00:00:00')," +
            "	(999, '\\\\yoks3016', 'disp999', 'user999', 'pass999', '\\\\yoks3106\\Project\\NES_文書管理システム\\99_tmp\\岩淵\\test\\server', '2019/11/13 00:00:00', '2019/11/13 00:00:00');" +
            "";

    String deleteSearchServerInfo = "delete from admin.search_server_info where server_id in (996, 997, 998, 999)";

    /**
     * A001_test_getSearchServerInfo（エラー系）
     * 検索対象サーバ設定画面表示
     * ログインクッキーが設定されていない場合
     * @throws Exception
     */
    @Test
    @SuppressWarnings("unused")
    public void A001_test_getSearchServerInfo() throws Exception{
        try {
            // DBとの接続を確立
            dbConnection.DBConnect();
            dbConnection.SQLExe(insertSearchServerInfo);

            MvcResult result = mockMvc.perform(get("/manage/search_server")
                    .param("searchServerInfoForm", ""))
            .andExpect(status().isOk())
            .andExpect(view().name("manage/searchServer"))
            .andExpect(model().attribute("userAuth", 1))
            .andReturn();

            System.out.println("A001_test_getSearchServerInfo 正常完了");
        } catch (Exception e ) {
            e.printStackTrace();
            throw e;
        } finally {
            // DBからテストデータ削除
            dbConnection.SQLExe(deleteSearchServerInfo);
        }
    }

    /**
     * A002_test_getSearchServerInfo（エラー系）
     * 検索対象サーバ設定画面表示
     * 管理者権限ではない場合
     * @throws Exception
     */
    @Test
    @SuppressWarnings("unused")
    public void A002_test_getSearchServerInfo() throws Exception{
        try {
            // DBとの接続を確立
            dbConnection.DBConnect();
            dbConnection.SQLExe(insertSearchServerInfo);

            Cookie cookies = new Cookie("userInfo", "\"userRole\":\"users\"");
            MvcResult result = mockMvc.perform(get("/manage/search_server")
                    .param("searchServerInfoForm", "").cookie(cookies))
            .andExpect(status().isOk())
            .andExpect(view().name("manage/searchServer"))
            .andExpect(model().attribute("userAuth", 1))
            .andReturn();

            System.out.println("A002_test_getSearchServerInfo 正常完了");
        } catch (Exception e ) {
            e.printStackTrace();
            throw e;
        } finally {
            // DBからテストデータ削除
            dbConnection.SQLExe(deleteSearchServerInfo);
        }
    }

    /**
     * A003_test_getSearchServerInfo（正常系）
     * 検索対象サーバ設定画面表示
     * @throws Exception
     */
    @Test
    public void A003_test_getSearchServerInfo() throws Exception{
        try {
            // DBとの接続を確立
            dbConnection.DBConnect();
            dbConnection.SQLExe(insertSearchServerInfo);

            Cookie cookies = new Cookie("userInfo", "\"userRole\":\"Administrators\"");
            MvcResult result = mockMvc.perform(get("/manage/search_server")
                    .param("searchServerInfoForm", "").cookie(cookies))
            .andExpect(status().isOk())
            .andExpect(view().name("manage/searchServer"))
            .andReturn();

            // 検索対象サーバ一覧
            @SuppressWarnings("unchecked")
            List<SearchServerInfoEntity> searchServerInfoList =
                    (List<SearchServerInfoEntity>) result.getModelAndView().getModel().get("serchServerInfo");

            // 取得したサーバ名保存
            List<Integer> serverId = new ArrayList<Integer>();
            // テストデータで登録したサーバ名
            List<Integer> insertServerId = new ArrayList<Integer>(Arrays.asList(
                    996, 997, 998 , 999));

            for (SearchServerInfoEntity ssil : searchServerInfoList) {
                serverId.add(ssil.getServerId());
            }
            // テストデータが応答値に含まれている事を確認
            assertTrue(serverId.containsAll(insertServerId));
            System.out.println("A003_test_getSearchServerInfo 正常完了");
        } catch (Exception e ) {
            e.printStackTrace();
            throw e;
        } finally {
            // DBからテストデータ削除
            dbConnection.SQLExe(deleteSearchServerInfo);
        }
    }

    /**
     * B001_test_save（正常系）
     * 検索対象サーバ設定画面　設定反映
     * @throws Exception
     */
    @Test
    public void B001_test_save() throws Exception{

        // 追加データ
        String addServerName = "addServerName";
        String addDisplayName = "addDispName";
        String addDirectoryPath = "\\\\yoks3016";
        String addUserName = "addUserName";
        String addUserPass = "addUserPass";
        // 編集データ
        Integer changeServerId = 996;
        String changeServerName = "changeServerName";
        String changeDisplayName = "changeDispName";
        String changeDirectoryPath = "\\\\yoks3016";
        String changeUserName = "changeUserName";
        String changeUserPass = "changeUserPass";
        // 削除データ
        Integer deleteServerId = 999;

        try {
            dbConnection.DBConnect();
            dbConnection.SQLExe(insertSearchServerInfo);

            SearchServerInfoSaveFrom requestForm = new SearchServerInfoSaveFrom();
            // リクエストデータ作詞絵
            List<AddValues> addValues = new ArrayList<AddValues>();
            List<ChangedValues> changeValues = new ArrayList<ChangedValues>();
            List<Integer> deleteRow = new ArrayList<Integer>();

            AddValues addValue = new AddValues();
            ChangedValues changeValue = new ChangedValues();

            // 追加データ
            addValue.setServerName(addServerName);
            addValue.setDisplayName(addDisplayName);
            addValue.setDirectoryPath(addDirectoryPath);
            addValue.setLoginUserName(addUserName);
            addValue.setLoginPassword(addUserPass);
            addValues.add(addValue);
            // 編集データ
            changeValue.setServerId(changeServerId);
            changeValue.setServerName(changeServerName);
            changeValue.setDisplayName(changeDisplayName);
            changeValue.setDirectoryPath(changeDirectoryPath);
            changeValue.setLoginUserName(changeUserName);
            changeValue.setLoginPassword(changeUserPass);
            changeValues.add(changeValue);
            //削除データ
            deleteRow.add(deleteServerId);

            requestForm.setAddValues(addValues);
            requestForm.setChangedValues(changeValues);
            requestForm.setDeleteRow(deleteRow);

            ObjectMapper mapper = new ObjectMapper();
            String requestJson = mapper.writeValueAsString(requestForm);

            // POST
            mockMvc.perform(post("/manage/search_server/save")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(requestJson))
                    .andExpect(status().isOk());

            // 追加確認
            String select = "select * from admin.search_server_info where display_name = '" + addDisplayName+ "'";
            ResultSet addRs = dbConnection.SelectSQLExe(select);
            // 行が取得出来ているなら登録OK
            assertTrue(addRs.next());
            addRs.close();

            // 変更確認
            String changeselect = "select * from admin.search_server_info where display_name = '" + changeDisplayName + "'";
            ResultSet changeRs = dbConnection.SelectSQLExe(changeselect);
            // 行が取得出来ているなら登録OK
            assertTrue(changeRs.next());
            changeRs.close();

            // 削除確認
            String delselect = "select * from admin.search_server_info where server_id = '" + deleteServerId+ "'";
            ResultSet delRs = dbConnection.SelectSQLExe(delselect);
            // 削除しているため0件
            assertTrue(!delRs.next());
            delRs.close();
            System.out.println("B001_test_save 正常終了");
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            // DBからテストデータ削除
            // 追加行削除する
            String addColumnDelSql = "delete from admin.search_server_info where display_name = '" + addDisplayName + "'";
            dbConnection.SQLExe(addColumnDelSql);
            // 削除行を取り除いた他の行も削除
            String delColumnDelSql = "delete from admin.search_server_info where server_id in (996, 997, 998, 999)";
            dbConnection.SQLExe(delColumnDelSql);
        }
    }

    /**
     * test_auth001（ネットワークが見つからない）
     * 検索対象サーバ設定画面　認証
     * @throws Exception
     */
    @Test
    public void test_auth001() throws Exception {

        //TODO
        SearchServerInfoForm form = new SearchServerInfoForm();
        form.setDirectoryPath("\\aaa");
        form.setLoginUserName("test");
        form.setLoginPassword("test");

        ObjectMapper mapper = new ObjectMapper();
        String requestJson = mapper.writeValueAsString(form);
        // POST
        MvcResult result = mockMvc.perform(post("/manage/search_server/auth")
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestJson))
                .andExpect(status().isOk())
                .andReturn();

        String resultData = result.getResponse().getContentAsString().replace("\"", "");
        assertEquals(resultData, FAILURE);
        System.out.println("test_auth001 正常終了");
    }

    /**
     * test_auth002（成功）
     * 検索対象サーバ設定画面　認証
     * @throws Exception
     */
    @Test
    public void test_auth002() throws Exception {

        SearchServerInfoForm form = new SearchServerInfoForm();
        form.setServerName("yoks3106");
        form.setDirectoryPath("\\DocMng\\01_test");
        form.setLoginUserName("FUSI\\DocMngUser");
        form.setLoginPassword("DocMng2019");

        ObjectMapper mapper = new ObjectMapper();
        String requestJson = mapper.writeValueAsString(form);
        // POST
        MvcResult result = mockMvc.perform(post("/manage/search_server/auth")
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestJson))
                .andExpect(status().isOk())
                .andReturn();

        String resultData = result.getResponse().getContentAsString().replace("\"", "");
        assertEquals(resultData, SUCCESS);
        System.out.println("test_auth002 正常終了");
    }

    /**
     * test_auth003（システム エラー 1219）
     * 検索対象サーバ設定画面
     * ユーザ名なし　パスワードなし
     * @throws Exception
     */
    @Test
    @SuppressWarnings("unused")
    public void test_auth003() throws Exception {

        SearchServerInfoForm form = new SearchServerInfoForm();
        form.setServerName("yoks3106");
        form.setDirectoryPath("\\DocMng\\01_test");
        form.setLoginUserName("");
        form.setLoginPassword("");

        ObjectMapper mapper = new ObjectMapper();
        String requestJson = mapper.writeValueAsString(form);
        // POST
        MvcResult result = mockMvc.perform(post("/manage/search_server/auth")
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestJson))
                .andExpect(status().isOk())
                .andReturn();

        String resultData = result.getResponse().getContentAsString().replace("\"", "");
        //assertEquals(resultData, ERR_1219);

        System.out.println("test_auth003 正常終了");
    }

    /**
     * test_auth004（システム エラー 1219）
     * 検索対象サーバ設定画面　
     * ユーザ名あり　パスワードなし
     * @throws Exception
     */
    @Test
    @SuppressWarnings("unused")
    public void test_auth004() throws Exception {

        //TODO
        SearchServerInfoForm form = new SearchServerInfoForm();
        form.setServerName("yoks3106");
        form.setDirectoryPath("\\DocMng\\01_test");
        form.setLoginUserName("test");
        form.setLoginPassword("");

        ObjectMapper mapper = new ObjectMapper();
        String requestJson = mapper.writeValueAsString(form);
        // POST
        MvcResult result = mockMvc.perform(post("/manage/search_server/auth")
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestJson))
                .andExpect(status().isOk())
                .andReturn();

        String resultData = result.getResponse().getContentAsString().replace("\"", "");
        //assertEquals(resultData, ERR_1219);

        System.out.println("test_auth004 正常終了");
    }
}
