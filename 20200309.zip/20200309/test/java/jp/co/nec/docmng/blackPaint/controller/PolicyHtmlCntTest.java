package jp.co.nec.docmng.blackPaint.controller;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.ui.Model;

import jp.co.nec.docmng.common.DBConnection;

@SuppressWarnings("javadoc")
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class PolicyHtmlCntTest extends SpringBootServletInitializer {

	// DBアクセス用クラス
	DBConnection dbConnection = new DBConnection();
	PreparedStatement ps = null;

	@Autowired
	HttpServletRequest request;

	@Autowired
	HttpServletResponse response;

	@Mock
	private Model model;

	@Autowired
	PolicyHtmlCnt policyHtmlCnt;

	// DB項目の挿入

	String insertPolicyInfo = ""
			+ "INSERT "
			+ "INTO admin.policy_info(policy_id, policy_number, policy_name,policy_type) "
			+ " VALUES (?, 1, '',?) ";

	String insertPolicyKeyword = ""
			+ "INSERT "
			+ "INTO admin.policy_keyword_info(keyword_id, policy_id,policy_keyword) "
			+ " VALUES (?,?,'test') ";

	//Delete文
	String deletePolicyInfo = ""
			+ "DELETE "
			+ "FROM admin.policy_info "
			+ "WHERE policy_id=? ";

	String deletePolicyKeyword = ""
			+ "DELETE "
			+ "FROM admin.policy_keyword_info "
			+ "WHERE keyword_id=? ";

	/**
	 * PolicyHtmlCnt正常系
	 * @throws Exception
	 */
	@Test
	public void testPolicyHtmlCntA001() throws Exception {

		// DBとの接続を確立
		Connection connection = dbConnection.DBConnectReturn();

		try {

			//delete Sql
			ps = connection.prepareStatement(deletePolicyKeyword);
			ps.setInt(1, 1);
			ps.executeUpdate();
			ps = connection.prepareStatement(deletePolicyKeyword);
			ps.setInt(1, 2);
			ps.executeUpdate();
			ps = connection.prepareStatement(deletePolicyKeyword);
			ps.setInt(1, 3);
			ps.executeUpdate();
			ps = connection.prepareStatement(deletePolicyKeyword);
			ps.setInt(1, 4);
			ps.executeUpdate();

			ps = connection.prepareStatement(deletePolicyInfo);
			ps.setInt(1, 1);
			ps.executeUpdate();
			ps = connection.prepareStatement(deletePolicyInfo);
			ps.setInt(1, 2);
			ps.executeUpdate();
			ps = connection.prepareStatement(deletePolicyInfo);
			ps.setInt(1, 3);
			ps.executeUpdate();


			//insert Sql
			ps = connection.prepareStatement(insertPolicyInfo);
			ps.setInt(1, 1);
			ps.setInt(2, 0);
			ps.executeUpdate();
			ps = connection.prepareStatement(insertPolicyInfo);
			ps.setInt(1, 2);
			ps.setInt(2, 1);
			ps.executeUpdate();
			ps = connection.prepareStatement(insertPolicyInfo);
			ps.setInt(1, 3);
			ps.setInt(2, 2);
			ps.executeUpdate();

			ps = connection.prepareStatement(insertPolicyKeyword);
			ps.setInt(1, 1);
			ps.setInt(2, 1);
			ps.executeUpdate();
			ps = connection.prepareStatement(insertPolicyKeyword);
			ps.setInt(1, 2);
			ps.setInt(2, 1);
			ps.executeUpdate();
			ps = connection.prepareStatement(insertPolicyKeyword);
			ps.setInt(1, 3);
			ps.setInt(2, 1);
			ps.executeUpdate();
			ps = connection.prepareStatement(insertPolicyKeyword);
			ps.setInt(1, 4);
			ps.setInt(2, 1);
			ps.executeUpdate();

			String ret = policyHtmlCnt.getPolicyInfo("", model);

			assertEquals(ret, "blackPaint/SelectPolicyHtmlVeiw");

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ps = connection.prepareStatement(deletePolicyKeyword);
			ps.setInt(1, 1);
			ps.executeUpdate();
			ps = connection.prepareStatement(deletePolicyKeyword);
			ps.setInt(1, 2);
			ps.executeUpdate();
			ps = connection.prepareStatement(deletePolicyKeyword);
			ps.setInt(1, 3);
			ps.executeUpdate();
			ps = connection.prepareStatement(deletePolicyKeyword);
			ps.setInt(1, 4);
			ps.executeUpdate();

			ps = connection.prepareStatement(deletePolicyInfo);
			ps.setInt(1, 1);
			ps.executeUpdate();
			ps = connection.prepareStatement(deletePolicyInfo);
			ps.setInt(1, 2);
			ps.executeUpdate();
			ps = connection.prepareStatement(deletePolicyInfo);
			ps.setInt(1, 3);
			ps.executeUpdate();

			ps.close();
			connection.close();
		} //try

	} //method


} //class
