package jp.co.nec.docmng.blackPaint.logic.edit;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletContext;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.core.io.ResourceLoader;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.zeroturnaround.zip.ZipUtil;

import com.aspose.cells.PdfSaveOptions;
import com.aspose.cells.Workbook;
import com.aspose.pdf.HtmlSaveOptions;
import com.aspose.pdf.LettersPositioningMethods;
//import com.aspose.slides.Presentation;
//import com.aspose.words.HtmlSaveOptions;
//import com.aspose.words.PdfSaveOptions;
//import com.aspose.words.SaveFormat;

import jp.co.nec.docmng.blackPaint.entity.DocumentInfoEntPaint;
import jp.co.nec.docmng.blackPaint.entity.MaskDocumentEntBlackPaint;
import jp.co.nec.docmng.blackPaint.service.DocInfoServicePaint;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocMarkerServicePaint;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocumentServicePaint;
import jp.co.nec.docmng.common.DBConnection;
import jp.co.nec.docmng.manage.service.PolicyInfoService;

@SuppressWarnings("javadoc")
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class ExcelEditTest extends SpringBootServletInitializer {

    // DBアクセス用クラス
    DBConnection dbConnection = new DBConnection();

    @Autowired
    ServletContext context;
    @Autowired
    DocInfoServicePaint docInfoService;

    @Autowired
    TmpMaskDocMarkerServicePaint tmpMaskDocTmpMarkerService;

    @Autowired
    TmpMaskDocumentServicePaint tmpMaskDocumentService;

    @Autowired
    PolicyInfoService policyInfoService;

    @Autowired
    private ResourceLoader resourceLoader;

    // DB項目の削除(初期化)
    String deleteCategoryInfo = "delete from admin.category_info where category_id in (0, 1);";
    String deleteDocumentInfo = "delete from common.document_info where document_id in (5,6,1001);";
    String deleteDocumentInternalInfo = "delete from common.document_info_internal where document_id in (5,6,1001);";
    String deleteMaskDocument = "delete from common.mask_document where mask_id in (5,6,1001);";
    String deleteTmpMaskDocument = "delete from common.tmp_mask_document where document_id in (5,6,1001);";
    String deleteDirectoryInfo = "delete from common.directory_info where directory_id =1;";
    String deleteServerInfo = "delete from admin.search_server_info where server_id =1;";
    String deleteDirectoryInternalInfo = "delete from common.directory_info_internal where directory_id =1;";

    // DB項目の挿入
    // カテゴリ(admin)
    String insertCategoryInfo = "insert into admin.category_info" +
            "	(category_id, category_name, category_author, create_time, update_time)" +
            "	values" +
            "	(0, 'test000', 'testauthor0', '2020/3/1 00:00:00', '2020/3/3 00:00:00')," +
            "	(1, 'test001', 'testauthor1', '2019/3/1 00:00:00', '2020/3/3 00:00:00');";

    // サーバー情報
    String insertSearchServerInfo = "insert into admin.search_server_info"
            + "	(server_id, server_name, display_name, login_user_name, login_password, directory_path, create_time, update_time)"
            + "	values"
            + "	(1, '\\\\yoks3016', 'disp999', 'user999', 'pass999', '\\\\yoks3106\\Project\\NES_文書管理システム\\99_tmp', '2019/11/13 00:00:00', '2019/11/13 00:00:00');"
            + "";
    // ディレクトリ情報
    String insertDirectoryInfo = "insert into common.directory_info"
            + "	(directory_id , server_id , directory_name , parent_id , directory_path,directory_type,create_time,update_time)"
            + "	values"
            + "	(1, 1, 'crawl_test', 1, '\\\\build1006636.swf.nec.co.jp\\crawl_test', 0, '2019/11/13 00:00:00', '2019/11/13 00:00:00');"
            + "";

    // ディレクトリ情報
    String insertDirectoryInternalInfo = "insert into common.directory_info_internal"
            + "	(directory_id , server_id , directory_name , parent_id , directory_path,directory_type,crawl_act_time,directory_update_flg,directory_delete_flg,create_time,update_time)"
            + "	values"
            + "	(1, 1, 'crawl_test', 1, '\\\\build1006636.swf.nec.co.jp\\crawl_test', 0,'2019/11/13 00:00:00',false,false, '2019/11/13 00:00:00', '2019/11/13 00:00:00');"
            + "";

    //////////////////////////////////////////
    String insertXlsDocument = "INSERT INTO common.document_info("
            + "	document_id, document_contents, html_zip_data, server_id , document_name, extension, document_size  , parent_id , file_path, marker , category_id , procenter_flg , procenter_parent_id , node_id , retention_period , author , updater , authorizer , file_update_time , mask_status , create_time , update_time)"
            + "	values "
            + "	( 5 ,'テキストテスト01',? , 1,'test01.xlsx' , 'xlsx'  , 0 , 1 , '\\\\build1006636.swf.nec.co.jp\\crawl_test\\test01.xlsx', null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 , null , null),"
            + "	( 1001 ,'テキストテスト01',? , 1,'test01.xlsx' , 'xlsx'  , 0 , 1 , '\\\\build1006636.swf.nec.co.jp\\crawl_test\\test01.xlsx', null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 , null , null),"
            + "	( 6 ,'テキストテスト02',? , 1,'test02.xlsx' , 'xlsx'   , 0 , 1 , '\\\\build1006636.swf.nec.co.jp\\crawl_test\\test02.xlsx', null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 , null , null);";
    //////////////////////////////////////////

    String insertXlsDocumentInternal = "INSERT INTO common.document_info_internal("
            + "	document_id, document_contents, html_zip_data, server_id , document_name, extension, document_size  , parent_id , file_path, marker , category_id , procenter_flg , procenter_parent_id , node_id , retention_period , author , updater , authorizer , file_update_time , mask_status ,crawl_act_time,document_update_flg,document_delete_flg, create_time , update_time)"
            + "	values "
            + "	( 5 ,'テキストテスト01',?, 1,'test01.xlsx' , 'xlsx'  , 0 , 1 , '\\\\build1006636.swf.nec.co.jp\\crawl_test\\test01.xlsx', null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 ,'2019/11/13 00:00:00',false,false, null , null),"
            + "	( 1001 ,'テキストテスト01',?, 1,'test01.xlsx' , 'xlsx'  , 0 , 1 , '\\\\build1006636.swf.nec.co.jp\\crawl_test\\test01.xlsx', null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 ,'2019/11/13 00:00:00',false,false, null , null),"
            + "	( 6 ,'テキストテスト02',? , 1,'test02.xlsx' , 'xlsx ' , 0 , 1 , '\\\\build1006636.swf.nec.co.jp\\crawl_test\\test02.xlsx', null  , 0 , false , 0 , 0 , null , null , null , null , null  , 0 ,'2019/11/13 00:00:00',false,false, null , null);";

    String insertXlsMaskDocument = "INSERT INTO common.mask_document("
            + "	mask_id, document_id, user_id, html_zip_data, node_id, file_id, category_id, "
            + "mask_status, create_time, update_time)"
            + "	VALUES"
            + "	(5, 5, 'user0005', ?, 5, 5, 0, 1, '2020/3/1 00:00:00', '2020/3/3 00:00:00'),"
            + "	(1001, 5, 'user0005', ?, 5, 5, 0, 1, '2020/3/1 00:00:00', '2020/3/3 00:00:00'),"
            + "	(6, 6, 'user0006', ?, 6, 6, 1, 2, '2020/3/1 00:00:00', '2020/3/3 00:00:00');";

    String insertTmpXlsDocument = "INSERT INTO common.tmp_mask_document("
            + "	document_id, user_id, html_zip_data, create_time , update_time)" + "	values "
            + "	( 5 ,'user0005',? , null , null)," + 	"( 1001 ,'user0005',? , null , null)," + "	( 6 ,'user0006',? , null , null);";

    // document_info検索条件
    String selectDocumentInfoXls = "select * from common.document_info WHERE document_id =";
    int tmpXlsId = 6;

    // document_info検索条件
    String selectMaskDocumentXls = "select * from common.mask_document WHERE document_id =";
//    int tmpXlsId = 6;
    private void setTestData() {
        // DBとの接続を確立
        dbConnection.DBConnect();

        // 削除のSQL文
        // 外部キーのあるテーブルから削除
        try {
            System.out.println("delete db start");
            dbConnection.SQLExe(deleteMaskDocument);
            dbConnection.SQLExe(deleteDocumentInfo);
            dbConnection.SQLExe(deleteDocumentInternalInfo);
            dbConnection.SQLExe(deleteTmpMaskDocument);
            dbConnection.SQLExe(deleteDirectoryInfo);
            dbConnection.SQLExe(deleteServerInfo);
            dbConnection.SQLExe(deleteDirectoryInternalInfo);
            dbConnection.SQLExe(deleteCategoryInfo);
            System.out.println("delete db  end");
        } catch (Exception e) {
//                 e.printStackTrace();
        }

        // srcDoc : 変換するファイルのパス
        String srcDoc1 = "C:\\Users\\Public\\Documents\\test/test01.xlsx";
        // 一度PDF変換をかませる
        String dstPdfTmp1 = "C:\\Users\\Public\\Documents\\test\\test05/test_tmp.pdf";
        // dstDoc : 変換語のHTMLファイルのパス
        String dstDoc1 = "C:\\Users\\Public\\Documents\\test\\test05/test05.html";
        // dstDoc : 変換語のHTMLファイルのパス
        String dstRedDoc1 = "C:\\Users\\Public\\Documents\\test\\test05/red_5.html";

        /* excel→PDF convert start */
        Workbook book = null;
        try {
            book = new Workbook(srcDoc1);
        } catch (Exception e6) {
            // TODO 自動生成された catch ブロック
            e6.printStackTrace();
        }
        PdfSaveOptions pdfSaveOptions = new PdfSaveOptions();
        try {
            book.save(dstPdfTmp1, pdfSaveOptions);
        } catch (Exception e5) {
            // TODO 自動生成された catch ブロック
            e5.printStackTrace();
        }
        if (book != null)
            book.dispose();

        /* PDF→html convert start */
        try {
            com.aspose.pdf.Document pdf = new com.aspose.pdf.Document(dstPdfTmp1);

            HtmlSaveOptions newOptions = new HtmlSaveOptions();
            // SaveOption設定
            newOptions.LettersPositioningMethod = LettersPositioningMethods.UseEmUnitsAndCompensationOfRoundingErrorsInCss;
            newOptions.FontSavingMode = HtmlSaveOptions.FontSavingModes.AlwaysSaveAsEOT;

            String strOs = System.getProperty("os.name").toLowerCase();
            if (strOs.indexOf("windows") >= 0) {
                newOptions.setDefaultFontName("MS Gothic");
            } else {
                newOptions.setDefaultFontName("VL Gothic");
            } // if

            pdf.save(dstDoc1, newOptions);

            pdf = new com.aspose.pdf.Document(dstPdfTmp1);
            pdf.save(dstRedDoc1, newOptions);
        } catch (Exception e) {
            System.err.println(e);
        } // try

        // dstDoc : 変換語のHTMLファイルのパス
        String strFileOutDir = "C:\\Users\\Public\\Documents\\test\\test05";

        // zipに固める
        String strZipOut = "C:/Users/Public/Documents/mask01.zip";
        ZipUtil.pack(new File(strFileOutDir), new File(strZipOut));

        // zipをbyte配列にする
        List<byte[]> zipData = new ArrayList<byte[]>();

        byte[] byteZip1 = null;
        File objZipFile = null;
        objZipFile = new File(strZipOut);
        try {
            byteZip1 = Files.readAllBytes(objZipFile.toPath());
            zipData.add(byteZip1);//AIなし用
            zipData.add(byteZip1);//AIあり用
        } catch (IOException e4) {
            // TODO 自動生成された catch ブロック
            e4.printStackTrace();
        }

        try {
            strZipOut = "C:\\Users\\Public\\Documents\\test\\test07\\mask01.zip";
            // zipをbyte配列にする
            byte[] byteZip2 = null;
            objZipFile = new File(strZipOut);
            byteZip2 = Files.readAllBytes(objZipFile.toPath());
            zipData.add(byteZip2);
        } catch (IOException e1) {
            // TODO 自動生成された catch ブロック
            e1.printStackTrace();
        }

        // テストデータをInsert
        try {
            System.out.println("insert db start");
            dbConnection.SQLExe(insertCategoryInfo);
            dbConnection.SQLExe(insertSearchServerInfo);
            dbConnection.SQLExe(insertDirectoryInternalInfo);
            dbConnection.SQLExe(insertDirectoryInfo);
            dbConnection.SQLExeZipData(insertXlsDocument, zipData);
            dbConnection.SQLExeZipData(insertXlsDocumentInternal, zipData);
            dbConnection.SQLExeZipData(insertXlsMaskDocument, zipData);
            dbConnection.SQLExeZipData(insertTmpXlsDocument, zipData);
            System.out.println("insert db end");
        } catch (Exception e) {
//                 e.printStackTrace();
        }
        System.out.println("setTestData end");
    }
    /**
     * test_excelEditMain（正常系）テスト
     */
    @Test
    public void test_excelEditMain() {
        //テストデータをセットする
        setTestData();
        // 初期表示の時
        test_excelEditMain_status1();
        // 初期表示の時 AIデータあり
        test_excelEditMain_status1001();
        // 紐づけ処理の時
        test_excelEditMain_status4();
    }
    /**
     * test_excelEditMain（異常系）テスト
     */
    @Test
    public void test_excelEditMain_Err() {
        // DBとの接続を確立
        dbConnection.DBConnect();

        //テストデータをセットする
        setTestData();
        // 初期表示の時
        test_excelEditMain_status1_Err();
    }

    public void test_excelEditMain_status1() {
        System.out.println("test_excelEditMain_status1 start");
        ExcelEdit instance = new ExcelEdit();

        // DocumentIDでdocument_infoから情報を取得
        ResultSet resultSet = dbConnection.SelectSQLExe(selectDocumentInfoXls+"5");
        ResultSet resultSetMask = dbConnection.SelectSQLExe(selectMaskDocumentXls +"5");

        DocumentInfoEntPaint documentInfoEntPaint = new DocumentInfoEntPaint();
        List<DocumentInfoEntPaint> listDoc = new ArrayList<DocumentInfoEntPaint>();
        MaskDocumentEntBlackPaint maskDocumentEntBlackPaint = new MaskDocumentEntBlackPaint();
        List<MaskDocumentEntBlackPaint> listMaskDoc = new ArrayList<MaskDocumentEntBlackPaint>();
        try {
            while (resultSet.next()) {
                documentInfoEntPaint.setDocumentId(Integer.parseInt(resultSet.getString("document_id")));
                documentInfoEntPaint.setDocumentContents(resultSet.getString("document_contents"));
                documentInfoEntPaint.setHtmlZipData(resultSet.getBytes("html_zip_data"));
                documentInfoEntPaint.setServerId(resultSet.getInt("server_id"));
                documentInfoEntPaint.setDocumentName(resultSet.getString("document_name"));
                documentInfoEntPaint.setExtension(resultSet.getString("extension"));
                documentInfoEntPaint.setDocumentSize(resultSet.getBigDecimal("document_size"));
                documentInfoEntPaint.setParentId(resultSet.getInt("parent_id"));
                documentInfoEntPaint.setFilePath(resultSet.getString("file_path"));
                documentInfoEntPaint.setMarker(resultSet.getString("marker"));
                documentInfoEntPaint.setCategoryId(resultSet.getInt("category_id"));
                documentInfoEntPaint.setProcenterFlg(resultSet.getBoolean("procenter_flg"));
                documentInfoEntPaint.setRetentionPeriod(resultSet.getDate("retention_period"));
                documentInfoEntPaint.setAuthor(resultSet.getString("author"));
                documentInfoEntPaint.setUpdater(resultSet.getString("updater"));
                documentInfoEntPaint.setAuthorizer(resultSet.getString("authorizer"));
                documentInfoEntPaint.setFileUpdateTime(resultSet.getDate("file_update_time"));
                documentInfoEntPaint.setMaskStatus(resultSet.getInt("mask_status"));
                documentInfoEntPaint.setCreateTime(resultSet.getDate("create_time"));
                documentInfoEntPaint.setFileUpdateTime(resultSet.getDate("update_time"));
                documentInfoEntPaint.setNodeId(resultSet.getInt("node_id"));
                documentInfoEntPaint.setProcenterParentId(resultSet.getInt("procenter_parent_id"));
                listDoc.add(0, documentInfoEntPaint);
            }
            while(resultSetMask.next()) {
                maskDocumentEntBlackPaint.setDocumentId(Integer.parseInt(resultSetMask.getString("document_id")));
                maskDocumentEntBlackPaint.setUserId(resultSetMask.getString("user_id"));
                maskDocumentEntBlackPaint.setHtmlZipData(resultSetMask.getBytes("html_zip_data"));
                maskDocumentEntBlackPaint.setCreateTime(resultSetMask.getTimestamp("create_time"));
                maskDocumentEntBlackPaint.setUpdateTime(resultSetMask.getTimestamp("update_time"));
                maskDocumentEntBlackPaint.setFileId(resultSetMask.getInt("file_id"));
                maskDocumentEntBlackPaint.setCategoryId(resultSetMask.getInt("category_id"));
                maskDocumentEntBlackPaint.setMaskStatus(resultSetMask.getInt("mask_status"));
                listMaskDoc.add(maskDocumentEntBlackPaint);
            }
        } catch (SQLException e) {
            // TODO 自動生成された catch ブロック
            e.printStackTrace();
        }
        String status = "1";
        HashMap<String, String> ret = instance.excelEditMain(listDoc, listMaskDoc, "C:/JUnitTest/status1/", resourceLoader, status, "");

        System.out.println(ret);
        assertEquals(ret.get("strPageCnt"), "4");
        assertEquals(ret.get("strEditMarker"), "");
        assertEquals(ret.get("aiData"), "");
        assertEquals(ret.get("strHeight"), "785");

        System.out.println("test_excelEditMain_status1 end");
    }

    public void test_excelEditMain_status1001() {//AIデータあり
        System.out.println("test_excelEditMain_status1001 start");
        ExcelEdit instance = new ExcelEdit();

        // DocumentIDでdocument_infoから情報を取得
        ResultSet resultSet = dbConnection.SelectSQLExe(selectDocumentInfoXls+"1001");
        ResultSet resultSetMask = dbConnection.SelectSQLExe(selectMaskDocumentXls +"1001");

        DocumentInfoEntPaint documentInfoEntPaint = new DocumentInfoEntPaint();
        List<DocumentInfoEntPaint> listDoc = new ArrayList<DocumentInfoEntPaint>();
        MaskDocumentEntBlackPaint maskDocumentEntBlackPaint = new MaskDocumentEntBlackPaint();
        List<MaskDocumentEntBlackPaint> listMaskDoc = new ArrayList<MaskDocumentEntBlackPaint>();
        try {
            while (resultSet.next()) {
                documentInfoEntPaint.setDocumentId(Integer.parseInt(resultSet.getString("document_id")));
                documentInfoEntPaint.setDocumentContents(resultSet.getString("document_contents"));
                documentInfoEntPaint.setHtmlZipData(resultSet.getBytes("html_zip_data"));
                documentInfoEntPaint.setServerId(resultSet.getInt("server_id"));
                documentInfoEntPaint.setDocumentName(resultSet.getString("document_name"));
                documentInfoEntPaint.setExtension(resultSet.getString("extension"));
                documentInfoEntPaint.setDocumentSize(resultSet.getBigDecimal("document_size"));
                documentInfoEntPaint.setParentId(resultSet.getInt("parent_id"));
                documentInfoEntPaint.setFilePath(resultSet.getString("file_path"));
                documentInfoEntPaint.setMarker(resultSet.getString("marker"));
                documentInfoEntPaint.setCategoryId(resultSet.getInt("category_id"));
                documentInfoEntPaint.setProcenterFlg(resultSet.getBoolean("procenter_flg"));
                documentInfoEntPaint.setRetentionPeriod(resultSet.getDate("retention_period"));
                documentInfoEntPaint.setAuthor(resultSet.getString("author"));
                documentInfoEntPaint.setUpdater(resultSet.getString("updater"));
                documentInfoEntPaint.setAuthorizer(resultSet.getString("authorizer"));
                documentInfoEntPaint.setFileUpdateTime(resultSet.getDate("file_update_time"));
                documentInfoEntPaint.setMaskStatus(resultSet.getInt("mask_status"));
                documentInfoEntPaint.setCreateTime(resultSet.getDate("create_time"));
                documentInfoEntPaint.setFileUpdateTime(resultSet.getDate("update_time"));
                documentInfoEntPaint.setNodeId(resultSet.getInt("node_id"));
                documentInfoEntPaint.setProcenterParentId(resultSet.getInt("procenter_parent_id"));
                listDoc.add(0, documentInfoEntPaint);
            }
        } catch (SQLException e) {
            // TODO 自動生成された catch ブロック
            e.printStackTrace();
        }
        String status = "1001";
        HashMap<String, String> ret = instance.excelEditMain(listDoc, listMaskDoc, "C:/JUnitTest/status1001/", resourceLoader, status, "1,2");

        System.out.println(ret);
        assertEquals(ret.get("strPageCnt"), "4");
        assertTrue(ret.get("strEditMarker") != "");
        assertTrue(ret.get("aiData") != "");
        assertEquals(ret.get("strHeight"), "785");

        System.out.println("test_excelEditMain_status1 end");
    }


    public void test_excelEditMain_status4() {
        System.out.println("test_excelEditMain_status4 start");
        ExcelEdit instance = new ExcelEdit();

        // DocumentIDでdocument_infoから情報を取得
        ResultSet resultSet = dbConnection.SelectSQLExe(selectDocumentInfoXls+"6");
        ResultSet resultSetMask = dbConnection.SelectSQLExe(selectMaskDocumentXls + "6");

        DocumentInfoEntPaint documentInfoEntPaint = new DocumentInfoEntPaint();
        List<DocumentInfoEntPaint> listDoc = new ArrayList<DocumentInfoEntPaint>();
        MaskDocumentEntBlackPaint maskDocumentEntBlackPaint = new MaskDocumentEntBlackPaint();
        List<MaskDocumentEntBlackPaint> listMaskDoc = new ArrayList<MaskDocumentEntBlackPaint>();
        try {
            while (resultSet.next()) {
                documentInfoEntPaint.setDocumentId(Integer.parseInt(resultSet.getString("document_id")));
                documentInfoEntPaint.setDocumentContents(resultSet.getString("document_contents"));
                documentInfoEntPaint.setHtmlZipData(resultSet.getBytes("html_zip_data"));
                documentInfoEntPaint.setServerId(resultSet.getInt("server_id"));
                documentInfoEntPaint.setDocumentName(resultSet.getString("document_name"));
                documentInfoEntPaint.setExtension(resultSet.getString("extension"));
                documentInfoEntPaint.setDocumentSize(resultSet.getBigDecimal("document_size"));
                documentInfoEntPaint.setParentId(resultSet.getInt("parent_id"));
                documentInfoEntPaint.setFilePath(resultSet.getString("file_path"));
                documentInfoEntPaint.setMarker(resultSet.getString("marker"));
                documentInfoEntPaint.setCategoryId(resultSet.getInt("category_id"));
                documentInfoEntPaint.setProcenterFlg(resultSet.getBoolean("procenter_flg"));
                documentInfoEntPaint.setRetentionPeriod(resultSet.getDate("retention_period"));
                documentInfoEntPaint.setAuthor(resultSet.getString("author"));
                documentInfoEntPaint.setUpdater(resultSet.getString("updater"));
                documentInfoEntPaint.setAuthorizer(resultSet.getString("authorizer"));
                documentInfoEntPaint.setFileUpdateTime(resultSet.getDate("file_update_time"));
                documentInfoEntPaint.setMaskStatus(resultSet.getInt("mask_status"));
                documentInfoEntPaint.setCreateTime(resultSet.getDate("create_time"));
                documentInfoEntPaint.setFileUpdateTime(resultSet.getDate("update_time"));
                documentInfoEntPaint.setNodeId(resultSet.getInt("node_id"));
                documentInfoEntPaint.setProcenterParentId(resultSet.getInt("procenter_parent_id"));
                listDoc.add(0, documentInfoEntPaint);
            }
            while(resultSetMask.next()) {
                maskDocumentEntBlackPaint.setDocumentId(Integer.parseInt(resultSetMask.getString("document_id")));
                maskDocumentEntBlackPaint.setUserId(resultSetMask.getString("user_id"));
                maskDocumentEntBlackPaint.setHtmlZipData(resultSetMask.getBytes("html_zip_data"));
                maskDocumentEntBlackPaint.setCreateTime(resultSetMask.getTimestamp("create_time"));
                maskDocumentEntBlackPaint.setUpdateTime(resultSetMask.getTimestamp("update_time"));
                maskDocumentEntBlackPaint.setFileId(resultSetMask.getInt("file_id"));
                maskDocumentEntBlackPaint.setCategoryId(resultSetMask.getInt("category_id"));
                maskDocumentEntBlackPaint.setMaskStatus(resultSetMask.getInt("mask_status"));
                listMaskDoc.add(maskDocumentEntBlackPaint);
            }
        } catch (SQLException e) {
            // TODO 自動生成された catch ブロック
            e.printStackTrace();
        }

        String status = "4";
        HashMap<String, String> ret = instance.excelEditMain(listDoc, listMaskDoc, "C:/JUnitTest/status4/", resourceLoader, status, "");

        System.out.println(ret);

        assertEquals(ret.get("strPageCnt"), "4");
        assertEquals(ret.get("strEditMarker"), "");
        assertEquals(ret.get("aiData"), "");
        assertEquals(ret.get("strHeight"), "785");

        System.out.println("test_excelEditMain_status4 start");
    }

    //異常系
    public void test_excelEditMain_status1_Err() {
        System.out.println("test_excelEditMain_status1_Err start");
        ExcelEdit instance = new ExcelEdit();

        // DocumentIDでdocument_infoから情報を取得
        ResultSet resultSet = dbConnection.SelectSQLExe(selectDocumentInfoXls+"5");
        ResultSet resultSetMask = dbConnection.SelectSQLExe(selectMaskDocumentXls +"5");

        DocumentInfoEntPaint documentInfoEntPaint = new DocumentInfoEntPaint();
        List<DocumentInfoEntPaint> listDoc = new ArrayList<DocumentInfoEntPaint>();
        MaskDocumentEntBlackPaint maskDocumentEntBlackPaint = new MaskDocumentEntBlackPaint();
        List<MaskDocumentEntBlackPaint> listMaskDoc = new ArrayList<MaskDocumentEntBlackPaint>();
        try {
            while (resultSet.next()) {
                documentInfoEntPaint.setDocumentId(Integer.parseInt(resultSet.getString("document_id")));
                documentInfoEntPaint.setDocumentContents(resultSet.getString("document_contents"));
                documentInfoEntPaint.setHtmlZipData(resultSet.getBytes("html_zip_data"));
                documentInfoEntPaint.setServerId(resultSet.getInt("server_id"));
                documentInfoEntPaint.setDocumentName(resultSet.getString("document_name"));
                documentInfoEntPaint.setExtension(resultSet.getString("extension"));
                documentInfoEntPaint.setDocumentSize(resultSet.getBigDecimal("document_size"));
                documentInfoEntPaint.setParentId(resultSet.getInt("parent_id"));
                documentInfoEntPaint.setFilePath(resultSet.getString("file_path"));
                documentInfoEntPaint.setMarker(resultSet.getString("marker"));
                documentInfoEntPaint.setCategoryId(resultSet.getInt("category_id"));
                documentInfoEntPaint.setProcenterFlg(resultSet.getBoolean("procenter_flg"));
                documentInfoEntPaint.setRetentionPeriod(resultSet.getDate("retention_period"));
                documentInfoEntPaint.setAuthor(resultSet.getString("author"));
                documentInfoEntPaint.setUpdater(resultSet.getString("updater"));
                documentInfoEntPaint.setAuthorizer(resultSet.getString("authorizer"));
                documentInfoEntPaint.setFileUpdateTime(resultSet.getDate("file_update_time"));
                documentInfoEntPaint.setMaskStatus(resultSet.getInt("mask_status"));
                documentInfoEntPaint.setCreateTime(resultSet.getDate("create_time"));
                documentInfoEntPaint.setFileUpdateTime(resultSet.getDate("update_time"));
                documentInfoEntPaint.setNodeId(resultSet.getInt("node_id"));
                documentInfoEntPaint.setProcenterParentId(resultSet.getInt("procenter_parent_id"));
                listDoc.add(0, documentInfoEntPaint);
            }
            while(resultSetMask.next()) {
                maskDocumentEntBlackPaint.setDocumentId(Integer.parseInt(resultSetMask.getString("document_id")));
                maskDocumentEntBlackPaint.setUserId(resultSetMask.getString("user_id"));
                maskDocumentEntBlackPaint.setHtmlZipData(resultSetMask.getBytes("html_zip_data"));
                maskDocumentEntBlackPaint.setCreateTime(resultSetMask.getTimestamp("create_time"));
                maskDocumentEntBlackPaint.setUpdateTime(resultSetMask.getTimestamp("update_time"));
                maskDocumentEntBlackPaint.setFileId(resultSetMask.getInt("file_id"));
                maskDocumentEntBlackPaint.setCategoryId(resultSetMask.getInt("category_id"));
                maskDocumentEntBlackPaint.setMaskStatus(resultSetMask.getInt("mask_status"));
                listMaskDoc.add(maskDocumentEntBlackPaint);
            }
        } catch (SQLException e) {
            // TODO 自動生成された catch ブロック
            e.printStackTrace();
        }
        String status = "1";
//        List<DocumentInfoEntPaint> tmpListDoc = listDoc;
//        listDoc = null;
//        try {
//            HashMap<String, String> ret1 = instance.excelEditMain(listDoc, listMaskDoc, "C:/JUnitTest/status1/", resourceLoader, status, "");
//            System.out.println(ret1);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        listDoc = tmpListDoc;
//        List<MaskDocumentEntBlackPaint> tmpLstMaskDoc = listMaskDoc;
//        try {
//            HashMap<String, String> ret2 = instance.excelEditMain(listDoc, null, "C:/JUnitTest/status1/", resourceLoader, status, "");
//            System.out.println(ret2);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        listMaskDoc = tmpLstMaskDoc;

        try {
            HashMap<String, String> ret3 = instance.excelEditMain(listDoc, listMaskDoc, "", resourceLoader, status, "");
            System.out.println(ret3);
        } catch (Exception e) {
            e.printStackTrace();
        }

        ResourceLoader tmpResourceLoader = resourceLoader;
        resourceLoader = null;
        try {
            HashMap<String, String> ret4 = instance.excelEditMain(listDoc, listMaskDoc, "C:/JUnitTest/status1/", resourceLoader, status, "");
            System.out.println(ret4);
        } catch (Exception e) {
            e.printStackTrace();
        }
        resourceLoader = tmpResourceLoader;
        try {
            HashMap<String, String> ret5 = instance.excelEditMain(listDoc, listMaskDoc, "C:/JUnitTest/status1/", resourceLoader, "", "");
            System.out.println(ret5);
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("test_excelEditMain_status1_Err end");
    }
}
