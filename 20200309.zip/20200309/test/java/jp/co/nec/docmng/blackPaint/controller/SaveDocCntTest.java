package jp.co.nec.docmng.blackPaint.controller;

import static org.junit.Assert.*;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.ui.Model;

import jp.co.nec.docmng.common.DBConnection;

@SuppressWarnings("javadoc")
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class SaveDocCntTest extends SpringBootServletInitializer {

	// DBアクセス用クラス
	DBConnection dbConnection = new DBConnection();
	PreparedStatement ps = null;

	@Autowired
	HttpServletRequest request;

	@Autowired
	HttpServletResponse response;

	@Mock
	private Model model;

	@Autowired
	SaveDocCnt saveDocCnt;

	// DB項目の挿入
	String insertDirectoryInfoInternal = "INSERT \r\n" +
			"INTO common.directory_info_internal( \r\n" +
			"  directory_id\r\n" +
			"  , server_id\r\n" +
			"  , directory_name\r\n" +
			"  , parent_id\r\n" +
			"  , directory_path\r\n" +
			"  , directory_type\r\n" +
			"  , crawl_act_time\r\n" +
			"  , directory_update_flg\r\n" +
			"  , directory_delete_flg\r\n" +
			") \r\n" +
			"VALUES ( \r\n" +
			"  0 \r\n" +
			"  , 0 \r\n" +
			"  , ''\r\n" +
			"  , 0 \r\n" +
			"  , '' \r\n" +
			"  , 0 \r\n" +
			"  , '2019/11/13 00:00:00' \r\n" +
			"  , false \r\n" +
			"  , false \r\n" +
			")";

	//DB項目の削除
	String deleteDirectoryInfoInternal = ""
			+ "DELETE "
			+ "FROM common.directory_info_internal WHERE directory_id=0";

	String insertDirectoryInfo = "INSERT \r\n" +
			"INTO common.directory_info( \r\n" +
			"  directory_id\r\n" +
			"  , server_id\r\n" +
			"  , directory_name\r\n" +
			"  , parent_id\r\n" +
			"  , directory_path\r\n" +
			"  , directory_type\r\n" +
			") \r\n" +
			"VALUES ( \r\n" +
			"  0 \r\n" +
			"  , 0 \r\n" +
			"  , ''\r\n" +
			"  , 0 \r\n" +
			"  , '' \r\n" +
			"  , 0 \r\n" +
			")";

	//DB項目の削除
	String deleteDirectoryInfo = ""
			+ "DELETE "
			+ "FROM common.directory_info WHERE directory_id=0";

	// DB項目の挿入
	String insertDocumentInfoInternal = ""
			+ "INSERT  "
			+ "INTO common.document_info_internal(  "
			+ "  document_id "
			+ "  , document_contents "
			+ "  , server_id "
			+ "  , document_name "
			+ "  , document_size "
			+ "  , parent_id "
			+ "  , file_path "
			+ "  , procenter_flg "
			+ "  , crawl_act_time "
			+ "  , document_update_flg "
			+ "  , document_delete_flg "
			+ ")  "
			+ "VALUES (  "
			+ "  ? "
			+ "  , '' "
			+ "  , 0 "
			+ "  , 'test' "
			+ "  , 0 "
			+ "  , 0 "
			+ "  , '' "
			+ "  , true "
			+ "  , '2019/11/13 00:00:00' "
			+ "  , false "
			+ "  , false "
			+ ")";

	//DB項目の削除
	String deleteDocumentInfoInternal = ""
			+ "DELETE "
			+ "FROM common.document_info_internal WHERE document_id=?";

	// DB項目の挿入
	String insertDocumentInfo = ""
			+ "INSERT  "
			+ "INTO common.document_info(  "
			+ "  document_id "
			+ "  , document_contents "
			+ "  , server_id "
			+ "  , document_name "
			+ "  , document_size "
			+ "  , parent_id "
			+ "  , file_path "
			+ "  , procenter_flg "
			+ ")  "
			+ "VALUES (  "
			+ "  ? "
			+ "  , '' "
			+ "  , 0 "
			+ "  , 'test' "
			+ "  , 0 "
			+ "  , 0 "
			+ "  , '' "
			+ "  , true "
			+ ")";

	//DB項目の削除
	String deleteDocumentInfo = ""
			+ "DELETE "
			+ "FROM common.document_info WHERE document_id=?";

	// DB項目の挿入
	String insertMaskDocument = ""
			+ "INSERT "
			+ "INTO common.mask_document( "
			+ "  mask_id"
			+ "  , document_id"
			+ "  , user_id"
			+ ") "
			+ "VALUES ( "
			+ "  ?"
			+ "  , ?"
			+ "  , ?"
			+ ")";

	//DB項目の削除
	String deleteMaskDocument = ""
			+ "DELETE "
			+ "FROM common.mask_document WHERE document_id=?";

	// DB項目の挿入
	String insertMaskDocumentMarker = ""
			+ "INSERT "
			+ "INTO common.mask_document_marker( "
			+ "  marker_id"
			+ "  , document_id"
			+ "  , user_id"
			+ ") "
			+ "VALUES ( "
			+ "  ?"
			+ "  , ?"
			+ "  , ?"
			+ ")";

	//DB項目の削除
	String deleteMaskDocumentMaker = ""
			+ "DELETE "
			+ "FROM common.mask_document_marker WHERE document_id=?";

	// DB項目の挿入
	String insertPolicyInfo = ""
			+ "INSERT "
			+ "INTO admin.policy_info(policy_id, policy_number, policy_name,policy_type) "
			+ " VALUES (?, 1, '',?) ";

	String insertPolicyKeyword = ""
			+ "INSERT "
			+ "INTO admin.policy_keyword_info(keyword_id, policy_id,policy_keyword) "
			+ " VALUES (?,?,'test') ";

	//Delete文
	String deletePolicyInfo = ""
			+ "DELETE "
			+ "FROM admin.policy_info "
			+ "WHERE policy_id=? ";

	String deletePolicyKeyword = ""
			+ "DELETE "
			+ "FROM admin.policy_keyword_info "
			+ "WHERE policy_id=? ";

	//JSON
	String strJson = "[\r\n" +
			"    {\r\n" +
			"        \"tmpDir\": [\r\n" +
			"            \"src/main/resources/testDocumentTmp/\"\r\n" +
			"        ],\r\n" +
			"        \"strFileName\": [\r\n" +
			"            \"test.pptx\"\r\n" +
			"        ],\r\n" +
			"        \"updateTime\": [\r\n" +
			"            \"2020/03/07 20:49\"\r\n" +
			"        ],\r\n" +
			"        \"retentionPeriod\": [\r\n" +
			"            \"2021/03/07\"\r\n" +
			"        ],\r\n" +
			"        \"cateId\": [\r\n" +
			"            1\r\n" +
			"        ],\r\n" +
			"        \"documentId\": [\r\n" +
			"            0\r\n" +
			"        ],\r\n" +
			"        \"arrPrint\": [\r\n" +
			"            null,\r\n" +
			"            true\r\n" +
			"        ],\r\n" +
			"        \"arrMaskPaths\": [\r\n" +
			"            \"src/main/resources/testDocumentTmp/mask_testPdf/mask_1.pdf\"\r\n" +
			"        ],\r\n" +
			"        \"arrRedPaths\": [\r\n" +
			"            \"src/main/resources/testDocumentTmp/red_testPdf/red_1.pdf\"\r\n" +
			"        ],\r\n" +
			"        \"keywords\": [\r\n" +
			"            \"1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111\"\r\n"
			+
			"        ],\r\n" +
			"        \"pages\": [\r\n" +
			"            1\r\n" +
			"        ],\r\n" +
			"        \"policyNames\": [\r\n" +
			"            \"addPolicyName\"\r\n" +
			"        ],\r\n" +
			"        \"Reasons\": [\r\n" +
			"            \"test\"\r\n" +
			"        ],\r\n" +
			"        \"Remarks\": [\r\n" +
			"            \"\"\r\n" +
			"        ],\r\n" +
			"        \"glArrBfIds\": [\r\n" +
			"            \"red1300000\"\r\n" +
			"        ],\r\n" +
			"        \"glArrAfIds\": [\r\n" +
			"            \"red1300005\"\r\n" +
			"        ],\r\n" +
			"        \"glArrPolicys\": [\r\n" +
			"            0\r\n" +
			"        ],\r\n" +
			"        \"strHtmlUuid\": [\r\n" +
			"            \"9e2eb43e-77c2-4878-b975-c351e88ce406\"\r\n" +
			"        ],\r\n" +
			"        \"pageBadge\": [\r\n" +
			"            \"1\"\r\n" +
			"        ]\r\n" +
			"    }\r\n" +
			"]";

	/**
	 * SaveDocCnt正常系
	 * @throws Exception
	 */
	@Test
	public void testSaveDocCntA001() throws Exception {

		// DBとの接続を確立
		Connection connection = dbConnection.DBConnectReturn();

		try {

			//delete Sql
			ps = connection.prepareStatement(deleteMaskDocument);
			ps.setInt(1, 0);
			ps.executeUpdate();

			ps = connection.prepareStatement(deleteMaskDocumentMaker);
			ps.setInt(1, 0);
			ps.executeUpdate();

			ps = connection.prepareStatement(deleteDocumentInfoInternal);
			ps.setInt(1, 0);
			ps.executeUpdate();

			ps = connection.prepareStatement(deleteDocumentInfo);
			ps.setInt(1, 0);
			ps.executeUpdate();

			ps = connection.prepareStatement(deleteDirectoryInfo);
			ps.executeUpdate();

			ps = connection.prepareStatement(deleteDirectoryInfoInternal);
			ps.executeUpdate();

			ps = connection.prepareStatement(deletePolicyKeyword);
			ps.setInt(1, 0);
			ps.executeUpdate();

			ps = connection.prepareStatement(deletePolicyInfo);
			ps.setInt(1, 0);
			ps.executeUpdate();

			//insert Sql
			ps = connection.prepareStatement(insertDirectoryInfoInternal);
			ps.executeUpdate();

			ps = connection.prepareStatement(insertDirectoryInfo);
			ps.executeUpdate();

			ps = connection.prepareStatement(insertDocumentInfoInternal);
			ps.setInt(1, 0);
			ps.executeUpdate();

			ps = connection.prepareStatement(insertDocumentInfo);
			ps.setInt(1, 0);
			ps.executeUpdate();

			ps = connection.prepareStatement(insertMaskDocument);
			ps.setInt(1, 0);
			ps.setInt(2, 0);
			ps.setString(3, "0001");
			ps.executeUpdate();

			ps = connection.prepareStatement(insertMaskDocumentMarker);
			ps.setInt(1, 0);
			ps.setInt(2, 0);
			ps.setString(3, "0001");
			ps.executeUpdate();

			ps = connection.prepareStatement(insertPolicyInfo);
			ps.setInt(1, 0);
			ps.setInt(2, 0);
			ps.executeUpdate();

			ps = connection.prepareStatement(insertPolicyKeyword);
			ps.setInt(1, 0);
			ps.setInt(2, 0);
			ps.executeUpdate();

			//作業ディレクトリが削除されるのでコピー
			FileUtils.copyDirectory(new File("src/main/resources/testDocument"),
					new File("src/main/resources/testDocumentTmp"));

			String ret = saveDocCnt.saveDocCntMain(strJson, "", null, "", "", model);

			assertEquals(ret, "blackPaint/Success");

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			//delete Sql
			ps = connection.prepareStatement(deleteMaskDocument);
			ps.setInt(1, 0);
			ps.executeUpdate();

			ps = connection.prepareStatement(deleteMaskDocumentMaker);
			ps.setInt(1, 0);
			ps.executeUpdate();

			ps = connection.prepareStatement(deleteDocumentInfoInternal);
			ps.setInt(1, 0);
			ps.executeUpdate();

			ps = connection.prepareStatement(deleteDocumentInfo);
			ps.setInt(1, 0);
			ps.executeUpdate();

			ps = connection.prepareStatement(deleteDirectoryInfo);
			ps.executeUpdate();

			ps = connection.prepareStatement(deleteDirectoryInfoInternal);
			ps.executeUpdate();

			ps = connection.prepareStatement(deletePolicyKeyword);
			ps.setInt(1, 0);
			ps.executeUpdate();

			ps = connection.prepareStatement(deletePolicyInfo);
			ps.setInt(1, 0);
			ps.executeUpdate();

			ps.close();
			connection.close();
		} //try

	} //method

	/**
	 * SaveDocCnt異常系
	 * @throws Exception
	 */
	@Test
	public void saveDocCntB001() throws Exception {

		try {
			String ret = saveDocCnt.handleException(new RuntimeException("errTest"), request, response, model);
			assertEquals(ret, "blackPaint/Fail");

		} catch (Exception e) {
			e.printStackTrace();
		} //try

	} //method

	/**
	 * SaveDocCnt異常系
	 * @throws Exception
	 */
	@Test(expected = RuntimeException.class)
	public void saveDocCntB002() throws Exception {

		saveDocCnt.saveDocCntMain("", "", null, "", "", model);

	} //method

} //class
