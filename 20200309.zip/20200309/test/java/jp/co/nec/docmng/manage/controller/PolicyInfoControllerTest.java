package jp.co.nec.docmng.manage.controller;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.Cookie;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.common.DBConnection;
import jp.co.nec.docmng.manage.entity.PolicyInfoEntity;
import jp.co.nec.docmng.manage.entity.PolicyInfoReflectForm;
import jp.co.nec.docmng.manage.entity.PolicyInfoReflectForm.AddValues;
import jp.co.nec.docmng.manage.entity.PolicyInfoReflectForm.ChangedValues;
import jp.co.nec.docmng.manage.entity.PolicyKeywordInfo;

@SuppressWarnings("javadoc")
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class PolicyInfoControllerTest {

    DBConnection dbConnection = new DBConnection();

    private MockMvc mockMvc;

    /**
     * 非表示対象ポリシー名1
     */
    private static final String DISPLAY_NON_POLICY1 = "その他ポリシー";
    /**
     * 非表示対象ポリシー名2
     */
    private static final String DISPLAY_NON_POLICY2 = "図・表";

    @Autowired
    PolicyInfoController target;

    @Before
    public void setup() {
        mockMvc = MockMvcBuilders.standaloneSetup(target).build();
    }

    // 必要なテーブルを空にする（使いまわすためメソッド化）
    private void testDBEmpty () throws Exception{
        // 削除のSQL文
        // 外部キーのあるテーブルから削除
        try {
            dbConnection.SQLExe(delteTemTeacherPolicyList);
            dbConnection.SQLExe(deletePolicyKeyword);
            dbConnection.SQLExe(deletePolicyInfo);

        } catch (Exception e) {
//            e.printStackTrace();
        }
    }

    String insertPolicyInfo = "insert into admin.policy_info " +
            " (policy_id, policy_number, policy_name, policy_author, policy_reason, policy_type, create_time, update_time)" +
            "	VALUES" +
            "	(996, 996, 'name1', 'author1', 'reason1', 0, '2019/11/11 12:00:00', '2019/11/11 12:00:00')," +
            "	(997, 997, 'name2', 'author2', 'reason2', 0, '2019/11/11 12:00:00', '2019/11/11 12:00:00')," +
            "	(998, 998, '"+DISPLAY_NON_POLICY2+"', 'author1', 'reason1', 2, '2019/11/11 12:00:00', '2019/11/11 12:00:00')," +
            "	(999, 999, '"+DISPLAY_NON_POLICY1+"', 'author1', 'reason1', 1, '2019/11/11 12:00:00', '2019/11/11 12:00:00');";

    String key51 = "123456789012345678901234567890123456789012345678901";
    String key50 = "12345678901234567890123456789012345678901234567890";

    String insertPolicyKeyword = "INSERT INTO admin.policy_keyword_info(" +
            "	keyword_id, policy_id, policy_keyword, create_time, update_time)" +
            "	values " +
            "	(990, 996, '"+ key50 +"', '2019/11/13 12:00:00', '2019/11/13 12:00:00')," +
            "	(991, 996, 'keyword1-2', '2019/11/13 12:00:00', '2019/11/13 12:00:00')," +
            "	(992, 996, 'keyword1-3', '2019/11/13 12:00:00', '2019/11/13 12:00:00')," +
            "	(993, 996, 'keyword1-4', '2019/11/13 12:00:00', '2019/11/13 12:00:00')," +
            "	(994, 996, 'keyword1-5', '2019/11/13 12:00:00', '2019/11/13 12:00:00')," +
            "	(995, 997, '"+ key51 +"', '2019/11/13 12:00:00', '2019/11/13 12:00:00')," +
            "	(996, 998, 'keyword2-2', '2019/11/13 12:00:00', '2019/11/13 12:00:00')," +
            "	(997, 999, 'keyword2-3', '2019/11/13 12:00:00', '2019/11/13 12:00:00');";

    String deletePolicyInfo = "delete from admin.policy_info" +
            "	where policy_id in (996, 997, 998, 999);";
    String deletePolicyKeyword = "delete from admin.policy_keyword_info" +
            "	where keyword_id in (990, 991, 992, 993, 994, 995, 996, 997);";

    String insertTmpTeacherPolicyInfo = "INSERT INTO admin.tmp_teacher_policy_list(" +
            "	user_id, sort_id, policy_id, directory_path, create_time, update_time)" +
            "	VALUES" +
            "	('user1', 1, 996, '\\\\yoks3106\\NES_文書管理システム\\99_tmp\\岩淵\\test\\category\\test1\\', '2019/11/06 12:00:00', '2019/11/06 12:00:00'),"+
            "	('user1', 3, 996, '\\\\yoks3106\\NES_文書管理システム\\99_tmp\\岩淵\\test\\category\\test2\\', '2019/11/06 12:00:00', '2019/11/06 12:00:00')," +
            "	('user1', 2, 997, '\\\\yoks3106\\NES_文書管理システム\\99_tmp\\岩淵\\test\\category\\test3\\', '2019/11/06 12:00:00', '2019/11/06 12:00:00')," +
            "	('user1', 4, 998, '\\\\yoks3106\\NES_文書管理システム\\99_tmp\\岩淵\\test\\category\\test4\\', '2019/11/06 12:00:00', '2019/11/06 12:00:00');";

    String deletePolicyInforef = "delete from admin.policy_info" +
            "	where policy_id in (996, 998, 999);";
    String deletePolicyKeywordref = "delete from admin.policy_keyword_info" +
            "	where keyword_id in (990, 991, 992, 993, 994, 996, 997);";
    String delteTemTeacherPolicyList = "delete from admin.tmp_teacher_policy_list where user_id = 'user1'";

    /**
     * test_getPolicyInfo001（エラー系）
     * 黒塗りポリシー設定画面表示処理
     * ログインクッキーが設定されていない場合
     * @throws Exception
     */
    @SuppressWarnings("unused")
    @Test
    public void test_getPolicyInfo001() throws Exception{
        testDBEmpty();
        try {
            // DBとの接続を確立
            dbConnection.DBConnect();
            dbConnection.SQLExe(insertPolicyInfo);
            dbConnection.SQLExe(insertPolicyKeyword);
            dbConnection.SQLExe(insertTmpTeacherPolicyInfo);

            MvcResult result = mockMvc.perform(get("/manage/policy"))
                .andExpect(status().isOk())
                .andExpect(view().name("manage/policy"))
                .andExpect(model().attribute("userAuth", 1))
                .andReturn();

            System.out.println("test_getPolicyInfo001 正常終了");

        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            // エラーがあっても必ずテストデータは削除
            testDBEmpty();
            dbConnection.DBClose();
        }
    }

    /**
     * test_getPolicyInfo002（エラー系）
     * 黒塗りポリシー設定画面表示処理
     * 管理者権限ではない場合
     * @throws Exception
     */
    @SuppressWarnings("unused")
    @Test
    public void test_getPolicyInfo002() throws Exception{
        testDBEmpty();
        try {
            // DBとの接続を確立
            dbConnection.DBConnect();
            dbConnection.SQLExe(insertPolicyInfo);
            dbConnection.SQLExe(insertPolicyKeyword);
            dbConnection.SQLExe(insertTmpTeacherPolicyInfo);

            Cookie cookies = new Cookie("userInfo", "\"userRole\":\"users\"");
            MvcResult result = mockMvc.perform(get("/manage/policy").cookie(cookies))
                .andExpect(status().isOk())
                .andExpect(view().name("manage/policy"))
                .andExpect(model().attribute("userAuth", 1))
                .andReturn();

            System.out.println("test_getPolicyInfo002 正常終了");

        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            // エラーがあっても必ずテストデータは削除
            testDBEmpty();
            dbConnection.DBClose();
        }
    }

    /**
     * test_getPolicyInfo003（正常系）
     * 黒塗りポリシー設定画面表示処理
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @Test
    public void test_getPolicyInfo003() throws Exception{
        testDBEmpty();
        try {
            // DBとの接続を確立
            dbConnection.DBConnect();
            dbConnection.SQLExe(insertPolicyInfo);
            dbConnection.SQLExe(insertPolicyKeyword);
            dbConnection.SQLExe(insertTmpTeacherPolicyInfo);

            Cookie cookies = new Cookie("userInfo", "\"userRole\":\"Administrators\"");
            MvcResult result = mockMvc.perform(get("/manage/policy").cookie(cookies))
                .andExpect(status().isOk())
                .andExpect(view().name("manage/policy"))
                .andReturn();

            // 黒塗りポリシー一覧
            List<PolicyInfoEntity> policyInfo =
                    (List<PolicyInfoEntity>) result.getModelAndView().getModel().get("policyInfo");

            // ポリシーキーワード一覧
            List<PolicyKeywordInfo> policyKeywordInfos =
                    (List<PolicyKeywordInfo>) result.getModelAndView().getModel().get("policyKeywordInfos");

            List<String> policyNameList  = new ArrayList<String>();
            List<String> keyWordList = new ArrayList<String>();

            for (PolicyInfoEntity pie : policyInfo) {
                policyNameList.add(pie.getPolicyName());
            }
            for (PolicyKeywordInfo pki : policyKeywordInfos) {
                keyWordList.add(pki.getPolicyKeyword());
            }

            List<String> insertPolicyNameList = new ArrayList<String>(Arrays.asList(
                    "name1", "name2"));
            List<String> insertKeywordList = new ArrayList<String>(Arrays.asList(
                    key50, "keyword1-2", "keyword1-3", "keyword1-4", "keyword1-5",
                    key51, "keyword2-2", "keyword2-3"
                    ));

            assertTrue(policyNameList.containsAll(insertPolicyNameList));
            assertTrue(keyWordList.containsAll(insertKeywordList));

            System.out.println("test_getPolicyInfo003 正常終了");
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            // エラーがあっても必ずテストデータは削除
            testDBEmpty();
            dbConnection.DBClose();
        }
    }

    /**
     * test_policyReflect001（正常系）
     * 黒塗りポリシー設定画面 設定反映処理
     * @throws Exception
     */
    @Test
    public void test_policyReflect001() throws Exception{
        // 追加データ
        String addPolicyName = "addPolicyName";
        Integer addPolicyNumber = 9999;
        String addPolicyReason = "addReason";
        // 更新データ
        Integer changePolicyId = 996;
        String changePolicyName = "changePolicyName";
        Integer changePolicyNumber = 9999;
        String changePolicyReason = "changeRason";
        // 削除データ
        Integer deletePolicyId = 997;

        try {
            // DBとの接続を確立
            dbConnection.DBConnect();

            dbConnection.SQLExe(insertPolicyInfo);
            dbConnection.SQLExe(insertPolicyKeyword);
            dbConnection.SQLExe(insertTmpTeacherPolicyInfo);

            PolicyInfoReflectForm requestForm = new PolicyInfoReflectForm();

            // リクエストデータ作成
            List<AddValues> addValues = new ArrayList<AddValues>();
            List<ChangedValues> changeValues = new ArrayList<ChangedValues>();
            List<Integer> deleteRow = new ArrayList<Integer>();

            AddValues addValue = new AddValues();
            ChangedValues changeValue = new ChangedValues();
            deleteRow.add(deletePolicyId);

            addValue.setPolicyName(addPolicyName);
            addValue.setPolicyNumber(addPolicyNumber);
            addValue.setPolicyReason(addPolicyReason);
            addValues.add(addValue);

            changeValue.setPolicyId(changePolicyId);
            changeValue.setPolicyName(changePolicyName);
            changeValue.setPolicyNumber(changePolicyNumber);
            changeValue.setPolicyReason(changePolicyReason);
            changeValues.add(changeValue);

            requestForm.setAddValues(addValues);
            requestForm.setChangedValues(changeValues);
            requestForm.setDeleteRow(deleteRow);

            ObjectMapper mapper = new ObjectMapper();
            String requestJson = mapper.writeValueAsString(requestForm);

            mockMvc.perform(post("/manage/policy/policy_reflect")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(requestJson))
                    .andExpect(status().isOk());

            // 追加確認
            String select = "select * from admin.policy_info where policy_name = '" + addPolicyName+ "'";
            ResultSet addRs = dbConnection.SelectSQLExe(select);
            // 行が取得出来ているなら登録OK
            assertTrue(addRs.next());
            addRs.close();

            // 変更確認
            String changeselect = "select * from admin.policy_info where policy_name = '" + changePolicyName+ "'";
            ResultSet changeRs = dbConnection.SelectSQLExe(changeselect);
            // 行が取得出来ているなら登録OK
            assertTrue(changeRs.next());
            changeRs.close();

            // 削除確認
            String delselect = "select * from admin.policy_info where policy_id = '" + deletePolicyId+ "'";
            ResultSet delRs = dbConnection.SelectSQLExe(delselect);
            // 削除しているため0件
            assertTrue(!delRs.next());
            delRs.close();
            System.out.println("test_policyReflect001 正常終了");
        } catch (Exception e) {
            e.printStackTrace();
            // エラーの場合は全て削除
            testDBEmpty();
            throw e;
        } finally {
            // エラーがあっても必ずテストデータは削除
            // 追加行の削除
            // 外部キー参照してるものから削除
            dbConnection.SQLExe(delteTemTeacherPolicyList);
            dbConnection.SQLExe(deletePolicyKeywordref);
            dbConnection.SQLExe(deletePolicyInforef);
            dbConnection.SQLExe("delete from admin.policy_info where policy_number = " + addPolicyNumber +"");
            dbConnection.DBClose();
        }
    }

    /**
     * test_policyReflect002（リクエストデータ空）
     * 黒塗りポリシー設定画面 設定反映処理
     * @throws Exception
     */
    @Test
    public void test_policyReflect002() throws Exception{
        // リクエストデータ空で送信
        try {
            mockMvc.perform(post("/manage/policy/policy_reflect")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(""))
                    .andExpect(status().isBadRequest());

            System.out.println("test_policyReflect002 正常終了");
        } catch (Exception e) {
            e.printStackTrace();
            // エラーの場合は全て削除
            testDBEmpty();
            throw e;
        } finally {
        }
    }
}
