package jp.co.nec.docmng.blackPaint.controller;

import static org.junit.Assert.*;

import javax.servlet.http.HttpServletResponse;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.ui.Model;

@SuppressWarnings("javadoc")
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class MaskHtmlInitMainTest extends SpringBootServletInitializer {

	@Autowired
	HttpServletResponse response;

	@Mock
	private Model model;

	@Autowired
	MaskHtmlInit maskHtmlInit;

	/**
	 * MaskHtmlInit正常系
	 * @throws Exception
	 */
	@Test
	public void testMaskHtmlInitCntA001() throws Exception {
		String ret = maskHtmlInit.MaskHtmlInitMain(response, model);
		assertEquals(ret, "blackPaint/MaskHtmlInit");
	} //method

} //class
