/**
 * 名称：MaskDocumentEntBlackPaint.java
 * 機能名：黒塗り処理黒塗り文書保存情報entity
 * 概要：黒塗り処理で使用する黒塗り文書保存情報entity
 */

package jp.co.nec.docmng.blackPaint.entity;

import java.sql.Timestamp;

import lombok.Data;

/**
 * 黒塗り処理黒塗り文書保存情報entity
 */
@Data
public class MaskDocumentEntBlackPaint {

	/**
	 * 文書ID
	 */
	private Integer documentId;

	/**
	 * ユーザID
	 */
	private String userId;

	/**
	 * HTML群(zip圧縮)
	 */
	private byte[] htmlZipData;

	/**
	 * 作成日時
	 */
	private Timestamp createTime;

	/**
	 * 更新日時
	 */
	private Timestamp updateTime;

	/**
	 * ノードID
	 */
	private Integer nodeId;

	/**
	 * ファイルID
	 */
	private Integer fileId;

	/**
	 * 分類軸ID
	 */
	private Integer categoryId;

	/**
	 * 黒塗り状態
	 */
	private Integer maskStatus;

}
