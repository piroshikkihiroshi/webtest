/**
 * 名称：HtmlToPdfModel.java
 * 機能名：HTML→PDF変換
 * 概要：HTMLをPDFに変換する
 * @modify 20191216 InputStreamで読み込んでから処理するように変更
 */

package jp.co.nec.docmng.blackPaint.logic.htmltopdf;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aspose.html.HTMLDocument;
import com.aspose.html.drawing.Margin;
import com.aspose.html.drawing.Page;
import com.aspose.html.drawing.Size;
import com.aspose.html.rendering.HtmlRenderer;
import com.aspose.html.rendering.pdf.PdfDevice;
import com.aspose.html.rendering.pdf.PdfRenderingOptions;

import jp.co.nec.docmng.blackPaint.entity.DocumentInfoEntPaint;
import jp.co.nec.docmng.blackPaint.logic.dirFile.FileCnt;

/**
 * HTML→PDF変換
 */
public class HtmlToPdfModel {

	static Logger objLog = LoggerFactory.getLogger(HtmlToPdfModel.class);

	/**
	 * strHtml_iからPDFを作成する
	 * @param strPath_i 相対パスを絶対パスに変更する必要があるのでimgが格納されているDirを指定
	 * @param strPdfOutPath_i pdf出力先のファイル名を含めたフルパス
	 * @param listDoc_i List&lt;DocumentInfoEntPaint&gt;対象document_ifに対するdocument_infoリスト
	 * @return strPdfOutPath_i ;PDF出力ディレクトリ
	 */
	public synchronized String convertHtmlToPdf(
			String strPath_i,
			String strPdfOutPath_i,
			List<DocumentInfoEntPaint> listDoc_i) {

		//※※※※※※動かなかったらこちらを使う/※※※※※※

		InputStream fileStream=null;
		FileCnt objFileCnt = new FileCnt();
		try {
			fileStream = new FileInputStream(strPath_i);
		} catch (FileNotFoundException e1) {
			objLog.error( "file："+strPath_i+"がありません", e1 );
			return null;
		}
		HTMLDocument htmlDocument = new HTMLDocument(fileStream,strPath_i);
		HtmlRenderer renderer = new HtmlRenderer();
		FileOutputStream objOs = null;
		PdfDevice objPdfDevice=null;
		PdfRenderingOptions pdfRenderingOptions = null;

		String strFileName = strPath_i.substring(strPath_i.lastIndexOf("/")+1);
		String strExtension = listDoc_i.get(0).getExtension();
		try {
			objOs = new FileOutputStream(strPdfOutPath_i, true);
			if (strExtension.contains("ppt") && strFileName.indexOf("MaskListPrev.html")<0) { //pptはサイズ指定
				pdfRenderingOptions = new PdfRenderingOptions();
//		        pdfRenderingOptions.getPageSetup().setAnyPage(new Page(new Size(1280, 750),new Margin(0,10,0,0)));
				pdfRenderingOptions.getPageSetup().setAnyPage(new Page(new Size(1280, 750),new Margin(150,10,0,0)));
		        pdfRenderingOptions.getPageSetup().setAdjustToWidestPage(true);
        		objPdfDevice = new PdfDevice(pdfRenderingOptions,objOs);
			} else {
				objPdfDevice = new PdfDevice(objOs);
			}//if

		} catch (FileNotFoundException e1) {
			objLog.error( "file："+strPdfOutPath_i+"がありません", e1 );
			return null;
		}

		// 0228 cssのフォント反映
		if ((strExtension.contains("ppt") || strExtension.contains("xls") || strExtension.contains("pdf"))&& strFileName.indexOf("MaskListPrev.html")<0) { //pptはサイズ指定
			String strCssPath = strPath_i.substring(0,strPath_i.lastIndexOf("/")+1) +listDoc_i.get(0).getDocumentId()+ "/style.css";
			try {
				objFileCnt.shapeStyleCssPdf(strCssPath);
			} catch (IOException e) {
				// TODO 自動生成された catch ブロック
				e.printStackTrace();
			}
		}

		try {
			renderer.render(objPdfDevice, htmlDocument);
		} catch (Exception e) {
			objLog.error( "pdf作成時にエラーが発生しました", e );
			return null;
		} finally {
			if (fileStream != null) {
				try {
					fileStream.close();
					fileStream = null;
				}
				catch (IOException e) {
					objLog.error( "ストリームのクローズに失敗", e );
				}
			} //if
			if (objOs != null) {
				try {
					objOs.close();
					objOs=null;
				}
				catch (IOException e) {
					objLog.error( "ストリームのクローズに失敗", e );
				}
			} //if
			if (renderer != null) {
				renderer.dispose();
				renderer = null;
			}
			if (objPdfDevice != null) {
				objPdfDevice.dispose();
				objPdfDevice = null;
			}
			if (htmlDocument != null) {
				htmlDocument.dispose();
				htmlDocument = null;
			} //if

		} //try

		return strPdfOutPath_i;

	} //convertHtmlToPdf


} //class

