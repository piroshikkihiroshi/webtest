/**
 * 名称：DocGet.java
 * 機能名：DocumentIngoデータ取得
 * 概要：DocumentIngoのデータを取得(zip 全文テキストを除く)しjsonで返却する
 */

package jp.co.nec.docmng.blackPaint.util.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.blackPaint.entity.DocumentInfoEntPaint;
import jp.co.nec.docmng.blackPaint.service.DocInfoServicePaint;

/**
 * DocumentIngoデータ取得
 */
@RestController
public class DocGet {

	@Autowired
	DocInfoServicePaint docInfoService;

	/**
	 * DocumentIngoのデータを取得(zip 全文テキストを除く)しjsonで返却する
	 * @param documentId
	 * @return String documentIdで指定したレコード
	 */
	@GetMapping("/rest/doc/rec")
	public String getDocInfo(@RequestParam("documentId") int documentId) {
		String strRet = "";
		final List<DocumentInfoEntPaint> listPolicy = docInfoService.selectDocFileInfo(documentId);

		final ObjectMapper objMapper = new ObjectMapper();
		try {
			strRet = objMapper.writeValueAsString(listPolicy);
		} catch (final JsonProcessingException e) {
			e.printStackTrace();
		}
		return strRet;
	} //method

} //class
