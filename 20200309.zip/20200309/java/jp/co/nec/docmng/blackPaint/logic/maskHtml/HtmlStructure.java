/**
 * 名称：HtmlStructurel.java
 * 機能名：HTML格納クラス
 * 概要：HTMLのchar毎の情報を格納するクラス
 */

package jp.co.nec.docmng.blackPaint.logic.maskHtml;

/**
 * HTMLのchar毎の情報を格納するクラス<br>
 * HashMap&lt;Integer, HtmlStructure&gt; の形で格納し、keyは置換対象外文字やtagを含んだポジション
 * (&lt;div&gt;タグ等を含む)を格納する
 */
public class HtmlStructure {
	/**
	 * 対象文字
	 */
	public String strTgt = "";

	/**
	 * strTgtのステータス 0：置換対象外(半角文字等) 1：対象 2：HTMLtag 3：特殊文字(改行、タグ「\t」など)
	 */
	public int intStatus = 0;

	/**
	 * 置換対象外文字やtagを抜いたときのポジション
	 */
	public int intNotTagPos = 0;

} //class
