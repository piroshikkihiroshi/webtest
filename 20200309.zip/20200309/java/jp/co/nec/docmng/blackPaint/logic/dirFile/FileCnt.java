/**
 * 名称：FileCnt.java
 * 機能名：ファイル管理
 * 概要：ファイル管理のためのクラス
 */

package jp.co.nec.docmng.blackPaint.logic.dirFile;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.jsoup.Jsoup;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.zeroturnaround.zip.ZipUtil;

/**
 * ファイル管理
 */
public class FileCnt {
	static Logger objLog = LoggerFactory.getLogger(FileCnt.class);
	static String PAGE_CLASS = "awdiv awpage";
	/**
	 * File名から拡張子を抜いたファイル名を取得する
	 * @param strFileName_i ファイルのフルパス
	 * @return String 取得文字列
	 */
	synchronized public String getNameWithoutExtension(String strFileName_i) {
		int index = strFileName_i.lastIndexOf('.');
		if (index != -1) {
			return strFileName_i.substring(0, index);
		}
		return strFileName_i;
	} //getNameWithoutExtension

	/**
	 * strpath_iで指定したファイルを改行付きですべて読み込む
	 * @param strpath_i ファイルのフルパス
	 * @return 読み込んだ文字列
	 * @throws IOException 入出力エラー
	 */
	public String readAll(final String strpath_i) throws IOException {
//		return Files.lines(Paths.get(strpath_i), Charset.forName("UTF-8"))
//				.collect(Collectors.joining(System.getProperty("line.separator")));
		try (Stream<String> lines = Files.lines(Paths.get(strpath_i), Charset.forName("UTF-8"))) {
			return lines.collect(Collectors.joining(System.getProperty("line.separator")));
		} catch (IOException e) {
			objLog.error("Files.lins exception.", e);
			e.printStackTrace();
			return "";
		}
	} //readAll

    /**
     * pathにdocumentを書き込む
     * @param path ファイルのフルパス
     * @param document 書込む内容
     * @return boolean true：成功 false：失敗
     */
	public boolean writeFile(String path, String document) {
		PrintWriter stream = null;
		try {
			stream = new PrintWriter(new BufferedWriter(new OutputStreamWriter(
					new FileOutputStream(path, true),"utf-8")));
			stream.println(document);
			return true;
		} catch (Exception e) {
			objLog.error("ファイル出力失敗", e);
			return false;
		}
		finally {
			if (stream != null) {
				stream.close();
				stream = null;
			} //if
		} //try
	} //method

    /**
     * 複数のPDFを１つに結合する(文字コード変換)
     * @param inputFiles 複数のPDF
     * @return 結合結果をバイナリで返す
     */
//    public ByteArrayOutputStream PDFCombine(File[] inputFiles,String strCode_i){
        public ByteArrayOutputStream PDFCombine(File[] inputFiles){

        ByteArrayOutputStream arrBytes = new ByteArrayOutputStream();

        List<PDDocument> pddHolder = new ArrayList<>();

        try(PDDocument combiledPDFdoc= new PDDocument()){
            for(File objFile : inputFiles){
                try{
            		byte[] byteFile = null;
        			byteFile = Files.readAllBytes(objFile.toPath());
//        			String line = new String(byteFile, "SJIS");
//        			byte[] byteEnc = line.getBytes(StandardCharsets.UTF_8.toString());
//        			String line = new String(byteFile, "UTF-8");
//        			byte[] byteEnc = line.getBytes("Shift_JIS");

//                    PDDocument objPdfDoc = PDDocument.load(objFile);
//        			PDDocument objPdfDoc =PDDocument.load(byteFile);
        			PDDocument objPdfDoc =PDDocument.load(byteFile);
                    for(PDPage objPdfPage : objPdfDoc.getPages()) combiledPDFdoc.addPage(objPdfPage);
                    pddHolder.add(objPdfDoc);
                } catch (IOException ex) {
                	System.err.println(ex);
                }
            }
            combiledPDFdoc.save(arrBytes);
            // Save後に開放可能、Save前に開放すると上手く動かない
            pddHolder.stream().sequential().forEach(item -> {
                try {item.close();} catch (IOException ex) {}
            });
        } catch (IOException ex) {
        	System.err.println(ex);
        } //try
        return arrBytes;
    } //method

    /**
     * 保存文書zipファイル解凍用メソッド
     * @param objDirCls ディレクトリ管理
     * @param strFileOutDir 出力先ディレクトリ
     * @param strZipPath zipパス
     * @param objZipPath zipパス
     * @param zip zipファイル
     * @param newDirFlag trueの場合に出力先ディレクトリを作成する
     * @throws Exception 想定外エラー
     */
    public void unzipHtml (
            DirCnt objDirCls,
            String strFileOutDir,
            String strZipPath,
            Path objZipPath,
            byte[] zip,
            boolean newDirFlag
            ) throws Exception{
        try {
            if (newDirFlag) {
                // newDirFlagがtrueの時のみ新しくディレクトリを作成する
                objDirCls.makeDirWithCheck(strFileOutDir);
            } //if
            //zipファイル出力
            Files.write(objZipPath, zip);
            //unzipする
            ZipUtil.unpack(new File(strZipPath), new File(strFileOutDir));
            //作業ファイルかたづけ
            File fileZip = new File(strZipPath);
            fileZip.delete();
        } catch (Exception e) {
            objLog.error( "err message", e );
            e.printStackTrace();
            throw e;
        } //try
    }

    /**
     * 指定されたHTMLファイルの文字列データを返す処理を実施する
     * @param strFileOutDir ファイルパス
     * @param refHtmlName ファイル名
     * @return HTML文字列データ
     */
    public String zipHtmltoString (String strFileOutDir, String refHtmlName) {
        File file = new File(strFileOutDir + refHtmlName);
        String tmpHtml = ""; //戻り値用HTML文字列変数
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String tmp = "";
            // ファイルから文字列を取り出す
            while ((tmp = br.readLine()) != null) {
                tmpHtml += tmp;
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return tmpHtml;
    }

	/**
	 * style.cssを整形する(PDF用)
	 *
	 * @param strCsspath_i
	 * @return 読み込んだ文字列
	 * @throws IOException
	 */
	public String shapeStyleCssPdf(final String strCsspath_i) throws IOException {
		Path file = Paths.get(strCsspath_i);
		List<String> list = Files.readAllLines(file, Charset.forName("UTF-8"));
		StringBuilder objSb = new StringBuilder();
		boolean blFontFace = false;
		for (int i = 0; i < list.size(); i++) {
			String strTmp = list.get(i);
			if (strTmp.contains("@font-face")) {
				blFontFace = true;
			}else if (strTmp.matches("font-family:.*")) {
				if(blFontFace) {
					strTmp = "font-family:\"MS PGothic\";";
					blFontFace =false;
				}else {
					strTmp = "font-family:\"VL Gothic\";";
				} //if

			} // if
			objSb.append(strTmp + "\r\n");
		} // for
		File newfile = new File(strCsspath_i);
		PrintWriter filewriter = new PrintWriter(
				new BufferedWriter(new OutputStreamWriter(new FileOutputStream(newfile), "UTF-8")));
		filewriter.write(objSb.toString());

		if (filewriter != null)
			filewriter.close();

		return objSb.toString();

	} // method


	/**
	 * html文字列からasposeで分割したページ数を返す
	 * @param strHtml_i 対象HTML
	 * @return ページ数
	 */
	public int aspPageGet(String strHtml_i) {
		int intRet = 0;
		org.jsoup.nodes.Document objDoc = Jsoup.parse(strHtml_i);
		Elements elmCls= objDoc.getElementsByClass(PAGE_CLASS);
		intRet = elmCls.size();
		elmCls = null;

		return intRet;
	} //aspPageGet


} //FileCnt
