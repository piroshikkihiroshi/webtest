/**
 * 名称：RefEdit.java
 * 機能名：Refファイル 黒塗り文書作成画面初期表示メソッド
 * 概要：Refファイルを黒塗り文書作成画面に初期表示する
 */

package jp.co.nec.docmng.blackPaint.logic.edit;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ResourceLoader;

import jp.co.nec.docmng.blackPaint.controller.MaskHtmlCnt;
import jp.co.nec.docmng.blackPaint.entity.DocumentInfoEntPaint;
import jp.co.nec.docmng.blackPaint.entity.TmpMaskDocMarkerEntBlackPaint;
import jp.co.nec.docmng.blackPaint.entity.TmpMaskDocumentEntBlackPaint;
import jp.co.nec.docmng.blackPaint.logic.dirFile.DirCnt;
import jp.co.nec.docmng.blackPaint.logic.dirFile.FileCnt;
import jp.co.nec.docmng.blackPaint.logic.maskHtml.HtmlStructure;
import jp.co.nec.docmng.blackPaint.logic.maskHtml.MaskHtmlModel;
import jp.co.nec.docmng.blackPaint.service.DocInfoServicePaint;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocMarkerServicePaint;
import jp.co.nec.docmng.blackPaint.service.TmpMaskDocumentServicePaint;

/**
 * Refファイル 黒塗り文書作成画面初期表示メソッド
 */
public class RefEdit {
    static Logger objLog = LoggerFactory.getLogger(MaskHtmlCnt.class);

    @Autowired
    ServletContext context;
    @Autowired
    DocInfoServicePaint docInfoService;

    @Autowired
    TmpMaskDocMarkerServicePaint tmpMaskDocTmpMarkerService;

    @Autowired
    TmpMaskDocumentServicePaint tmpMaskDocumentService;

    HashMap<String, String> hashMap = new HashMap<String, String>();

    /**
     * 黒塗り文書作成画面初期表示メソッド
     * 画面初期表示の処理をする。
     * @param listDoc 文書情報から取得したデータのリスト
     * @param strTmpDir ファイル作成用フォルダパス
     * @param resourceLoader ResourceLoader
     * @param status 空文字: 初期処理 1: 再開 2: 黒塗りリスト確定
     * @param documentIdRef 参照文書ID
     * @param UserId ユーザID
     * @param tmpMaskDocTmpMarkerService
     * @param tmpMaskDocumentService
     * @param docInfoService
     * @return
     */
    public HashMap<String,String> refEditMain(
            List<DocumentInfoEntPaint> listDoc,
            String strTmpDir,
            ResourceLoader resourceLoader,
            Integer documentIdRef,
            String UserId,
            String status, //空文字: 初期処理 1: 再開 2: 黒塗りリスト確定
            TmpMaskDocMarkerServicePaint tmpMaskDocTmpMarkerService,
            TmpMaskDocumentServicePaint tmpMaskDocumentService,
            DocInfoServicePaint docInfoService
            ) {

        FileCnt objFileCnt = new FileCnt();
        MaskHtmlModel  objMaskCls = new MaskHtmlModel();
        DirCnt objDirCls = new DirCnt();

        int documentId = listDoc.get(0).getDocumentId();

        String strHeight = "785"; //word A4の時 他は未考慮
        int insPageLen = 1942; //txtのページの長さ(1行54文字、36行想定)-2

//        listDoc = docInfoService.selectDocInfo(documentId);
        //DocumentIDで一時保存を復元
        List<TmpMaskDocumentEntBlackPaint> tmpDoc = null;
        tmpDoc = tmpMaskDocumentService.getTmpHtmlZip(documentId, UserId);
        List<TmpMaskDocMarkerEntBlackPaint> listInfo = null;
        //policy等取得
        listInfo = tmpMaskDocTmpMarkerService.selectTmpMaskDocMarker(documentId, UserId);

        String arrMask = "";
        // ポリシーを設定
        for (int i = 0; i < listInfo.size(); i++) {
            TmpMaskDocMarkerEntBlackPaint tmdmebp = listInfo.get(i);
            arrMask +=tmdmebp.getMarkerStartCd()+":";
            arrMask +=tmdmebp.getMarkerEndCd()+":";
            arrMask +=tmdmebp.getMarkerPolicy()+"+";
        } //for
        if (listInfo.size() != 0) {
            // 0以外の時最後尾の+削除
            arrMask = arrMask.substring(0,arrMask.length()-1);
        }
        //DocumentIDRefでdocument_infoから情報を取得（参照文書）
        List<DocumentInfoEntPaint> refDoc=null;
        refDoc =docInfoService.selectDocInfo(documentIdRef);

        String strOrgFilePath = listDoc.get(0).getDocumentName();
        String refOrgFilePath = refDoc.get(0).getDocumentName();
        objLog.info("対象ファイル名：" + strOrgFilePath);
//        objLog.info("参照文書ファイル名：" + refOrgFilePath);

        String strOrgPath = listDoc.get(0).getFilePath();
        String refOrgPath = refDoc.get(0).getDocumentName();
        objLog.info("対象パス：" + strOrgPath);
        objLog.info("参照文書パス：" + refOrgPath);

        //一度RealPathへファイルをコピーする
        String strFileName = strOrgFilePath.substring(strOrgFilePath.lastIndexOf("\\") + 1, strOrgFilePath.length());
        objFileCnt.getNameWithoutExtension(strFileName);
        String refFileName = refOrgFilePath.substring(refOrgFilePath.lastIndexOf("\\") + 1, refOrgFilePath.length());
        String refFileWithoutExtension = objFileCnt.getNameWithoutExtension(refFileName);

        String strHtmlName = documentId + ".html"; //作成html名
        String refHtmlName = documentIdRef + ".html"; //作成html名
//        String refHtmlPath = strTmpDir + refFileWithoutExtension + ".html"; //作成htmlパス

        hashMap.put("strRefHtmlName", refHtmlName);
        hashMap.put("strRefFileName", refFileName);

        FileWriter objFile=null;
        PrintWriter objPw=null;
        // スタイルシートを共通メソッドから取得
        String refStyle = "";
        refStyle+="<style>";
        refStyle+=".tagRed{";
        refStyle+="    color: rgb(233, 84, 84);";
//        strStyle+="    background-color: #ffff7b;";
        refStyle+="}";
        refStyle+=".tagRng{";
        refStyle+="    color: rgb(233, 87, 51);";
        refStyle+="    background-color: rgba(159, 192, 230, 0.884);";
        refStyle+="}";
        refStyle+=".tagMsk{";
        refStyle+="    color: black;";
        if (listDoc.get(0).getExtension().equals("txt")) {
            refStyle+="    word-break: break-all;";
//            refStyle+="    padding: 3px;";
//            refStyle+="    font-family: Courier, Monaco, monospace;";
            refStyle+="    line-height: 1.2;";
            refStyle+="    width: 97%;";
            refStyle+="    text-align: justify;";
            refStyle+="    background-color: black;";
        }else {
//            refStyle+="    font-size: 10.5pt;";
            refStyle+="    background-color: black;";
        } //id

        if (listDoc.get(0).getExtension().contains("pdf")) {
        	refStyle+="    color: black;";
        	refStyle+="    display: inline-grid;";
        	refStyle+="    overflow: hidden;";
        }

        refStyle+="}";
        refStyle+=".awpage {";
        refStyle+="    position: relative;";
        refStyle+="    border: none;";
        refStyle+="    margin: 0px;";
        refStyle+="}";
        refStyle+=".redimg{";
        refStyle+="    -webkit-filter: sepia(100%)  hue-rotate(300deg); ";
        refStyle+="    -moz-filter: sepia(100%)  hue-rotate(300deg);";
        refStyle+="    -o-filter: sepia(100%)  hue-rotate(300deg);";
        refStyle+="    -ms-filter: sepia(100%)  hue-rotate(300deg);";
        refStyle+="    filter: sepia(100%)  hue-rotate(300deg);";
        refStyle+="}";
        refStyle+="</style>";


        String refRefOutPath = strTmpDir + refHtmlName;

        int intPageCnt = 1;
        // 参照文書ページ数
        int intRefPageCnt = 1;

        // zip解凍用
        String strFileOutDir = strTmpDir;
        String strZipPath = strFileOutDir + "mask.zip";
        Path objZipPath = Paths.get(strZipPath);

        String strRefHtml;

        if (refDoc.get(0).getExtension().equals("txt")) {
            try {
                //出力フォルダ作成
                objDirCls.makeDirWithCheck(strTmpDir);
                objDirCls.makeDirWithCheck(strTmpDir + documentIdRef);
                //動的templateを作成
                String refOutHtml = "";
                refOutHtml+="<body>";
                refOutHtml+=refDoc.get(0).getDocumentContents();
                refOutHtml+="</body>";
//                refOutHtml = objMaskCls.insertStyleTxt(refOutHtml, refStyle);

                strRefHtml = refOutHtml;
                //20191212 結果から再度構造体を作成し、ページネーションを作成
                HashMap<Integer, HtmlStructure> hashBodyPageStructure = objMaskCls.getBodyStructure(strRefHtml);
                String strTmpTxt ="";
                strTmpTxt = objMaskCls.bodyMakePaginate(hashBodyPageStructure,insPageLen);

                //スタイルシートPath埋め込み
                strRefHtml = objMaskCls.insertStyleTxt(strTmpTxt,refStyle);



                //htmlを出力する(参照文書)
                objFile = new FileWriter(refRefOutPath);
                objPw = new PrintWriter(new BufferedWriter(objFile));
                objPw.println(strRefHtml);
                objPw.close();


                objLog.info("REFHTML完了(txt)");
                intRefPageCnt = objFileCnt.aspPageGet(strRefHtml);

                hashMap.put("strRefPageCnt", intRefPageCnt+"");

            } catch (IOException e) {
                objLog.error( "err message", e );
                e.printStackTrace();
            }
        } else if(refDoc.get(0).getExtension().contains("doc"))  {
            // Wordの場合
            // 参照文書
            byte[] refHtmlZip=null;
            refHtmlZip = refDoc.get(0).getHtmlZipData();
            //file出力
            try {
                // 参照文書ファイルの解凍
                objFileCnt.unzipHtml(objDirCls, strFileOutDir, strZipPath, objZipPath, refHtmlZip, true);

                // 20200115　ファイル名をdocumentIdに変更した対応
                //変更前ファイル名
                 File bfFile = new File(strFileOutDir+refFileWithoutExtension+".html");
                 //変更後のファイル名
                 File afFile = new File(strFileOutDir+documentIdRef+".html");
                 bfFile.renameTo(afFile);

                //変更前ファイル名
                 File bfDir = new File(strFileOutDir+"/"+refFileWithoutExtension);
                 //変更後のファイル名
                 File afDir = new File(strFileOutDir+"/"+documentIdRef);
                 bfDir.renameTo(afDir);

                // ページカウント
                String tmpHtml = objFileCnt.zipHtmltoString(strFileOutDir, refHtmlName);
                // 20200115　ファイル名をdocumentIdに変更した対応
                tmpHtml = tmpHtml.replace("href=\""+refFileWithoutExtension+"/", "href=\""+documentIdRef+"/");
                tmpHtml = tmpHtml.replace("src=\""+refFileWithoutExtension+"/", "src=\""+documentIdRef+"/");
                intRefPageCnt = objFileCnt.aspPageGet(tmpHtml);
                hashMap.put("strRefPageCnt", intRefPageCnt+"");

                // 参照文書のスタイル変更
                tmpHtml = objMaskCls.insertStyle(tmpHtml, refStyle);

                //htmlを書換出力する
                objFile = new FileWriter(refRefOutPath);
                objPw = new PrintWriter(new BufferedWriter(objFile));
                objPw.println(tmpHtml);
                objPw.close();
                objLog.info("REFHTML完了(word)");
            } catch (IOException e1) {
                objLog.error( "err message", e1 );
                e1.printStackTrace();
            } //try
            catch (Exception e) {
                objLog.error( "err message", e );
                e.printStackTrace();
            } //try
        } else if(refDoc.get(0).getExtension().contains("xls"))  {
            // Excelの場合
            // 参照文書
            byte[] refHtmlZip=null;
            refHtmlZip = refDoc.get(0).getHtmlZipData();
            //file出力
            try {
                // 参照文書ファイルの解凍
                objFileCnt.unzipHtml(objDirCls, strFileOutDir, strZipPath, objZipPath, refHtmlZip, true);

                // 20200115　ファイル名をdocumentIdに変更した対応
                //変更前ファイル名
                 File bfFile = new File(strFileOutDir+refFileWithoutExtension+".html");
                 //変更後のファイル名
                 File afFile = new File(strFileOutDir+documentIdRef+".html");
                 bfFile.renameTo(afFile);

                //変更前ファイル名
                 File bfDir = new File(strFileOutDir+"_files/"+refFileWithoutExtension);
                 //変更後のファイル名
                 File afDir = new File(strFileOutDir+"/"+documentIdRef);
                 bfDir.renameTo(afDir);

                // ページカウント
                String tmpHtml = objFileCnt.zipHtmltoString(strFileOutDir, refHtmlName);
                // 20200115　ファイル名をdocumentIdに変更した対応
                tmpHtml = tmpHtml.replaceAll("\\<(.+=).+_files/", "<$1\\\""+documentId+"/");
                tmpHtml = tmpHtml.replace("stl_02", "awdiv awpage");
                intRefPageCnt = objFileCnt.aspPageGet(tmpHtml);
                hashMap.put("strRefPageCnt", intRefPageCnt+"");

                // 参照文書のスタイル変更
                tmpHtml = objMaskCls.insertStyle(tmpHtml, refStyle);

                //htmlを書換出力する
                objFile = new FileWriter(refRefOutPath);
                objPw = new PrintWriter(new BufferedWriter(objFile));
                objPw.println(tmpHtml);
                objPw.close();
                objLog.info("REFHTML完了(excel)");
            } catch (IOException e1) {
                objLog.error( "err message", e1 );
                e1.printStackTrace();
            } //try
            catch (Exception e) {
                objLog.error( "err message", e );
                e.printStackTrace();
            } //try
        } else if(refDoc.get(0).getExtension().contains("ppt"))  {
            // PowerPointの場合
            // 参照文書
            byte[] refHtmlZip=null;
            refHtmlZip = refDoc.get(0).getHtmlZipData();
            //file出力
            try {
                // 参照文書ファイルの解凍
                objFileCnt.unzipHtml(objDirCls, strFileOutDir, strZipPath, objZipPath, refHtmlZip, true);

                // 20200115　ファイル名をdocumentIdに変更した対応
                //変更前ファイル名
                 File bfFile = new File(strFileOutDir+refFileWithoutExtension+".html");
                 //変更後のファイル名
                 File afFile = new File(strFileOutDir+documentIdRef+".html");
                 bfFile.renameTo(afFile);

                //変更前ファイル名
                 File bfDir = new File(strFileOutDir+"_files/"+refFileWithoutExtension);
                 //変更後のファイル名
                 File afDir = new File(strFileOutDir+"/"+documentIdRef);
                 bfDir.renameTo(afDir);

                // ページカウント
                String tmpHtml = objFileCnt.zipHtmltoString(strFileOutDir, refHtmlName);
                // 20200115　ファイル名をdocumentIdに変更した対応
                tmpHtml = tmpHtml.replaceAll("\\<(.+=).+_files/", "<$1\\\""+documentId+"/");
                tmpHtml = tmpHtml.replace("stl_02", "awdiv awpage");
                intRefPageCnt = objFileCnt.aspPageGet(tmpHtml);
                hashMap.put("strRefPageCnt", intRefPageCnt+"");

                // 参照文書のスタイル変更
                tmpHtml = objMaskCls.insertStylePpt(tmpHtml, refStyle);

                //htmlを書換出力する
                objFile = new FileWriter(refRefOutPath);
                objPw = new PrintWriter(new BufferedWriter(objFile));
                objPw.println(tmpHtml);
                objPw.close();
                objLog.info("REFHTML完了(powerpoint)");
                strHeight = "485";
            } catch (IOException e1) {
                objLog.error( "err message", e1 );
                e1.printStackTrace();
            } //try
            catch (Exception e) {
                objLog.error( "err message", e );
                e.printStackTrace();
            } //try
        } else if(refDoc.get(0).getExtension().contains("pdf"))  {
            // PDFの場合
            // 参照文書
            byte[] refHtmlZip=null;
            refHtmlZip = refDoc.get(0).getHtmlZipData();
            //file出力
            try {
                // 参照文書ファイルの解凍
                objFileCnt.unzipHtml(objDirCls, strFileOutDir, strZipPath, objZipPath, refHtmlZip, true);

                // 20200115　ファイル名をdocumentIdに変更した対応
                //変更前ファイル名
                 File bfFile = new File(strFileOutDir+refFileWithoutExtension+".html");
                 //変更後のファイル名
                 File afFile = new File(strFileOutDir+documentIdRef+".html");
                 bfFile.renameTo(afFile);

                //変更前ファイル名
                 File bfDir = new File(strFileOutDir+"_files/"+refFileWithoutExtension);
                 //変更後のファイル名
                 File afDir = new File(strFileOutDir+"/"+documentIdRef);
                 bfDir.renameTo(afDir);

                // ページカウント
                String tmpHtml = objFileCnt.zipHtmltoString(strFileOutDir, refHtmlName);
                // 20200115　ファイル名をdocumentIdに変更した対応
                tmpHtml = tmpHtml.replaceAll("\\<(.+=).+_files/", "<$1\\\""+documentId+"/");
                tmpHtml = tmpHtml.replace("stl_02", "awdiv awpage");
                intRefPageCnt = objFileCnt.aspPageGet(tmpHtml);
                hashMap.put("strRefPageCnt", intRefPageCnt+"");

                // 参照文書のスタイル変更
                tmpHtml = objMaskCls.insertStyle(tmpHtml, refStyle);

                //htmlを書換出力する
                objFile = new FileWriter(refRefOutPath);
                objPw = new PrintWriter(new BufferedWriter(objFile));
                objPw.println(tmpHtml);
                objPw.close();
                objLog.info("REFHTML完了(pdf)");
            } catch (IOException e1) {
                objLog.error( "err message", e1 );
                e1.printStackTrace();
            } //try
            catch (Exception e) {
                objLog.error( "err message", e );
                e.printStackTrace();
            } //try
        }



        // 一時保存ファイルの解凍
        try {
            // 黒塗り処理一時保存
            byte[] arrHtmlZip=null;
            arrHtmlZip = tmpDoc.get(0).getHtmlZipData();
            // 一時保存ファイルの解凍（参照文書と同じ場所に解凍）
            objFileCnt.unzipHtml(objDirCls, strFileOutDir, strZipPath, objZipPath, arrHtmlZip, false);
            // 一時保存ファイルのページカウント
            String tmpHtml = objFileCnt.zipHtmltoString(strFileOutDir, "red_" + strHtmlName);
            intPageCnt = objFileCnt.aspPageGet(tmpHtml);
            hashMap.put("strPageCnt", intPageCnt+"");
        } catch (IOException e) {
            objLog.error( "err message", e );
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

		hashMap.put("strHeight", strHeight);
        return hashMap;


    } // method

} // class
