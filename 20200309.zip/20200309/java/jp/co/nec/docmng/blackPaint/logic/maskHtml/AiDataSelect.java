/**
 * 名称：AiDataSelect.java
 * 機能名：AiData処理クラス
 * 概要：選択したポリシーIDをもとにAiDataを選別するクラス
 */

package jp.co.nec.docmng.blackPaint.logic.maskHtml;



/**
 * AIデータを選別するクラス<br>
 */
public class AiDataSelect {
	/**
	 *
	 * @param aiData AIデータ
	 * @param policySelect 黒塗りポリシー選択画面で選択したポリシーID
	 * @return String 選別したAIデータ
	 */
	public String selectAiData(
			String aiData,
			String policySelect
			) {

		String selectAiData ="";
		String[] arrSelectPolicy = policySelect.split(",");
		String[] arrAiData = aiData.split("\\+");


		if(!(aiData.equals(""))) {
	        for (int i = 0; i < arrAiData.length; i++) {
	            String[] arrTmp = arrAiData[i].split(":");
	            for (int j = 0; j < arrSelectPolicy.length; j++){
	            	if(arrSelectPolicy[j].indexOf(arrTmp[2])>=0 ) {
	            		selectAiData += arrTmp[0]+":";
	            		selectAiData += arrTmp[1]+":";
	            		selectAiData += arrTmp[2]+"+";
		            }
	            }
	        } //for
	        if(selectAiData!="") {
	        	selectAiData = selectAiData.substring(0,selectAiData.length()-1 );
	        }
		}
		return selectAiData;
	} //selectAiData

} //class
