/**
 * 名称：PolicyKeywordInfoBlackPaint.java
 * 機能名：黒塗り処理黒塗りポリシーキーワード情報entity
 * 機能:黒塗り処理で使用する文書情報entity
 */

package jp.co.nec.docmng.blackPaint.entity;

import java.util.Date;
import lombok.Data;

/**
 * 黒塗り処理黒塗りポリシーキーワード情報entity
 */
@Data
public class PolicyKeywordInfoBlackPaint {

	/**
	 * ポリシーID
	 */
	private Integer policyId;

	/**
	 * キーワードID
	 */
	private String policyKeyword;

	/**
	 * 作成日時
	 */
	private Date createTime;

	/**
	 * 文書ID
	 */
	private Date updateTime;

	/**
	 * 表示・非表示切替用フラグ
	 */
	boolean viewFlag = true;

}