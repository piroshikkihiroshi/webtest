/**
 * 名称：MaskDocumentService.java
 * 機能名：黒塗り処理黒塗り文書保存情報連携
 * 概要：黒塗り処理にて使用する黒塗り文書保存情報への連携用サービス
 */

package jp.co.nec.docmng.blackPaint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.blackPaint.entity.MaskDocumentEntBlackPaint;
import jp.co.nec.docmng.blackPaint.repository.MaskDocumentMapPaint;

/**
 * 黒塗り処理黒塗り文書保存情報連携
 */
@Service
public class MaskDocumentServicePaint {
	@Autowired
	private MaskDocumentMapPaint maskDocumentMapPaint;

	/**
	 * ドキュメントID、ユーザID指定によるHTML群(zip圧縮)の取得
	 * @param document_id 取得条件となるドキュメントID
	 * @param user_id 取得条件となるユーザID
	 * @return 取得したデータのリスト
	 */
	@Transactional
	public List<MaskDocumentEntBlackPaint> getHtmlZip(Integer document_id, String user_id) {
		return maskDocumentMapPaint.getHtmlZip(document_id, user_id);

	} //method

	/**
	 * データ登録処理
	 * @param MaskDocumentEnt 登録内容を格納したentity
	 */
	@Transactional
	public void insertMaskDocument(MaskDocumentEntBlackPaint MaskDocumentEnt) {
		maskDocumentMapPaint.insertMaskDocument(MaskDocumentEnt);
	} //insertMaskDocumentMarker

	/**
	 * ドキュメントID、ユーザID指定による削除処理
	 * @param document_id 削除条件となるドキュメントID
	 * @param user_id 削除条件となるユーザID
	 */
	@Transactional
	public void deleteDoc(Integer document_id, String user_id) {
		maskDocumentMapPaint.deleteDoc(document_id, user_id);
	} //deleteDoc

	/**
	 * ファイルID指定でユニークなレコードを取得する
	 * @param file_id Procenter/CのファイルID
	 * @return 取得したデータのリスト
	 */
	@Transactional
	public List<MaskDocumentEntBlackPaint> getMaskDoc(Integer file_id) {
		return maskDocumentMapPaint.getMaskDoc(file_id);

	} //method

	/**
	 * ファイルIDとユーザーID指定でユニークなレコードを取得する
	 * @param file_id Procenter/CのファイルID
	 * @param user_id ユーザーID
	 * @return 取得したデータのリスト
	 */
	@Transactional
	public List<MaskDocumentEntBlackPaint> getUserMaskDoc(Integer file_id, String user_id) {
		return maskDocumentMapPaint.getUserMaskDoc(file_id, user_id);

	} //method

} //PolicyInfoServiceApi
