/**
 * 名称：SearchServerInfoSaveFrom.java
 * 機能名：管理系検索対象サーバ設定情報entity(From)
 * 概要：管理系で使用する検索対象サーバ設定情報entity(From)
 */

package jp.co.nec.docmng.manage.entity;

import java.util.List;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * 管理系検索対象サーバ設定情報entity(From)
 */
@JsonInclude
public class SearchServerInfoSaveFrom {
    private List<AddValues> addValues;
    private List<ChangedValues> changedValues;
    private List<Integer> deleteRow;

    /**
     * addValues getter
     * @return addValues
     */
    public List<AddValues> getAddValues() {
        return addValues;
    }
    /**
     * addValues setter
     * @param addValues
     */
    public void setAddValues(List<AddValues> addValues) {
        this.addValues = addValues;
    }

    /**
     * changedValues getter
     * @return changedValues
     */
    public List<ChangedValues> getChangedValues() {
        return changedValues;
    }
    /**
     * changedValues setter
     * @param changedValues
     */
    public void setChangedValues(List<ChangedValues> changedValues) {
        this.changedValues = changedValues;
    }

    /**
     * deleteRow getter
     * @return deleteRow
     */
    public List<Integer> getDeleteRow() {
        return deleteRow;
    }
    /**
     * deleteRow setter
     * @param deleteRow
     */
    public void setDeleteRow(List<Integer> deleteRow) {
        this.deleteRow = deleteRow;
    }

	/**
	 * 値追加
	 */
    public static class AddValues {
        @NotBlank(message = "必須項目です。")
        private String displayName;
        @NotBlank(message = "必須項目です。")
        private String serverName;
        @NotBlank(message = "必須項目です。")
        private String loginUserName;
        @NotBlank(message = "必須項目です。")
        private String loginPassword;
        @NotBlank(message = "必須項目です。")
        private String directoryPath;

        /**
         * displayName getter
         * @return displayName
         */
        public String getDisplayName() {
            return displayName;
        }
        /**
         * displayName setter
         * @param displayName
         */
        public void setDisplayName(String displayName) {
            this.displayName = displayName;
        }

        /**
         * serverName getter
         * @return serverName
         */
        public String getServerName() {
            return serverName;
        }
        /**
         * serverName setter
         * @param serverName
         */
        public void setServerName(String serverName) {
            this.serverName = serverName;
        }

        /**
         * loginUserName getter
         * @return loginUserName
         */
        public String getLoginUserName() {
            return loginUserName;
        }
        /**
         * loginUserName setter
         * @param loginUserName
         */
        public void setLoginUserName(String loginUserName) {
            this.loginUserName = loginUserName;
        }

        /**
         * loginPassword getter
         * @return loginPassword
         */
        public String getLoginPassword() {
            return loginPassword;
        }
        /**
         * loginPassword setter
         * @param loginPassword
         */
        public void setLoginPassword(String loginPassword) {
            this.loginPassword = loginPassword;
        }

        /**
         * directoryPath getter
         * @return directoryPath
         */
        public String getDirectoryPath() {
            return directoryPath;
        }
        /**
         * directoryPath setter
         * @param directoryPath
         */
        public void setDirectoryPath(String directoryPath) {
            this.directoryPath = directoryPath;
        }

    }

	/**
	 * 値変更
	 */
    public static class ChangedValues {
        @NotBlank(message = "必須項目です。")
        private Integer serverId;
        @NotBlank(message = "必須項目です。")
        private String displayName;
        @NotBlank(message = "必須項目です。")
        private String serverName;
        @NotBlank(message = "必須項目です。")
        private String loginUserName;
        @NotBlank(message = "必須項目です。")
        private String loginPassword;
        @NotBlank(message = "必須項目です。")
        private String directoryPath;

        /**
         * serverId getter
         * @return serverId
         */
        public Integer getServerId() {
            return serverId;
        }
        /**
         * serverId setter
         * @param serverId
         */
        public void setServerId(Integer serverId) {
            this.serverId = serverId;
        }

        /**
         * displayName getter
         * @return displayName
         */
        public String getDisplayName() {
            return displayName;
        }
        /**
         * displayName setter
         * @param displayName
         */
        public void setDisplayName(String displayName) {
            this.displayName = displayName;
        }

        /**
         * serverName getter
         * @return serverName
         */
        public String getServerName() {
            return serverName;
        }
        /**
         * serverName setter
         * @param serverName
         */
        public void setServerName(String serverName) {
            this.serverName = serverName;
        }

        /**
         * loginUserName getter
         * @return loginUserName
         */
        public String getLoginUserName() {
            return loginUserName;
        }
        /**
         * loginUserName setter
         * @param loginUserName
         */
        public void setLoginUserName(String loginUserName) {
            this.loginUserName = loginUserName;
        }

        /**
         * loginPassword getter
         * @return loginPassword
         */
        public String getLoginPassword() {
            return loginPassword;
        }
        /**
         * loginPassword setter
         * @param loginPassword
         */
        public void setLoginPassword(String loginPassword) {
            this.loginPassword = loginPassword;
        }

        /**
         * directoryPath getter
         * @return directoryPath
         */
        public String getDirectoryPath() {
            return directoryPath;
        }
        /**
         * directoryPath setter
         * @param directoryPath
         */
        public void setDirectoryPath(String directoryPath) {
            this.directoryPath = directoryPath;
        }
    }
}


