/**
 * 名称：TmpTeacherCategoryService.java
 * 機能名：管理系教師データ(分類)登録画面一時保存情報連携
 * 概要：管理系にて使用する教師データ(分類)登録画面一時保存情報への連携用サービス
 */

package jp.co.nec.docmng.manage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.manage.entity.TmpTeacherCategoryList;
import jp.co.nec.docmng.manage.util.map.TmpTeacherCategoryListMapManage;

/**
 * 管理系教師データ(分類)登録画面一時保存情報連携
 */
@Service
public class TmpTeacherCategoryService {

    @Autowired
    private TmpTeacherCategoryListMapManage tmpTeacherCategoryListMapper;

	/**
	 * 全件取得
	 * @return 検索結果
	 */
    @Transactional
    public List<TmpTeacherCategoryList> findAll(){
        List<TmpTeacherCategoryList> entityList = tmpTeacherCategoryListMapper.findAll();
        return entityList;
    }

	/**
	 * データ登録
	 * @param tmpTeacherCategoryList 登録情報
	 */
    @Transactional
    public void insert(TmpTeacherCategoryList tmpTeacherCategoryList) {
        tmpTeacherCategoryListMapper.insertReflect(tmpTeacherCategoryList);
    }

	/**
	 * データ更新_分類軸ID
	 * @param targetCategory 更新条件の分類軸ID
	 * @param tmpTeacherCategoryList 更新値を格納したentity
	 */
    @Transactional
    public void updateCategoryId(Integer targetCategory, TmpTeacherCategoryList tmpTeacherCategoryList){
        tmpTeacherCategoryListMapper.updateCategoryId(targetCategory, tmpTeacherCategoryList);
    }

    /**
     * 全削除実施
     */
    @Transactional
    public void deleteAll() {
        tmpTeacherCategoryListMapper.deleteAll();
    }

}
