/**
 * 名称：TmpTeacherCategoryListMapManage.java
 * 機能名：管理系教師データ(分類)登録画面一時保存情報連携
 * 概要：管理系にて使用する教師データ(分類)登録画面一時保存情報への連携用レポジトリ
 */

package jp.co.nec.docmng.manage.util.map;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import jp.co.nec.docmng.manage.entity.TmpTeacherCategoryList;

/**
 * 管理系教師データ(分類)登録画面一時保存情報連携
 */
@Mapper
public interface TmpTeacherCategoryListMapManage {

	/**
	 * 全件取得
	 * @return 検索結果
	 */
    @Select("select * from admin.tmp_teacher_category_list order by sort_id")
    public List<TmpTeacherCategoryList> findAll();

	/**
	 * データ登録
	 * @param record 登録情報
	 */
    @Insert("insert into admin.tmp_teacher_category_list (user_id, sort_id, category_id, file_path, create_time, update_time) values (#{userId}, #{sortId}, #{categoryId}, #{filePath}, #{createTime}, #{updateTime})")
    void insertReflect(TmpTeacherCategoryList record);

	/**
	 * データ更新_分類軸ID
	 * @param targetCategory 更新条件の分類軸ID
	 * @param tmpTeacherCategoryList 更新値を格納したentity
	 */
    @Update("update admin.tmp_teacher_category_list set category_id = #{tmpTeacherCategoryList.categoryId}, update_time = #{tmpTeacherCategoryList.updateTime} where category_id = #{targetCategory}")
    void updateCategoryId(Integer targetCategory, TmpTeacherCategoryList tmpTeacherCategoryList);

    /**
     * 全削除実施
     */
    @Delete("delete from admin.tmp_teacher_category_list")
    void deleteAll();

}
