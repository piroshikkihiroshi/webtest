/**
 * 名称：TmpTeacherPolicyReqForm.javaファイル
 * 機能名：教師データ（黒塗り箇所摘出）の登録リクエストデータFrom
 * 概要：教師データ（黒塗り箇所摘出）の登録リクエストデータを保持する。
 */
package jp.co.nec.docmng.manage.entity;

import java.util.List;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * 教師データ（黒塗り箇所摘出）の登録リクエストデータを保持する。
 */
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class TmpTeacherPolicyListReqForm {
    @NotBlank(message = "必須項目です。")
    private String savePath;
    @NotBlank(message = "必須項目です。")

    private List<TmpTeacherPolicyList> tmpTeacherPolicyList;

    /**
     * savePath getter
     * @return savePath
     */
    public String getSavePath() {
        return savePath;
    }
    /**
     * savePath setter
     * @param savePath
     */
    public void setSavePath(String savePath) {
        this.savePath = savePath;
    }

    /**
     * tmpTeacherPolicyList getter
     * @return tmpTeacherPolicyList
     */
    public List<TmpTeacherPolicyList> getTmpTeacherPolicyList() {
        return tmpTeacherPolicyList;
    }
    /**
     * tmpTeacherPolicyList setter
     * @param tmpTeacherPolicyList
     */
    public void setTmpTeacherPolicyList(List<TmpTeacherPolicyList> tmpTeacherPolicyList) {
        this.tmpTeacherPolicyList = tmpTeacherPolicyList;
    }
}