/**
 * 名称：SearchServerInfoService.java
 * 機能名：管理系検索対象サーバ設定情報連携
 * 概要：管理系にて使用する検索対象サーバ設定情報への連携用サービス
 */

package jp.co.nec.docmng.manage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.manage.entity.SearchServerInfoEntity;
import jp.co.nec.docmng.manage.util.map.SearchServerInfoMapManage;

/**
 * 管理系検索対象サーバ設定情報連携
 */
@Service
public class SearchServerInfoService {

    @Autowired
    private SearchServerInfoMapManage searchServerInfoMapper;

	/**
	 * 全件取得
	 * @return 検索結果
	 */
    @Transactional
    public List<SearchServerInfoEntity> findAll(){
        List<SearchServerInfoEntity> entityList = searchServerInfoMapper.findAll();
        return entityList;
    }

	/**
	 * データ登録
	 * @param searchServerInfo 登録情報
	 */
    @Transactional
    public void insert(SearchServerInfoEntity searchServerInfo) {
        searchServerInfoMapper.insert(searchServerInfo);
    }

	/**
	 * データ更新_サーバID指定
	 * @param searchServerInfo 更新情報
	 */
    @Transactional
    public void update(SearchServerInfoEntity searchServerInfo) {
        searchServerInfoMapper.update(searchServerInfo);
    }

	/**
	 * データ削除_サーバID指定
	 * @param id サーバID
	 */
    @Transactional
    public void deleteById(Integer id){
        searchServerInfoMapper.deleteById(id);
    }

}
