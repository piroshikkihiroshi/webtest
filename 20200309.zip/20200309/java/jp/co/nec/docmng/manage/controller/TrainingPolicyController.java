/**
 * 名称：TrainingPolicyControllerファイル
 * 機能名：教師データ登録（黒塗り箇所抽出）コントローラー
 * 概要：教師データ登録（黒塗り箇所抽出）の制御を実施する
 */
package jp.co.nec.docmng.manage.controller;

import java.io.File;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import jp.co.nec.docmng.library.train.MakeTrainingData;
import jp.co.nec.docmng.manage.entity.PolicyInfoEntity;
import jp.co.nec.docmng.manage.entity.TmpTeacherPolicyList;
import jp.co.nec.docmng.manage.entity.TmpTeacherPolicyListReqForm;
import jp.co.nec.docmng.manage.service.PolicyInfoService;
import jp.co.nec.docmng.manage.service.TmpTeacherPolicyService;

/**
 * 教師データ（黒塗り箇所摘出）のリクエストを制御する
 */
@Controller
@RequestMapping("/manage/training_policy")
public class TrainingPolicyController {

    /** ロガー */
    private static Logger objLog = LoggerFactory.getLogger(TrainingPolicyController.class);

    @Autowired
    PolicyInfoService policyInfoService;
    @Autowired
    TmpTeacherPolicyService tmpTeacherPolicyService;

    /** 正解データコンバート用API */
    MakeTrainingData train = new MakeTrainingData();

    /** 黒塗りポリシー一覧が空の場合のエラーメッセージ  */
    static final String POLICYINFO_EMPTY_ERR = "ポリシー情報が存在しません。";

    /** 正解データ格納先に指定されたパスが存在しない場合のエラーメッセージ  */
    static final String PATH_NOTEXISTS_ERR = "以下に記載したパスが存在しません。";

    /**
     * 管理者権限
     */
    private static final String USER_ROLE_TYPE = "Administrators";

    /**
     * <p>教師データ登録（黒塗り箇所摘出）初期表示処理</p>
     * 処理内容：教師データ登録（黒塗り箇所摘出）を表示する
     * @param model モデル
	 * @param request HTTPリクエスト
     * @return 教師データ登録（黒塗り箇所摘出）画面のURL
     */
    @GetMapping
    public String getTrainingPolicy(Model model, HttpServletRequest request) {

        //クッキー情報を取得する
        System.out.println("");
        System.out.println(request.getHeader("Cookie"));
        int userAuth = 0;

        //管理者権限の文字列が検出されなかった場合
        if(request.getHeader("Cookie") == null){
            userAuth = 1;

            objLog.info("getSearchServerInfo request end (failed)");
            model.addAttribute("userAuth", userAuth);
            return "manage/trainingPolicy";
        }

        //ログインしているユーザーの権限を確認する
        String userRoleString = "\"userRole\":\"";
        int openUserRolePoint = request.getHeader("Cookie").indexOf(userRoleString);
        int openUserRoleEndPoint = request.getHeader("Cookie").indexOf(USER_ROLE_TYPE,openUserRolePoint) + USER_ROLE_TYPE.length();
        System.out.println(openUserRolePoint);
        System.out.println(openUserRoleEndPoint);

        //管理者権限の文字列が検出されなかった場合
        if(openUserRoleEndPoint == 13){
            userAuth = 1;

            objLog.info("getSearchServerInfo request end (failed)");
            model.addAttribute("userAuth", userAuth);
            return "manage/trainingPolicy";
        }

        String openUserRole = request.getHeader("Cookie").substring(openUserRolePoint+userRoleString.length(),openUserRoleEndPoint);
        System.out.println(openUserRole);

        objLog.info("getTrainingPolicy request start");

        // 全件取得
        List<PolicyInfoEntity> policyInfos = policyInfoService.findAll();

        // ポリシー一覧が取得できなかった場合
        if (Objects.isNull(policyInfos) || policyInfos.size() == 0) {
            // エラーを返しalertを表示させる
            model.addAttribute("err", POLICYINFO_EMPTY_ERR);
            objLog.info("policy info not found");
            objLog.trace("policyInfos null");
            objLog.info("getTrainingPolicy request end (error)");
            return "manage/trainingPolicy";
        }

        // 保存先の取得とテキストへの設定
        ResourceBundle rb = ResourceBundle.getBundle("config/manage");
        model.addAttribute("saveRegistrationList", rb.getString("SavaFilePath.TrainingPolicy"));

        // 管理系教師データ(黒塗り箇所摘出)登録画面一時保存情報の全件取得
        List<TmpTeacherPolicyList> teacherPolicyLists = tmpTeacherPolicyService.findAll();

        // 表示用にポリシー名を付与する
        for (int i = 0; i < teacherPolicyLists.size(); i++) {
            teacherPolicyLists.get(i).setPolicyName(" ");
            for (int j = 0; j < policyInfos.size() ; j++) {
                if (policyInfos.get(j).getPolicyId().equals(teacherPolicyLists.get(i).getPolicyId())) {
                    teacherPolicyLists.get(i).setPolicyName(policyInfos.get(j).getPolicyName());
                    break;
                }
            }
        }

        model.addAttribute("policyInfo", policyInfos);
        model.addAttribute("teacherPolicyList", teacherPolicyLists);
        objLog.trace("policyInfo:{}", policyInfos);
        objLog.trace("teacherPolicyList:{}", teacherPolicyLists);
        objLog.info("getTrainingPolicy request end (success)");
        return "manage/trainingPolicy";
    }

    /**
     * <p>教師データ登録（黒塗り箇所摘出）設定反映メソッド</p>
     * 処理内容：教師データ登録（黒塗り箇所摘出）画面で追加・編集・削除した教師データをDBに更新する。
     * @param form 教師データ
     * @return レスポンス
     * @throws Exception 処理中に例外が発生した場合
     */
    @RequestMapping("/teacher_policy_reflect")
    @ResponseBody
    public ResponseEntity<String> teacherCategoryReflect (
            @RequestBody TmpTeacherPolicyListReqForm form) throws Exception {
        // 全件取得
        objLog.info("teacherCategoryReflect request start");

        if (Objects.isNull(form)) {
            objLog.trace("form:{}", form);
            objLog.info("request data not found");
            objLog.info("teacherCategoryReflect request end (error)");
            return new ResponseEntity<String>("request data not found",HttpStatus.BAD_REQUEST);
        }
        objLog.info("form : {} ", form);

        // システム日付を取得する
        Timestamp sysdate = Timestamp.valueOf(LocalDateTime.now());
        // 保存先
        String savePath = form.getSavePath();
        // 登録データ
        List<TmpTeacherPolicyList> teacherPolicyList = form.getTmpTeacherPolicyList();

        // 正解データコンバートAPI呼出し
        try {
        	String ret = correctDataConvert(teacherPolicyList, savePath);
        	if (ret.length() != 0) {
                objLog.error("teacherPolicyList:{}\r\n  savePath:{}", teacherPolicyList, savePath);
                objLog.error("error message", ret);
                return new ResponseEntity<String>(ret, HttpStatus.NOT_ACCEPTABLE);
        	}
        } catch (Exception e) {
            objLog.error("teacherPolicyList:{}\r\n  savePath:{}", teacherPolicyList, savePath);
            objLog.error("error message", e);
            e.printStackTrace();
            return new ResponseEntity<String>(e.getMessage(),HttpStatus.BAD_REQUEST);
        }

        try {
            // DB更新処理
            // ALL削除
            tmpTeacherPolicyService.deleteAll();
            // ALL登録
            for (TmpTeacherPolicyList list : teacherPolicyList) {
                list.setCreateTime(sysdate);
                list.setUpdateTime(sysdate);
                tmpTeacherPolicyService.insert(list);
            }
        } catch (Exception e) {
            objLog.error("teacherPolicyList:{}\r\n", teacherPolicyList);
            objLog.error("error message", e);
            e.printStackTrace();
            return new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
        objLog.info("TeacherCategoryReflect request end (success)");
        return new ResponseEntity<String>(HttpStatus.OK);
    }
    /**
     * <p>設定反映処理メソッド</p>
     * 処理内容：正解データコンバートAPIの呼び出しと処理を実施する。
     * @param teacherPolicyList 追加データ
     * @param savePath 保存先フォルダ
     * @return String 画面に出力するエラー文言（エラーがなければブランク）
     * @throws Exception 指定のフォルダが見つからなかった場合
     */
    private String correctDataConvert(List<TmpTeacherPolicyList> teacherPolicyList, String savePath) throws Exception {

    	boolean retErr = false;
        objLog.trace("teacherPolicyList:{} \r\nsavePath:{}", teacherPolicyList, savePath);

        File saveDrectory = new File(savePath);
        // 正解データコンバート保存先フォルダが存在しない場合
        if (!saveDrectory.exists()) {
            objLog.info("{} correct answer directoryPath path directory not found ", savePath);
            // エラー処理　例外をスローする
            throw new Exception(savePath + " correct answer directoryPath path directory not found ");
        }

        // 正解データコンバート用APIデータ（フォルダ）
        HashMap<Integer, String> input = new HashMap<Integer, String>();

        // 正解データコンバートへの引数作成
        String retErrString = PATH_NOTEXISTS_ERR;
        String wk = "";
        for (Integer i = 0; i < teacherPolicyList.size(); i++) {
            String directoryPath = teacherPolicyList.get(i).getDirectoryPath();
            File directory = new File(directoryPath);
            // 指定のフォルダが見つからなかった場合
            if (!directory.exists()) {
                objLog.info("{} file not found ", directoryPath);
            	retErrString += wk + (i + 1) + "行目";
                wk = "、";
                retErr = true;
            } else {
                // 正解データコンバート用データ保存
                input.put(teacherPolicyList.get(i).getPolicyId(), directoryPath);
            }
        }

        // 一覧に登録されたディレクトリパスが存在しなかった場合
        if (retErr) {
            return retErrString;
        }

        // 既存ファイルを削除する
        if (!deleteFolder(new File(savePath))) {
            objLog.info("file delete error", savePath);
            // エラー処理　例外をスローする
            throw new Exception(savePath + ":file delete error");
        }

        // 正解データコンバート呼出し
        train.makeBlackPrintTrainData(input, savePath);

        return "";
    }

	/**
	 * フォルダを削除する
	 * @param dir 処理起点となるフォルダのファイルオブジェクト
	 * @return boolean 削除結果
	 */
	private boolean deleteFolder(File dir) {

		boolean ret = true;

		// フォルダ存在確認
		if (dir.exists()) {
			// listFilesメソッドを使用して一覧を取得する
			File[] list = dir.listFiles();

			for (File objFile : list) {
				// ファイルの場合
				if(objFile.isFile()) {
					// ファイルを削除する
					ret = ret && objFile.delete();
				}
			}
		}
		return ret;
	}
}
