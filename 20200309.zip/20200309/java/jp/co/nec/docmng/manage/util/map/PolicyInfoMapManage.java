/**
 * 名称：PolicyInfoMapManage.java
 * 機能名：管理系ポリシー情報連携
 * 概要：管理系にて使用するポリシー情報への連携用レポジトリ
 */

package jp.co.nec.docmng.manage.util.map;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import jp.co.nec.docmng.manage.entity.PolicyInfoEntity;

/**
 * 管理系ポリシー情報連携
 */
@Mapper
public interface PolicyInfoMapManage {

	/**
	 * 全件取得(ポリシー種別が0のレコード)
	 * @return 検索結果
	 */
    @Select("select * from admin.policy_info where policy_type = 0 order by policy_number")
    public List<PolicyInfoEntity> findAll();

	/**
	 * データ登録
	 * @param policyInfoEntity 登録情報
	 */
    @Insert("insert into admin.policy_info (policy_number, policy_name, policy_author, policy_reason, create_time, update_time, policy_type) values (#{policyNumber}, #{policyName}, #{policyAuthor}, #{policyReason}, #{createTime}, #{updateTime}, #{policyType})")
    public void insert(PolicyInfoEntity policyInfoEntity);

	/**
	 * データ更新_ポリシー指定
	 * @param policyInfoEntity 更新情報
	 */
    @Update("update admin.policy_info set policy_number = coalesce(#{policyNumber}, policy_number), policy_name = coalesce(#{policyName}, policy_name), policy_reason = coalesce(#{policyReason}, policy_reason), update_time = coalesce(#{updateTime}, update_time) where policy_Id = #{policyId}")
    public void update(PolicyInfoEntity policyInfoEntity);

	/**
	 * データ削除_ポリシー指定
	 * @param id ポリシーID
	 */
    @Delete("delete from admin.policy_info where policy_id = #{policyId}")
    public void deleteById(Integer id);

}
