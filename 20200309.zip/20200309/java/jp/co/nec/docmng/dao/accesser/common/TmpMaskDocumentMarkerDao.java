package jp.co.nec.docmng.dao.accesser.common;

import java.io.Reader;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import jp.co.nec.docmng.dao.entity.common.TmpMaskDocumentMarker;
import jp.co.nec.docmng.dao.entity.common.TmpMaskDocumentMarkerExample;
import jp.co.nec.docmng.dao.mapper.common.TmpMaskDocumentMarkerMapper;

/**
 * TmpMaskDocumentMarkerDao
 * 黒塗り文書黒塗り箇所一時保存テーブルの全件を取得する。
 */
public class TmpMaskDocumentMarkerDao {
	
	/**
	 * 黒塗り文書黒塗り箇所一時保存テーブルの情報を表示する。
	 * @return List<TmpMaskDocumentMarker> tmpMaskDocumentMarkerList 黒塗り文書黒塗り箇所一時保存テーブルの情報リストを取得する。
	 */
	
	public List<TmpMaskDocumentMarker> getTmpMaskDocumentMarkerAll() {
		
	List<TmpMaskDocumentMarker> tmpMaskDocumentMarkerList = null;
	
	try (Reader readerConfig = Resources.getResourceAsReader("mybatis-config.xml");) {

		// 読み込んだ設定ファイルからSqlSessionFactoryを生成する
		SqlSessionFactory sqlFactory = new SqlSessionFactoryBuilder().build(readerConfig);

		// SQLセッションを取得する
		try (SqlSession sqlSession = sqlFactory.openSession()) {

			// 黒塗り文書黒塗り箇所一時保存テーブルのMapperを取得する
			TmpMaskDocumentMarkerMapper tmpMaskDocumentMarkerMapper = sqlSession.getMapper(TmpMaskDocumentMarkerMapper.class);

			// 黒塗り文書黒塗り箇所一時保存テーブルの条件検索用クラスを生成する
			TmpMaskDocumentMarkerExample tmpMaskDocumentMarkerExample = new TmpMaskDocumentMarkerExample();
			
			tmpMaskDocumentMarkerExample.setOrderByClause("marker_id");

			// 上記の条件でテーブルを検索する
			tmpMaskDocumentMarkerList = tmpMaskDocumentMarkerMapper.selectByExample(tmpMaskDocumentMarkerExample);
		}
	} catch (Exception e) {
		// テーブル情報を取得できない場合
		e.printStackTrace();
	}
	return tmpMaskDocumentMarkerList;
	}
}
