package jp.co.nec.docmng.dao.accesser.common;

import java.io.Reader;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import jp.co.nec.docmng.dao.entity.common.DirectoryInfoInternal;
import jp.co.nec.docmng.dao.entity.common.DirectoryInfoInternalExample;
import jp.co.nec.docmng.dao.mapper.common.DirectoryInfoInternalMapper;

/**
 * DirectoryInfoInternalDao
 * ディレクトリ情報テーブル(内部処理用)の全件を取得する。
 */
public class DirectoryInfoInternalDao {
	
	/**
	 * ディレクトリ情報テーブル(内部処理用)の情報を表示する。
	 * @return List&lt;DirectoryInfoInternal&gt; directoryInfoInternalList ディレクトリ情報テーブル(内部処理用)の情報リストを取得する。
	 */
	public List<DirectoryInfoInternal> getDirectoryInternalAll() {
		
	List<DirectoryInfoInternal> directoryInfoInternalList = null;
	
	try (Reader readerConfig = Resources.getResourceAsReader("mybatis-config.xml");) {

		// 読み込んだ設定ファイルからSqlSessionFactoryを生成する
		SqlSessionFactory sqlFactory = new SqlSessionFactoryBuilder().build(readerConfig);

		// SQLセッションを取得する
		try (SqlSession sqlSession = sqlFactory.openSession()) {

			// ディレクトリ情報テーブル(内部処理用)のMapperを取得する
			DirectoryInfoInternalMapper directoryInfoInternalMapper = sqlSession.getMapper(DirectoryInfoInternalMapper.class);

			// ディレクトリ情報テーブル(内部処理用)の条件検索用クラスを生成する
			DirectoryInfoInternalExample directoryInfoExample = new DirectoryInfoInternalExample();
			
			directoryInfoExample.setOrderByClause("directory_id");

			// 上記の条件でテーブルを検索する
			directoryInfoInternalList = directoryInfoInternalMapper.selectByExample(directoryInfoExample);
		}
	} catch (Exception e) {
		// テーブル情報を取得できない場合
		e.printStackTrace();
	}
	return directoryInfoInternalList;
	}
}
