package jp.co.nec.docmng.dao.accesser.admin;

import java.io.Reader;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import jp.co.nec.docmng.dao.entity.admin.PolicyInfo;
import jp.co.nec.docmng.dao.entity.admin.PolicyInfoExample;
import jp.co.nec.docmng.dao.mapper.admin.PolicyInfoMapper;

/**
 * PolicyInfoDao
 * 黒塗りポリシー情報テーブルの全件を取得する。
 */
public class PolicyInfoDao {

	/**
	 * 黒塗りポリシー情報テーブルの情報を表示する。
	 * @return List&lt;PolicyInfo&gt; policeInfoList 黒塗りポリシー情報テーブルの情報リストを取得する。
	 */
	public List<PolicyInfo> getPolicyAll() {
		
		List<PolicyInfo> policeInfoList = null ;
		
		try (Reader readerConfig = Resources.getResourceAsReader("mybatis-config.xml");) {

			// 読み込んだ設定ファイルからSqlSessionFactoryを生成する
			SqlSessionFactory sqlFactory = new SqlSessionFactoryBuilder().build(readerConfig);

			// SQLセッションを取得する
			try (SqlSession sqlSession = sqlFactory.openSession()) {

				// ポリシーテーブルのMapperを取得する
				PolicyInfoMapper policeInfoMapper = sqlSession.getMapper(PolicyInfoMapper.class);

				// ポリシーテーブルの条件検索用クラスを生成する
				PolicyInfoExample policeInfoExample = new PolicyInfoExample();
				
				policeInfoExample.setOrderByClause("policy_id");

				// 上記の条件でテーブルを検索する
				policeInfoList = policeInfoMapper.selectByExample(policeInfoExample);

			}
		} 
		catch (Exception e) {
			// テーブル情報を取得できない場合
			e.printStackTrace();
		}
		return policeInfoList;
	} 
}
