package jp.co.nec.docmng.dao.accesser.admin;

import java.io.Reader;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import jp.co.nec.docmng.dao.entity.admin.TmpTeacherCategoryList;
import jp.co.nec.docmng.dao.entity.admin.TmpTeacherCategoryListExample;
import jp.co.nec.docmng.dao.mapper.admin.TmpTeacherCategoryListMapper;

/**
 * TmpTeacherCategoryListDao
 * 教師データ(分類)登録画面一時保存テーブルの全件を取得する。
 */
public class TmpTeacherCategoryListDao {

	/**
	 * 教師データ(分類)登録画面一時保存テーブルの情報を表示する。
	 * @return List&lt;TmpTeacherCategoryList&gt; tmpTeacherCategoryList 教師データ(分類)登録画面一時保存テーブルの情報リストを取得する。
	 */
	public List<TmpTeacherCategoryList> getTmpTeacherCategoryAll() {
		
		List<TmpTeacherCategoryList> tmpTeacherCategoryList = null ;
		
		try (Reader readerConfig = Resources.getResourceAsReader("mybatis-config.xml");) {

			// 読み込んだ設定ファイルからSqlSessionFactoryを生成する
			SqlSessionFactory sqlFactory = new SqlSessionFactoryBuilder().build(readerConfig);

			// SQLセッションを取得する
			try (SqlSession sqlSession = sqlFactory.openSession()) {

				// 教師データ(分類)登録画面一時保存テーブルのMapperを取得する
				TmpTeacherCategoryListMapper tmpTeacherCategoryListMapper = sqlSession.getMapper(TmpTeacherCategoryListMapper.class);

				// 教師データ(分類)登録画面一時保存テーブルの条件検索用クラスを生成する
				TmpTeacherCategoryListExample tmpTeacherCategoryListExample = new TmpTeacherCategoryListExample();

				tmpTeacherCategoryListExample.setOrderByClause("user_id");

				// 上記の条件でテーブルを検索する
				tmpTeacherCategoryList = tmpTeacherCategoryListMapper.selectByExample(tmpTeacherCategoryListExample);

			}
		}
		catch (Exception e) {
			// テーブル情報を取得できない場合
			e.printStackTrace();
		}
		return tmpTeacherCategoryList;
	} 

} 
