import smtplib
from email.mime.text import MIMEText
from email.utils import formatdate

def createMailMsg(from_addr, to_addr, bcc_addrs, subject, body):
    msg = MIMEText(body)
    msg['Subject'] = subject
    msg['From'] = from_addr
    msg['To'] = to_addr
    msg['Bcc'] = bcc_addrs
    msg['Date'] = formatdate()
    return msg


def sendMailFromGmail(from_addr, to_addrs, msg,strPass_i):
    smtpobj = smtplib.SMTP('smtp.gmail.com', 587)
    smtpobj.ehlo()
    smtpobj.starttls()
    smtpobj.ehlo()
    smtpobj.login(from_addr, strPass_i)
    smtpobj.sendmail(from_addr, to_addrs, msg.as_string())
    smtpobj.close()

