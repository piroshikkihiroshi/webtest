# coding: UTF-8
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from time import sleep
from datetime import datetime
import configparser
import distutils.util
# import ctypes #debug msgbox用 ctypes.windll.user32.MessageBoxW(0, "Your text", "Your title", 1)
#※※※※注意 基本クロームは最新版！！！

#独自定義
from mailFunc import *

# Chrome Driver https://sites.google.com/a/chromium.org/chromedriver/downloads

#iniFile読み込み＋初期設定
INI_FILE = 'setting.ini'
objConf = configparser.SafeConfigParser()
objConf.read(INI_FILE)

strGsUrl = objConf.get('url', 'gsurl')
strGsBbsUrl = strGsUrl + '?url=../bulletin/bbs010.do'
strGsThreadUrl = strGsUrl + '?url=%2Fgsession%2Fbulletin%2Fbbs060.do%3Fbbs010forumSid%3D'
strGsThreadMakeUrl = ''

#main option
strId= objConf.get('main', 'gsid')
strPass= objConf.get('main', 'gspass')
blDebug = bool(distutils.util.strtobool(objConf.get('main', 'degug')))
blReadOut = bool(distutils.util.strtobool(objConf.get('main', 'readOut')))

#mail option
strFrommAddr = objConf.get('mail', 'gmail')
strMailPass = objConf.get('mail', 'gmailpass')
strToAddr = objConf.get('mail', 'toaddr')

#その他オプション
intWaitSec = 10
blInit=True #初期処理Flag

intBbsCount=0 #掲示板のスレッド数
intBbsNoRead=0 #掲示板の未読数

strHtmlBody=''
strForumSid = ''
strThreadSid = ''

intBbsInitPage = 0 #掲示板のpage数
intBbsMaxPage = 0 #掲示板の最大page数
listBbsHref = list() #リスト要素格納用

strStTime='開始時刻：'+datetime.now().strftime("%Y/%m/%d %H:%M:%S")
strEdTime=''
strToday=datetime.now().strftime("%Y/%m/%d")

strBbc = ''
strSubject = '【GS掲示板】'
strBody = ''
strErrMsg=''

# 掲示板一覧取得用JavaScript
strBbsHrefScript = '''
var objHref= document.evaluate('//*[@class="forum_li_title"]/a', document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
var strHref='';
for(var i=0;i<objHref.snapshotLength;i++){
	strHref+=objHref.snapshotItem(i).href + ',';
}
if(strHref.length > 0){
	strHref=strHref.slice(0,-1)
}
return strHref;
'''

# Page取得用JavaScript(実行時にreturnは返す)
strPageScript = '''
var strPage = document.getElementsByName('bbs010page2')[0].childNodes[0].innerText;
var arrPages = strPage.replace(/ /g,'').split('/');
var strActivePage = arrPages[0];
var strMaxPage = arrPages[1];
'''

# 掲示板URLNo取得用JavaScript
strUrlNoScript = '''
var objHref= document.evaluate('//*[@class="menu_bun"]/a', document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
var strRet='';
for(var i=0;i<objHref.snapshotLength;i++){
//	console.log(objHref.snapshotItem(i).href)
	var strTmp=objHref.snapshotItem(i).href.replace('javascript:getList(','').replace(');','').split(',')[1]
	var objTmp=objHref.snapshotItem(i);
	var objClass=objTmp.getElementsByClassName('text_title_midoku');
	if(objClass.length==0){
		objClass=objTmp.getElementsByClassName('text_title_kidoku');
	}
	var strClass=objClass[0].getAttribute('class');
	var strText=objClass[0].innerText;
	strRet+=strTmp + '|' + strClass + '|' + strText + ',,';
}
if(strRet.length > 0){
	strRet=strRet.slice(0,-2)
}
return strRet;
'''

#掲示板のTitle
strBbsTitleScript = '''
var strBbsTitle=document.getElementsByClassName('text_bbs2')[0].innerText;
return strBbsTitle;
'''

# 各掲示板のPage取得用JavaScript(実行時にreturnは返す)
strEachPageScript = '''
var objChkDom=document.getElementsByName('bbs060page1')[1];
var strActivePage = '1';
var strMaxPage = '1';
if( typeof objChkDom!= 'undefined'){
	var strPage = document.getElementsByName('bbs060page1')[1].childNodes[0].innerText;
	var arrPages = strPage.replace(/ /g,'').split('/');
	var strActivePage = arrPages[0];
	var strMaxPage = arrPages[1];
}
'''

# ブラウザのオプションを格納する変数。
options = Options()
if blDebug == False:
    options.add_argument('--headless') #Headlessモードを有効にする

try:
    # ブラウザを起動する
    objWebDriver = webdriver.Chrome(executable_path='chromedriver.exe',chrome_options=options)    
    # objWebDriver = webdriver.Chrome(executable_path='C:\chorome_driver\chromedriver.exe',chrome_options=options)
    objWebDriver.implicitly_wait(intWaitSec) # 要素が見つかるまで10秒待つ設定(seconds)
    objWebDriver.get(strGsUrl) # ブラウザでアクセスする    
    #login
    objId=objWebDriver.find_element_by_name('cmn001Userid')
    objId.send_keys(strId)
    objPass=objWebDriver.find_element_by_name('cmn001Passwd')
    objPass.send_keys(strPass)
    objLoginBtn=objWebDriver.find_element_by_class_name('login_btn')
    objLoginBtn.click()

    #Acceess BBS
    objWebDriver.get(strGsBbsUrl)
    # 最初にPageを取得
    objWebDriver.switch_to.frame("body") # bodyフレームを選択 #参考 objWebDriver.switch_to.window objWebDriver.window_handle # 親フレーム（ウインドウ）に戻っておく
    intBbsInitPage=int(objWebDriver.execute_script(strPageScript + ' return strActivePage;'))
    intBbsMaxPage=int(objWebDriver.execute_script(strPageScript + ' return strMaxPage;'))

    #各掲示板移動用JavaScript取得
    for i in range(intBbsInitPage, intBbsMaxPage + 1):
        strGetHref=objWebDriver.execute_script(strBbsHrefScript) #各掲示板アクセスJavaScriptを取得
        arrGetHref=strGetHref.split(",")
        for objItem in arrGetHref:
            listBbsHref.append(objItem)
        objWebDriver.execute_script('buttonPush("nextPage");')

    #掲示板毎に処理
    for objItem in listBbsHref:
        objWebDriver.get(strGsBbsUrl)
        objWebDriver.switch_to.frame("body")
        objWebDriver.execute_script(objItem) #対象掲示板へ移動
        sleep(1) #サーバの処理が追いつかない場合の対策

        strForumSid=str(objItem).replace('javascript:clickForum(','').replace(');','')  #URLを作成する為にForumSidを作成
        intBbsInitPage=int(objWebDriver.execute_script(strEachPageScript + ' return strActivePage;'))
        intBbsMaxPage=int(objWebDriver.execute_script(strEachPageScript + ' return strMaxPage;'))

        #各掲示板のすべてのページを処理
        for i in range(intBbsInitPage, intBbsMaxPage + 1):
            strGetHref=objWebDriver.execute_script(strUrlNoScript) #掲示板URLNo取得用JavaScript
            if blInit:
                strBbsTitle=objWebDriver.execute_script(strBbsTitleScript)
                strHtmlBody+= '\r\n' + '【' + strBbsTitle + '】' + '\r\n'
                blInit=False

            arrGetHref=strGetHref.split(",,") #カンマが使われている場合に備え二つでスプリット        
            for objItem in arrGetHref:
                arrSplit=objItem.split("|")
                strThreadSid = str(arrSplit[0])
                strClass = str(arrSplit[1])
                strTitle = str(arrSplit[2])
                strGsThreadMakeUrl = strGsThreadUrl + strForumSid + '%26threadSid%3D' + strThreadSid
                # print(strGsThreadMakeUrl)
                if strClass == 'text_title_midoku': #未読なら必ず出力
                    strHtmlBody+= '[' + strTitle + ']'
                    # strHtmlBody+= '[' + strTitle + ']' + '\r\n'                
                    strHtmlBody+= '・・・未読' + '\r\n'
                    strHtmlBody+= strGsThreadMakeUrl + '\r\n'
                    intBbsNoRead+=1
                elif strClass == 'text_title_kidoku' and blReadOut: #既読ならblReadOut=Trueで出力
                    # strHtmlBody+= '[' + strTitle + ']' + '\r\n'
                    strHtmlBody+= '[' + strTitle + ']'
                    strHtmlBody+= '既読・・・' + '\r\n'
                    strHtmlBody+= strGsThreadMakeUrl + '\r\n'
                intBbsCount+=1
            objWebDriver.execute_script("changePageSingly('next');")
            sleep(2) #サーバの処理が追いつかない場合の対策            
        blInit=True
except:
    strBody+= '\r\n'+'予期せぬエラーが発生しました。正確に掲示板情報を取得できていません。'+'\r\n'
    strSubject+='※エラー発生'
finally:
    # release
    objWebDriver.close()
    objWebDriver.quit()
    strEdTime='終了時刻：' + datetime.now().strftime("%Y/%m/%d %H:%M:%S")
    #send mail

    strSubject+=' ' + strToday + ' '
    if intBbsNoRead==0:
        strSubject+='未読なし'
    else:
        strSubject+='未読あり'    
    strBody+=strStTime + '\r\n' + strEdTime + '\r\n'
    if blReadOut:
        strBody+='既読・未読ともに出力します。' + '\r\n'
    else:
        strBody+='未読のみ出力します。' + '\r\n'
    strBody+='未読/スレッド数・・・' + str(intBbsNoRead) + '/' + str(intBbsCount) + '\r\n'
    strBody+=strHtmlBody
    arrToAddr=strToAddr.split(',')

    for objItem in arrToAddr:
        strSendMsg = createMailMsg(strFrommAddr, objItem, strBbc, strSubject, strBody)
        sendMailFromGmail(strFrommAddr, objItem, strSendMsg,strMailPass)





