# coding: UTF-8
import logging
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from time import sleep
from datetime import datetime
from selenium.webdriver.common.alert import Alert
import configparser
import distutils.util
import subprocess
import os
import sys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
# import ctypes #debug msgbox用 ctypes.windll.user32.MessageBoxW(0, "Your text", "Your title", 1)
#※※※※注意 基本クロームは最新版！！！

#スクリーンショット用関数
def screenShotFull(driver, filename):
    '''フルページ スクリーンショット'''
    # url取得
    url = driver.current_url
    # ページサイズ取得
    w = driver.execute_script("return document.body.scrollWidth;")
    h = driver.execute_script("return document.body.scrollHeight;")
    # set window size
    driver.set_window_size(w,h)

    # Get Screen Shot
    driver.save_screenshot(filename)

#画面遷移確認用関数
def screenMoveRet(driver):
    strTitle=driver.execute_script("var strTitle = document.getElementsByTagName('title')[0].innerText; return strTitle;")
    if strTitle=='サーバエラー':
        return False
    else:
        return True

#ドライバ終了関数
def driverClose(objWebDriver):
    objWebDriver.close()
    objWebDriver.quit()

# Chrome Driver https://sites.google.com/a/chromium.org/chromedriver/downloads

strUrl = 'http://localhost:8080/MaskHtmlCnt?documentId='
listDoc = ['4'] #テストしたいdocument_idを格納


# ログの出力名を設定
logger = logging.getLogger('Logging')
# ログレベルの設定
logger.setLevel(10)
# ログのコンソール出力の設定
sh = logging.StreamHandler()
logger.addHandler(sh)
 
# ログのファイル出力先を設定
fh = logging.FileHandler('Debug.log')
logger.addHandler(fh)
 
# ログの出力形式の設定
formatter = logging.Formatter('%(asctime)s:%(lineno)d:%(levelname)s:%(message)s')
fh.setFormatter(formatter)
sh.setFormatter(formatter)
 

#main option
blDebug = True


#その他オプション
intWaitSec = 10
blInit=True #初期処理Flag

basePath = os.path.join(os.path.dirname(os.path.abspath(__file__))+'/')

strStTime='start：'+datetime.now().strftime("%Y/%m/%d %H:%M:%S")
isRet=False

# ブラウザのオプションを格納する変数。
options = Options()
if blDebug == False:
    options.add_argument('--headless') #Headlessモードを有効にする
for tgtDoc in listDoc:
    strDocUrl = strUrl + tgtDoc
    try:
        logger.info(strStTime)

        # SC格納用Directory
        strRetDir='result/'+tgtDoc+'/'
        os.makedirs(strRetDir,exist_ok=True)

        # ブラウザを起動する
        objWebDriver = webdriver.Chrome(executable_path='chromedriver.exe',chrome_options=options)    
        objWebDriver.implicitly_wait(300) #ページ読み込み最大時間指定 PDF作成があるので余裕を持つ

        #Access
        objWebDriver.get(strDocUrl)
        screenShotFull(objWebDriver,strRetDir+'01_Access.png')
        #結果確認
        isRet=screenMoveRet(objWebDriver)
        if not isRet:
            logger.exception('Fail')
            driverClose(objWebDriver)
            continue
        logger.info('Access Success')

        # 黒塗りリスト
        objBtn=objWebDriver.find_element_by_id('KURONURI_LIST')
        objBtn.click()
        Alert(objWebDriver).accept()
        screenShotFull(objWebDriver,strRetDir+'02_list.png')
        #結果確認
        isRet=screenMoveRet(objWebDriver)
        if not isRet:
            logger.exception('Fail')
            driverClose(objWebDriver)
            continue
        logger.info('List Access Success')

        #確定ボタン
        objWebDriver.execute_script('confirmList();')
        Alert(objWebDriver).accept()
        screenShotFull(objWebDriver,strRetDir+'03_list_return.png')
        #結果確認
        isRet=screenMoveRet(objWebDriver)
        if not isRet:
            logger.exception('Fail')
            driverClose(objWebDriver)
            continue
        logger.info('List Return Success')

        #ブラウザを閉じて再開
        driverClose(objWebDriver)
        objWebDriver = webdriver.Chrome(executable_path='chromedriver.exe',chrome_options=options)    
        objWebDriver.implicitly_wait(300) #ページ読み込み最大時間指定 PDF作成があるので余裕を持つ
        objWebDriver.get(strDocUrl)

        sleep(2)
        objBtn=objWebDriver.find_element_by_id('SAIKAI')
        objBtn.click()
        Alert(objWebDriver).accept()
        sleep(2)
        Alert(objWebDriver).accept()
        sleep(2)
        screenShotFull(objWebDriver,strRetDir+'04_restart.png')
        #結果確認
        isRet=screenMoveRet(objWebDriver)
        if not isRet:
            logger.exception('Fail')
            driverClose(objWebDriver)
            continue
        logger.info('restart Success')

        #保存プレビュー画面
        objWebDriver.execute_script('saveMaskProvMask();')
        Alert(objWebDriver).accept()
        
        WebDriverWait(objWebDriver, 15).until(EC.presence_of_all_elements_located) # ページ上のすべての要素が読み込まれるまで待機 
        screenShotFull(objWebDriver,strRetDir+'05_save_prev.png')        
        #結果確認
        isRet=screenMoveRet(objWebDriver)
        if not isRet:
            logger.exception('Fail')
            driverClose(objWebDriver)
            continue
        logger.info('save_prev Success')

        #保存
        objWebDriver.execute_script('saveDoc();')
        #プレビューがうまく取れないのでalertあとにもう一度撮る
        # screenShotFull(objWebDriver,strRetDir+'05_2_save_prev_2.png')
        Alert(objWebDriver).accept()
        
        screenShotFull(objWebDriver,strRetDir+'06_save.png')        
        #結果確認
        isRet=screenMoveRet(objWebDriver)
        if not isRet:
            logger.exception('Fail')
            driverClose(objWebDriver)
            continue
        logger.info('save Success')        

        # release
        driverClose(objWebDriver)

    except:
        import traceback
        logger.error(traceback.print_exc())
    finally:
        strEdTime=tgtDoc+ 'end ：' + datetime.now().strftime("%Y/%m/%d %H:%M:%S")
        logger.info(strEdTime);

strEdTime='all end：' + datetime.now().strftime("%Y/%m/%d %H:%M:%S")
logger.info(strEdTime);







