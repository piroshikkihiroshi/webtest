package _postTest._postTest;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;

public class PostTest {
	private static final String EOL = "\r\n";

	//    public int getProCenterMultipart(String filename, String strUrl_i) throws IOException {
	public int getProCenterMultipart(List<String> listFilePath, String strUrl_i) throws IOException {

		String method = "POST";
		String strBoundary = "---------------------------7dd24e3050716";
		String strEncJson  = "";
		//connection open
		HttpURLConnection objCon = (HttpURLConnection) new URL(strUrl_i).openConnection();

		//header
		objCon.setDoOutput(true);
		objCon.setRequestMethod(method);
		objCon.setUseCaches(false);
		objCon.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + strBoundary);
		OutputStream objOS = objCon.getOutputStream();

		for (int i = 0; i <= listFilePath.size(); i++) {
			if(i==0) { //jsonの作成
				//セッションと結合
				String strJson = "";
				strJson+="\"files\": [";
				for (int j = 0; j < listFilePath.size(); j++) {
					strJson+="\"file_"+(j+1)+"\",";
				} //for
				strJson = strJson.substring(0,strJson.length()-1);
				strJson +="]";

				//※※※※※※session infoと結合

				strEncJson=URLEncoder.encode(strJson, "UTF-8");

				objOS.write(("--" + strBoundary + EOL +
						"Content-Disposition: form-data; name=\"query\"; " +
//						strEncJson + EOL).getBytes(StandardCharsets.UTF_8)) ;
						strEncJson + EOL +
						"Content-Type: application/octet-stream" + EOL + EOL)
								.getBytes(StandardCharsets.UTF_8));
//				byte[] arrBuffer = new byte[128];
//				int intSize = -1;
//				while (-1 != (intSize = objFile.read(arrBuffer))) {
//					objOS.write(arrBuffer, 0, intSize);
//				}
			}else { //実ファイル送付
				String filename = listFilePath.get(i - 1);
				FileInputStream objFile = new FileInputStream(filename);
				objOS.write(("--" + strBoundary + EOL +
						"Content-Disposition: form-data; name=\"file_"+(i)+"\"; " +
						"filename=\"" + filename + "\"" + EOL +
						"Content-Type: application/octet-stream" + EOL + EOL)
								.getBytes(StandardCharsets.UTF_8));
				byte[] arrBuffer = new byte[128];
				int intSize = -1;
				while (-1 != (intSize = objFile.read(arrBuffer))) {
					objOS.write(arrBuffer, 0, intSize);
				}
				objFile.close();

			} //if


		} //for
		objOS.write((EOL + "--" + strBoundary + "--" + EOL).getBytes(StandardCharsets.UTF_8));
		objOS.flush();

		int intRet = 0;

		try {
			intRet = objCon.getResponseCode();
		} catch (Exception e) {
			System.err.println(e);
		} finally {
			//keep-aliveなので切断なし
//			objCon.disconnect();
		} //try

		return intRet;

	} //method
} //class
