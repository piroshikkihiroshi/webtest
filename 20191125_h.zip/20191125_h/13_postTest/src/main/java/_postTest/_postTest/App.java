package _postTest._postTest;

import java.util.ArrayList;
import java.util.List;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		PostTest posttest = new PostTest();

		//設定ファイル取得
//		ResourceBundle objRb = ResourceBundle.getBundle("config/procenter");
//		String strBaseUrl = objRb.getString("procenter_url");
//		String strProcenterUserId = objRb.getString("procenter_user_id");
//		String strProcenterPassword = objRb.getString("procenter_user_password");
		String strJson = "";
		String strSessionInfoJson="";


		String filename = "C:\\temp\\pdftest\\mask";

		List<String> listFile = new ArrayList<String>();
		for (int i = 1; i <= 3; i++) {
			listFile.add(filename + "_" + i + ".pdf");
		} //for


		String strUrl = "http://localhost/test/parsejson.php?XDEBUG_SESSION_START=xdebug;";
		try {
			posttest.getProCenterMultipart(listFile,strUrl);
		} catch (Exception e) {
			System.err.println();
		}

	} //method
} //class
