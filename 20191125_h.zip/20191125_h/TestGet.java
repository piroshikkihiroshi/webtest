package jp.co.nec.docmng.blackPaint.util.api;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import jp.co.nec.docmng.library.asposeToHtml.service.WordToHtml;



@RestController
public class TestGet {


	@GetMapping("/rest/aaaa")
	public String fwordTest()
		{
		WordToHtml wordToHtml = new WordToHtml();
		String strDir = "C:\\Users\\ueda tatsuya\\Desktop\\20191028_h\\";
		String strOrgFileName = "SpringBoot習得手順書.docx";
		String strHtmlDirPath = "C:\\Users\\ueda tatsuya\\Desktop\\20191028_h\\test\\";
		try {
			wordToHtml.wordToHtml(strDir, strOrgFileName, strHtmlDirPath);
		} catch (Exception e) {
			System.err.println(e);
		}


		String strRet = "end";

		return strRet;
	} //getPlicyAll

} //PolicyGet
