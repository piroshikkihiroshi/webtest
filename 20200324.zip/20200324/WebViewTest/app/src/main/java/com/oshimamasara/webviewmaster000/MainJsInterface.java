package com.oshimamasara.webviewmaster000;

//javaScript から呼び出す処理の記述

import android.app.Activity;
import android.os.Build;
import android.webkit.JavascriptInterface;

import androidx.annotation.RequiresApi;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.List;

//いらなそう
public class MainJsInterface {
    Activity activity;
    // 引数から activity への参照を得ていた方が都合が良い？
    MainJsInterface(Activity a){
        activity = a;
    } //コンストラクタ

    /**
     * 引数に取得しておいたデータをPOSTする
     *
     */
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @JavascriptInterface
    public void potUrlEncode(String strUrl_i) throws Exception {
        String strRet = "";
        String method = "POST";
        String strEncJson  = "";
        int intRet=0;
        //connection open
        HttpURLConnection objCon = (HttpURLConnection) new URL(strUrl_i).openConnection();
        objCon.setRequestMethod(method);
        objCon.setInstanceFollowRedirects(false);

        //header
        objCon.setDoOutput(true);
        objCon.setRequestMethod(method);
        objCon.setUseCaches(false);
        objCon.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        // 時間制限
        objCon.setReadTimeout(10000);
        objCon.setConnectTimeout(20000);
        objCon.connect();

        //body
        OutputStream objOS = null;
        String strSendStr = ((MainActivity) activity).getResults[0].toString();
        try {
            objOS = objCon.getOutputStream();
            objOS.write(strSendStr.getBytes(StandardCharsets.UTF_8));
        } finally {
            if (objOS!=null) objOS.close();
        } //try

        objOS.flush();
        InputStream obIin = null;
        StringBuilder textBuilder=null;
        try {
            //結果取得
            intRet = objCon.getResponseCode();
            obIin = objCon.getInputStream();
            textBuilder = new StringBuilder();
            try (Reader reader = new BufferedReader(new InputStreamReader
                    (obIin, Charset.forName(StandardCharsets.UTF_8.name())))) {
                int intc = 0;
                while ((intc = reader.read()) != -1) {
                    textBuilder.append((char) intc);
                } //while
            } //try
            strRet = textBuilder.toString();
        } catch (Exception e) {
            System.err.println(e);
        } finally {
			objCon.disconnect();
        } //try


    } //method

} //class
