package com.oshimamasara.webviewmaster000;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.*;

import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.io.Writer;
import com.oshimamasara.webviewmaster000.MainJsInterface;

public class MainActivity extends AppCompatActivity {

    WebView myWebView;

    private static final String TAG = MainActivity.class.getSimpleName();
    private static final String HTML_FILE_NAME = "sample.html";
    private static final String UTF8 = "UTF-8";
    private static final String TYPE_IMAGE = "image/*";
    private static final int INPUT_FILE_REQUEST_CODE = 1;
    private static final int REQUEST_CODE_FROM_JS = 2;

    private WebView mWebView;
    private ValueCallback<Uri> mUploadMessage;
    private ValueCallback<Uri[]> mFilePathCallback;

    //Upload Data
    Uri[] getResults = null;
    Uri getResult = null;

    //Activityが初めて生成され、Activityの初期化は全てここに書く。つまり全て初期化される。
    @SuppressLint("JavascriptInterface")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myWebView = (WebView) findViewById(R.id.webview);

        myWebView.getSettings().setJavaScriptEnabled(true);
        myWebView.getSettings().setDomStorageEnabled(true);

        myWebView.loadUrl("file:///android_asset/view/index.html");

        myWebView.setWebViewClient(new MyWebViewClient());
        //alert confirm 表示用
//        myWebView.setWebChromeClient(new WebChromeClient());
        //ファイルDialog実装
        myWebView.setWebChromeClient(MyWebChromeClient());

        //ここで指定した名前でJavaScriptから呼び出す事が出来る
        myWebView.addJavascriptInterface(new MainJsInterface(this), "Android");

    } //onCreate


    //※※※※※以下移動したい※※※※※

    //アプリ内でブラウザオープン　特定ドメイン以外はブラウザ起動
    // text https://developer.android.com/guide/webapps/webview#HandlingNavigation
    private class MyWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return false;
        }
    } //method

    //戻るボタン
    @Override
    public void onBackPressed() {
        if(myWebView!= null && myWebView.canGoBack())
            myWebView.goBack();// if there is previous page open it
        else
            super.onBackPressed();//if there is no previous page, close app
    } //method

    //ファイルDialog (open)
    private WebChromeClient MyWebChromeClient() {
        return new WebChromeClient() {
            // For Android < 3.0
            public void openFileChooser(ValueCallback<Uri> uploadFile) {
                openFileChooser(uploadFile, "");
            }

            // For 3.0 <= Android < 4.1
            public void openFileChooser(ValueCallback<Uri> uploadFile, String acceptType) {
                openFileChooser(uploadFile, acceptType, "");
            }

            // For 4.1 <= Android < 5.0
            public void openFileChooser(ValueCallback<Uri> uploadFile, String acceptType, String capture) {
                if(mUploadMessage != null){
                    mUploadMessage.onReceiveValue(null);
                }
                mUploadMessage = uploadFile;

                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(TYPE_IMAGE);

                startActivityForResult(intent, INPUT_FILE_REQUEST_CODE);
            }

            // For Android 5.0+
            @Override public boolean onShowFileChooser(WebView webView,
                                                       ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                // Double check that we don't have any existing callbacks
                if (mFilePathCallback != null) {
                    mFilePathCallback.onReceiveValue(null);
                }
                mFilePathCallback = filePathCallback;

                // Set up the intent to get an existing image
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(TYPE_IMAGE);
                startActivityForResult(intent, INPUT_FILE_REQUEST_CODE);

                return true;
            }
        };
    } //method

    //ファイルDialog (close)※ このときに実データ取得してしまうっぽい
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode != INPUT_FILE_REQUEST_CODE) {
            super.onActivityResult(requestCode, resultCode, data);
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (mFilePathCallback == null) {
                super.onActivityResult(requestCode, resultCode, data);
                return;
            }
            Uri[] results = null;

            // Check that the response is a good one
            if (resultCode == RESULT_OK) {
                String dataString = data.getDataString();
                if (dataString != null) {
                    results = new Uri[] { Uri.parse(dataString) };
                    //グローバルに保持
                    this.getResults = results;
                } //if
            } //if

            mFilePathCallback.onReceiveValue(results);
            mFilePathCallback = null;
        } else {
            if (mUploadMessage == null) {
                super.onActivityResult(requestCode, resultCode, data);
                return;
            }

            Uri result = null;

            if (resultCode == RESULT_OK) {
                if (data != null) {
                    result = data.getData();
                    //グローバルに保持
                    this.getResult = getResult;
                } //if
            } //if

            mUploadMessage.onReceiveValue(result);
            mUploadMessage = null;
        }
    } //method



} //class
