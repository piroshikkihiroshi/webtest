/**
**word→html変換したhtml(子フレーム)にJqueryは入っていないので、Jqueryを子フレームで使用したい場合
* $[tgt].contents().find()で探し当てて使用する
* ただ上記は直感的でないため、可能な限り生のjavascriptで記述する
*/

//定数等
const MSG_EDIT = "「編集」ボタンをクリックしてから編集を行ってください。";
const OFFCET_X = 10;
const OFFCET_Y_NOMAL = -90;
const OFFCET_Y_BOTTOM = -180;
const TAG_RED = "tagRed";
const TAG_MASK = "tagMsk";

const STATE_MASK = 1;
const STATE_RED = 2;
const MASK_MSG = "■";
const MASK_BF = "<span class='tagMsk' id='msk";
const MASK_BF_INIT = "<span class='tagMsk tagMskInit' id='msk";
const MASK_BF_END = "<span class='tagMsk tagMskEnd' id='msk";
const RED_BF = "<span class='tagRed' id='red";
const RED_BF_INIT = "<span class='tagRed tagRedInit' id='red";
const RED_BF_END = "<span class='tagRed tagRedEnd' id='red";
const MASK_END_CLS = "tagMskEnd";
const RED_END_CLS = "tagRedEnd";
const MASK_AF = "</span>";
const RED_AF = "</span>";
const MASK_INIT_CLS = "tagMskInit";
const RED_INIT_CLS = "tagRedInit";

const NODE_CROSS = 1;
const SPACE_MARK = '&nbsp;';
const REG_TAG_VAL_SPLIT = "(<\\/?[^>]+>)|([^<]+)";
const RED_ID_RED = 'red[0-9]{7}';
// const ORG_GET = '(?<=<span class="tagRed" id="red[0-9]{7}">).(?=</span>)'; //肯定的先読み+肯定的後読み
const RED_ORG_GET = '<span class="tagRed" id="red[0-9]{7}">(.)</span>';
const NOMAL_MENU = 1;
const MASK_MENU = 2;
const SVG_MENU = 3;

const ID_OFFSET = 4;
const ELEMENT_NODE_TYPE = 1;
const TEXT_NODE_TYPE = 3;
const RIGHT_TYPE = 2;
// const EDIT_ABLE="btn-success";
const EDIT_ABLE = "on";
const BTN_DISABLE = 'bottonDisable';
const ACT_POLICY = 'actPolicy';
const ID_COUNT = 1000000;
const CHART_POLICY = "図・表"; //図表専用ポリシー
const RED_IMG = 'redimg';

/**
 グローバル変数
*/
var glObjRedFlame = null;
var glObjRedBody = null;
var glObjMaskFlame = null;
var glObjMaskBody = null;
var glContextDom = null;
var glActContext = null;
//暫定で1200000余裕があればAIのマスク連番(サーバサイド処理)と合わせる
var glIdCnt = ID_COUNT + 200000;
var glActBfId = "";
var glActAfId = "";
var glActPolicy = 0;
var glObjRange = null;
var glSelectIinitId = null;
var glSelectEndId = null;
var glarrRepOrgOuter = [];
var glarrMaskOrgOuter = [];
// var glarrMaskOuter=[];
var glNewRangeFlg = false;
var glchngeRangeOrg = "";
var glChngeRangeInitPos = 0;
var glChngeRangeEndPos = 0;
var glTmpFileFlg = false; //tmpfileがあるか判定する //true 存在 false なし

//範囲変更前にinnerHTMLを保持
var glRangeRedTmpInner = "";
var glRangeRMskTmpInner = "";

//暫定で1300000 余裕があればAIのマスク連番(サーバサイド処理)と合わせる
var glMaskIdCnt = ID_COUNT + 300000;
var glRedIdCnt = ID_COUNT + 300000;

//サーバからajaxで持ってくるポリシー情報
var glPolicyLists = [];
//以下の配列は同インデックスで保持
var glArrBfIds = []; //黒塗り先頭ID
var glArrAfIds = []; //黒塗り終了ID
var glArrPolicys = []; //黒塗り対象のIDに紐づくポリシーID
var glarrRepOuter = []; //黒塗り候補変更後のOuterHtml
var glRemarks = [] //黒塗りリストの備考
//以下の配列は同インデックスで保持 end

var glChartId = -1; //図表のpolicyIdを保持
var glHashPolicy = {} //ポリシーのマッピング ID:Name

var glDocumentInfoLists = []; //document情報

/**
************Class************
*/

/**
* HTMLのchar毎の情報を格納するクラス
* HashMap<Integer, HtmlStructure> の形で格納し、keyは置換対象外文字やtagを含んだポジション
* (<div>タグ等を含む)を格納する
*/
class HtmlStructure {
    strTgt = ""; //対象文字
    intPage = 0; //Page
    intStatus = 0; //strTgtのステータス 0：置換対象外(半角文字等) 1：対象 2：tag
    intNotTagPos = 0; //置換対象外文字やtagを抜いたときのポジション
} //class

/**
* 黒塗りリスト表示画面の情報を格納するクラス
*/
class listInfoCls {
    //黒塗りリスト表示画面に送付する配列を作成
    keywords = []; //黒塗り単語の配列
    pages = [];  //登場箇所の配列
    policyNames = []; //ポリシー名の配列
    Reasons = []; //黒塗り対処理由の配列
    Remarks = [] //黒塗りリストで記述した備考

    //20191107 add
    glArrBfIds = []; //黒塗り先頭ID
    glArrAfIds = []; //黒塗り終了ID
    glArrPolicys = []; //黒塗り対象のIDに紐づくポリシーID
    glarrRepOuter = []; //黒塗り候補変更後のOuterHtml


} //class

/**
************通常関数************
*/

/**
* 初期処理を実行する
*/
function bootOpen() {
    var repDiv = $("#repDiv");
    var maskDiv = $("#maskDiv");
    var refDiv = $("#refDiv");

    maskDiv.scroll(function () {
        repDiv.scrollTop(maskDiv.scrollTop());
        repDiv.scrollLeft(maskDiv.scrollLeft());
    }); //maskDiv.scroll(function ()


    repDiv.scroll(function () {
        maskDiv.scrollTop(repDiv.scrollTop());
        maskDiv.scrollLeft(repDiv.scrollLeft());
    }); //repDiv.scroll(function ()

    //userIdセット
    if (!isUserId()) {
        setUserId();
    } //if

    //user名セット
    if (!isUserName()) {
        setUserName();
    } //if

    //policy 取得
    getPolicyAll();
    //document情報
    getDocumentInfo(gldocumentId);
    //アイコンを入れ替える
    if (glDocumentInfoLists[0].extension==="txt") {
        document.getElementsByClassName("icon_l")[0].src = "./css/images/l_file_node.gif";
        document.getElementsByClassName("icon_s")[0].src = "./css/images/file_node.gif"
        document.getElementsByClassName("icon_s")[1].src = "./css/images/file_node.gif"
    } //if



    //コンテキストメニューのポリシーリスト作成
    document.getElementById('rangeSet').innerHTML = makePolicyList(glPolicyLists, 0);
    document.getElementById('policyMod').innerHTML = makePolicyList(glPolicyLists, 1);

    //glEditMarkerを各配列に分割する
    splitEditMarker(glEditMarker);

    //一時保存データがあるか確認する
    TmpInfoGet();  //ajaxだとreturnがうまくいかないのでGLに格納
    if (!glTmpFileFlg) {
        $('#SAIKAI').toggleClass(BTN_DISABLE);
        $('#HOZON_SAKUJYO').toggleClass(BTN_DISABLE);
    } //if

} //functionL

/**
 * 再開、保存削除ボタン制御 classがBTN_DISABLEのときは押下不可可能
 */
function tmpBtnStateCng() {
    $('#SAIKAI').toggleClass(BTN_DISABLE);
    $('#HOZON_SAKUJYO').toggleClass(BTN_DISABLE);
} //function

/**
 * 再開、保存削除ボタンを強制再開
 */
function tmpBtnStateRemove() {
    $('#SAIKAI').removeClass(BTN_DISABLE);
    $('#HOZON_SAKUJYO').removeClass(BTN_DISABLE);
} //function


/**
 * 再開、保存状態を判定する
 */
function isTmpBtn() {
    if ($('#SAIKAI').hasClass(BTN_DISABLE)) {
        return true;
    } //if
    return false;
} //function


/**
* policy一覧を取得する
* @return boolean
*/
function getPolicyAll() {
    $.ajax({
        type: 'GET',
        url: 'rest/policy/all',
        processData: false, // Ajaxがdataを整形しない指定
        contentType: false, // contentTypeもfalseに指定(Fileをアップロード時は必要)
        async: false, //非同期false
        success: function (retData) {
            glPolicyLists = JSON.parse(retData);
            for (let i = 0; i < glPolicyLists.length; i++) { //nullがあったら空文字にする
                //nullは空文字にしておく
                for (const key in glPolicyLists[i]) {
                    if (glPolicyLists[i][key] === null) {
                        glPolicyLists[i][key] = '';
                    } //if
                } //for
            } //for

            console.log("success");
            return false;
        }, //function
        error: function (e) {
            console.log("fail");
            return false;
        } //function
    }); //ajax
} //function

/**
 * glEditMarkerを各配列に分割する
 * @param strEditMarker_i 黒塗り先頭ID:黒塗り終了ID:policyID構成 複数ある場合は+でセパレート
 */
function splitEditMarker(strEditMarker_i) {
    glArrBfIds = []; //黒塗り先頭ID
    glArrAfIds = []; //黒塗り終了ID
    glArrPolicys = []; //黒塗り対象のIDに紐づくポリシーID
    if(strEditMarker_i!==""){ //空文字は通さない
        var arrMulti = strEditMarker_i.split('+');
        for (let i = 0; i < arrMulti.length; i++) {
            var arrTmp = arrMulti[i].split(':');
            for (let j = 0; j < arrTmp.length; j++) {
                glArrBfIds[i] = arrTmp[0];
                glArrAfIds[i] = arrTmp[1];
                glArrPolicys[i] = Number(arrTmp[2]);
            } //for
        } //for
    } //if


} //function

/**
 * 黒塗り箇所範囲選択用のOuterHtmlを作成する
 */
function makeMaskOuter() {
    //黒塗り箇所範囲選択用のOuterHtmlだけ作成しておく
    var objTgtFlame = document.getElementById("red").contentDocument;
    var objTgtBody = document.getElementById("red").contentDocument.body;
    for (let i = 0; i < glArrBfIds.length; i++) {

        var intBfPos = objTgtBody.innerHTML.indexOf(objTgtFlame.getElementById(glArrBfIds[i]).outerHTML);
        var intAfPos = objTgtBody.innerHTML.indexOf(objTgtFlame.getElementById(glArrAfIds[i]).outerHTML) + objTgtFlame.getElementById(glArrAfIds[i]).outerHTML.length;
        var strTmp = objTgtBody.innerHTML.substring(intBfPos, intAfPos);
        glarrRepOuter[i] = strTmp;
    } //for
} //function


/**
 * glEditMarkerを作成する
 * @return 黒塗り先頭ID:黒塗り終了ID:policyID構成 複数ある場合は+でセパレート
 */
function makeEditMarker() {
    var strRet = "";
    for (let i = 0; i < glArrBfIds.length; i++) {
        strRet += glArrBfIds[i] + ':';
        strRet += glArrAfIds[i] + ':';
        strRet += glArrPolicys[i] + '+';
    } //for

    if (strRet !== '') {
        strRet = strRet.substr(0, strRet.length - 1);
    } //if
    return strRet;

} //function

/**
 * マスク候補、マスクで置換した文字列を元の文字列に戻す
 * @return 置換したBody文字列
 */
function bodyCharReturn(strBfBody, strAfBody) {
    var strRepVal = "";
    //基本マスク候補対象 余裕があればリファクタリング
    var strInnerBody = glObjRedFlame.body.innerHTML;
    var objPattern = new RegExp(RED_ORG_GET, 'gi'); //グルーピングで入れ替える
    var strAct = strInnerBody.substring(strBfBody.length, strInnerBody.indexOf(strAfBody));
    strAct = strAct.replace(' ' + RED_INIT_CLS, '').replace(' ' + RED_END_CLS, ''); //RED_INIT_CLSとRED_END_CLSだけは消し込んどく
    strRepVal = strAct.replace(objPattern, '$1');
    return strRepVal;
} //function

/**
* strの文字列をbeforeStrをafterStrに全置換する
* @return 置換文字列
*/
function replaceAll(str, beforeStr, afterStr) {
    var reg = new RegExp(beforeStr, "g");
    return str.replace(reg, afterStr);
} //function

/**
 * 半角記号を全角スペースにする
 * @param strTgt_i
 * @return 置換後のストリング
 */
function replaceHalfSpace(strTgt_i) {
    var strReplace = replaceAll(strTgt_i, SPACE_MARK, "　");
    return strReplace;
} //function

/**
* 全てのタグにIDを付与する(もともとIDある場合は処理スキップ)
*/
function allIdPut(objTgtDom_i, strTagName_i) {
    var strActId = objTgtDom_i.getAttribute("id");
    if (strActId === null) {
        objTgtDom_i.setAttribute("id", strTagName_i + glIdCnt);
        glIdCnt++;
    } //if

    for (var index = glIdCnt; index < objTgtDom_i.childElementCount; index++) {
        var objActDom = objTgtDom_i.children[index];
        strActId = objActDom.getAttribute("id");
        if (strActId === null) {
            objActDom.setAttribute("id", strTagName_i + index);
            glIdCnt++;
        } //if
    } // for
    if (objTgtDom_i.childElementCount != 0) {
        for (var index = 0; index < objTgtDom_i.childElementCount; index++) {
            var objActDom = objTgtDom_i.children[index];
            allIdPut(objActDom, strTagName_i);
        } // for
    }//if
} //function

/**
* コンテキストメニューのポリシーリストのInnerHTMLを作成する
* @param arrPolicyLists_i policyのリスト
* @param intState_i 0:候補・ポリシー指定用：1：ポリシー変更用
*/

function makePolicyList(arrPolicyLists_i, intState_i) {
    var strRet = "";
    var intChartOffcet = 0;
    for (var i = 0; i < arrPolicyLists_i.length; i++) {
        intPolicy = arrPolicyLists_i[i].policyId;
        intPolicyName = arrPolicyLists_i[i].policyName;
        if (arrPolicyLists_i[i].policyName === CHART_POLICY) { //図・表は表示しない
            glChartId = arrPolicyLists_i[i].policyId; //ポリシーIDだけ保持
            intChartOffcet++; //図表分だけずれるOFFSET
        } else if (intState_i === 0) {
            strRet += '<li><a id="tgt' + intPolicy + '" onClick=tgtMaskChk(' + intPolicy + ')>' + arrPolicyLists_i[i].policyName + '</a></li> ';
            glHashPolicy[intPolicy]=intPolicyName; //マッピングを保持
        } else {
            strRet += '<li><a id="mod' + intPolicy + '" onClick=policyMod(' + intPolicy + ')>' + arrPolicyLists_i[i].policyName + '</a></li> ';
            glHashPolicy[intPolicy]=intPolicyName; //マッピングを保持
        } //if
    } //for

    return strRet;
}//function

/**
* bodyの構造体hashを取得
* @param strOrgBody_i
* @return HtmlStructureのハッシュ
*/
function getBodyStructure(strOrgBody_i) {
    var strTgtVal = strOrgBody_i;

    var hashRetStructure = {};
    var listLastNotTagPos = []; //intNotTagPosを格納していく
    var strRegrep = REG_TAG_VAL_SPLIT; //タグとタグを除いた値をグループで取得する
    var objPattern = new RegExp(strRegrep, "g");
    var strCurrentKwd = ""; //現在ヒットしている単語
    var intCurrentPos = 0;
    var objRegRet;
    while ((objRegRet = objPattern.exec(strTgtVal)) != null) {
        strCurrentKwd = objRegRet[2];
        if (strCurrentKwd == undefined) { //タグの処理
            strCurrentKwd = objRegRet[1];
            searchAnalysis(hashRetStructure, listLastNotTagPos, strCurrentKwd, intCurrentPos, 2);
        } else if (strCurrentKwd == " " || strCurrentKwd == "　" || strCurrentKwd == SPACE_MARK) { //スペース処理
            searchAnalysis(hashRetStructure, listLastNotTagPos, strCurrentKwd, intCurrentPos, 0);
            continue; //スペースはそのまま格納
        } else if (Boolean(strCurrentKwd.match(/^\t$|^\v$|^\n$|^\r$|^\f$/g))) { //特殊記号処理(特殊記号のみの場合のみ処理)
            searchAnalysis(hashRetStructure, listLastNotTagPos, strCurrentKwd, intCurrentPos, 0);
            continue; //特殊記号処理はそのまま格納
        } else { //通常文字
            searchAnalysis(hashRetStructure, listLastNotTagPos, strCurrentKwd, intCurrentPos, 1);
        } //if
        intCurrentPos = Object.keys(hashRetStructure).length;

    }  //while

    return hashRetStructure;
} //function

/**
* 検索結果からbodyの構造体hashを作成する
* @param HashMap<Integer, HtmlStructure> hashRetStructure_i 参照渡しのハッシュ
* HtmlStructureはHTMLのchar毎の情報を格納するクラス
* HashMap<Integer, HtmlStructure> の形で格納し、keyは置換対象外文字やtagを含んだポジション(<div>タグ等を含む)を格納する
* @param strCurrentKwd_i 現在正規表現でヒットしている文字列
* @param intCurrentPos_i タグを含めた現在のposition
* @param intStatus_i 0：置換対象外(半角文字等) 1：対象 2：tag
*/
function searchAnalysis(hashRetStructure_i, listLastNotTagPos_i, strCurrentKwd_i, intCurrentPos_i, intStatus_i) {
    var intCntPos = Object.keys(hashRetStructure_i).length;
    var intNotTagPos = 0;
    objHtmlStructure = null;
    var arrTmp = strCurrentKwd_i.split("");
    var strTgt = "";

    if (listLastNotTagPos_i.length != 0) { //tag抜き文字の最終を取得する
        intNotTagPos = listLastNotTagPos_i[listLastNotTagPos_i.length - 1];
    } //if

    for (var i = 0; i < arrTmp.length; i++) {
        objHtmlStructure = new HtmlStructure();
        strTgt = arrTmp[i];
        objHtmlStructure.strTgt = strTgt;
        objHtmlStructure.intStatus = intStatus_i;
        if (intStatus_i == 1) { //通常文字はintNotTagPosをカウント
            intNotTagPos++;
            objHtmlStructure.intNotTagPos = intNotTagPos;
        } //if
        hashRetStructure_i[intCntPos + (i + 1)] = objHtmlStructure;
    } //for

    if (intStatus_i == 1) { //通常時はtag抜き文字の最終を格納
        listLastNotTagPos_i.push(intNotTagPos);
    } //if
} //function

/**
 * 選択領域の文字列を置換してbodyを入れ替え、または赤文字変換した文字列を取得
 * @param hashBodyStructure_i HTMLのchar毎の情報を格納するクラスを格納したhash key：HTMLのindex : val HTMLのchar(index)毎の情報を格納するクラス
 * @param intMaskStatus_i 置換ステータス :マスク 2:赤文字
 * @return 置換したBody文字列
 */
function bodyCharChange(hashBodyStructure_i, intMaskStatus_i) {
    var strRepBody = "";
    var intStatus = 0;
    var blFlag = true;
    var intIndCnt = Object.keys(hashBodyStructure_i).length;
    for (var i = 1; i < Object.keys(hashBodyStructure_i).length + 1; i++) {
        var objHtmlStructure = hashBodyStructure_i[i];
        intStatus = objHtmlStructure.intStatus;
        intNotTagPos = objHtmlStructure.intNotTagPos;
        if (intStatus == 1) { //通常文字の場合
            if (intMaskStatus_i == 1 && blFlag) { //初期だけ特別クラス
                strRepBody += MASK_BF_INIT + glMaskIdCnt + "'>" + MASK_MSG + MASK_AF; //マスク
                blFlag = false;
                glMaskIdCnt++;
            } else if (blFlag) { //初期だけ特別クラス
                strRepBody += RED_BF_INIT + glRedIdCnt + "'>" + objHtmlStructure.strTgt + RED_AF; //赤塗り
                blFlag = false;
                glRedIdCnt++;
            } else if (intMaskStatus_i == 1 && i == intIndCnt) { //最後も特別クラス
                strRepBody += MASK_BF_END + glMaskIdCnt + "'>" + MASK_MSG + MASK_AF; //マスク
                blFlag = false;
                glMaskIdCnt++;
            } else if (i == intIndCnt) { //最後も特別クラス
                strRepBody += RED_BF_END + glRedIdCnt + "'>" + objHtmlStructure.strTgt + RED_AF; //赤塗り
                blFlag = false;
                glRedIdCnt++;
            } else if (intMaskStatus_i == 1) {
                strRepBody += MASK_BF + glMaskIdCnt + "'>" + MASK_MSG + MASK_AF; //マスク
                glMaskIdCnt++;
            } else {
                strRepBody += RED_BF + glRedIdCnt + "'>" + objHtmlStructure.strTgt + RED_AF; //赤塗り
                glRedIdCnt++;
            } //if

        } else { //その他の場合そのまま出力する
            strRepBody += objHtmlStructure.strTgt;
        } //if
    } //for
    return strRepBody;
} //function

/**
* 引数の文字列をtagとそれ以外に分割する
*/
function splitTagArr(strTgtVal_i, arrTag_i, arrNotTag_i) {
    var strTgtVal = strTgtVal_i;
    var strRegrep = REG_TAG_VAL_SPLIT; //タグとタグを除いた値をグループで取得する
    var objPattern = new RegExp(strRegrep, "g");
    var strCurrentKwd = ""; //現在ヒットしている単語
    var objRegRet;
    while ((objRegRet = objPattern.exec(strTgtVal)) != null) {
        strCurrentKwd = objRegRet[2];
        if (strCurrentKwd == undefined) { //タグ
            strCurrentKwd = objRegRet[1];
            arrTag_i.push(strCurrentKwd);
            arrNotTag_i.push(""); //indexを合わせるために空文字を挿入
        } else { //通常文字
            arrTag_i.push("");//indexを合わせるために空文字を挿入
            arrNotTag_i.push(strCurrentKwd);
        } //if
    }  //while
} //function

/**
* 引数の文字列の最終がタグか判定する
* @return tag:true tag以外 false
*/
function isLastTag(strTgtVal_i) {
    var strTgtVal = strTgtVal_i;
    var strRegrep = REG_TAG_VAL_SPLIT; //タグとタグを除いた値をグループで取得する
    var objPattern = new RegExp(strRegrep, "g");
    var strCurrentKwd = ""; //現在ヒットしている単語
    var objRegRet;
    var blRet = false;
    while ((objRegRet = objPattern.exec(strTgtVal)) != null) {
        strCurrentKwd = objRegRet[2];
        if (strCurrentKwd == undefined) { //タグ
            blRet = true;
        } else { //通常文字
            blRet = false;
        } //if
    }  //while
    return blRet;
} //function

/**
* マスク候補IFlame内の選択指定している範囲のbodyInnerHtmlからの距離を返す
* @return 0:intInitPartPos,1:intEndPartPosの配列
*/
function getSelectionInnerPos() {

    //選択されていなかったらreturn
    if (glObjRedFlame.getSelection().toString() == "") {
        return;
    } //if

    var objSelection = glObjRedFlame.getSelection(); // 選択範囲のオブジェクト取得
    var objTgtRange = objSelection.getRangeAt(0); //rangeを取得
    var objInitDom = null;
    var objEndDom = null;
    var strInnerBody = glObjRedFlame.body.innerHTML;
    /**
    * memo Dom横断の場合のobjTgtRange.startOffset,objTgtRange.endOffsetの挙動
    *「objTgtRange.startContainer.wholeText」から何文字OffsetしたかがobjTgtRange.startOffset
    *「objTgtRange.endContainer.wholeText」から何文字OffsetしたかがobjTgtRange.endOffset
    *また、wholeTextはDOMのinnerTextと一致するのでそこから捜索する
    */

    //部分文字列の前半取得 glSelectEndId
    //glSelectIinitIdとglSelectEndIdがどちらが先にあるIDか調べてglSelectEndIdのほうが早かったら入れ替える
    var intInitPos = strInnerBody.indexOf(glSelectIinitId);
    var intEndPos = strInnerBody.indexOf(glSelectEndId);

    if (intInitPos > intEndPos) {
        var strTmp1 = glSelectIinitId;
        var strTmp2 = glSelectEndId;
        glSelectIinitId = strTmp2;
        glSelectEndId = strTmp1;
    } //if

    try {
        var objInitDom = glObjRedFlame.getElementById(glSelectIinitId)
        var objInitParentDom = glObjRedFlame.getElementById(glSelectIinitId)

        var intInitChildCnt = objInitDom.childElementCount;
        var objInitNode = objSelection.anchorNode;//Selectionのアンカーとは、選択の開始点
        var objPrevDom = objInitNode.previousSibling;
        var blChildFlg = false;

        if (intInitChildCnt > 0 && (objPrevDom != null)) { //子要素がある場合かつ前のdomが無い
            blChildFlg = true;
        } //if

        var strInitInner = objInitParentDom.innerHTML.toString();
        var strInitOuter = objInitParentDom.outerHTML.toString();
        var intInitOutPos;
        var intInitPartPos;
        if (blChildFlg) { //子要素がある場合
            intInitPartPos = glObjRedFlame.body.innerHTML.indexOf(getSelectionHtml());
        }else { //子要素がない場合
            var strInitPart = strInitInner.substr(objTgtRange.startOffset, strInitInner.length);
            strInitPart = strInitOuter.substr(strInitOuter.lastIndexOf(strInitPart), strInitOuter.length); //閉じタグプラス
            intInitOutPos = strInnerBody.indexOf(strInitOuter);
            intInitPartPos = intInitOutPos + strInitOuter.lastIndexOf(strInitPart);
        } //if

        //部分文字列の後半取得
        var objEndParentDom = glObjRedFlame.getElementById(glSelectEndId);

        var objEndNode = objSelection.focusNode; //Selectionのフォーカスとは、選択の終了点
        var objPrevDom = objEndNode.previousSibling;
        blChildFlg = false;
        blChildFind = false;
        if (intInitChildCnt > 0 && (objPrevDom != null)) { //子要素がある場合かつ前のdomが無い
            blChildFlg = true;
        } //if


        var strEndInner = objEndParentDom.innerHTML.toString();
        var strEndOuter = objEndParentDom.outerHTML.toString();

        var strEndPart;
        var intEndOutPos;
        var intEndPartPos;
        intChildOffcet = 0;
        if (blChildFlg) { //子要素がある場合
            intEndPartPos = glObjRedFlame.body.innerHTML.indexOf(getSelectionHtml()) + getSelectionHtml().length;
        } else { //子要素がない場合
            objPattern = new RegExp(RED_ID_RED , "gi");
            var strEndId = strEndOuter.match(objPattern)[0] ;
            var strEndOuter = glObjRedFlame.getElementById(strEndId).outerHTML; //Endのアウターをさきに取得

            var hashBodyStructure = {};
            var inttagLen=0
            hashBodyStructure = getBodyStructure(strEndOuter); //hashBodyStructureを作成してtagとtag以外を振り分ける
            for (var i = 1; i < Object.keys(hashBodyStructure).length + 1; i++) {
                var objHtmlStructure = hashBodyStructure[i];
                var intStatus = objHtmlStructure.intStatus;
                intNotTagPos = objHtmlStructure.intNotTagPos;
                if (intStatus == 1) { //通常文字の場合
                    break; //innerTextになるのでbreak
                } else {
                    inttagLen++;  //tagの文字数を数える
                } //if
            } //for
            var strOuterPart = strEndOuter.substr(0,inttagLen + objTgtRange.endOffset); //EndのOuterHtmlの部品
            intEndPartPos=strInnerBody.indexOf(strOuterPart) + strOuterPart.length;

        }//if
        var arrRet = [];
        arrRet.push(intInitPartPos);
        arrRet.push(intEndPartPos);
        return arrRet;
    } catch (error) {
        var arrRet = [];
        arrRet[0] = 0;
        arrRet[1] = 0;
        arrRet[2] = error;
        return arrRet;
    } //try


} //function

/**
* 選択指定している範囲のマスク、マスク候補を変更する
* @param policyId
*/
function tgtMaskChk(policyId_i) {

    //選択されていなかったらreturn
    if (glObjRedFlame.getSelection().toString() == "") {
        return;
    } //if

    var strTgtVal = "";
    var arrPos = getSelectionInnerPos();
    if (arrPos.length >= 3) {
        alert("黒塗り候補文字が選択箇所に入っています。\n別の場所を選択するか、「範囲変更」を行ってください。");
        contextNone();
        return;
    } //if
    var intInitPartPos = arrPos[0];
    var intEndPartPos = arrPos[1];
    var strInnerBody = glObjRedFlame.body.innerHTML;
    var strMaskInnerBody = glObjMaskFlame.body.innerHTML;

    //値を実際に取得
    strTgtVal = strInnerBody.substring(intInitPartPos, intEndPartPos);
    var strBfBody = strInnerBody.substr(0, intInitPartPos);
    var strAfBody = strInnerBody.substring(intEndPartPos, strInnerBody.length);

    //すでに黒塗り候補に入っているか調べる
    // var strRegrep = RED_ORG_GET;
    var strRegrep = RED_INIT_CLS + "|" + RED_END_CLS;
    var objPattern = new RegExp(strRegrep, "gi");
    if (objPattern.test(strTgtVal)) {
        alert("黒塗り候補文字が選択箇所に入っています。\n別の場所を選択するか、「範囲変更」を行ってください。");
        contextNone();
        return;
    } //if

    //画像は範囲選択で含めない(単体でマスク指定)
    var strRegrep = '\<img';
    var objPattern = new RegExp(strRegrep, "gi");
    if (objPattern.test(strTgtVal)) {
        alert("画像が選択箇所に入っています。\n画像をマスク処理する際は、画像自体を右クリックして「候補指定」を行ってください。");
        contextNone();
        return;
    } //if

    //マスク候補処理
    var hashBodyStructure = {};
    hashBodyStructure = getBodyStructure(strTgtVal);
    var strRepVal = bodyCharChange(hashBodyStructure, STATE_RED);


    //bodyを入れ替える
    var strChangeBody = strBfBody + strRepVal + strAfBody;
    glObjRedBody.innerHTML = strChangeBody;

    //マスク処理
    var strMaskInnerBody = glObjMaskFlame.body.innerHTML;
    var strMakkTgtVal = strMaskInnerBody.substring(intInitPartPos, intEndPartPos);

    var hashBodyMaskStructure = getBodyStructure(strMakkTgtVal);
    var strMaskRepVal = bodyCharChange(hashBodyMaskStructure, STATE_MASK);

    //bodyを入れ替える
    var strMaskBfBody = strMaskInnerBody.substr(0, intInitPartPos);
    var strMaskAfBody = strMaskInnerBody.substring(intEndPartPos, strMaskInnerBody.length);
    var strMaskChangeBody = strMaskBfBody + strMaskRepVal + strMaskAfBody;
    glObjMaskBody.innerHTML = strMaskChangeBody;

    //グローバルに黒塗り先頭ID,黒塗り終了ID,黒塗り対象のIDに紐づくポリシーID,OuterHTMLを保持
    var objPattern = new RegExp(RED_ID_RED, "g");
    var arrRedIds = strRepVal.match(objPattern);
    var strBfId = arrRedIds[0];
    var strAfId = arrRedIds[arrRedIds.length - 1];

    glArrBfIds.push(strBfId);
    glArrAfIds.push(strAfId);
    glArrPolicys.push(policyId_i);
    glarrRepOuter.push(strRepVal);

    contextNone();

} //function

/**
* 選択範囲をもとの文書に戻す
*/
function tgtMaskOrg() {
    var strBfId = glActBfId;
    var strAfId = glActAfId;
    var strOrg = "";

    //bodyを入れ替える(マスク候補)
    var objBfOuter = glObjRedFlame.getElementById(strBfId);
    var objAfOuter = glObjRedFlame.getElementById(strAfId);
    var strInnerBody = glObjRedFlame.body.innerHTML;
    var intInitPos = strInnerBody.indexOf(objBfOuter.outerHTML);
    var intEndPos = strInnerBody.indexOf(objAfOuter.outerHTML) + objAfOuter.outerHTML.length
    var strBfBody = strInnerBody.substr(0, intInitPos);
    var strAfBody = strInnerBody.substring(intEndPos, strInnerBody.length);

    strOrg = bodyCharReturn(strBfBody, strAfBody);
    var strChangeBody = strBfBody + strOrg + strAfBody;
    glObjRedBody.innerHTML = strChangeBody;

    //bodyを入れ替える(マスク)
    strBfId = strBfId.replace("red", "msk");
    strAfId = strAfId.replace("red", "msk");
    objBfOuter = glObjMaskFlame.getElementById(strBfId);
    objAfOuter = glObjMaskFlame.getElementById(strAfId);
    strInnerBody = glObjMaskFlame.body.innerHTML;
    intInitPos = strInnerBody.indexOf(objBfOuter.outerHTML);
    intEndPos = strInnerBody.indexOf(objAfOuter.outerHTML) + objAfOuter.outerHTML.length
    strBfBody = strInnerBody.substr(0, intInitPos);
    strAfBody = strInnerBody.substring(intEndPos, strInnerBody.length);
    strOrg = replaceAll(strOrg, "red", "msk");
    strChangeBody = strBfBody + strOrg + strAfBody;

    glObjMaskBody.innerHTML = strChangeBody;

    contextNone();

} //function


/**
* 選択範囲を開放する
*/
function tgtMaskRelease() {
//    var blRet = confirm("現在選択されている候補を解除してよろしいですか？");
//    if (blRet) {
        //元のbodyに戻す
        tgtMaskOrg();
        //配列要素から削除 glActBfId
        var intIndex = glArrBfIds.indexOf(glActBfId);
        glArrBfIds.splice(intIndex, 1);
        glArrAfIds.splice(intIndex, 1);
        glArrPolicys.splice(intIndex, 1);
        glarrRepOuter.splice(intIndex, 1);

//    } //if
    contextNone();
} //function

/**
 * 黒塗り候補を選択状態にする
*/
function getRedRange(e) {
    //glarrRepOuterから選択するIDを捜索
    var strActId = e.target.id;
    var intIndex = 0;
    for (var i = 0; i < glarrRepOuter.length; i++) {
        var objTgt = glarrRepOuter[i];
        if (objTgt.indexOf(strActId) >= 0) {
            intIndex = i;
            break;
        } //if
    } //for

    var objPattern = new RegExp(RED_ID_RED, "g");
    var arrRedIds = glarrRepOuter[intIndex].match(objPattern);
    // var arrRedIds =  $('#red').contents().find('#'+strActId).siblings(); //兄弟要素じゃないもの取れないので却下

    var strBfId = arrRedIds[0];
    var strAfId = arrRedIds[arrRedIds.length - 1];
    //rangeの作成
    objRange = glObjRedFlame.createRange();
    objRange.setStart(glObjRedFlame.getElementById(strBfId), 0);
    objRange.setEnd(glObjRedFlame.getElementById(strAfId), glObjRedFlame.getElementById(strAfId).innerText.length);
    var objTgtSelection = glObjRedFlame.getSelection();
    glObjRedBody.focus();
    objTgtSelection.removeAllRanges();
    objTgtSelection.addRange(objRange);
    //id,policy,rangeをグローバルに保持
    glActBfId = strBfId;
    glActAfId = strAfId;
    intIndex = 0;
    intIndex = glArrBfIds.indexOf(strBfId);
    glActPolicy = glArrPolicys[intIndex];
    glObjRange = objRange;

} //function

/**
 * 範囲変更押下
 */
function changeRange() {
    //キャンセル用にGL変数に保持
    var strInnerBody = glObjRedFlame.body.innerHTML;
    var strInnerMaskBody = glObjMaskFlame.body.innerHTML;
    glRangeRedTmpInner = strInnerBody;
    glRangeRMskTmpInner = strInnerMaskBody;

    //元のbodyに戻す
    tgtMaskOrg();

    // var strPolicyName = glPolicyLists[glActPolicy - 1].policyName;
    var strPolicyName = glHashPolicy[glActPolicy];

    alert("新たな選択範囲を選んで右クリックしてください\n※現在のポリシー「" + strPolicyName + "」は引き継がれます");
    glNewRangeFlg = true;
    contextNone();

} //function


/**
 **********イベント イベント操作関係 **********
*/

/**
 * 独自コンテキストメニューを閉じる
*/
function contextNone() {

    $("#policyMod").find(".actPolicy").removeClass(ACT_POLICY);
    document.getElementById('contextmenu').style.display = "none";
    document.getElementById('contextmenu_red').style.display = "none";
    document.getElementById('contextmenu_img').style.display = "none";
    document.getElementById('contextmenu_img_return').style.display = "none";
    document.getElementById('contextmenu_svg').style.display = "none";
    document.getElementById('contextmenu_svg_return').style.display = "none";



} //fanction

/**
 * mouseUpActイベント
*/
function mouseUpAct(e) { //contextメニューが出てないときだけ処理する
    if (e.button != 2) { //右クリック時は無視
        glSelectEndId = e.target.id;
    } //if
} //function

/**
 * マウスダウンイベント
*/
function mouseDownAct(e) {

    if (e.button == 0) { //通常クリック時のみ発火
        glSelectIinitId = e.target.id;
    } //if

    //範囲変更フラグが立っている時かつ右クリック
    if (glNewRangeFlg && e.button == RIGHT_TYPE) {

        if (glObjRedFlame.getSelection().toString() != "") { //範囲変更されている
            blRet = confirm("新たな範囲変更場所はこちらでよろしいでしょうか？");
            if (blRet) {
                changeRangeAfter(e);
            } else {
                //範囲変更前に戻す
                changeRangeCancel();
                return;
            } //if
        } else {
            blRet = confirm("範囲変更をキャンセルしますか？");
            if (blRet) {
                //範囲変更前に戻す
                changeRangeCancel();
                return;
            } //if
        } //if
    } //if

    //ownerがSVGで右クリックの場合
    if (e.target.ownerSVGElement!==undefined && e.button == RIGHT_TYPE) {
        var blEdit = isEdit();
        if (!(blEdit)) { //編集ボタンが押されていなかったらアラートを出して戻す
            alert(MSG_EDIT);
            return;
        } //if

        contextOpen(e, SVG_MENU);
        return ;
    } //if

    contextNone();
} //function


function contextOpen(e, intStatus_i) {

    var intTop = 0;
    if (e.screenY >= 500) { //画面下部で右クリック時はメニューを右上に出す
        intTop = e.screenY + OFFCET_Y_BOTTOM;
    } else {
        intTop = e.screenY + OFFCET_Y_NOMAL;
    } //if

    if (intStatus_i == NOMAL_MENU) {
        var objTgtDom = $('#contextmenu')[0];
        if (e.screenX > 0) {
            objTgtDom.style.left = e.screenX - window.screenX + OFFCET_X + "px";
            objTgtDom.style.top = intTop + "px";
            objTgtDom.style.display = "block";
        } else {
            objTgtDom.style.left = e.screenX + window.screen.availWidth + OFFCET_X + "px";
            objTgtDom.style.top = intTop + "px";
            objTgtDom.style.display = "block";
        }
    } else if (intStatus_i == MASK_MENU) {
        var objTgtDom = $('#contextmenu_red')[0];
        if (e.screenX > 0) {
            objTgtDom.style.left = e.screenX - window.screenX + OFFCET_X + "px";
            objTgtDom.style.top = intTop + "px";
            objTgtDom.style.display = "block";
        } else {
            objTgtDom.style.left = e.screenX + window.screen.availWidth + OFFCET_X + "px";
            objTgtDom.style.top = intTop + "px";
            objTgtDom.style.display = "block";
        }
        //対象Policyを探し当てて色替え
        var intIndex = glArrBfIds.indexOf(glActBfId);
        var intTgtPolicy = glArrPolicys[intIndex];
        $("#mod" + intTgtPolicy).addClass(ACT_POLICY);

    } else if (e.target.tagName === 'IMG') { //タグ時処理
        //対象のタグidを格納
        glSelectEndId = e.target.id;
        if (e.target.classList.contains(RED_IMG)) { //すでにマスク後か判定
            var objTgtDom = $('#contextmenu_img_return')[0];
            if (e.screenX > 0) {
                objTgtDom.style.left = e.screenX - window.screenX + OFFCET_X + "px";
                objTgtDom.style.top = intTop + "px";
                objTgtDom.style.display = "block";
            } else {
                objTgtDom.style.left = e.screenX + window.screen.availWidth + OFFCET_X + "px";
                objTgtDom.style.top = intTop + "px";
                objTgtDom.style.display = "block";
            } //if
        }else{
            var objTgtDom = $('#contextmenu_img')[0];
            if (e.screenX > 0) {
                objTgtDom.style.left = e.screenX - window.screenX + OFFCET_X + "px";
                objTgtDom.style.top = intTop + "px";
                objTgtDom.style.display = "block";
            } else {
                objTgtDom.style.left = e.screenX + window.screen.availWidth + OFFCET_X + "px";
                objTgtDom.style.top = intTop + "px";
                objTgtDom.style.display = "block";
            } //if
        } //if
    //画像がsvgのとき
    } else if (intStatus_i == SVG_MENU) {
        //対象のタグidを格納
        glSelectEndId = e.target.ownerSVGElement.id;
        if(e.target.ownerSVGElement.classList.contains(RED_IMG)){
        // if(e.target.ownerSVGElement.classList.length!=0){ //すでにマスク後か判定
            var objTgtDom = $('#contextmenu_svg_return')[0];
            if (e.screenX > 0) {
                objTgtDom.style.left = e.screenX - window.screenX + OFFCET_X + "px";
                objTgtDom.style.top = intTop + "px";
                objTgtDom.style.display = "block";
            } else {
                objTgtDom.style.left = e.screenX + window.screen.availWidth + OFFCET_X + "px";
                objTgtDom.style.top = intTop + "px";
                objTgtDom.style.display = "block";
            } //if
        }else{
            var objTgtDom = $('#contextmenu_svg')[0];
            if (e.screenX > 0) {
                objTgtDom.style.left = e.screenX - window.screenX + OFFCET_X + "px";
                objTgtDom.style.top = intTop + "px";               
                objTgtDom.style.display = "block";
            } else {
                objTgtDom.style.left = e.screenX + window.screen.availWidth + OFFCET_X + "px";
                objTgtDom.style.top = intTop + "px";
                objTgtDom.style.display = "block";
            } //if
        } //if


    } //if




} //fanction

/**
 * コンテキストメニュー(右クリック)操作関数
*/
function contextFunc(e) {
    glActContext = e; //context保持
    var blEdit = isEdit();

    console.log(e.screenY);

    if (!(blEdit)) { //編集ボタンが押されていなかったらアラートを出して戻す
        alert(MSG_EDIT);
        return;
    } //if


    var objSelection = glObjRedFlame.getSelection(); // 選択範囲のオブジェクト取得
    var strClsChk = e.target.getAttribute("class");
    if (strClsChk == null) strClsChk = "";

    if (e.target.tagName === 'IMG') { //対象tagがIMGなら図表用のコンテキストメニューを開く
        contextOpen(e, 3);
    }else if (strClsChk.indexOf(TAG_RED) >= 0) { //対象クラスがTAG_REDならMASK_MENUを開く
        getRedRange(e);
        contextOpen(e, MASK_MENU);
    } else if (objSelection != "") { //選択されていたらNOMAL_MENUを開く
        contextOpen(e, NOMAL_MENU);
    } //if
} //function

/**
 * 範囲変更Cancel
 */
function changeRangeCancel() {
    //選択前のinnerHTMLに戻す
    glObjRedFlame.body.innerHTML = glRangeRedTmpInner;
    glObjMaskFlame.body.innerHTML = glRangeRMskTmpInner;
    glNewRangeFlg = false;
    contextNone();
    alert("範囲変更前の状態へ戻しました。");
} //functin

/**
 * 範囲変更実処理
 */
function changeRangeAfter(e) {
    //該当するインデックスを削除し、新たに範囲を設定する　
    // var intIndex=glArrPolicys.indexOf(glActPolicy)
    var intIndex = glArrBfIds.indexOf(glActBfId);
    glArrBfIds.splice(intIndex, 1);
    glArrAfIds.splice(intIndex, 1);
    glArrPolicys.splice(intIndex, 1);
    glarrRepOuter.splice(intIndex, 1);
    tgtMaskChk(glActPolicy);

    alert("新たな選択範囲が選択されました")
    glNewRangeFlg = false;
    contextNone();

} //function

/**
 * 編集ボタン制御 classがEDIT_ABLEのときだけ編集可能
 */
function editBtnStateCng() {
    $('#HENSHU').toggleClass(EDIT_ABLE);

} //function

/**
 * 編集可能、不可能を判定する
 */
function isEdit() {
    if ($('#HENSHU').hasClass(EDIT_ABLE)) {
        return true;
    } //if
    return false;
} //function

/**
 * ポリシーを変更する
 */
function policyMod(intPolicy_i) {
    //現在と変更後のPolicyをひきあててアラート
    var strPolicyName = glHashPolicy[glActPolicy];
    var strModName = glHashPolicy[intPolicy_i];

    // var strPolicyName = glPolicyLists[glActPolicy - 1].policyName;
    // var strModName = glPolicyLists[intPolicy_i - 1].policyName;
    var blRet = confirm("現在のポリシー「" + strPolicyName + "」から「" + strModName + "」へ変更してよろしいですか？");
    if (blRet) {
        var intIndex = glArrBfIds.indexOf(glActBfId); //現在のポリシーのINDEX(ポリシーだと一意にならないのでマッピングしてるglActBfIdにて取得)
        glArrPolicys[intIndex] = intPolicy_i; //新しいポリシーに変更
    } //if
    contextNone();
} //functon

/**
 * 黒塗りリストのjsonを作成する
 * @return 作成したJSON
 */
function makeMaskJson() {



	//黒塗りリスト表示画面に送付する配列を作成
    var keywords=[]; //黒塗り単語の配列
    var pages=[];  //登場箇所の配列
    var policyNames=[]; //ポリシー名の配列
    var Reasons=[]; //黒塗り対処理由の配列
    var Remarks=[]; //黒塗り対処理由の配列


  //黒塗りリスト表示画面に送付する配列を作成
    var tmpkeywords=[]; //黒塗り単語の配列
    var tmppages=[];  //登場箇所の配列
    var tmppolicyNames=[]; //ポリシー名の配列
    var tmpReasons=[]; //黒塗り対処理由の配列
    var tmpRemarks=[]; //黒塗り対処理由の配列
    var tmpArrBfIds=[];
    var tmpArrAfIds=[];
    var tmpArrPolicys=[];
    var tmparrRepOuter=[];

  //黒塗り単語の配列 ポリシー名の配列 黒塗り対処理由の配列作成
    for (let i = 0; i < glArrPolicys.length; i++) {
        for (let j = 0; j < glPolicyLists.length; j++) {
            var intDiffPolicy=Number(glPolicyLists[j].policyId);
            if (glArrPolicys[i]===intDiffPolicy) {
                policyNames[i]=glPolicyLists[j].policyName;
                Reasons[i]=glPolicyLists[j].policyReason;
//                if(glRemarks[i]==null){
//                	Remarks[i]=glRemarks[i] || "";
//                }else{
//                	Remarks[i]=glRemarks[i];
//                }

                //キーワード取得
                var intBfPos = glObjRedBody.innerHTML.indexOf(glObjRedFlame.getElementById(glArrBfIds[i]).outerHTML);
                var intAfPos = glObjRedBody.innerHTML.indexOf(glObjRedFlame.getElementById(glArrAfIds[i]).outerHTML) + glObjRedFlame.getElementById(glArrAfIds[i]).outerHTML.length;
                var strTmp = glObjRedBody.innerHTML.substring(intBfPos, intAfPos); //対象のアウター
                //innerTextを取得するため、tmpの親を作成し、OuterHTMLを埋め込む
                var objTmpParent = $('<div></div>').append(strTmp);
                keywords[i] = objTmpParent[0].innerText;

            } //if
        } //for
    } //for


       //黒塗り単語の配列 ポリシー名の配列 黒塗り対処理由の配列作成
        if(glRemarks.length>=glArrPolicys.length){
        	for (let i = 0; i < glArrPolicys.length; i++) {
        		if(glRemarks[i]==null){
        			glRemarks[i]=glRemarks[i] || "";
                }else{
                	glRemarks[i]=glRemarks[i];
                }
        	}
        }else if(glRemarks.length<glArrPolicys.length){
        	for (let i = 0; i < glRemarks.length; i++) {
        		if(glRemarks[i]==null){
        			glRemarks[i]=glRemarks[i] || "";
                }else{
                	glRemarks[i]=glRemarks[i];
                }
        	}
        	for (let i = glRemarks.length; i < glArrPolicys.length; i++) {
        		glRemarks[i]="";
        	}
        }


    //ページ取得
    var strTmpBody = glObjRedBody.innerHTML;
    var arrTmpPages = strTmpBody.split('class="awdiv awpage"') //pageクラス

    for (let i = 0; i < glArrBfIds.length; i++) {
        for (let j = 0; j < arrTmpPages.length; j++) {
            if (arrTmpPages[j].indexOf(glArrBfIds[i]) >= 0) {
                pages[i] = j;
                break;
            } //if
        } //for
    } //for

    var objTgtFlame = document.getElementById("red").contentDocument;
    var objInitList = objTgtFlame.getElementsByClassName('tagRedInit');
    for (let i = 0; i < objInitList.length; i++) {
    	var intIndex=glArrBfIds.indexOf(objInitList[i].id);
    	tmpkeywords[i] = keywords[intIndex];
    	tmppages[i] = pages[intIndex];
    	tmppolicyNames[i] = policyNames[intIndex];
    	tmpReasons[i] = Reasons[intIndex];
    	tmpRemarks[i] = glRemarks[intIndex];
    	tmpArrBfIds[i] = glArrBfIds[intIndex];
    	tmpArrAfIds[i] = glArrAfIds[intIndex];
    	tmpArrPolicys[i] = glArrPolicys[intIndex];
    	tmparrRepOuter[i] = glarrRepOuter[intIndex];

    }

    keywords=tmpkeywords;
    pages=tmppages;
    policyNames=tmppolicyNames;
    Reasons=tmpReasons;
    glRemarks=tmpRemarks;
    glArrBfIds=tmpArrBfIds;
    glArrAfIds=tmpArrAfIds;
    glArrPolicys=tmpArrPolicys;
    glarrRepOuter=tmparrRepOuter;


  //クラスをインスタンス化して配列格納、jaonにして送付
  objListInfo = new listInfoCls();
  objListInfo.keywords = keywords;
  objListInfo.pages = pages;
  objListInfo.policyNames = policyNames;
  objListInfo.Reasons = Reasons;
  objListInfo.Remarks = glRemarks; //黒塗り備考 初期に送るときは空の配列

  //20191107 add
  objListInfo.glArrBfIds = glArrBfIds; //黒塗り先頭ID
  objListInfo.glArrAfIds = glArrAfIds; //黒塗り終了ID
  objListInfo.glArrPolicys = glArrPolicys; //黒塗り対象のIDに紐づくポリシーID
  objListInfo.glarrRepOuter = glarrRepOuter; //黒塗り候補変更後のOuterHtml



    var strJson = JSON.stringify(objListInfo);
    return strJson;
} //makeMaskJson

/**
 * 黒塗りリストを表示する
 */
function maskListView() {

    var blRet = confirm("「一時保存」後に「黒塗りリスト」を表示しないと編集内容が復元できません。\r\n「一時保存」を行って「黒塗りリスト」を表示してよろしいですか?");
    if (blRet) {

    	var strJson = makeMaskJson();

        //一時保存処理
        saveTmpDocDelMain(1); //Delete → Insert
        saveTmpDocMain(1);



        // //別ウィンドウで表示
        // window.open("about:blank","maskList","width=1500,height=1000,scrollbars=yes");

        var objForm = document.createElement('form');
        var objReq1 = document.createElement('input');
        var objReq2 = document.createElement('input');
        var objReq3 = document.createElement('input');
        var objReq4 = document.createElement('input');
        var objReq5 = document.createElement('input');
        var objReq6 = document.createElement('input');

        objForm.method = 'POST';
        objForm.action = "MaskListCnt";
        // objForm.target = 'maskList';

        objReq1.type = 'hidden'; //入力フォームが表示されないように
        objReq1.name = 'blackPaintList';
        objReq1.value = strJson;

        objReq2.type = 'hidden'; //入力フォームが表示されないように
        objReq2.name = 'tmpDir';
        objReq2.value = glStrTmpDir;

        objReq3.type = 'hidden'; //入力フォームが表示されないように
        objReq3.name = 'strFileName';
        objReq3.value = glFileName;

        objReq4.type = 'hidden'; //入力フォームが表示されないように
        objReq4.name = 'documentId';
        objReq4.value = gldocumentId;

        objReq5.type = 'hidden'; //入力フォームが表示されないように
        objReq5.name = 'intPageCnt';
        objReq5.value = PAGE_COUNT;

        objReq6.type = 'hidden'; //入力フォームが表示されないように
        objReq6.name = 'strFilePath';
        objReq6.value = glFilePath;



        objForm.appendChild(objReq1);
        objForm.appendChild(objReq2);
        objForm.appendChild(objReq3);
        objForm.appendChild(objReq4);
        objForm.appendChild(objReq5);
        objForm.appendChild(objReq6);

        document.body.appendChild(objForm);
        //POST送信フラグを「true」に設定
        $("#top").select();
        isPost = true;
        objForm.submit();


    } //if



} //function


/**
 * 文書保存画面を表示する
 */
function saveMaskProvMask() {

	var blRet = confirm("「一時保存」後に「黒塗り文書保存画面」を表示しないと編集内容が復元できません。\r\n「一時保存」を行って「黒塗り文書保存画面」を表示してよろしいですか?");
	if (blRet) {

	var strJson = makeMaskJson();

        //一時保存処理
        saveTmpDocDelMain(1); //Delete → Insert
        saveTmpDocMain(1);


    var strMaskHtml = glObjMaskFlame.body.outerHTML;
    var strRedHtml = glObjRedFlame.body.outerHTML;


    //別ウィンドウで表示
    // window.open("about:blank","SaveProvMaskCnt","width=1500,height=1000,scrollbars=yes"); arrdocumentId

    var objForm = document.createElement('form');
    var objReq = document.createElement('input');
    var objReq2 = document.createElement('input');
    var objReq3 = document.createElement('input');
    var objReq4 = document.createElement('input');
    var objReq5 = document.createElement('input');
    var objReq6 = document.createElement('input');
    var objReq7 = document.createElement('input');



    objForm.method = 'POST';
    objForm.action = "SaveProvMaskCnt";
    // objForm.target = 'SaveProvMaskCnt';

    objReq.type = 'hidden'; //入力フォームが表示されないように
    objReq.name = 'tmpDir';
    objReq.value = glStrTmpDir;

    objReq2.type = 'hidden'; //入力フォームが表示されないように
    objReq2.name = 'strRedHtml';
    objReq2.value = strRedHtml;

    objReq3.type = 'hidden'; //入力フォームが表示されないように
    objReq3.name = 'strMaskHtml';
    objReq3.value = strMaskHtml;

    objReq4.type = 'hidden'; //入力フォームが表示されないように
    objReq4.name = 'listJson';
    objReq4.value = strJson;

    objReq5.type = 'hidden'; //入力フォームが表示されないように
    objReq5.name = 'strFileName';
    objReq5.value = glFileName;

    objReq6.type = 'hidden'; //入力フォームが表示されないように
    objReq6.name = 'documentId';
    objReq6.value = gldocumentId;

    objReq7.type = 'hidden'; //入力フォームが表示されないように
    objReq7.name = 'strFilePath';
    objReq7.value = glFilePath;


    // objForm.appendChild(objReq);
    objForm.appendChild(objReq2);
    objForm.appendChild(objReq3);
    objForm.appendChild(objReq4);
    objForm.appendChild(objReq5);
    objForm.appendChild(objReq6);
    objForm.appendChild(objReq7);
    document.body.appendChild(objForm);

    //POST送信フラグを「true」に設定
    $("#top").select();
    isPost = true;

    objForm.submit();
	}

} //function



/**
 * 次のページへページネーションする
 */
function pageNext() {
    if (Number(glIntPageAct) !== Number((PAGE_COUNT) - 1) * Number(PAGE_PX)) {
        maskDiv.scrollTo(0, Number(glIntPageAct) + Number(PAGE_PX));
        glIntPageAct += Number(PAGE_PX);
        var intPages = glIntPageAct / Number(PAGE_PX) + 1;
        document.getElementsByClassName('pageNate0')[0].value = "" + intPages;
        document.getElementsByClassName('pageNate1')[0].value = "" + intPages;
    } //if
} //functon

/**
 * 前のページへページネーションする
 */
function pageBack() {
    if (Number(glIntPageAct) !== 0) {
        maskDiv.scrollTo(0, Number(glIntPageAct) - Number(PAGE_PX));
        glIntPageAct -= Number(PAGE_PX);
        var intPages = glIntPageAct / Number(PAGE_PX) + 1;
        document.getElementsByClassName('pageNate0')[0].value = intPages;
        document.getElementsByClassName('pageNate1')[0].value = intPages;
    } //if
} //functon

/**
 * 指定したページへページネーションする
 */
function pageSelect(intTgtPage_i) {
    maskDiv.scrollTo(0, PAGE_PX * intTgtPage_i);
    glIntPageAct += PAGE_PX * intTgtPage_i;
} //functon

/**
 * 最初のページへページネーションする
 */
function pageInit() {
    maskDiv.scrollTo(0, 0);
    glIntPageAct = 0;
} //functon

/**
 * 最後のページへページネーションする
 */
function pageEnd() {
    maskDiv.scrollTo(0, (PAGE_PX * (PAGE_COUNT - 1)));
    glIntPageAct = PAGE_PX * (PAGE_COUNT - 1);
} //functon

/**
 * 選択範囲のouterHTMLを取得する(修正版)
 */
function getSelectionHtml() {
    var html = "";
    var sel = glObjRedFlame.getSelection();
    if (sel.rangeCount) {
        var container = document.createElement("div");
        for (var i = 0, len = sel.rangeCount; i < len; ++i) {
            container.appendChild(sel.getRangeAt(i).cloneContents());
        } //for
        html = container.innerHTML;
        if (glSelectIinitId !== glSelectEndId) {
            var strRegrep = '^.+' + glSelectIinitId + '"\>';
            var objPattern = new RegExp(strRegrep, "gi");
            html = html.replace(objPattern, '');

            strRegrep = glSelectEndId + '">(.+)';
            objPattern = new RegExp(strRegrep, "gi");
            var arrTmp = html.match(objPattern, '');
            var strTmp = arrTmp[0].replace(glSelectEndId + '">', '')

            strRegrep = '\<.*';
            objPattern = new RegExp(strRegrep, "gi");
            strTmp = strTmp.replace(objPattern, '');

            strRegrep = strTmp + '.*';
            objPattern = new RegExp(strRegrep, "gi");
            html = html.replace(objPattern, strTmp);
        } //if
    } //if

    return html;
} //function

/**
 * 左側のテキストボックスに入力したページへページネーションする
 */
function enter0() {
	if ( event.keyCode !== 13 ) { // Enterキー除外
	    return false;
	}
    var arrPages = document.getElementsByClassName('pageNate0');
    var intPage = Number(arrPages[0].value) - 1;
    if ((intPage !== undefined) && (intPage !== -1) && (intPage < PAGE_COUNT) && (intPage >= 0)) {
        pageSelect(intPage);
        var intPages = intPage + 1;
        document.getElementsByClassName('pageNate1')[0].value = "" + intPages;

        glIntPageAct = intPage * Number(PAGE_PX);

    } //if
} //function

/**
 * 右側のテキストボックスに入力したページへページネーションする
 */
function enter1() {
	if ( event.keyCode !== 13 ) { // Enterキー除外
	    return false;
	}
    var arrPages = document.getElementsByClassName('pageNate1');
    var intPage = Number(arrPages[0].value) - 1;
    if ((intPage !== undefined) && (intPage !== -1) && (intPage < PAGE_COUNT) && (intPage >= 0)) {
        pageSelect(intPage);
        var intPages = intPage + 1;
        document.getElementsByClassName('pageNate0')[0].value = intPages;
        glIntPageAct = intPage * Number(PAGE_PX);
    } //if
} //function

/**
 * 「一時保存」ボタン押下処理
 */
function saveTmpDoc() {

    if (glTmpFileFlg) {
        var blRet = confirm("すでに一時保存データがありますが上書きしますか？"); //処理確認
        if (blRet) {
            saveTmpDocDelMain(1); //Delete → Insert
            saveTmpDocMain(0);
        } //if
    } else {
        var blRet = confirm("一時保存を行いますか？"); //処理確認
        if (blRet) {
            saveTmpDocMain(0);
        } //if
    } //if


    return;
} //function

/**
 * 「一時保存」ボタン押下処理メイン
 * @param メッセージ表示status 0:表示 1 非表示
 */
function saveTmpDocMain(status) {

    $("#top").select();
    var strMaskHtml = glObjMaskFlame.body.outerHTML;
    var strRedHtml = glObjRedFlame.body.outerHTML;
    var arrTmpDir = [glStrTmpDir];
    var arrStrRedHtml = [strRedHtml];
    var arrStrMaskHtml = [strMaskHtml];
    var arrStrFileName = [glFileName];
    var arrdocumentId = [gldocumentId];

    //hashを作成してjsonで送付
    let HashJson = {
        'tmpDir': arrTmpDir,
        'strRedHtml': arrStrRedHtml,
        'strMaskHtml': arrStrMaskHtml,
        'strFileName': arrStrFileName,
        'documentId': arrdocumentId,
        'glArrBfIds': glArrBfIds,
        'glArrAfIds': glArrAfIds,
        'glArrPolicys': glArrPolicys,
        // 'glArrPolicys': arrSavePolicy,
        'glRemarks': glRemarks
    };

    $.ajax({
        type: 'POST',
        url: 'blackpaint/SaveTmpDocCnt',
        data: '[' + JSON.stringify(HashJson) + ']', //連想配列をJSONに変換
        dataType: "json",
        processData: false, // Ajaxがdataを整形しない指定
        contentType: false, // contentTypeもfalseに指定(Fileをアップロード時は必要)
        async: false, //非同期false
        success: function (retData) {
            console.log("success");
            //btnFlg処理
            glTmpFileFlg = true;
            tmpBtnStateRemove();
            if (status === 0) {
                alert("一時保存しました。");
            } //if
            return false;
        }, //function
        error: function (e) {
            console.log("fail");
            if (status === 0) {
                alert("一時保存に失敗しました。")
            } //if
            return false;
        } //function
    }); //ajax


} //saveTmpDoc


/**
 * 「一時保存再開」ボタン押下処理
 */
function SaveTmpReopen() {
    var blRet = false;
    blRet = isTmpBtn();
    if (blRet) {
        return;
    } //if

    blRet = confirm("一時保存していたデータを再開しますか？"); //処理確認
    if (blRet) {
        SaveTmpReopenMain(0);
    } //if
    return;
} //function

/**
 * 「一時保存再開」ボタン押下処理Main
 * @param メッセージ表示status 0:表示 1 非表示
 */
function SaveTmpReopenMain(status) {

    $("#top").select();
    $.ajax({
        type: 'POST',
        url: 'blackpaint/SaveTmpReopen',
        data: gldocumentId,
        dataType: "json",
        processData: false, // Ajaxがdataを整形しない指定
        contentType: false, // contentTypeもfalseに指定(Fileをアップロード時は必要)
        async: false, //非同期false
        success: function (retData) {
            console.log("success");
            //iframe再読み込み
            $(document).ready(function () {
                $('#red').each(function () {
                    this.contentWindow.location.reload(true);
                });
            });
            $(document).ready(function () {
                $('#mask').each(function () {
                    this.contentWindow.location.reload(true);
                });
            });
            $("#top").select();
            if (status === 0) {
                alert("一時保存していたデータを再開します");
            } //if

            //gl変数初期化
            glArrBfIds = []; //黒塗り先頭ID
            glArrAfIds = []; //黒塗り終了ID
            glArrPolicys = []; //黒塗り対象のIDに紐づくポリシーID
            glarrRepOuter = []; //黒塗り候補変更後のOuterHtml
            glRemarks = []; //黒塗りリストの備考
            for (let i = 0; i < retData.length; i++) {
                glArrBfIds[i] = retData[i].markerStartCd;
                glArrAfIds[i] = retData[i].markerEndCd;
                glArrPolicys[i] = retData[i].markerPolicy;
                glRemarks[i] = retData[i].markerRemarks;
            } //for

            //マスク候補とマスクの初期処理一部を走らせる
            $('#red').on('load', function () {
                glObjRedFlame = document.getElementById("red").contentDocument;
                glObjRedBody = glObjRedFlame.body;
                //Event追加
                //コンテキストメニュー
                glObjRedBody.oncontextmenu = function () { //デフォルト無効
                    return false;
                };
                glObjRedBody.addEventListener("mousedown", mouseDownAct, false);
                glObjRedBody.addEventListener('mouseup', mouseUpAct, false);
                glObjRedBody.addEventListener('contextmenu', contextFunc, false);
                //黒塗り箇所範囲選択用のOuterHtmlを作成する
                makeMaskOuter();
            });// function

            $('#mask').on('load', function () {
                glObjMaskFlame = document.getElementById("mask").contentDocument;
                glObjMaskBody = glObjMaskFlame.body;
            });// function

            return false;
        }, //function
        error: function (e) {
            console.log("fail");
            return false;
        } //function
    }); //ajax

} //SaveTmpReopen

/**
 * 他画面からCancel動作で画面遷移した際呼び込む関数
 * @param メッセージ表示status 0:表示 1 非表示
 */
function CancelBack(status) {

    $("#top").select();
    $.ajax({
        type: 'POST',
        url: 'blackpaint/SaveTmpReopen',
        data: gldocumentId,
        dataType: "json",
        processData: false, // Ajaxがdataを整形しない指定
        contentType: false, // contentTypeもfalseに指定(Fileをアップロード時は必要)
        async: false, //非同期false
        success: function (retData) {
            console.log("success");
            //iframe再読み込み
            $(document).ready(function () {
                $('#red').each(function () {
                    this.contentWindow.location.reload(true);
                });
            });
            $(document).ready(function () {
                $('#mask').each(function () {
                    this.contentWindow.location.reload(true);
                });
            });
            $("#top").select();
            if (status === 0) {
                alert("一時保存していたデータを再開します");
            } //if

            //bootOpenとおるのでglEditMarkerをつくる必要
            glEditMarker = "";
            for (let i = 0; i < retData.length; i++) {
                glEditMarker+=retData[i].markerStartCd+":";
                glEditMarker+=retData[i].markerEndCd+":";
                glEditMarker+=retData[i].markerPolicy+"+";
                //glRemarksはつくっておく
                glRemarks[i] = retData[i].markerRemarks;
            } //for
            glEditMarker = glEditMarker.substr(0,glEditMarker.length - 1);

            return false;
        }, //function
        error: function (e) {
            console.log("fail");
            return false;
        } //function
    }); //ajax

} //function

/**
 * 黒塗りリスト画面で「確定」ボタン押下した際呼び込む関数
 * @param json配列
 */
function confirmBack(glblackPaintList) {

    //gl変数初期化(備考のみ)
    glRemarks = glblackPaintList.Remarks; //黒塗りリストの備考

} //function

/**
 * 「一時保存削除」ボタン押下処理
 */
function saveTmpDocDel() {

    var blRet = false;
    blRet = isTmpBtn();
    if (blRet) {
        return;
    } //if

    blRet = confirm("一時保存削除を行いますか？"); //処理確認
    if (blRet) {
        saveTmpDocDelMain(0);
    } //if
    return;
} //function

/**
 * 「一時保存」ボタン押下処理メイン
 * @param メッセージ表示status 0:表示 1 非表示
 */
function saveTmpDocDelMain(status) {

    $("#top").select();
    var arrdocumentId = [gldocumentId];
    //hashを作成してjsonで送付
    let HashJson = {
        'documentId': arrdocumentId
    };

    $.ajax({
        type: 'POST',
        url: 'blackpaint/SaveTmpDelDocCnt',
        data: '[' + JSON.stringify(HashJson) + ']', //連想配列をJSONに変換
        dataType: "json",
        processData: false, // Ajaxがdataを整形しない指定
        contentType: false, // contentTypeもfalseに指定(Fileをアップロード時は必要)
        async: false, //非同期false
        success: function (retData) {
            //btnFlg処理
            glTmpFileFlg = false;
            tmpBtnStateCng();
            console.log("success");
            if (status === 0) {
                alert("一時保存削除しました。")
            } //if

            return false;
        }, //function
        error: function (e) {
            console.log("fail");
            if (status === 0) {
                alert("一時保存削除に失敗しました。");
            }//if
            return false;
        } //function
    }); //ajax


} //function


/**
 * 「一時保存」にデータが保存されているか確認する
 * @return true 保存されている false 保存されていない
 */
function TmpInfoGet() {

    $("#top").select();
    var blRet = false;
    //hashを作成してjsonで送付
    let HashJson = {
        'documentId': gldocumentId
    };

    $.ajax({
        type: 'POST',
        url: 'blackpaint/rest/tmpinfo',
        data: '[' + JSON.stringify(HashJson) + ']', //連想配列をJSONに変換
        dataType: "json",
        processData: false, // Ajaxがdataを整形しない指定
        contentType: false, // contentTypeもfalseに指定(Fileをアップロード時は必要)
        async: false, //非同期false
        success: function (retData) {
            console.log("success");
            var objJson = JSON.parse(retData);
            blRet = Boolean(objJson);
            glTmpFileFlg = blRet; //returnがうまくいかないのでGL変数に格納
        }, //function
        error: function (e) {
            console.log("fail");
            glTmpFileFlg = false;
            // return false;
        } //function
    }); //ajax
    // return blRet;
} //function

/**
 * 次のページへページネーションする
 */
function pageRefNext() {
    if (Number(glIntPageRefAct) !== Number((REFPAGE_COUNT) - 1) * Number(PAGE_PX)) {
        refDiv.scrollTo(0, Number(glIntPageRefAct) + Number(PAGE_PX));
        glIntPageRefAct += Number(PAGE_PX);
        var intPages = glIntPageRefAct / Number(PAGE_PX) + 1;
        document.getElementsByClassName('pageNateRef')[0].value = "" + intPages;
    } //if
} //functon

/**
 * 前のページへページネーションする
 */
function pageRefBack() {
    if (Number(glIntPageRefAct) !== 0) {
        refDiv.scrollTo(0, Number(glIntPageRefAct) - Number(PAGE_PX));
        glIntPageRefAct -= Number(PAGE_PX);
        var intPages = glIntPageRefAct / Number(PAGE_PX) + 1;
        document.getElementsByClassName('pageNateRef')[0].value = intPages;
    } //if
} //functon

/**
 * 指定したページへページネーションする
 */
function pageRefSelect(intTgtPage_i) {
    refDiv.scrollTo(0, PAGE_PX * intTgtPage_i);
    glIntPageRefAct += PAGE_PX * intTgtPage_i;
} //functon


/**
 * 右側のテキストボックスに入力したページへページネーションする
 */
function enterRef() {
	if ( event.keyCode !== 13 ) { // Enterキー除外
	    return false;
	}
    var arrPages = document.getElementsByClassName('pageNateRef');
    var intPage = Number(arrPages[0].value) - 1;
    if ((intPage !== undefined) && (intPage !== -1) && (intPage < REFPAGE_COUNT)&& (intPage >= 0)) {
        pageRefSelect(intPage);
        glIntPageRefAct = intPage * Number(PAGE_PX);
    } //if
} //function


/**
 * 図・表をマスクする
 * @param イベント
 */
function changeMaskImg() {
    //黒塗り候補側処理
    var strTgtID = glSelectEndId;
    var objRedTgt = glObjRedFlame.getElementById(strTgtID);
    //図表がリストに表示されない修正
    objRedTgt.classList.add(RED_INIT_CLS);
    objRedTgt.classList.add(RED_IMG);
    var intRedImgClsLen = RED_IMG.length; //クラス分の長さを覚えておく
    var strMaskId=strTgtID.replace('red','msk');
    var objMskTgt = glObjMaskFlame.getElementById(strMaskId);
    //黒塗り側処理
    var srcMask = strFileWithoutExtension+"/m"; //mask用src画像
    var intSrdMaskLen = srcMask.length;
    var strSrc =objMskTgt.getAttribute("src");
    var intSrcLen = strSrc.length;
    var intOffcetLen = intSrcLen - intSrdMaskLen;
    var strDummyCls='';
    for (let i = 0; i < intOffcetLen + intRedImgClsLen; i++) {
        strDummyCls+="0";
    } //for
    var srcMakeSrc =srcMask;
    objMskTgt.src = srcMakeSrc;
    objMskTgt.classList.add(strDummyCls);

    //配列情報を格納
    glArrBfIds.push(strTgtID);
    glArrAfIds.push(strTgtID);
    glArrPolicys.push(glChartId);
    glarrRepOuter.push(objRedTgt.outerHTML);
    contextNone();

} //function


/**
 * 図・表のマスクを元に戻す
 * @param イベント
 */
function returnMaskImg() {
    //黒塗り候補側処理
    var strTgtID = glSelectEndId;
    var objRedTgt = glObjRedFlame.getElementById(strTgtID);
    var strOrgImg = objRedTgt.getAttribute("src"); //オリジナル画像を取得しておく

//    objRedTgt.classList.remove(RED_INIT_CLS+' '+RED_IMG);
    objRedTgt.classList.remove(RED_INIT_CLS)
     objRedTgt.classList.remove(RED_IMG)

    // var intRedImgClsLen = RED_IMG.length; //クラス分の長さを覚えておく
    var strMaskId=strTgtID.replace('red','msk');
    var objMskTgt = glObjMaskFlame.getElementById(strMaskId);
    //黒塗り側処理
    var strRegrep = "^0*$"; //0埋め判定
    var objPattern = new RegExp(strRegrep, "gi");
    var listClass = objMskTgt.classList;
    for (let i = 0; i < listClass.length; i++) {
        var strTgtCls = listClass[i];
        if (objPattern.test(strTgtCls)) {
            objMskTgt.classList.remove(strTgtCls);
            break;
        } //if
    } //for

    //src入れ替え
    objMskTgt.src = strOrgImg;

    //配列要素から削除
    var intIndex = glArrBfIds.indexOf(glActBfId);
    glArrBfIds.splice(intIndex, 1);
    glArrAfIds.splice(intIndex, 1);
    glArrPolicys.splice(intIndex, 1);
    glarrRepOuter.splice(intIndex, 1);
    contextNone();

} //function

/**
 * 図・表をマスクする(Svg用)
 * @param イベント
 */
function changeMaskSvg() {
    //黒塗り候補側処理
    var strTgtID = glSelectEndId;
    var objRedTgt = glObjRedFlame.getElementById(strTgtID);
    //図表がリストに表示されない修正
    objRedTgt.classList.add(RED_INIT_CLS);
    objRedTgt.classList.add(RED_IMG);
    // var intRedImgClsLen = RED_IMG.length; //クラス分の長さを覚えておく
    var strMaskId=strTgtID.replace('red','msk');
    var objMskTgt = glObjMaskFlame.getElementById(strMaskId);
    //黒塗り側処理
    var srcMask = strFileWithoutExtension+"/m"; //mask用src画像
    //svgタグ自体をimgタグに置き換える
    var maskSvgWidth = objMskTgt.width.baseVal.valueAsString;
    var maskSvgHeight = objMskTgt.height.baseVal.valueAsString;
    var maskImgTagOuter = '<img id="'+strMaskId+'" src="'+srcMask+'" width="'+maskSvgWidth+'" height="'+maskSvgHeight+'">';
    objMskTgt.outerHTML = maskImgTagOuter;
    objMskTgt=glObjMaskFlame.getElementById(strMaskId); //outerを置き換えたので更新
    //svgタグ自体をimgタグに置き換える end

    //outerHtmlの長さを合わせる
    var intRedImgClsLen = objRedTgt.outerHTML.length; //outerHTMLの長さ
    var intMskImgClsLen = objMskTgt.outerHTML.length; //outerHTMLの長さ
    var intOffcetLen = intRedImgClsLen - intMskImgClsLen;
    // var intSrdMaskLen = srcMask.length;
    // var strSrc =objMskTgt.getAttribute("src");
    // var intSrcLen = strSrc.length;
    // var intOffcetLen = intSrcLen - intSrdMaskLen;
    var strDummyCls='';
    for (let i = 0; i < intOffcetLen + intRedImgClsLen; i++) {
        strDummyCls+="0";
    } //for
    // var srcMakeSrc =srcMask;
    // objMskTgt.src = srcMakeSrc;
    objMskTgt.classList.add(strDummyCls);

    //配列情報を格納
    glArrBfIds.push(strTgtID);
    glArrAfIds.push(strTgtID);
    glArrPolicys.push(glChartId);
    glarrRepOuter.push(objRedTgt.outerHTML);
    contextNone();

} //function


/**
 * 図・表のマスクを元に戻す(Svg用)
 * @param イベント
 */
function returnMaskSvg() {
    //黒塗り候補側処理
    var strTgtID = glSelectEndId;
    var objRedTgt = glObjRedFlame.getElementById(strTgtID);
    var strOrgImg = objRedTgt.getAttribute("src"); //オリジナル画像を取得しておく

//    objRedTgt.classList.remove(RED_INIT_CLS+' '+RED_IMG);
    objRedTgt.classList.remove(RED_INIT_CLS)
     objRedTgt.classList.remove(RED_IMG)

    // var intRedImgClsLen = RED_IMG.length; //クラス分の長さを覚えておく
    var strMaskId=strTgtID.replace('red','msk');
    var objMskTgt = glObjMaskFlame.getElementById(strMaskId);
    //黒塗り側処理
    var strRegrep = "^0*$"; //0埋め判定
    var objPattern = new RegExp(strRegrep, "gi");
    var listClass = objMskTgt.classList;
    for (let i = 0; i < listClass.length; i++) {
        var strTgtCls = listClass[i];
        if (objPattern.test(strTgtCls)) {
            objMskTgt.classList.remove(strTgtCls);
            break;
        } //if
    } //for

    //src入れ替え
    objMskTgt.src = strOrgImg;

    //配列要素から削除
    var intIndex = glArrBfIds.indexOf(glActBfId);
    glArrBfIds.splice(intIndex, 1);
    glArrAfIds.splice(intIndex, 1);
    glArrPolicys.splice(intIndex, 1);
    glarrRepOuter.splice(intIndex, 1);
    contextNone();

} //function





/**
 * マウスホバー時のポリシー名表示
 * @param イベント
 */
function mousOverAct(e) {
    var strHover = "<div class='arrow'></div><div class='popover-content'></div>";
    var strPolicyName="";
    if (e.target.classList.contains(TAG_RED)){
        //ポリシー名引当て
        var intTgtIdIdx=Number(e.target.id.replace("red","",e.target.id));


        	 var intCnt = 1000000;
             var strBfId="";
             var i =0;

             while(true){
                 var strTgtId = "red"+String(intTgtIdIdx - i);
                 if (glArrBfIds.indexOf(strTgtId)>=0) {
                     strBfId=strTgtId;
                     break;
                 } //if
                 i++;
                 intCnt--;
                 if(0>intCnt){ //フェールセーフ
                	 console.log("カウントが「"+intCnt+"」になったため、ポリシー検索を中断");
                     break;
                 } //if
             } //while

        if(glIntTgtIdIdx==strBfId){
        	var intIndex=glArrBfIds.indexOf(strBfId);
            var intTgtPolicyId=glArrPolicys[intIndex];
            strPolicyName = glHashPolicy[intTgtPolicyId];
            var objTgtDom = document.getElementById("polocyinfo");
            strHover+=strPolicyName + '</div>';
            objTgtDom.innerHTML = strHover;

            objTgtDom.style.left = glIntTgtIdLef + "px";
            objTgtDom.style.top = glIntTgtIdTop + "px";

            objTgtDom.style.display = "block";

        }else{

             glIntTgtIdIdx=strBfId;

             var intIndex=glArrBfIds.indexOf(strBfId);
             var intTgtPolicyId=glArrPolicys[intIndex];
             strPolicyName = glHashPolicy[intTgtPolicyId];
             var objTgtDom = document.getElementById("polocyinfo");
             strHover+=strPolicyName + '</div>';

             objTgtDom.innerHTML = strHover;
             objTgtDom.style.left = e.screenX - 0 - window.screenX - OFFCET_X + "px";
             objTgtDom.style.top = e.screenY - 100 - window.screenY - OFFCET_X + "px";

             glIntTgtIdLef = objTgtDom.style.left;
             glIntTgtIdTop = objTgtDom.style.top;

             objTgtDom.style.display = "block";
        }


    } else if(e.target.classList.contains(RED_IMG)){
    	if(glIntTgtIdIdx==strBfId){
    		strPolicyName = CHART_POLICY;
            var objTgtDom = document.getElementById("polocyinfo");
            strHover+=strPolicyName + '</div>';
            objTgtDom.innerHTML = strHover;
            objTgtDom.style.left = glIntTgtIdLef + "px";
            objTgtDom.style.top = glIntTgtIdTop + "px";
            objTgtDom.style.display = "block";
    	}else{
    		glIntTgtIdIdx=strBfId;
    		strPolicyName = CHART_POLICY;
            var objTgtDom = document.getElementById("polocyinfo");
            strHover+=strPolicyName + '</div>';
            objTgtDom.innerHTML = strHover;
            objTgtDom.style.left = e.screenX - 0 - window.screenX - OFFCET_X + "px";
            objTgtDom.style.top = e.screenY - 100 - window.screenY - OFFCET_X + "px";
            objTgtDom.style.display = "block";
    	}


    } //if
} //function

/**
 * マウスホバーアウト時のアクション
 * @param イベント
 */
function mousOutAct(e) {
    var objTgtDom = document.getElementById("polocyinfo");
    objTgtDom.style.display = "none";
}//function


function disRef() {

	var blRet = confirm("「一時保存」後に「参照文書検索画面」を表示しないと編集内容が復元できません。\r\n「一時保存」を行って「参照文書検索画面」を表示してよろしいですか?");
	if (blRet) {

		 //一時保存処理
        saveTmpDocDelMain(1); //Delete → Insert
        saveTmpDocMain(1);

		var objForm = document.createElement('form');
	    var objReq = document.createElement('input');


	    objForm.method = 'GET';
	    objForm.action = "docManage/searchReferenceFile";

	    objReq.type = 'hidden'; //入力フォームが表示されないように
	    objReq.name = 'documentId';
        objReq.value = gldocumentId;

	    objForm.appendChild(objReq);

	    document.body.appendChild(objForm);

        //POST送信フラグを「true」に設定
        $("#top").select();
        isPost = true;

	    objForm.submit();
	}


    /*var objMaskDiv= $('.maskDoc');
    var objRefDiv= $('.refDoc');

    var objMaskBut= $('.maskPage');
    var objRefBut= $('.refPage');

    var refbutton =document.getElementById("SANSHOU_BUNSHO_HYOUJI");

    if (objRefDiv.hasClass("blindframe")) {
    	objMaskDiv.removeClass("openframe");
    	objMaskDiv.addClass("blindframe");
    	objMaskBut.removeClass("openframe");
    	objMaskBut.addClass("blindframe");

        objRefDiv.removeClass("blindframe");
        objRefDiv.addClass("openframe");
        objRefBut.removeClass("blindframe");
        objRefBut.addClass("openframe");

        refbutton.innerHTML = refbutton.innerHTML.replace("参照文書表示","黒塗り表示");
        refbutton.classList.toggle("on");

    }else{
    	objMaskDiv.removeClass("blindframe");
    	objMaskDiv.addClass("openframe");
    	objMaskBut.removeClass("blindframe");
    	objMaskBut.addClass("openframe");

        objRefDiv.removeClass("openframe");
        objRefDiv.addClass("blindframe");
        objRefBut.removeClass("openframe");
        objRefBut.addClass("blindframe");

        refbutton.innerHTML = refbutton.innerHTML.replace("黒塗り表示","参照文書表示");
        refbutton.classList.toggle("on");
    }*/
}

function closeMaskDoc() {
	var blSel = confirm("本当にキャンセル操作をしますか？");
    if (blSel) {

    var blRet = confirm("「一時保存」後に「黒塗り文書作成画面」を閉じないと編集内容が復元できません。\r\n「黒塗り文書作成画面」を閉じる際に、「一時保存」を実施しますか?");
    if (blRet) {
        // if (!window.opener || !Object.keys(window.opener).length) {
        //     alert("元画面が存在しません。");

        //一時保存処理
        saveTmpDocDelMain(1); //Delete → Insert
        saveTmpDocMain(1);
        //POST送信フラグを「true」に設定
        $("#top").select();
        isPost = true;

        try {
            if((window.opener) && (Object.keys(window.opener).length)){
                if(window.opener.SearchMain && typeof window.opener.SearchMain.afterChildClose === 'function'){
                    window.opener.SearchMain.afterChildClose();
                } //if
            } //if
        } catch (error) {
            console.log(error);
        } finally{
            window.close();
        } //try

    } else{

        isPost = true;
        try {
            if((window.opener) && (Object.keys(window.opener).length)){
                if(window.opener.SearchMain && typeof window.opener.SearchMain.afterChildClose === 'function'){
                    window.opener.SearchMain.afterChildClose();
                } //if
            } //if
        } catch (error) {
            console.log(error);
        } finally{
            window.close();
        } //try
    } //if

    }//if

} //function

/**
 * ユーザーIDをセットする
 */
function setUserId() {

    var strUserId = "";
    try {
        strUserId=DomainCookie.getUserId();
    } catch (error) {
        console.log("DOMAINCookieは設定されていません");
        strUserId="";
    } //try

    $.ajax({
        type: 'GET',
        url: 'rest/useidset?userId=' + strUserId,
        processData: false, // Ajaxがdataを整形しない指定
        contentType: false, // contentTypeもfalseに指定(Fileをアップロード時は必要)
        async: false, //非同期false
        success: function (retData) {
            console.log("success");
            return false;
        }, //function
        error: function (e) {
            console.log("fail");
            return false;
        } //function
    }); //ajax
} //function

/**
 * ユーザーIDがセットされているかチェックする
 * @return boolean true セットされている false セットされていない
 */
function isUserId() {
    var strCookieIds = document.cookie.split(';');
    var blRet =false;
	for(let i=0 ; i< strCookieIds.length  ; i++){
		var objUserKey = strCookieIds[i].split('=')
    	if( objUserKey[0].indexOf("user_id")>=0){
            blRet = true;
            return blRet;
    	} //if
    } //for
    return blRet;

} //function



/**
 * ユーザー名をセットする
 */
function setUserName() {

    var strUserName = "";
    try {
        strUserName=DomainCookie.getUserName();
    } catch (error) {
        console.log("DOMAINCookieは設定されていません");
        strUserName="";
    } //try

    $.ajax({
        type: 'GET',
        url: 'rest/usernameset?userName=' + strUserName,
        processData: false, // Ajaxがdataを整形しない指定
        contentType: false, // contentTypeもfalseに指定(Fileをアップロード時は必要)
        async: false, //非同期false
        success: function (retData) {
            console.log("success");
            return false;
        }, //function
        error: function (e) {
            console.log("fail");
            return false;
        } //function
    }); //ajax
} //function

/**
 * ユーザー名がセットされているかチェックする
 * @return boolean true セットされている false セットされていない
 */
function isUserName() {
    var strCookieIds = document.cookie.split(';');
    var blRet =false;
	for(let i=0 ; i< strCookieIds.length  ; i++){
		var objUserKey = strCookieIds[i].split('=')
    	if( objUserKey[0].indexOf("user_name")>=0){
            blRet = true;
            return blRet;
    	} //if
    } //for
    return blRet;

} //function



