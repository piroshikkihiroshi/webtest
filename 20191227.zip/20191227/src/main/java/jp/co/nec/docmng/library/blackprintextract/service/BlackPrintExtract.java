package jp.co.nec.docmng.library.blackprintextract.service;


import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import jp.co.nec.docmng.library.blackprintextract.entity.BlackPrintPlace;;

public class BlackPrintExtract {

    /**
    * extractBlackPrintPlaceメソッド
    * @param ID 抽出対象の文書ID。 in。
    * @return 黒塗候補箇所情報を返す。
    * @throws Exception 入力IDに該当する文書が見つからない等の場合にExceptionを投げる。
    */
	public List<BlackPrintPlace> extractBlackPrintPlace(int ID) throws Exception {
		String text = getDocumentText(ID);
		List<BlackPrintPlace> list = extract(text);
		return list;
	}

    /**
    * getDocumentTextメソッド
    * @param ID 抽出対象の文書ID。 in。
    * @return 指定された文書IDの本文。
    * @throws Exception 入力IDに該当する文書の本文取得に失敗した場合にExceptionを投げる。
    */
	private String getDocumentText(int ID) {
		String filename = "src/main/resources/" + ID + ".txt";
		Path file = Paths.get(filename);
		if (!file.toFile().exists())
			return null;
		String text = null;
		try {
			text = new String(Files.readAllBytes(file));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 		return text;
	}
	
    /**
    * getDocumentText4Stubメソッド
    * @param ID 抽出対象の文書ID。 in。
    * @return 指定された文書IDの本文。
    * @throws Exception 入力IDに該当する文書の本文取得に失敗した場合にExceptionを投げる。
    */
	public String getDocumentText4Stub(int ID) {
		String filename = "src/main/resources/" + ID + ".txt";
		Path file = Paths.get(filename);
		if (!file.toFile().exists())
			return null;
		String text = null;
		try {
			text = new String(Files.readAllBytes(file));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 		return text;
	}
	
    /**
    * extractメソッド
    * @param text 抽出対象の文書の本文。 in。
    * @return 黒塗候補箇所情報。 out。
    */
	private List<BlackPrintPlace> extract(String text) {
		List<BlackPrintPlace> list = dummy(text);
		return list;		
	}
	
    /**
    * dummyメソッド
    * stub用のダミー抽出器
    * @param text 抽出対象の文書の本文。 in。
    * @return 黒塗候補箇所情報。 out。
    */
	private List<BlackPrintPlace> dummy(String text) {
		final String[] policy = {"内閣", "防衛", "日本"};
		List<BlackPrintPlace> list = new ArrayList<BlackPrintPlace>();
		
		for (int i = 0; i < policy.length; i++) {
			String keyword = policy[i];
	        int end = 0;
	        do {
	        	int start = text.indexOf(keyword, end);
	        	if (start != -1) {
	        		end = start + keyword.length();
	        		BlackPrintPlace place = new BlackPrintPlace();
	        		place.setPolicyID(i+1);
	        		place.setStart(start);
	        		place.setEnd(end);
	        		list.add(place);
	        	}
	        	else 
	        		break;
	        } while (true);			
		}
		return list;
	}
}
