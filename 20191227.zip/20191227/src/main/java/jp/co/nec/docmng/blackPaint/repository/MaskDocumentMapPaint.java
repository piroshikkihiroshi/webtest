package jp.co.nec.docmng.blackPaint.repository;


import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import jp.co.nec.docmng.blackPaint.entity.MaskDocumentEntBlackPaint;


@Mapper
public interface MaskDocumentMapPaint {

	//table mask_document

	@Insert("INSERT INTO common.mask_document(document_id, user_id, html_zip_data, create_time, update_time) VALUES (#{document_id}, #{user_id}, #{html_zip_data}, #{create_time}, #{update_time})")
    public void insertMaskDocument(MaskDocumentEntBlackPaint MaskDocumentEnt);

	@Select("SELECT html_zip_data FROM common.mask_document WHERE document_id = #{document_id} and user_id = #{user_id}")
    public List<MaskDocumentEntBlackPaint> getHtmlZip(Integer document_id,String user_id);

	@Select("SELECT document_id FROM common.mask_document WHERE document_id = #{document_id} and user_id = #{user_id}")
    public List<MaskDocumentEntBlackPaint> isDoc(Integer document_id,String user_id);

	@Delete("DELETE FROM common.mask_document WHERE document_id = #{document_id} and user_id = #{user_id}")
    public void deleteDoc(Integer document_id,String user_id);



} //interface
