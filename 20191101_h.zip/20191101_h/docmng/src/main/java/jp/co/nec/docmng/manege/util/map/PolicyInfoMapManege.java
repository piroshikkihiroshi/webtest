package jp.co.nec.docmng.manege.util.map;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import jp.co.nec.docmng.manege.entity.PolicyInfoEntity;

@Mapper
public interface PolicyInfoMapManege {

    @Select("select * from admin.policy_info order by policy_id")
    public List<PolicyInfoEntity> findAll();

}
