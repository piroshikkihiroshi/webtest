package jp.co.nec.docmng.manege.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import jp.co.nec.docmng.manege.entity.PolicyInfoEntity;
import jp.co.nec.docmng.manege.entity.TmpTeacherPolicyList;
import jp.co.nec.docmng.manege.service.PolicyInfoService;
import jp.co.nec.docmng.manege.service.TmpTeacherPolicyService;

@Controller
@RequestMapping("/manege/training_policy")
public class TrainingPolicyController {

    @Autowired
    PolicyInfoService policyInfoService;
    @Autowired
    TmpTeacherPolicyService tmpTeacherPolicyService;

    @GetMapping
    public String getTrainingPolicy(Model model) {
        // 全件取得
        List<PolicyInfoEntity> policyInfos = policyInfoService.findAll();
        model.addAttribute("policyInfo", policyInfos);

        System.out.println(policyInfos);
//
        List<TmpTeacherPolicyList> teacherPolicyLists = tmpTeacherPolicyService.findAll();
        model.addAttribute("teacherPolicyList", teacherPolicyLists);


        System.out.println(teacherPolicyLists);

//        model.addAttribute("");

        return "manege/training_policy";
    }

}
