package jp.co.nec.docmng.blackPaint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.docmng.blackPaint.entity.PolicyInfoEntBlackPaint;
import jp.co.nec.docmng.blackPaint.repository.PolicyInfoMapPaint;


@Service
public class PolicyInfoServiceApi {
	 @Autowired
	 private  PolicyInfoMapPaint objPolicyInfoMapper;
	 @Transactional
	 public List<PolicyInfoEntBlackPaint> findAll() {
	  // 全件
	  return objPolicyInfoMapper.findAll();
	 } //findAll
} //PolicyInfoServiceApi
