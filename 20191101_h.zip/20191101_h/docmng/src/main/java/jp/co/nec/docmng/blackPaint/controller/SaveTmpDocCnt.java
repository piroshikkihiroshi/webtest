/**
 * 名称：SaveTmpDocCnt.java
 * 機能名：一時保存Control
 * 概要：一時保存機能のControlを行う。
 */

package jp.co.nec.docmng.blackPaint.controller;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;

import org.apache.commons.io.FileUtils;
import org.jsoup.nodes.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.blackPaint.logic.HtmlToPdf.HtmlToPdfModel;
import jp.co.nec.docmng.blackPaint.logic.dirFile.FileCnt;

/**
 * 一時保存機能のControlを行う。
 */
@RestController
//@Controller
public class SaveTmpDocCnt {

	/**
	 * context サーブレットのRealPathを取得する
	 * objLog log出力に使用する
	 * PAGE_CLASS ページを判定するHTMLClass。ページをSplitするのに使用する
	 * ARR_HEAD ファイル名、フォルダ名を判定するために使用する
	 */
	@Autowired
	ServletContext context;
	static Logger objLog = LoggerFactory.getLogger(SaveTmpDocCnt.class);

	static String PAGE_CLASS = "awdiv awpage"; //splitするページのHTMLClass
	static String[] ARR_HEAD = {"mask_","red_"}; //ファイル名、フォルダ名のヘッダー配列

	/**
	 * 一時保存メソッド
	 * 一時保存を押下したときのの処理をする。
	 * @param strTmpDir_i 黒塗り編集画面で処理したHTMLが格納されたTMPディレクトリ名。
	 * @param strRedHtml_i 黒塗り編集候補HTMLのouterHTML。
	 * @param strMaskHtml_i 黒塗り編集HTMLのouterHTML。
	 * @param strFileName_i オリジナルwordファイル名。
	 */
	@ResponseBody
	@PostMapping("/SaveTmpDocCnt")
	public String SaveTmpDocCntRest(
			@RequestBody String strHashJson,
			Model model) {

		//モデル初期化
		FileCnt objFileCnt = new FileCnt();
		HtmlToPdfModel objPdfCls = new HtmlToPdfModel();

		//メンバ変数初期化
		String strTmpDir=""; //黒塗り編集画面で処理したHTMLが格納されたTMPディレクトリ名。
		String strRedHtml=""; //黒塗り編集候補HTMLのouterHTML。
		String strMaskHtml=""; //黒塗り編集HTMLのouterHTML。
		String strFileName=""; //オリジナルwordファイル名。


		Document objDoc=null;
		String strBasePath =""; //黒塗り作成時の作業フォルダ
		String strHead=""; //ファイル名、フォルダ名のヘッダー
		String strFileOutDir=""; //PDF出力フォルダ
		String strHtmlDir=""; //黒塗り作成時HTMLに対するimg,css等が入っているフォルダ
		String strRealPath = context.getRealPath("/");
		String strOrgFileName = ""; //オリジナルwordファイル名
		String strRelativePath = ""; //iFrameに表示するための相対パス
		int intPages = 0; //PDFページ枚数
		String strTmpTimeStamp=""; //tempファイルタイムスタンプ
		strTmpTimeStamp=String.valueOf(System.currentTimeMillis());

		//POSTされたjsonをパースする
		ObjectMapper objMapper = new ObjectMapper();
		List<Map<String, String>> objTmpList = null;
		TypeReference<List<Map<String, String>>> objType = new TypeReference<List<Map<String, String>>>() {};
		try {
			objTmpList = objMapper.readValue(strHashJson, objType);
		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		} catch (IOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		} //try

		HashMap<String, String> objMap = (HashMap<String, String>) objTmpList.get(0);

		for (String strKey : objMap.keySet()) {
			switch (strKey) {
			case "tmpDir":
				strTmpDir = objMap.get(strKey);
				break;
			case "strRedHtml":
				strRedHtml = objMap.get(strKey);
				break;
			case "strMaskHtml":
				strMaskHtml = objMap.get(strKey);
				break;
			case "strFileName":
				strFileName = objMap.get(strKey);
				break;
			default:
				break;
			}

		} //for


		//拡張子無しファイル名取得
		String strFileWithoutExtension = objFileCnt.getNameWithoutExtension(strOrgFileName);

		//黒塗り候補HTMLの作成 黒塗りHTMLの作成
		for (int intIndex = 0; intIndex < ARR_HEAD.length; intIndex++) {
			strHead=ARR_HEAD[intIndex];
			strBasePath=strRealPath + strTmpDir ;
			FileWriter objFile=null;
			PrintWriter objPw=null;
			try {

				String strGetHtml = "";
				if(strHead.equals("mask_")) {
					strGetHtml = strMaskHtml;
				}else {
					strGetHtml = strRedHtml;
				} //if
				//出力フォルダ作成
				strFileOutDir=strBasePath+strHead+strTmpTimeStamp+"split"+"/";
				Path objSrcPath = Paths.get(strBasePath);
				Path objTgtPath = Paths.get(strFileOutDir);
				Files.copy(objSrcPath, objTgtPath);

				//html群をコピー
				strHtmlDir=strBasePath+strFileWithoutExtension+"/";
				File objHtmlPath = new File(strHtmlDir);
				File objTgtHtmlPath = new File(strFileOutDir+strFileWithoutExtension);
				FileUtils.copyDirectory(objHtmlPath, objTgtHtmlPath);

//				String strOutPath = strFileOutDir+strHead+ (i + 1) + ".html";
				String strOutPath = strFileOutDir+strHead+ ".html";
				objFile = new FileWriter(strOutPath);
				objPw = new PrintWriter(new BufferedWriter(objFile));
				objPw.println(strGetHtml);
				objPw.close();


//				//動的templateを作成
//				String strOutHtml = "";
//				strOutHtml+="<!DOCTYPE html> <html> <head> <meta http-equiv='Content-Type' content='text/html; charset=utf-8' /> <title>";
//				strOutHtml+=strFileWithoutExtension;
//				strOutHtml+="</title> <link rel='stylesheet' type='text/css' href='";
//				strOutHtml+=strFileWithoutExtension;
//				strOutHtml+="/styles.css' media='all' /> ";
//				strOutHtml+=" <link rel='stylesheet' type='text/css' href='";
//				strOutHtml+=strFileWithoutExtension;
//				strOutHtml+="/mask.css' media='all' /> </head> <body>";

				//PDF作成処理
//				if(strHead.equals("mask_")) {
//					strGetHtml = strMaskHtml_i;
//				}else {
//					strGetHtml = strRedHtml_i;
//				} //if


//				objDoc = Jsoup.parse(strGetHtml);
//				Elements elmCls= objDoc.getElementsByClass(PAGE_CLASS);

//				for (int i = 0; i < elmCls.size(); i++) {
//					Element elmTgt = elmCls.get(i);
//					String strGetOuterHtml = elmTgt.outerHtml();
//					String strOutPath = strFileOutDir+strHead+ (i + 1) + ".html";
//					//html out
//					String strRepHtml=strOutHtml;
//					strRepHtml+=strGetOuterHtml;
//					strRepHtml+="</body> </html>";
//
//
////					objFile = new FileWriter(strOutPath);
////					objPw = new PrintWriter(new BufferedWriter(objFile));
////					objPw.println(strRepHtml);
////					objPw.close();
//
////					//pdfout
////					String strOutPdfPath = strFileOutDir+strHead+ (i + 1) + ".pdf";
////					String strChkHtml = objPdfCls.convertHtmlToPdf(strRepHtml,strFileOutDir,strOutPdfPath);
////					objLog.info(strHead.substring(0,strHead.length()-1) + (i + 1) +"枚目pdf出力完了");
//
//				} //for

				//クライアントにわたす情報格納
//				intPages = elmCls.size();
//				strRelativePath="/"+strTmpDir_i+strHead+"split"+"/"+strHead;
//				objLog.info(strHead.substring(0,strHead.length()-1)+ "のpdf出力すべて完了");


			} catch (IOException e) {
				// TODO 自動生成された catch ブロック
				e.printStackTrace();
			} //try

		} //for

//		model.addAttribute("strTmpDir", strTmpDir_i); //親作業directory
//		model.addAttribute("strFileName", strFileName_i); //オリジナルファイルネーム
//		model.addAttribute("strTmpTimeStamp", strTmpTimeStamp); //今回の作業derectory
//		model.addAttribute("intPages",  String.valueOf(intPages)); //PDFページ数




	return "";
} //getView1


} //MaskHtmlCnt
