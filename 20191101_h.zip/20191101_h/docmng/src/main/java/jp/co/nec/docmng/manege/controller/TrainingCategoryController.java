package jp.co.nec.docmng.manege.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import jp.co.nec.docmng.manege.entity.CategoryInfo;
import jp.co.nec.docmng.manege.entity.TmpTeacherCategoryList;
import jp.co.nec.docmng.manege.service.CategoryInfoService;
import jp.co.nec.docmng.manege.service.TmpTeacherCategoryService;

@Controller
@RequestMapping("/manege/training_category")
public class TrainingCategoryController {

    @Autowired
    CategoryInfoService categoryInfoService;

    @Autowired
    TmpTeacherCategoryService tmpTeacherCategoryService;

    @GetMapping
    public String getTrainingCategory(Model model) {
        // 全件取得
        List<CategoryInfo> categoryInfos = categoryInfoService.findAll();
        model.addAttribute("categoryInfo", categoryInfos);

        List<TmpTeacherCategoryList> teacherCategoryLists = tmpTeacherCategoryService.findAll();
        model.addAttribute("teacherCategoryList", teacherCategoryLists);



//        model.addAttribute("");

        return "manege/training_category";
    }

}
