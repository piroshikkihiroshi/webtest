package jp.co.nec.docmng.manege.controller;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.thymeleaf.util.StringUtils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.manege.entity.SearchServerInfoEntity;
import jp.co.nec.docmng.manege.entity.SearchServerInfoForm;
import jp.co.nec.docmng.manege.service.SearchServerInfoService;

@Controller
@RequestMapping("/manege/search_server")
public class SearchServerInfoController {

    /**
     * 実行batファイルパス
     */
    private static final String BAT_FILE_PATH = "src/main/resources/netuse.bat";

    //TODO 設定反映ステータスと認証ステータスを同じ文字列で渡してしまっているが変えたほうが良い？
    /**
     * 設定反映ステータス：成功
     */
    private static final String SUCCESS = "success";

    /**
     * 設定反映ステータス：失敗
     */
    private static final String FAILURE = "failure";

    /**
     * 設定反映ステータス格納用変数
     */
    private String saveStatus = null;

    @Autowired
    private SearchServerInfoService searchServerInfoService;

    /**
     * <p>検索対象サーバ設定画面GET処理</p>
     * 処理内容：<br>
     * <ol>
     *   <li>検索対象サーバ設定画面をGETする</li>
     * </ol>
     * @param form 検索対象追加用フォーム
     * @param model モデル
     * @return 検索対象サーバ設定画面のURL
     */
    @GetMapping
    public String getSearchServerInfo(@ModelAttribute("searchServerInfoForm") SearchServerInfoForm form, Model model) {

        // 全件取得する
        List<SearchServerInfoEntity> searchServerInfoList = searchServerInfoService.findAll();
        model.addAttribute("serchServerInfo", searchServerInfoList);

        //TODO 設定反映失敗時のアラート、エラー番号を出力する予定
        if (StringUtils.equals(saveStatus, SUCCESS)) {
            model.addAttribute("saveStatus", SUCCESS);
        } else if (StringUtils.equals(saveStatus, FAILURE)) {
            model.addAttribute("saveStatus", FAILURE);
        }
        saveStatus = null;

        return "manege/search_server";

    }

    //TODO 例外時の処理、ログ出力
    /**
     * <p>設定反映処理</p>
     * 処理内容：<br>
     * <ol>
     *   <li>画面上で削除した項目と紐づくDBの項目を削除する</li>
     *   <li>画面上で編集した項目と紐づくDBの項目を更新する</li>
     *   <li>画面上で追加した項目と紐づくDBの項目を追加する</li>
     * </ol>
     * @param editValue 画面上で編集した項目の値
     * @param deleteRows 画面上で削除した項目のサーバID
     * @param addValue
     * @return リロード
     */
    @PostMapping(params = "save")
    public String save(@RequestParam("editValue") String editValue, @RequestParam("deleteRow") List<Integer> deleteRows,
            @RequestParam("addValue") String addValue) {

        try {

            // システム日付を取得する
            Timestamp sysdate = Timestamp.valueOf(LocalDateTime.now());

            ObjectMapper mapper = new ObjectMapper();

            // 追加項目
            // Json文字列をツリーとして扱う
            JsonNode addRoot = mapper.readTree(addValue);

            Iterator<String> addFieldNames = addRoot.fieldNames();

            while (addFieldNames.hasNext()) {
                // キー取得
                String fieldName = addFieldNames.next();

                JsonNode jn = addRoot.get(fieldName);

                // 取得したオブジェクトをエンティティにマッピングする
                SearchServerInfoEntity addServerInfo = mapper.readValue(jn.toString(), SearchServerInfoEntity.class);
                // システム日付を設定する
                addServerInfo.setCreateTime(sysdate);

                searchServerInfoService.insert(addServerInfo);

            }

            // 編集項目
            // Json文字列をツリーとして扱う
            JsonNode editRoot = mapper.readTree(editValue);

            Iterator<String> editFieldNames = editRoot.fieldNames();

            while (editFieldNames.hasNext()) {

                // キーを取得する
                String fieldName = editFieldNames.next();

                JsonNode jn = editRoot.get(fieldName);

                // 取得したオブジェクトをエンティティにマッピングする
                SearchServerInfoEntity editServerInfo = mapper.readValue(jn.toString(), SearchServerInfoEntity.class);
                // キーを設定
                editServerInfo.setServerId(Integer.valueOf(fieldName));
                // システム日付を設定する
                editServerInfo.setUpdateTime(sysdate);

                searchServerInfoService.update(editServerInfo);
            }

            // 削除項目
            if (!CollectionUtils.isEmpty(deleteRows)) {

                for (int i = 0; i < deleteRows.size(); i++) {
                    searchServerInfoService.deleteById(deleteRows.get(i));
                }
            }

            saveStatus = SUCCESS;

        } catch (Exception e) {
            e.printStackTrace();

            //TODO エラーログ出力

            saveStatus = FAILURE;

        }
        return "redirect:search_server";

    }

    @PostMapping
    @ResponseBody
    public String auth(@RequestBody SearchServerInfoForm form) throws Exception {

        String userName = form.getLoginUserName();
        String password = form.getLoginPassword();
        String directoryPath = form.getDirectoryPath();

        // コマンド実行用batファイル作成
        FileWriter fw = new FileWriter(BAT_FILE_PATH, false);
        PrintWriter pw = new PrintWriter(new BufferedWriter(fw));
        pw.println("@echo off");
        // 下記を記載すればコマンドプロンプトがUTF-8に設定されるが、出力が英語になってしまうため、標準出力読み込み時にShift-JISを指定して読み込む対応とする
        // pw.println("chcp 65001");

        // ユーザー名がない場合
        if (StringUtils.isEmpty(userName)) {
            pw.println("net use " + directoryPath);
            // ユーザー名はあるがパスワードがない場合
        } else if (StringUtils.isEmpty(password)) {
            pw.println("net use " + directoryPath + " /user:" + userName);
            // ユーザー名とパスワード両方ある場合
        } else {
            pw.println("net use " + directoryPath + " /user:" + userName + " " + password);
        }

        // 認証に成功した場合に接続を削除するコマンド
        pw.println("if %errorlevel% equ 0 ( net use " + form.getDirectoryPath()
                + " /delete /no ) else ( exit /b %errorlevel% )");
        // ファイルを出力する
        pw.close();

        // コマンド実行
        ProcessBuilder pb = new ProcessBuilder(BAT_FILE_PATH);
        pb.redirectErrorStream(true);
        Process runtimeProcess = pb.start();

        InputStream is = runtimeProcess.getInputStream();
        // コマンドプロンプトのデフォルト文字コードがShift-JISなので
        BufferedReader br = new BufferedReader(new InputStreamReader(is, "Shift-JIS"));

        String firstLine = null;
        String line;
        int count = 0;
        while ((line = br.readLine()) != null) {
            // コマンド実行のログ出力
            System.out.println(line);

            // 一行目を取得する
            if(count == 0) {
                firstLine = line;
            }
            count++;
        }

        // プロセス値を取得する
        int exitValue = runtimeProcess.waitFor();

        String authStr = null;
        // 認証成功時
        if (exitValue == 0) {
            authStr = "success";
            // 認証失敗時
        } else {

            //TODO 未実装：標準エラー出力のエラーコードに応じて戻り値を設定する
            // 画面側で受け取った値に応じてalert出力
            if(StringUtils.contains(firstLine, "システム エラー 86")) {
                authStr = "86";
            }else if(StringUtils.contains(firstLine, "システム エラー 1219")) {
                authStr = "1219";
            }else{
                authStr = "failure";
            }
        }

        // batファイルを削除する
        File file = new File(BAT_FILE_PATH);
        file.delete();

        ObjectMapper mapper = new ObjectMapper();
        String ret = mapper.writeValueAsString(authStr);

        return ret;
    }

}
