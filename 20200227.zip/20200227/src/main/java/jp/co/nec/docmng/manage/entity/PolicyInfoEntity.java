/**
 * 名称：PolicyInfoEntity.java
 * 機能名：管理系黒塗りポリシー設定情報entity
 * 概要：管理系で使用する黒塗りポリシー設定情報entity
 */

package jp.co.nec.docmng.manage.entity;

import java.sql.Timestamp;
import lombok.Data;

/**
 * 管理系黒塗りポリシー設定情報entity
 */
@Data
public class PolicyInfoEntity {

	/**
	 * ポリシーID
	 */
    private Integer policyId;

	/**
	 * 表示順位
	 */
    private Integer policyNumber;

	/**
	 * 黒塗りポリシー名
	 */
    private String policyName;

	/**
	 * 黒塗りポリシー作成者
	 */
    private String policyAuthor;

	/**
	 * 黒塗り対処理由
	 */
    private String policyReason;

	/**
	 * 作成日時
	 */
    private Timestamp createTime;

	/**
	 * 更新日時
	 */
    private Timestamp updateTime;

	/**
	 * 表示・非表示切替用フラグ
	 */
    private Boolean viewFlag = true;

}
