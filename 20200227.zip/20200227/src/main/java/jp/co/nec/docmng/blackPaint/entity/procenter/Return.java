/**
 * 名称：Return.java
 * 機能名：PROCENTER Return管理
 * 機能:PROCENTERのReturn管理
 */

package jp.co.nec.docmng.blackPaint.entity.procenter;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * PROCENTER Return管理
 */
public class Return {

	/**
	 * セッションID
	 */
	private String sessionID;

	/**
	 * ユーザID
	 */
	private String userID;

	/**
	 * ロケール
	 */
	private String locale;

	/**
	 * クライアントコード
	 */
	private String clientCode;

	/**
	 * サーバエイジェント
	 */
	private String serverAddress;

	/**
	 * ユーザエイジェント
	 */
	private String userAgent;

	/**
	 * sessionID getter
	 * @return sessionID
	 */
	@JsonProperty("sessionId")
	public String getSessionID() {
		return sessionID;
	}
	/**
	 * sessionID setter
	 * @param value
	 */
	@JsonProperty("sessionId")
	public void setSessionID(String value) {
		this.sessionID = value;
	}

	/**
	 * userID getter
	 * @return userID
	 */
	@JsonProperty("userId")
	public String getUserID() {
		return userID;
	}
	/**
	 * userID setter
	 * @param value
	 */
	@JsonProperty("userId")
	public void setUserID(String value) {
		this.userID = value;
	}

	/**
	 * locale getter
	 * @return locale
	 */
	@JsonProperty("locale")
	public String getLocale() {
		return locale;
	}
	/**
	 * locale setter
	 * @param value
	 */
	@JsonProperty("locale")
	public void setLocale(String value) {
		this.locale = value;
	}

	/**
	 * clientCode getter
	 * @return clientCode
	 */
	@JsonProperty("clientCode")
	public String getClientCode() {
		return clientCode;
	}
	/**
	 * clientCode setter
	 * @param value
	 */
	@JsonProperty("clientCode")
	public void setClientCode(String value) {
		this.clientCode = value;
	}

	/**
	 * serverAddress getter
	 * @return serverAddress
	 */
	@JsonProperty("serverAddress")
	public String getServerAddress() {
		return serverAddress;
	}
	/**
	 * serverAddress setter
	 * @param value
	 */
	@JsonProperty("serverAddress")
	public void setServerAddress(String value) {
		this.serverAddress = value;
	}

	/**
	 * userAgent getter
	 * @return userAgent
	 */
	@JsonProperty("userAgent")
	public String getUserAgent() {
		return userAgent;
	}
	/**
	 * userAgent setter
	 * @param value
	 */
	@JsonProperty("userAgent")
	public void setUserAgent(String value) {
		this.userAgent = value;
	}
}
