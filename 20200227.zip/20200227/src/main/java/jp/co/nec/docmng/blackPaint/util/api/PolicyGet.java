/**
 * 名称：PolicyGet.java
 * 機能名：ポリシーテーブルデータ取得
 * 概要：ポリシーテーブル一覧をjsonで取得する
 */

package jp.co.nec.docmng.blackPaint.util.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.nec.docmng.blackPaint.entity.PolicyInfoEntBlackPaint;
import jp.co.nec.docmng.blackPaint.repository.PolicyInfoMapPaint;

/**
 * ポリシーテーブルデータ取得
 */
@RestController
public class PolicyGet {

	@Autowired
	PolicyInfoMapPaint objPolicyInfoService;

	/**
	 * ポリシーテーブル一覧をjsonで取得する
	 * @return String ポリシーテーブル全件
	 */
	@GetMapping("/rest/policy/all")
	public String getPolicyAll(){
		String strRet = "";
		List<PolicyInfoEntBlackPaint> listPolicy = objPolicyInfoService.findAll();

        ObjectMapper objMapper = new ObjectMapper();
        try {
        	strRet = objMapper.writeValueAsString(listPolicy);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return strRet;
	} //getPlicyAll

} //PolicyGet
